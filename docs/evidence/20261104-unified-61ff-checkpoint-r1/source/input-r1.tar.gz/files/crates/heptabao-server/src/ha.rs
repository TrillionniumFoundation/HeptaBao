#[path = "ha_legacy_upgrade.rs"]
mod legacy_upgrade;
pub(crate) use legacy_upgrade::LegacyCommitError;
use std::collections::{BTreeMap, BTreeSet};
use std::fmt;
use std::fs::{self, OpenOptions};
use std::io::{BufReader, Read, Seek, SeekFrom, Write};
use std::net::{SocketAddr, TcpListener};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::thread::{self, JoinHandle};
use std::time::{Duration, Instant};

use base64::{Engine as _, engine::general_purpose::STANDARD};
use futures::future::BoxFuture;
use heptabao_ha_service::{
    MutualTlsPeerTransport, NodeId, PinnedClientCertificateMap, RAFT_ALPN_PROTOCOL,
    TlsPeerEndpoint, serve_one_mtls_authenticated_peer_frame,
};
use heptabao_raft_runtime::{
    CommitReceipt, MembershipObservation, ProcessRaftNode, RaftPeerRpc, RaftRpcKind,
    RemoteNetworkFactory, RemoteRaftError, ReplicatedEnvelope,
};
use ring::digest;
use rustls::pki_types::{CertificateDer, PrivateKeyDer};
use rustls::server::WebPkiClientVerifier;
use rustls::{ClientConfig, RootCertStore, ServerConfig};
use serde::Deserialize;
use tokio::runtime::{Builder as RuntimeBuilder, Runtime};
use tokio::sync::Semaphore;
use zeroize::Zeroizing;

use crate::{
    Response,
    ha_forward::{
        ForwardRequest, decode_legacy_response_for_transition,
        decode_request_for_cluster_compatible as decode_forward_request,
        encode_legacy_request_for_transition, encode_legacy_response_for_transition,
        encode_response_for_cluster as encode_forward_response, is_forward_request,
    },
    ha_state::{
        ClusterStateCodec, CommittedStateDescriptor, MAX_REPLICATED_STATE_CHUNKS,
        REPLICATED_STATE_CHUNK_BYTES, ReplicatedChunkRef, ReplicatedStateManifest,
    },
    service::OwnerPublicationBinding,
};

#[path = "ha_record_runtime.rs"]
mod records;
pub(crate) use records::{CommittedRecordState, RecordPublicationPreflightError};

#[cfg(feature = "native-v6-ha")]
#[path = "ha_native_v6_runtime.rs"]
mod native_v6_runtime;
#[cfg(feature = "native-v6-ha")]
pub(crate) use native_v6_runtime::{
    CommittedNativeV6Read, NativeHaCommittedIntentRetirement, NativeHaIntentReadObservation,
    NativeHaPreparedIntentRetirement, NativeHaPublicationError, NativeV6ArchiveRootAnchor,
    NativeV6FailureObservation, NativeV6IngressRead, NativeV6IngressSuperseded,
    NativeV6RequestObservation, NativeV6TimingSpan,
};

#[cfg(feature = "native-v6-ha")]
#[path = "ha_snapshot_clock.rs"]
pub(crate) mod snapshot_clock;

// Timing only: every caller's original operation is evaluated exactly once.
// With no native request observation this wrapper retains no data or output.
pub(crate) fn observe_native_v6_timing<T, E>(
    scope: &'static str,
    phase: &'static str,
    original_until: Option<Instant>,
    operation: impl FnOnce() -> Result<T, E>,
) -> Result<T, E> {
    #[cfg(feature = "native-v6-ha")]
    let timing = NativeV6TimingSpan::start(scope, phase, original_until);
    #[cfg(not(feature = "native-v6-ha"))]
    let _ = (scope, phase, original_until);
    let result = operation();
    #[cfg(feature = "native-v6-ha")]
    if let Some(timing) = timing {
        timing.finish(result.is_ok());
    }
    result
}

#[cfg(feature = "native-v6-ha")]
#[path = "ha_native_v6_backup.rs"]
pub(crate) mod native_v6_backup;

const RAFT_FRAME_MAGIC: &[u8; 5] = b"HBRT1";
const RAFT_FRAME_REQUEST: u8 = 1;
const RAFT_FRAME_RESPONSE: u8 = 2;
const RAFT_FRAME_HEADER_BYTES: usize = 29;
const LEGACY_RAFT_FRAME_HEADER_BYTES: usize = 27;
const MAX_CLUSTER_ID_BYTES: usize = 128;
const MAX_RAFT_FRAME_BYTES: usize = 896 * 1024;
const MAX_TLS_FILE_BYTES: usize = 1024 * 1024;
const REPLICATION_KEY_BYTES: usize = 32;
const REPLICATED_CHUNK_MIN_BYTES: usize = 192 * 1024;
const REPLICATED_CHUNK_WINDOW_BYTES: usize = 64;
const REPLICATED_CHUNK_MASK: u64 = (1_u64 << 18) - 1;
const BOOTSTRAP_MARKER_LEAF: &str = ".heptabao-bootstrap-v1";
const BOOTSTRAP_MARKER_MAGIC: &[u8] = b"HBBT1\0";
const BOOTSTRAP_COMPLETE_SUFFIX: &[u8] = b"complete\n";
const MAX_BOOTSTRAP_MARKER_BYTES: usize = 64;

type MutualTlsConfigs = (Arc<ClientConfig>, Arc<ServerConfig>, [u8; 32]);
pub(crate) type ForwardHandler = Arc<dyn Fn(ForwardRequest) -> Response + Send + Sync>;

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HaPeerConfig {
    pub node_name: String,
    pub address: SocketAddr,
    /// Deployment-advertised HTTPS API origin; never inferred from the Raft socket.
    #[serde(default)]
    pub api_address: Option<String>,
    /// Deployment-advertised native mTLS request-forwarding origin. This is
    /// separate from the public API and is never inferred from a Raft socket.
    #[serde(default)]
    pub cluster_address: Option<String>,
    pub server_name: String,
    pub certificate_sha256: String,
    /// Optional overlap pin for bounded leaf-certificate rotation. During a
    /// rollout peers accept either digest for the same enrolled node identity;
    /// remove the old pin after every node has moved to the new certificate.
    #[serde(default)]
    pub certificate_sha256_next: Option<String>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HaProcessConfig {
    pub node_id: u64,
    pub cluster_id: String,
    pub raft_dir: PathBuf,
    pub listen: SocketAddr,
    pub ca_file: PathBuf,
    pub cert_file: PathBuf,
    pub key_file: PathBuf,
    pub replication_key_file: PathBuf,
    pub peers: BTreeMap<u64, HaPeerConfig>,
    #[serde(default)]
    pub bootstrap: bool,
    /// Initial voters may be a subset of the statically enrolled peer registry.
    #[serde(default)]
    pub initial_voters: Option<BTreeSet<u64>>,
    #[serde(default = "default_peer_timeout_ms")]
    pub peer_timeout_ms: u64,
    #[serde(default = "default_forward_timeout_ms")]
    pub forward_timeout_ms: u64,
    #[serde(default = "default_max_inflight")]
    pub max_inflight: usize,
    /// Explicit, temporary one-step rolling compatibility for the pre-cluster-
    /// bound HBFQ1/HBFS1 forwarding wire and the pre-cluster-bound HBRT1
    /// consensus wire. Defaults closed and is refused for a fresh Raft state.
    #[serde(default)]
    pub allow_legacy_peer_v1: bool,
    /// Omission preserves the old bridge's outbound behavior. After every
    /// voter is upgraded, set false on all nodes while receivers stay dual-
    /// format; only then retire allow_legacy_peer_v1 by rolling restart.
    #[serde(default)]
    pub emit_legacy_peer_v1: Option<bool>,
}

impl HaProcessConfig {
    fn outbound_legacy_peer_v1(&self) -> bool {
        self.emit_legacy_peer_v1
            .unwrap_or(self.allow_legacy_peer_v1)
    }

    /// Pure admission before any durable directory or listener is created.
    /// The real TLS leaf and committed enrollment are still checked at startup
    /// and on every native operation; configuration is never a quorum proof.
    pub(crate) fn validate_native_v6_storage(&self) -> Result<(), String> {
        validate_config(self)?;
        let peers = parse_peers(self)?;
        if self.allow_legacy_peer_v1
            || self.outbound_legacy_peer_v1()
            || peers
                .iter()
                .any(|peer| peer.certificate_sha256_next.is_some())
        {
            return Err("native V6 storage requires strict enrolled peer identities without a legacy or overlapping-pin transition".into());
        }
        Ok(())
    }
}

fn default_peer_timeout_ms() -> u64 {
    750
}

fn default_forward_timeout_ms() -> u64 {
    15_000
}

fn default_max_inflight() -> usize {
    64
}

#[path = "ha_peer_budget.rs"]
mod peer_budget;
use peer_budget::PeerWorkerBudget;

#[cfg(feature = "native-v6-ha")]
#[path = "ha_native_v6_peer_capacity.rs"]
mod native_v6_peer_capacity;

struct ParsedPeer {
    id: u64,
    node: NodeId,
    endpoint: TlsPeerEndpoint,
    certificate_sha256: [u8; 32],
    certificate_sha256_next: Option<[u8; 32]>,
    api_address: Option<String>,
    cluster_address: Option<String>,
}

#[derive(Clone)]
struct MutualTlsRaftRpc {
    local_id: u64,
    cluster_id: String,
    peers: Arc<BTreeMap<u64, NodeId>>,
    transport: MutualTlsPeerTransport,
    inflight: Arc<Semaphore>,
    emit_legacy_peer_v1: bool,
}

impl fmt::Debug for MutualTlsRaftRpc {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("MutualTlsRaftRpc")
            .field("local_id", &self.local_id)
            .field("cluster_id", &self.cluster_id)
            .field("peers", &self.peers.keys().collect::<Vec<_>>())
            .field("transport", &"[MUTUAL_TLS]")
            .field("emit_legacy_peer_v1", &self.emit_legacy_peer_v1)
            .finish()
    }
}

impl RaftPeerRpc for MutualTlsRaftRpc {
    fn exchange(
        &self,
        source: u64,
        target: u64,
        kind: RaftRpcKind,
        payload: Vec<u8>,
        timeout: Duration,
    ) -> BoxFuture<'static, Result<Vec<u8>, RemoteRaftError>> {
        // Capture the caller's budget before this future can wait to be polled.
        // Admission, blocking-pool queueing and every socket operation share it.
        let deadline = Instant::now().checked_add(timeout);
        let local_id = self.local_id;
        let cluster_id = self.cluster_id.clone();
        let target_node = self.peers.get(&target).cloned();
        let transport = self.transport.clone();
        let inflight = self.inflight.clone();
        // ReadIndex did not exist in legacy peer frames. Its authority witness
        // always carries the authenticated current cluster binding.
        let emit_legacy_peer_v1 = self.emit_legacy_peer_v1 && kind != RaftRpcKind::ReadIndex;
        Box::pin(async move {
            if source != local_id || source == target || timeout.is_zero() {
                return Err(RemoteRaftError::InvalidRpc);
            }
            let target_node = target_node.ok_or(RemoteRaftError::InvalidTopology)?;
            let deadline = deadline.ok_or(RemoteRaftError::InvalidRpc)?;
            if Instant::now() >= deadline {
                return Err(RemoteRaftError::Transport("peer RPC timed out".into()));
            }
            let request_frame = RaftWireFrame {
                cluster_id: cluster_id.clone(),
                role: RAFT_FRAME_REQUEST,
                source,
                target,
                kind,
                payload,
                legacy_v1: emit_legacy_peer_v1,
            };
            let request = if emit_legacy_peer_v1 {
                encode_legacy_raft_frame_for_transition(request_frame)?
            } else {
                encode_raft_frame(request_frame)?
            };
            let async_deadline = tokio::time::Instant::from_std(deadline);
            let permit = tokio::time::timeout_at(async_deadline, inflight.acquire_owned())
                .await
                .map_err(|_| RemoteRaftError::Transport("peer RPC admission timed out".into()))?
                .map_err(|_| RemoteRaftError::Transport("peer RPC admission closed".into()))?;
            // A ready permit can win a timeout poll after the deadline elapsed.
            if Instant::now() >= deadline {
                return Err(RemoteRaftError::Transport(
                    "peer RPC admission timed out".into(),
                ));
            }
            let mut work = QueuedRaftRpc(tokio::task::spawn_blocking(move || {
                // Keep capacity charged until a running exchange actually ends.
                let _permit = permit;
                transport
                    .exchange_before(&target_node, &request, deadline)
                    .map_err(|error| RemoteRaftError::Transport(error.to_string()))
            }));
            let response = tokio::time::timeout_at(async_deadline, &mut work.0)
                .await
                .map_err(|_| RemoteRaftError::Transport("peer RPC timed out".into()))?
                .map_err(|error| RemoteRaftError::Transport(error.to_string()))??;
            if Instant::now() >= deadline {
                return Err(RemoteRaftError::Transport("peer RPC timed out".into()));
            }
            let response = decode_raft_frame_for_cluster_compatible(
                &response,
                &cluster_id,
                emit_legacy_peer_v1,
            )?;
            if response.role != RAFT_FRAME_RESPONSE
                || response.source != target
                || response.target != source
                || response.kind != kind
                || response.legacy_v1 != emit_legacy_peer_v1
            {
                return Err(RemoteRaftError::InvalidRpc);
            }
            if Instant::now() >= deadline {
                return Err(RemoteRaftError::Transport("peer RPC timed out".into()));
            }
            Ok(response.payload)
        })
    }
}

// Dropping a JoinHandle detaches its work. Abort cancels an unstarted blocking
// job instead; a job that already started retains its permit and absolute I/O
// deadline. This never retries a mutation or treats timeout as proof of no effect.
struct QueuedRaftRpc<T>(tokio::task::JoinHandle<T>);

impl<T> Drop for QueuedRaftRpc<T> {
    fn drop(&mut self) {
        self.0.abort();
    }
}

#[derive(Debug)]
struct RaftWireFrame {
    cluster_id: String,
    role: u8,
    source: u64,
    target: u64,
    kind: RaftRpcKind,
    payload: Vec<u8>,
    legacy_v1: bool,
}

// Fixed workers bound inbound TLS memory and keep a forwarded client request
// from monopolizing the only receiver of Raft votes and append messages.
struct PeerListener {
    shutdown_supervisor: &'static peer_shutdown::PeerShutdownSupervisor,
    shutdown_receipt: Arc<peer_shutdown::PeerNodeShutdownReceipt>,
    stop: Arc<AtomicBool>,
    workers: Vec<JoinHandle<()>>,
    #[cfg(all(
        feature = "native-v6-ha",
        any(test, feature = "experimental-native-v6-ha")
    ))]
    native_capacity_installed: bool,
}

impl PeerListener {
    fn owns_current_worker(&self) -> bool {
        let current = thread::current().id();
        self.workers
            .iter()
            .any(|worker| worker.thread().id() == current)
    }

    fn stop_and_join(&mut self) -> peer_shutdown::WorkerJoinSummary {
        self.stop.store(true, Ordering::Release);
        let mut summary = peer_shutdown::WorkerJoinSummary::default();
        for worker in self.workers.drain(..) {
            summary.joined += 1;
            if worker.join().is_err() {
                summary.panicked += 1;
            }
        }
        if summary.panicked != 0 {
            let _ = writeln!(
                std::io::stderr().lock(),
                "HBHA-PEER-SHUTDOWN worker_panics={} joined={}",
                summary.panicked,
                summary.joined
            );
        }
        summary
    }
}

impl Drop for PeerListener {
    fn drop(&mut self) {
        // HaProcess moves a self-owned listener and all runtime dependencies to
        // its pre-started supervisor before this destructor can run on a peer.
        // Ordinary startup failures and external owners still join in place.
        let _ = self.stop_and_join();
    }
}

#[path = "ha_peer_shutdown.rs"]
mod peer_shutdown;

/// Opaque evidence issued only after complete chunk authentication and hashing.
/// It is process-local, contains no plaintext state and is never serialized.
#[derive(Clone)]
pub(crate) struct ValidatedReadCursor {
    records_v5: bool,
    generation: u64,
    envelope_identity: [u8; 32],
}

pub(crate) enum CommittedStateRead {
    Absent,
    Unchanged,
    Materialized(CommittedApplicationState),
    Records(Box<CommittedRecordState>),
}

pub(crate) struct CommittedApplicationState {
    pub digest: [u8; 32],
    pub bytes: Zeroizing<Vec<u8>>,
    /// True only for the pre-manifest HBSR1 whole-state envelope.  HBSM2-
    /// HBSM4 are all manifest-backed, even when older manifests do not carry
    /// owner publication metadata, so callers must not infer this from the
    /// optional owner fields.
    pub legacy_whole_state: bool,
    pub read_cursor: Option<ValidatedReadCursor>,
    pub owner_manifest_digest: Option<[u8; 32]>,
    pub changed_owner_mask: Option<u8>,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum BootstrapMarkerState {
    Pending,
    Complete,
}

#[derive(Debug)]
struct BootstrapAdmission {
    path: PathBuf,
    binding: [u8; 32],
}

impl BootstrapAdmission {
    fn binding(cluster_id: &str, voters: &BTreeSet<u64>) -> [u8; 32] {
        let mut context = digest::Context::new(&digest::SHA256);
        context.update(b"heptabao-bootstrap-admission-v1\0");
        context.update(&(cluster_id.len() as u64).to_be_bytes());
        context.update(cluster_id.as_bytes());
        context.update(&(voters.len() as u64).to_be_bytes());
        for voter in voters {
            context.update(&voter.to_be_bytes());
        }
        let mut binding = [0_u8; 32];
        binding.copy_from_slice(context.finish().as_ref());
        binding
    }

    fn marker_path(raft_dir: &Path) -> Result<PathBuf, String> {
        if !raft_dir.is_absolute() {
            return Err("HA raft directory for bootstrap marker must be absolute".into());
        }
        Ok(raft_dir.join(BOOTSTRAP_MARKER_LEAF))
    }

    fn pending_bytes(&self) -> Vec<u8> {
        let mut bytes = Vec::with_capacity(BOOTSTRAP_MARKER_MAGIC.len() + self.binding.len());
        bytes.extend_from_slice(BOOTSTRAP_MARKER_MAGIC);
        bytes.extend_from_slice(&self.binding);
        bytes
    }

    fn parse_state(&self, bytes: &[u8]) -> Result<BootstrapMarkerState, String> {
        let pending = self.pending_bytes();
        if !bytes.starts_with(&pending) {
            return Err("HA bootstrap admission marker binding is invalid".into());
        }
        let suffix = &bytes[pending.len()..];
        if suffix == BOOTSTRAP_COMPLETE_SUFFIX {
            return Ok(BootstrapMarkerState::Complete);
        }
        if BOOTSTRAP_COMPLETE_SUFFIX.starts_with(suffix) {
            // An interrupted append remains pending. Exact committed membership
            // is re-observed before completing the suffix on the next attempt.
            return Ok(BootstrapMarkerState::Pending);
        }
        Err("HA bootstrap admission marker is corrupt".into())
    }

    fn open_options(&self, write: bool, create: bool) -> OpenOptions {
        let mut options = OpenOptions::new();
        options.read(true).write(write).create_new(create);
        #[cfg(unix)]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.mode(0o600);
        }
        #[cfg(target_os = "linux")]
        {
            use std::os::unix::fs::OpenOptionsExt;
            options.custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC | libc::O_NONBLOCK);
        }
        options
    }

    fn validate_file(file: &fs::File) -> Result<(), String> {
        let metadata = file
            .metadata()
            .map_err(|_| "cannot inspect HA bootstrap admission marker".to_owned())?;
        if !metadata.is_file() || metadata.len() > MAX_BOOTSTRAP_MARKER_BYTES as u64 {
            return Err("HA bootstrap admission marker must be a bounded regular file".into());
        }
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            if metadata.permissions().mode() & 0o077 != 0 {
                return Err("HA bootstrap admission marker must be owner only".into());
            }
        }
        Ok(())
    }

    fn read_from(&self, file: &mut fs::File) -> Result<Vec<u8>, String> {
        Self::validate_file(file)?;
        file.seek(SeekFrom::Start(0))
            .map_err(|_| "cannot seek HA bootstrap admission marker".to_owned())?;
        let mut bytes = Vec::new();
        file.take(MAX_BOOTSTRAP_MARKER_BYTES as u64 + 1)
            .read_to_end(&mut bytes)
            .map_err(|_| "cannot read HA bootstrap admission marker".to_owned())?;
        if bytes.len() > MAX_BOOTSTRAP_MARKER_BYTES {
            return Err("HA bootstrap admission marker exceeds its bound".into());
        }
        Ok(bytes)
    }

    fn sync_parent(&self) -> Result<(), String> {
        let parent = self
            .path
            .parent()
            .ok_or_else(|| "HA bootstrap admission marker parent is unavailable".to_owned())?;
        fs::File::open(parent)
            .and_then(|directory| directory.sync_all())
            .map_err(|_| "HA bootstrap admission directory sync failed".to_owned())
    }

    fn load(
        raft_dir: &Path,
        cluster_id: &str,
        voters: &BTreeSet<u64>,
    ) -> Result<Option<(Self, BootstrapMarkerState)>, String> {
        let admission = Self {
            path: Self::marker_path(raft_dir)?,
            binding: Self::binding(cluster_id, voters),
        };
        let mut file = match admission.open_options(false, false).open(&admission.path) {
            Ok(file) => file,
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => {
                return Ok(None);
            }
            Err(_) => {
                return Err("cannot open HA bootstrap admission marker".into());
            }
        };
        let bytes = admission.read_from(&mut file)?;
        let state = admission.parse_state(&bytes)?;
        Ok(Some((admission, state)))
    }

    fn create_pending(
        raft_dir: &Path,
        cluster_id: &str,
        voters: &BTreeSet<u64>,
    ) -> Result<Self, String> {
        let admission = Self {
            path: Self::marker_path(raft_dir)?,
            binding: Self::binding(cluster_id, voters),
        };
        let mut file = admission
            .open_options(true, true)
            .open(&admission.path)
            .map_err(|_| "cannot create HA bootstrap admission marker".to_owned())?;
        file.write_all(&admission.pending_bytes())
            .and_then(|()| file.sync_all())
            .map_err(|_| "cannot persist HA bootstrap admission marker".to_owned())?;
        admission.sync_parent()?;
        Ok(admission)
    }

    fn mark_complete(&self) -> Result<(), String> {
        let mut file = self
            .open_options(true, false)
            .open(&self.path)
            .map_err(|_| "cannot open HA bootstrap marker for completion".to_owned())?;
        let bytes = self.read_from(&mut file)?;
        if self.parse_state(&bytes)? == BootstrapMarkerState::Complete {
            return Ok(());
        }
        let pending = self.pending_bytes();
        file.set_len(pending.len() as u64)
            .and_then(|()| file.seek(SeekFrom::End(0)).map(|_| ()))
            .and_then(|()| file.write_all(BOOTSTRAP_COMPLETE_SUFFIX))
            .and_then(|()| file.sync_all())
            .map_err(|_| "cannot complete HA bootstrap admission marker".to_owned())?;
        self.sync_parent()
    }
}

fn prepare_bootstrap_admission(
    raft_dir: &Path,
    cluster_id: &str,
    voters: &BTreeSet<u64>,
    enrolled: &BTreeSet<u64>,
    existing: bool,
    runtime: &Runtime,
    node: &ProcessRaftNode,
) -> Result<(BootstrapAdmission, BootstrapMarkerState), String> {
    if let Some((admission, marker)) = BootstrapAdmission::load(raft_dir, cluster_id, voters)? {
        if !existing {
            return Err("HA bootstrap marker exists without prior durable Raft state".into());
        }
        let observed = runtime
            .block_on(node.membership_observation())
            .map_err(|_| "persisted HA bootstrap membership is unavailable".to_owned())?;
        if !observed.voters.is_subset(enrolled) || !observed.nodes.is_subset(enrolled) {
            return Err("persisted HA bootstrap membership contains an unenrolled node".into());
        }
        if marker == BootstrapMarkerState::Complete {
            // Reopen metrics can transiently expose empty or local-only
            // membership before the durable log is replayed. Historical
            // completion forbids restoring the initial set, while current
            // authority stays fenced until safe membership is observed.
            return Ok((admission, marker));
        }
        let recovered = legacy_bootstrap_marker_state(
            node.id(), voters, enrolled, &observed,
        )
        .ok_or_else(|| {
            "pending HA bootstrap marker has ambiguous committed membership; explicit operator recovery is required"
                .to_owned()
        })?;
        if recovered == BootstrapMarkerState::Complete {
            admission.mark_complete()?;
        }
        return Ok((admission, recovered));
    }
    if !existing {
        return BootstrapAdmission::create_pending(raft_dir, cluster_id, voters)
            .map(|admission| (admission, BootstrapMarkerState::Pending));
    }
    let observed = runtime
        .block_on(node.membership_observation())
        .map_err(|_| "existing HA bootstrap membership is unavailable".to_owned())?;
    let state = legacy_bootstrap_marker_state(
        node.id(), voters, enrolled, &observed,
    )
    .ok_or_else(|| {
        "existing HA bootstrap state has no marker and its membership is ambiguous; explicit operator recovery is required"
            .to_owned()
    })?;
    let admission = BootstrapAdmission::create_pending(raft_dir, cluster_id, voters)?;
    if state == BootstrapMarkerState::Complete {
        admission.mark_complete()?;
    }
    Ok((admission, state))
}

pub(crate) struct StorageBinding {
    pub(crate) directory: PathBuf,
    pub(crate) name: String,
    pub(crate) cluster_address: Option<String>,
    pub(crate) api_address: Option<String>,
}

pub struct HaProcess {
    #[cfg(feature = "native-v6-ha")]
    native_v6: Option<Arc<native_v6_runtime::NativeV6Runtime>>,
    storage_dir: PathBuf,
    record_commits_since_gc: AtomicU64,
    bootstrap_ready: AtomicBool,
    bootstrap_voters: Option<BTreeSet<u64>>,
    bootstrap_admission: Option<BootstrapAdmission>,
    bootstrap_history_complete: AtomicBool,
    bootstrap_owner: bool,
    runtime: Arc<Runtime>,
    node: Option<Arc<ProcessRaftNode>>,
    codec: ClusterStateCodec,
    cluster_id: String,
    peers: Arc<BTreeMap<u64, NodeId>>,
    api_addresses: BTreeMap<u64, String>,
    cluster_addresses: BTreeMap<u64, String>,
    forward_transport: MutualTlsPeerTransport,
    forward_timeout: Duration,
    emit_legacy_peer_v1: bool,
    forward_handler: Arc<Mutex<Option<ForwardHandler>>>,
    #[cfg(feature = "native-v6-ha")]
    snapshot_clock_handler: Arc<Mutex<Option<snapshot_clock::SnapshotClockHandler>>>,
    listener: Option<PeerListener>,
}

impl fmt::Debug for HaProcess {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("HaProcess")
            .field("cluster_id", &self.cluster_id)
            .field("running", &self.node.is_some())
            .field("listener", &self.listener.is_some())
            .finish()
    }
}

// These are duration classes, not authorization. Both retain the same actual
// inbound origin; choosing the business class cannot restart a TLS/queue budget.
pub(crate) struct InboundPeerDeadlines {
    pub(crate) read_rpc: Instant,
    pub(crate) forward_request: Instant,
}
impl InboundPeerDeadlines {
    pub(crate) fn new(started: Instant, peer: Duration, forward: Duration) -> Self {
        Self {
            read_rpc: started + peer,
            forward_request: started + forward,
        }
    }
}
#[cfg(test)]
mod inbound_deadline_tests {
    use super::*;
    #[test]
    fn inbound_deadline_classes_charge_elapsed_queue_time_without_renewal() {
        let admitted = Instant::now() - Duration::from_millis(600);
        let deadlines =
            InboundPeerDeadlines::new(admitted, Duration::from_millis(500), Duration::from_secs(5));
        assert!(Instant::now() >= deadlines.read_rpc);
        assert!(Instant::now() < deadlines.forward_request);
        assert_eq!(deadlines.read_rpc, admitted + Duration::from_millis(500));
        assert_eq!(deadlines.forward_request, admitted + Duration::from_secs(5));
        let old = Instant::now() - Duration::from_secs(6);
        let queued =
            InboundPeerDeadlines::new(old, Duration::from_millis(500), Duration::from_secs(5));
        assert!(Instant::now() >= queued.read_rpc);
        assert!(Instant::now() >= queued.forward_request);
    }
}

impl HaProcess {
    pub fn start(config: HaProcessConfig) -> Result<Self, String> {
        Self::start_inner(config, false)
    }

    /// Normal server startup binds its selected storage profile before opening
    /// the Raft owner. Native workers, self pin and ciphertext custody belong
    /// to this same process from its first accepted peer connection.
    pub fn start_with_storage(
        config: HaProcessConfig,
        server: &crate::http::Config,
    ) -> Result<Self, String> {
        crate::configuration::validate_storage(server, Some(&config))?;
        let native = matches!(
            server.storage.as_ref(),
            Some(crate::configuration::StorageConfig::NativeV6Raft { .. })
        );
        #[cfg(feature = "native-v6-storage")]
        if native {
            crate::service::Service::validate_native_v6_raft_seed(&server.data_dir)?;
        }
        Self::start_inner(config, native)
    }

    /// Install candidate native/ReadIndex workers and ciphertext custody before
    /// accepting the first peer connection. Ordinary startup remains separate.
    #[cfg(all(
        feature = "native-v6-ha",
        any(test, feature = "experimental-native-v6-ha")
    ))]
    pub fn start_native_v6_candidate(config: HaProcessConfig) -> Result<Self, String> {
        Self::start_inner(config, true)
    }

    fn start_inner(config: HaProcessConfig, native_candidate: bool) -> Result<Self, String> {
        #[cfg(not(feature = "native-v6-ha"))]
        if native_candidate {
            return Err("native HA candidate feature is unavailable".into());
        }
        validate_config(&config)?;
        // Establish the independent shutdown owner before any peer can exist.
        let shutdown_supervisor = peer_shutdown::PeerShutdownSupervisor::global()?;
        let replication_key = load_replication_key(&config.replication_key_file)?;
        let codec = ClusterStateCodec::new(config.cluster_id.clone(), replication_key)
            .map_err(|error| error.to_string())?;
        let parsed_peers = parse_peers(&config)?;
        let api_addresses = parsed_peers
            .iter()
            .filter_map(|peer| {
                peer.api_address
                    .as_ref()
                    .map(|address| (peer.id, address.clone()))
            })
            .collect();
        let cluster_addresses = parsed_peers
            .iter()
            .filter_map(|peer| {
                peer.cluster_address
                    .as_ref()
                    .map(|address| (peer.id, address.clone()))
            })
            .collect();
        let peer_ids = parsed_peers
            .iter()
            .map(|peer| peer.id)
            .collect::<BTreeSet<_>>();
        let nodes_by_id = parsed_peers
            .iter()
            .map(|peer| (peer.id, peer.node.clone()))
            .collect::<BTreeMap<_, _>>();
        let ids_by_node = parsed_peers
            .iter()
            .map(|peer| (peer.node.clone(), peer.id))
            .collect::<BTreeMap<_, _>>();
        let endpoint_map = parsed_peers
            .iter()
            .filter(|peer| peer.id != config.node_id)
            .map(|peer| (peer.node.clone(), peer.endpoint.clone()))
            .collect::<BTreeMap<_, _>>();
        let pinned = parsed_peers
            .iter()
            .filter(|peer| peer.id != config.node_id || native_candidate)
            .flat_map(|peer| {
                std::iter::once((peer.certificate_sha256, peer.node.clone())).chain(
                    peer.certificate_sha256_next
                        .map(|digest| (digest, peer.node.clone())),
                )
            })
            .collect::<BTreeMap<_, _>>();
        let timeout = Duration::from_millis(config.peer_timeout_ms);
        let (client_tls, server_tls, local_leaf_digest) = build_mutual_tls(&config)?;
        #[cfg(feature = "native-v6-ha")]
        let native_v6 = Arc::new(native_v6_runtime::NativeV6Runtime::configured(
            &config,
            client_tls.clone(),
            local_leaf_digest,
        )?);
        let local = parsed_peers
            .iter()
            .find(|peer| peer.id == config.node_id)
            .ok_or_else(|| "HA local node is missing from peer registry".to_owned())?;
        if local.certificate_sha256 != local_leaf_digest
            && local.certificate_sha256_next != Some(local_leaf_digest)
        {
            return Err("HA local certificate digest does not match peer registry".into());
        }
        let forward_timeout = Duration::from_millis(config.forward_timeout_ms);
        let forward_transport =
            MutualTlsPeerTransport::new(endpoint_map.clone(), client_tls.clone(), forward_timeout)
                .map_err(|error| error.to_string())?;
        let transport = MutualTlsPeerTransport::new(endpoint_map, client_tls, timeout)
            .map_err(|error| error.to_string())?;
        let peers = Arc::new(nodes_by_id);
        let rpc = Arc::new(MutualTlsRaftRpc {
            local_id: config.node_id,
            cluster_id: config.cluster_id.clone(),
            peers: peers.clone(),
            transport: transport.clone(),
            inflight: Arc::new(Semaphore::new(config.max_inflight)),
            emit_legacy_peer_v1: config.outbound_legacy_peer_v1(),
        });
        let network = RemoteNetworkFactory::new(config.node_id, peer_ids.clone(), rpc)
            .map_err(|error| error.to_string())?;
        let mut runtime_builder = RuntimeBuilder::new_multi_thread();
        runtime_builder.worker_threads(2).enable_time();
        #[cfg(feature = "native-v6-ha")]
        if native_candidate {
            // Owned root-pull tasks use cancellable asynchronous sockets. The
            // ordinary blocking transport retains its existing runtime setup.
            runtime_builder.enable_io();
        }
        let runtime = Arc::new(runtime_builder.build().map_err(|error| error.to_string())?);
        let existing = durable_state_exists(&config.raft_dir)?;
        if config.allow_legacy_peer_v1 && !existing {
            return Err(
                "legacy HA peer-wire transition requires existing durable Raft state".into(),
            );
        }
        let allow_legacy_peer_v1 = config.allow_legacy_peer_v1;
        let emit_legacy_peer_v1 = config.outbound_legacy_peer_v1();
        let node = if existing {
            runtime
                .block_on(ProcessRaftNode::reopen(
                    &config.raft_dir,
                    config.node_id,
                    network,
                ))
                .map_err(|error| error.to_string())?
        } else {
            runtime
                .block_on(ProcessRaftNode::create(
                    &config.raft_dir,
                    config.node_id,
                    network,
                ))
                .map_err(|error| error.to_string())?
        };
        let node = Arc::new(node);
        #[cfg(feature = "native-v6-ha")]
        if native_candidate {
            native_v6.enable()?;
        }
        let rpc_service = node.rpc_service();
        let listener = TcpListener::bind(config.listen)
            .map_err(|_| "cannot bind HA peer listener".to_owned())?;
        listener
            .set_nonblocking(true)
            .map_err(|_| "cannot configure HA peer listener".to_owned())?;
        let identities =
            PinnedClientCertificateMap::new(pinned).map_err(|error| error.to_string())?;
        let stop = Arc::new(AtomicBool::new(false));
        let listener = Arc::new(listener);
        let identities = Arc::new(identities);
        let ids_by_node = Arc::new(ids_by_node);
        let forward_handler: Arc<Mutex<Option<ForwardHandler>>> = Arc::new(Mutex::new(None));
        #[cfg(feature = "native-v6-ha")]
        let snapshot_clock_handler = Arc::new(Mutex::new(None));
        let worker_budget = PeerWorkerBudget::for_limit(config.max_inflight);
        let forward_slots = Arc::new(Semaphore::new(worker_budget.forwarding));
        #[cfg(feature = "native-v6-ha")]
        let native_capacity = native_candidate.then(|| {
            Arc::new(native_v6_peer_capacity::NativePeerCapacity::for_budget(
                &worker_budget,
            ))
        });
        #[cfg(feature = "native-v6-ha")]
        let worker_count = native_capacity
            .as_ref()
            .map_or(worker_budget.workers, |capacity| capacity.workers);
        #[cfg(not(feature = "native-v6-ha"))]
        let worker_count = worker_budget.workers;
        #[cfg(feature = "native-v6-ha")]
        let read_slots = native_capacity.as_ref().map_or_else(
            || forward_slots.clone(),
            |capacity| capacity.read_index.clone(),
        );
        #[cfg(not(feature = "native-v6-ha"))]
        let read_slots = forward_slots.clone();
        let mut listener_pool = PeerListener {
            shutdown_supervisor,
            shutdown_receipt: Arc::new(peer_shutdown::PeerNodeShutdownReceipt::default()),
            stop: stop.clone(),
            workers: Vec::new(),
            #[cfg(all(
                feature = "native-v6-ha",
                any(test, feature = "experimental-native-v6-ha")
            ))]
            native_capacity_installed: native_candidate,
        };
        let local_id = config.node_id;
        let cluster_id = config.cluster_id.clone();
        #[cfg(feature = "native-v6-ha")]
        let native_cluster_digest = codec.native_v6_cluster_digest();
        for worker_id in 0..worker_count {
            let listener_stop = stop.clone();
            let listener = listener.clone();
            let identities = identities.clone();
            let ids_by_node = ids_by_node.clone();
            let server_tls = server_tls.clone();
            let rpc_service = rpc_service.clone();
            let runtime_handle = runtime.handle().clone();
            let listener_forward_handler = forward_handler.clone();
            #[cfg(feature = "native-v6-ha")]
            let listener_snapshot_clock_handler = snapshot_clock_handler.clone();
            let forward_slots = forward_slots.clone();
            let read_slots = read_slots.clone();
            #[cfg(feature = "native-v6-ha")]
            let native_capacity = native_capacity.clone();
            let listener_cluster_id = cluster_id.clone();
            let listener_allow_legacy_peer_v1 = allow_legacy_peer_v1;
            #[cfg(feature = "native-v6-ha")]
            let listener_native_v6 = native_v6.clone();
            #[cfg(feature = "native-v6-ha")]
            let listener_native_node = node.clone();
            let worker = thread::Builder::new()
                .name(format!("heptabao-raft-peer-{local_id}-{worker_id}"))
                .spawn(move || {
                    while !listener_stop.load(Ordering::Acquire) {
                        let service = rpc_service.clone();
                        let ids = &ids_by_node;
                        let handle = &runtime_handle;
                        // One actual inbound origin charges TLS/frame/queue time.
                        // Consensus RPCs keep their peer-attempt budget; forwarding
                        // has the separately configured business-request budget.
                        #[cfg(feature = "private-ha-forward-diagnostic")]
                        let mut receiver_kind = None;
                        let result = serve_one_mtls_authenticated_peer_frame(
                            &listener,
                            server_tls.clone(),
                            &identities,
                            forward_timeout,
                            listener_allow_legacy_peer_v1,
                            |authenticated| {
                                #[cfg(feature = "private-ha-forward-diagnostic")]
                                { receiver_kind = Some("authenticated_unclassified"); }
                                #[cfg(feature = "native-v6-ha")]
                                if heptabao_ha_service::is_snapshot_clock_request(authenticated.payload()) {
                                    return snapshot_clock::handle_authenticated(
                                        authenticated,
                                        snapshot_clock::ListenerContext {
                                            cluster: &listener_cluster_id,
                                            cluster_digest: native_cluster_digest,
                                            local: local_id,
                                            ids,
                                            native_candidate,
                                            node: &listener_native_node,
                                            handler: &listener_snapshot_clock_handler,
                                            slots: &forward_slots,
                                        },
                                    );
                                }
                                #[cfg(feature = "native-v6-ha")]
                                if heptabao_ha_service::is_native_v6_closure_frame(authenticated.payload())
                                    || heptabao_ha_service::is_native_v6_root_pull_frame(authenticated.payload())
                                    || native_v6_runtime::is_native_v6_retention_admission_frame(authenticated.payload()) {
                                    #[cfg(feature = "private-ha-forward-diagnostic")]
                                    { receiver_kind = Some("native"); }
                                    // These independent native permits were installed
                                    // with real extra workers at candidate startup.
                                    // ReadIndex retains its own worker capacity too.
                                    let capacity = native_capacity.as_ref()
                                        .ok_or(heptabao_ha_service::HaError::InvalidCluster)?;
                                    let slots = if heptabao_ha_service::is_native_v6_root_pull_frame(authenticated.payload())
                                        || native_v6_runtime::is_native_v6_retention_admission_frame(authenticated.payload()) {
                                        capacity.root_pull.clone()
                                    } else {
                                        capacity.native.clone()
                                    };
                                    let _native_slot = slots.try_acquire_owned()
                                        .map_err(|_| heptabao_ha_service::HaError::WriterBusy)?;
                                    return listener_native_v6.handle_authenticated(
                                        authenticated, &listener_native_node, handle,
                                        native_cluster_digest,
                                    );
                                }
                                let (peer, frame, accepted_at) = authenticated.into_legacy_parts();
                                // Charge TLS/frame parsing and queue delay from TCP
                                // admission, never the worker's idle accept() wait.
                                let inbound_deadlines = InboundPeerDeadlines::new(
                                    accepted_at, timeout, forward_timeout,
                                );
                                let source = *ids
                                    .get(&peer)
                                    .ok_or(heptabao_ha_service::HaError::UnknownPeer)?;
                                // Self pins exist only for a native loopback
                                // fsync vote. Legacy Raft/forwarding retain the
                                // old source != target authentication boundary.
                                if source == local_id {
                                    return Err(heptabao_ha_service::HaError::PeerAuthenticationFailed);
                                }
                                if is_forward_request(&frame) {
                                    #[cfg(feature = "private-ha-forward-diagnostic")]
                                    { receiver_kind = Some("forward"); }
                                    let mut request = decode_forward_request(
                                        &frame,
                                        &listener_cluster_id,
                                        listener_allow_legacy_peer_v1,
                                    )
                                    .map_err(|_| heptabao_ha_service::HaError::InvalidFrame)?;
                                    if (request.native_index_response
                                        || request.native_original_reply_profile.is_some())
                                        && !native_candidate {
                                        return Err(heptabao_ha_service::HaError::InvalidFrame);
                                    }
                                    if Instant::now() >= inbound_deadlines.forward_request {
                                        return Err(heptabao_ha_service::HaError::Transport);
                                    }
                                    if request.source != source || request.target != local_id {
                                        return Err(
                                            heptabao_ha_service::HaError::PeerAuthenticationFailed,
                                        );
                                    }
                                    // Only the authenticated enrolled peer reaches this
                                    // data-only scope. The Service reauthenticates the
                                    // original token and binds namespace/incarnation.
                                    let _logical_data = crate::request_metadata::Scope::enter(
                                        request.logical_data.take(), &request.method,
                                        &request.path, &request.namespace, &request.body,
                                    ).map_err(|_| heptabao_ha_service::HaError::InvalidFrame)?;
                                    let legacy_v1 = request.legacy_v1;
                                    let index_response = request.index_response;
                                    let unwrap_response = request.unwrap_response;
                                    let native_index_response = request.native_index_response;
                                    let _raw_reply_ingress = crate::auth::IngressReplyScope::authenticated_forward(request.wrapped_reply_ingress, request.wrapped_reply_lexical.take());
                                    let _native_original_reply_profile = crate::ha_forward::NativeOriginalReplyScope::authenticated_forward(request.native_original_reply_profile);
                                    // Forward admission leaves independent workers for
                                    // consensus while product requests await the service writer.
                                    let _forward_slot =
                                        forward_slots.clone().try_acquire_owned().map_err(
                                            |_| heptabao_ha_service::HaError::WriterBusy,
                                        )?;
                                    let handler = listener_forward_handler
                                        .lock()
                                        .map_err(|_| heptabao_ha_service::HaError::Transport)?
                                        .clone()
                                        .ok_or(heptabao_ha_service::HaError::NotLeader)?;
                                    let acknowledgement_route = request.path.starts_with("auth/token/revoke") && matches!(request.method.as_str(),"POST"|"PUT");
                                    let completion_scope = crate::ha_forward_completion::CompletionScope::enter(
                                        request.completion_nonce, &frame, inbound_deadlines.forward_request,
                                        &listener_cluster_id, local_id, acknowledgement_route,
                                    );
                                    let step_down = request.path == "sys/step-down";
                                    crate::ha_forward_completion::diagnostic_step_down(step_down);
                                    let response = handler(request);
                                    crate::ha_forward_completion::diagnostic_response("source_final", &response);
                                    let completion = completion_scope.finish();
                                    if step_down {
                                        eprintln!("heptabao-forward-diagnostic: phase=source_step_down original_status={} completion={}", response.status, completion.is_some());
                                    }
                                    return if legacy_v1 {
                                        encode_legacy_response_for_transition(
                                            local_id,
                                            source,
                                            response.status,
                                            &response.body,
                                        )
                                    } else if unwrap_response {
                                        crate::ha_forward::encode_completed_unwrap_response_for_cluster(
                                            &listener_cluster_id,
                                            local_id,
                                            source,
                                            &response,
                                            completion,
                                        )
                                    } else if native_index_response {
                                        crate::ha_forward::encode_completed_native_index_response_for_cluster(
                                            &listener_cluster_id,
                                            local_id,
                                            source,
                                            &response,
                                            completion,
                                        )
                                    } else if index_response {
                                        crate::ha_forward::encode_completed_index_response_for_cluster(
                                            &listener_cluster_id,
                                            local_id,
                                            source,
                                            &response,
                                            completion,
                                        )
                                    } else {
                                        encode_forward_response(
                                            &listener_cluster_id,
                                            local_id,
                                            source,
                                            response.status,
                                            &response.body,
                                        )
                                    }
                                    .map_err(|_| heptabao_ha_service::HaError::InvalidFrame);
                                }
                                #[cfg(feature = "private-ha-forward-diagnostic")]
                                { receiver_kind = Some("raft"); }
                                let request = decode_raft_frame_for_cluster_compatible(
                                    &frame,
                                    &listener_cluster_id,
                                    listener_allow_legacy_peer_v1,
                                )
                                .map_err(|_| heptabao_ha_service::HaError::InvalidFrame)?;
                                if Instant::now() >= inbound_deadlines.read_rpc {
                                    return Err(heptabao_ha_service::HaError::Transport);
                                }
                                if request.role != RAFT_FRAME_REQUEST
                                    || request.source != source
                                    || request.target != local_id
                                {
                                    return Err(
                                        heptabao_ha_service::HaError::PeerAuthenticationFailed,
                                    );
                                }
                                let legacy_v1 = request.legacy_v1;
                                // Candidate native admission needs ReadIndex even
                                // when forwarding is saturated. Its independent
                                // slots have real worker capacity. Ordinary startup
                                // retains the previous shared business slots.
                                let _read_slot =
                                    if request.kind == RaftRpcKind::ReadIndex {
                                        Some(read_slots.clone().try_acquire_owned().map_err(
                                            |_| heptabao_ha_service::HaError::WriterBusy,
                                        )?)
                                    } else {
                                        None
                                    };
                                // Peer workers are ordinary OS threads. Create
                                // the Tokio timer only after entering this
                                // process's runtime, retaining the accepted
                                // frame's original absolute deadline.
                                let payload = handle.block_on(async {
                                    tokio::time::timeout_at(
                                        tokio::time::Instant::from_std(inbound_deadlines.read_rpc),
                                        heptabao_raft_runtime::with_read_index_deadline(
                                            inbound_deadlines.read_rpc,
                                            service.handle(source, request.kind, request.payload),
                                        ),
                                    ).await
                                }).map_err(|_| heptabao_ha_service::HaError::Transport)?
                                .map_err(map_remote_service_error)?;
                                if Instant::now() >= inbound_deadlines.read_rpc {
                                    return Err(heptabao_ha_service::HaError::Transport);
                                }
                                let response = RaftWireFrame {
                                    cluster_id: listener_cluster_id.clone(),
                                    role: RAFT_FRAME_RESPONSE,
                                    source: local_id,
                                    target: source,
                                    kind: request.kind,
                                    payload,
                                    legacy_v1,
                                };
                                if legacy_v1 {
                                    encode_legacy_raft_frame_for_transition(response)
                                } else {
                                    encode_raft_frame(response)
                                }
                                .map_err(|_| heptabao_ha_service::HaError::InvalidFrame)
                            },
                        );
                        if result.is_err() {
                            #[cfg(feature = "private-ha-forward-diagnostic")]
                            if let (Some(kind), Err(error)) = (receiver_kind, &result) {
                                // Only a real authenticated handler is traced.
                                // Idle nonblocking accept/WouldBlock is silent.
                                // Both kind and HaError are closed classifications.
                                eprintln!("HBHA-PRIVATE-RECEIVER phase=receiver_result kind={kind} category={error:?}");
                            }
                            thread::sleep(Duration::from_millis(2));
                        }
                    }
                })
                .map_err(|_| "cannot start bounded HA peer worker".to_owned())?;
            listener_pool.workers.push(worker);
        }

        let bootstrap_voters = config
            .initial_voters
            .clone()
            .unwrap_or_else(|| peer_ids.clone());
        let bootstrap_owner = config.bootstrap;
        let (bootstrap_admission, state) = prepare_bootstrap_admission(
            &config.raft_dir,
            &config.cluster_id,
            &bootstrap_voters,
            &peer_ids,
            existing,
            &runtime,
            &node,
        )?;
        let mut bootstrap_history_complete = state == BootstrapMarkerState::Complete;
        let bootstrap_ready = if !bootstrap_history_complete
            && bootstrap_owner
            && reconcile_bootstrap_membership(
                &runtime,
                &node,
                !existing,
                config.node_id,
                &bootstrap_voters,
            ) {
            bootstrap_admission.mark_complete()?;
            bootstrap_history_complete = true;
            true
        } else {
            false
        };
        let bootstrap_admission = Some(bootstrap_admission);
        // Explicit legacy receiver/sender transition on this actual durable
        // process reopen. Never triggered by health or a business request.
        // Failure conveys no activation: ordinary service gates still require
        // their own live quorum, current graph, actor and original clock.
        if existing && config.allow_legacy_peer_v1 && emit_legacy_peer_v1 {
            let upgrade_started = Instant::now();
            let deadline = upgrade_started + Duration::from_secs(8);
            let observed = runtime.block_on(node.campaign_for_legacy_upgrade_before(deadline));
            match observed {
                Ok(observed) => eprintln!(
                    "heptabao-ha-legacy-upgrade: outcome=current-read-index leader={:?} term={} applied={:?} elapsed_ms={}",
                    observed.leader,
                    observed.term,
                    observed.applied_index,
                    upgrade_started.elapsed().as_millis(),
                ),
                Err(_) => eprintln!(
                    "heptabao-ha-legacy-upgrade: outcome=unavailable elapsed_ms={}",
                    upgrade_started.elapsed().as_millis(),
                ),
            }
        }

        Ok(Self {
            #[cfg(feature = "native-v6-ha")]
            native_v6: Some(native_v6),
            storage_dir: config.raft_dir,
            record_commits_since_gc: AtomicU64::new(0),
            bootstrap_ready: AtomicBool::new(bootstrap_ready),
            bootstrap_voters: Some(bootstrap_voters),
            bootstrap_admission,
            bootstrap_history_complete: AtomicBool::new(bootstrap_history_complete),
            bootstrap_owner,
            runtime,
            node: Some(node),
            codec,
            cluster_id: config.cluster_id,
            peers,
            api_addresses,
            cluster_addresses,
            forward_transport,
            forward_timeout,
            emit_legacy_peer_v1,
            forward_handler,
            #[cfg(feature = "native-v6-ha")]
            snapshot_clock_handler,
            listener: Some(listener_pool),
        })
    }

    pub(crate) fn emits_legacy_peer_v1(&self) -> bool {
        self.emit_legacy_peer_v1
    }

    #[cfg(test)]
    pub(crate) fn set_legacy_peer_v1_for_test(&mut self, enabled: bool) {
        self.emit_legacy_peer_v1 = enabled;
    }

    pub(crate) fn forward_timeout(&self) -> Duration {
        self.forward_timeout
    }

    /// Bootstrap admission is separate from listener/process startup. A
    /// committed learner may still be catching up, but health observation on
    /// the current bootstrap leader continues the same bounded, immutable
    /// membership transition instead of requiring a process restart. The
    /// completion marker is persisted before authority is exposed, so later
    /// guarded topology changes do not reopen historical bootstrap on restart.
    pub(crate) fn bootstrap_ready(&self) -> bool {
        if self.bootstrap_ready.load(Ordering::Acquire) {
            return true;
        }
        let (Some(expected), Some(admission), Some(node)) = (
            self.bootstrap_voters.as_ref(),
            self.bootstrap_admission.as_ref(),
            self.node.as_ref(),
        ) else {
            return false;
        };
        let observed = match self.runtime.block_on(node.membership_observation()) {
            Ok(observed) => observed,
            Err(_) => return false,
        };
        let enrolled = self.peers.keys().copied().collect::<BTreeSet<_>>();
        if self.bootstrap_history_complete.load(Ordering::Acquire) {
            let ready = bootstrap_membership_operational(&enrolled, &observed);
            if ready {
                self.bootstrap_ready.store(true, Ordering::Release);
            }
            return ready;
        }
        let ready = match legacy_bootstrap_marker_state(node.id(), expected, &enrolled, &observed) {
            Some(BootstrapMarkerState::Complete) => true,
            Some(BootstrapMarkerState::Pending)
                if self.bootstrap_owner && observed.leader == Some(node.id()) =>
            {
                reconcile_bootstrap_membership(&self.runtime, node, false, node.id(), expected)
            }
            _ => false,
        };
        if ready && admission.mark_complete().is_ok() {
            // Publish historical completion before exposing current authority.
            // Later topology changes are observed, never rewritten as bootstrap.
            self.bootstrap_history_complete
                .store(true, Ordering::Release);
            self.bootstrap_ready.store(true, Ordering::Release);
            return true;
        }
        false
    }

    pub(crate) fn register_forward_handler(
        &mut self,
        handler: ForwardHandler,
    ) -> Result<(), String> {
        let mut slot = self
            .forward_handler
            .lock()
            .map_err(|_| "HA forward handler registry is unavailable".to_owned())?;
        if slot.is_some() {
            return Err("HA forward handler is already registered".into());
        }
        *slot = Some(handler);
        Ok(())
    }

    pub(crate) fn forward_request_completed(
        &self,
        context: crate::ha_forward::ForwardContext<'_>,
    ) -> Result<
        (
            Response,
            crate::ha_forward_completion::CompletedForwardReceipt,
        ),
        String,
    > {
        self.forward_request_exchange(context, true, None)
            .and_then(|(response, receipt)| {
                receipt
                    .map(|receipt| (response, receipt))
                    .ok_or_else(|| "HA completed-forward proof is missing".into())
            })
    }

    pub(crate) fn forward_request_completed_with_native_original_reply(
        &self,
        context: crate::ha_forward::ForwardContext<'_>,
        profile: crate::ha_forward::NativeOriginalReplyProfile,
    ) -> Result<
        (
            Response,
            crate::ha_forward_completion::CompletedForwardReceipt,
        ),
        String,
    > {
        self.forward_request_exchange(context, true, Some(profile))
            .and_then(|(response, receipt)| {
                receipt
                    .map(|receipt| (response, receipt))
                    .ok_or_else(|| "HA completed-forward proof is missing".into())
            })
    }

    pub(crate) fn wait_forward_applied(
        &self,
        receipt: &crate::ha_forward_completion::CompletedForwardReceipt,
    ) -> Result<(), String> {
        if receipt.cluster != self.cluster_id
            || receipt.target != self.local_id()?
            || !self.enrolled(receipt.source)
        {
            return Err("HA completed-forward owner differs".into());
        }
        loop {
            if Instant::now() >= receipt.deadline {
                return Err("HA completed-forward original deadline elapsed".into());
            }
            let seen = self.leader_status()?;
            if seen
                .committed_index
                .is_some_and(|index| index >= receipt.applied_index())
                && seen
                    .applied_index
                    .is_some_and(|index| index >= receipt.applied_index())
            {
                return Ok(());
            }
            std::thread::sleep(
                Duration::from_millis(5)
                    .min(receipt.deadline.saturating_duration_since(Instant::now())),
            );
        }
    }

    fn forward_request_exchange(
        &self,
        context: crate::ha_forward::ForwardContext<'_>,
        completed: bool,
        native_original_reply_profile: Option<crate::ha_forward::NativeOriginalReplyProfile>,
    ) -> Result<
        (
            Response,
            Option<crate::ha_forward_completion::CompletedForwardReceipt>,
        ),
        String,
    > {
        let crate::ha_forward::ForwardContext {
            method,
            path,
            namespace,
            token,
            body,
            wrap_ttl_seconds,
            origin_peer,
            client_certificates,
            caller_deadline,
        } = context;
        let deadline = Instant::now() + self.forward_timeout;
        let deadline = caller_deadline.map_or(deadline, |caller| caller.min(deadline));
        let local = self.local_id()?;
        let leader = self
            .leader()?
            .ok_or_else(|| "HA cluster has no elected leader".to_owned())?;
        if leader == local {
            return Err("HA forward request cannot target the local leader".into());
        }
        let target = self
            .peers
            .get(&leader)
            .ok_or_else(|| "HA elected leader is absent from peer registry".to_owned())?;
        let legacy_v1 = self.emit_legacy_peer_v1;
        #[cfg(feature = "native-v6-ha")]
        let native_index_capacity = completed && self.native_v6_enabled();
        #[cfg(not(feature = "native-v6-ha"))]
        let native_index_capacity = false;
        if native_original_reply_profile.is_some() && !native_index_capacity {
            return Err("HA native original reply requires native completed forwarding".into());
        }
        let unwrap_response = path == "sys/wrapping/unwrap"
            || path.starts_with("sys/workflows/execute/")
            || wrap_ttl_seconds.is_some_and(|ttl| ttl > 0)
                && crate::auth::current_ingress().is_some()
            || native_original_reply_profile.is_some();
        if unwrap_response && (legacy_v1 || !completed) {
            return Err("HA unwrap requires negotiated completed-forward authority".into());
        }
        if completed && legacy_v1 {
            return Err("legacy forwarding has no completion authority".into());
        }
        let nonce = if completed {
            Some(crate::crypto::random::<32>().map_err(|_| "HA forward nonce unavailable")?)
        } else {
            None
        };
        let request = Zeroizing::new(if legacy_v1 {
            // HBFQ1 predates trusted origin and client-certificate forwarding.
            // Omit those optional contexts only for the bounded transition: the
            // legacy leader fails closed when authorization actually requires
            // source or certificate identity. Response wrapping is different:
            // omitting it could release plaintext, so it remains unsupported.
            if wrap_ttl_seconds.is_some() {
                return Err(
                    "legacy HA forwarding transition cannot carry response wrapping".into(),
                );
            }
            encode_legacy_request_for_transition(
                local, leader, method, path, namespace, token, body,
            )?
        } else {
            let context = crate::ha_forward::ForwardContext {
                method,
                path,
                namespace,
                token,
                body,
                wrap_ttl_seconds,
                origin_peer,
                client_certificates,
                caller_deadline,
            };
            if let Some(profile) = native_original_reply_profile {
                crate::ha_forward::encode_completed_request_with_native_original_reply(
                    &self.cluster_id,
                    (local, leader),
                    &context,
                    nonce,
                    profile,
                )?
            } else {
                let encode = if native_index_capacity {
                    crate::ha_forward::encode_completed_request_with_native_index_capacity
                } else {
                    crate::ha_forward::encode_completed_index_request_for_cluster
                };
                encode(&self.cluster_id, (local, leader), &context, nonce)?
            }
        });
        // Capacity follows this exact request, never an unsolicited S7 reply.
        let native_index_response = request
            .starts_with(heptabao_ha_service::NATIVE_INDEX_REQUEST_MAGIC)
            || request.starts_with(heptabao_ha_service::NATIVE_KV2_WRITE_REQUEST_MAGIC);
        let response = zeroize::Zeroizing::new(
            observe_native_v6_timing("forward_exchange", "peer_exchange", Some(deadline), || {
                self.forward_transport.exchange_before(target, &request, deadline)
            })
                .map_err(|error| {
                    // Synthetic-only diagnostic: do not log URL, Actor,
                    // token, frame, certificate or raw library error text.
                    let reason = error.to_string();
                    let lowered = reason.to_ascii_lowercase();
                    let category = if lowered.contains("certificate") {
                        "certificate"
                    } else if lowered.contains("handshake") || lowered.contains("tls") {
                        "tls_handshake"
                    } else if lowered.contains("timeout") || lowered.contains("deadline") {
                        "timeout"
                    } else if lowered.contains("connection") || lowered.contains("socket") {
                        "tcp"
                    } else if lowered.contains("peer") {
                        "peer"
                    } else {
                        "other"
                    };
                    eprintln!("HBHA-MIXED-FWD-R4 phase=exchange_failure category={category} local={} target={} reason_hash={:02x?}",
                        local, leader, crate::crypto::digest(reason.as_bytes()));
                    #[cfg(test)]
                    {
                        let observed = Instant::now();
                        let _ = writeln!(
                            std::io::stderr().lock(),
                            "HBHA-TEST-FORWARD-BOUND forward_expired={} forward_remaining_ns={} caller_expired={} caller_remaining_ns={}",
                            observed >= deadline,
                            deadline.saturating_duration_since(observed).as_nanos(),
                            caller_deadline.is_some_and(|until| observed >= until),
                            caller_deadline.map_or(0, |until| until.saturating_duration_since(observed).as_nanos()),
                        );
                    }
                    reason
                })?,
        );
        let mut response = if legacy_v1 {
            decode_legacy_response_for_transition(&response, &self.cluster_id)?
        } else if unwrap_response {
            crate::ha_forward::decode_unwrap_response_for_cluster(&response, &self.cluster_id)?
        } else if native_index_response {
            crate::ha_forward::decode_native_index_response_for_cluster(
                &response,
                &self.cluster_id,
            )?
        } else {
            crate::ha_forward::decode_index_response_for_cluster(&response, &self.cluster_id)?
        };
        if response.source != leader || response.target != local {
            return Err("HA forward response direction is invalid".into());
        }
        if Instant::now() >= deadline {
            return Err("HA forwarding deadline exceeded; outcome may be committed".into());
        }
        let receipt = if let Some(nonce) = nonce {
            let response_digest = crate::ha_forward_completion::wire_response_digest(&response)?;
            let wire = response
                .completion
                .take()
                .ok_or("HA completed-forward proof is missing")?;
            Some(
                crate::ha_forward_completion::CompletedForwardReceipt::verified(
                    wire,
                    crate::ha_forward_completion::CompletedExchange {
                        cluster: self.cluster_id.clone(),
                        source: leader,
                        target: local,
                        deadline,
                        nonce,
                        request: &request,
                        response_digest,
                    },
                )?,
            )
        } else {
            None
        };
        if let Some(receipt) = &receipt {
            observe_native_v6_timing(
                "forward_exchange",
                "wait_applied",
                Some(receipt.deadline),
                || self.wait_forward_applied(receipt),
            )?;
        }
        let unwrapped_json = if response.unwrapped_json.is_some() {
            Some(crate::auth::UnwrappedJson::from_completed_raw_forward(
                receipt
                    .as_ref()
                    .ok_or("HA unwrap completed authority is missing")?,
                &response,
            )?)
        } else {
            None
        };
        Ok((
            Response {
                unwrapped_json,
                response_headers: std::mem::take(&mut response.response_headers),
                consistency_index: response.consistency_index.and_then(|index| {
                    crate::http::consistency::IndexValue::for_raft(&self.cluster_id, index).wire()
                }),
                status: response.status,
                body: std::mem::take(&mut response.body),
            },
            receipt,
        ))
    }

    pub fn local_id(&self) -> Result<u64, String> {
        self.node
            .as_ref()
            .map(|node| node.id())
            .ok_or_else(|| "HA process is shut down".into())
    }

    pub(crate) fn storage_binding(&self) -> Result<StorageBinding, String> {
        let id = self.local_id()?;
        let name = self
            .peers
            .get(&id)
            .ok_or("running HA local peer is not enrolled")?
            .to_string();
        Ok(StorageBinding {
            directory: self.storage_dir.clone(),
            name,
            cluster_address: self.cluster_address(id).map(str::to_owned),
            api_address: self.api_address(id).map(str::to_owned),
        })
    }

    pub fn cluster_id(&self) -> &str {
        &self.cluster_id
    }

    pub(crate) fn api_address(&self, node_id: u64) -> Option<&str> {
        self.api_addresses.get(&node_id).map(String::as_str)
    }

    pub(crate) fn cluster_address(&self, node_id: u64) -> Option<&str> {
        self.cluster_addresses.get(&node_id).map(String::as_str)
    }

    pub fn leader(&self) -> Result<Option<u64>, String> {
        let node = self
            .node
            .as_ref()
            .ok_or_else(|| "HA process is shut down".to_owned())?;
        Ok(self.runtime.block_on(node.current_leader()))
    }

    pub fn is_leader(&self) -> Result<bool, String> {
        let local_id = self.local_id()?;
        Ok(self.leader()? == Some(local_id))
    }

    /// Transfer leadership to another configured voter and wait until this node
    /// observes a different leader. A failed/unreachable target is tried once
    /// before the next configured peer; no client mutation is retried here.
    pub fn step_down(&self) -> Result<u64, String> {
        let node = self
            .node
            .as_ref()
            .ok_or_else(|| "HA process is shut down".to_owned())?;
        let local = node.id();
        if self.runtime.block_on(node.current_leader()) != Some(local) {
            return Err("HA step-down requires the current leader".into());
        }
        let membership = self
            .runtime
            .block_on(node.membership_observation())
            .map_err(|_| "membership unavailable")?;
        let targets: Vec<u64> = membership
            .voters
            .iter()
            .copied()
            .filter(|id| *id != local)
            .collect();
        if targets.is_empty() {
            return Err("HA cluster has no alternate voter".into());
        }
        let original_deadline = crate::request_deadline::current();
        self.runtime.block_on(async {
            for target in targets {
                let deadline = original_deadline
                    .map(tokio::time::Instant::from_std)
                    .map_or_else(
                        || tokio::time::Instant::now() + Duration::from_secs(3),
                        |original| {
                            original.min(tokio::time::Instant::now() + Duration::from_secs(3))
                        },
                    );
                if tokio::time::Instant::now() >= deadline {
                    return Err("HA leadership transfer original deadline elapsed".into());
                }
                if !tokio::time::timeout_at(deadline, node.transfer_leadership(target))
                    .await
                    .is_ok_and(|result| result.is_ok())
                {
                    continue;
                }
                loop {
                    if let Some(leader) = node.current_leader().await
                        && leader != local
                    {
                        return Ok(leader);
                    }
                    if tokio::time::Instant::now() >= deadline {
                        break;
                    }
                    tokio::time::sleep(Duration::from_millis(25)).await;
                }
            }
            Err("HA leadership transfer did not complete".into())
        })
    }

    pub fn enrolled(&self, id: u64) -> bool {
        self.peers.contains_key(&id)
    }
    pub fn membership(&self) -> Result<heptabao_raft_runtime::MembershipObservation, String> {
        let node = self.node.as_ref().ok_or("HA stopped")?;
        self.ensure_linearizable()?;
        self.runtime
            .block_on(node.membership_observation())
            .map_err(|_| "membership observation failed".into())
    }
    pub fn modify_membership(
        &self,
        index: u64,
        id: u64,
        operation: &str,
    ) -> Result<heptabao_raft_runtime::MembershipObservation, String> {
        if !self.enrolled(id) {
            return Err("peer is not host-enrolled".into());
        }
        let node = self.node.as_ref().ok_or("HA stopped")?;
        self.block_on_read(node.change_membership_guarded(index, id, operation))
            .map_err(|_| "membership operation requires reconciliation".into())
    }
    pub fn observed_snapshot(&self) -> Result<heptabao_raft_runtime::SnapshotObservation, String> {
        let node = self.node.as_ref().ok_or("HA stopped")?;
        self.block_on_read(node.snapshot_observed())
            .map_err(|_| "snapshot completion unobserved".into())
    }

    // ReadIndex retains a quarter of the existing execution budget for required
    // completion (including response audit). HTTP separately keeps its original
    // reply-write reserve. Only async read gates get this earlier bound; this
    // neither extends the parent nor cancels surrounding writes/maintenance.
    fn block_on_read<F: std::future::Future>(&self, operation: F) -> F::Output {
        match crate::request_deadline::current() {
            Some(deadline) => {
                let now = Instant::now();
                let deadline = deadline
                    .checked_duration_since(now)
                    .map_or(deadline, |remaining| deadline - remaining / 4);
                self.runtime
                    .block_on(heptabao_raft_runtime::with_read_index_deadline(
                        deadline, operation,
                    ))
            }
            None => self.runtime.block_on(operation),
        }
    }

    pub fn ensure_linearizable(&self) -> Result<(), String> {
        let node = self
            .node
            .as_ref()
            .ok_or_else(|| "HA process is shut down".to_owned())?;
        self.block_on_read(node.ensure_linearizable())
            .map_err(|error| error.to_string())
    }

    /// Prove that the local process is observing the committed application
    /// generation identified by the typed `expected` identity.
    ///
    /// A successful ReadIndex only proves quorum authority; it does not prove
    /// that this process has applied the same application state after a
    /// restart, snapshot install, or leadership transfer.  Health and request
    /// admission use this stronger fence so a node cannot report an active
    /// authority while serving a stale local state image.
    pub(crate) fn ensure_application_identity(
        &self,
        expected: crate::state_record_root::StateIdentity,
    ) -> Result<(), String> {
        use crate::state_record_root::StateIdentity;
        if expected.digest() == [0; 32] {
            return Err("HA application identity is not initialized".into());
        }
        #[cfg(feature = "native-v6-ha")]
        if matches!(expected, StateIdentity::RecordsV6(_)) {
            return self.ensure_native_v6_application_identity(expected);
        }
        // This performs ReadIndex and authenticates the typed root, including
        // its base and public references. A published V5 root never falls back
        // to a retired legacy client, even if the raw digest happens to match.
        if let Some(committed) = self.read_record_root_if_present(None)? {
            return match committed {
                CommittedStateRead::Records(record) if record.identity == expected => Ok(()),
                CommittedStateRead::Records(record) => {
                    eprintln!(
                        "heptabao-prepublication-diagnostic: stage=authenticated_record_selection expected_digest={:02x?} selected_digest={:02x?} selected_generation={:?} selected_schema={}",
                        expected.digest(),
                        record.identity.digest(),
                        record.read_cursor.as_ref().map(|cursor| cursor.generation),
                        record.root.state_schema
                    );
                    Err("HA application state is not converged on the committed identity".into())
                }
                _ => Err("HA application state is not converged on the committed identity".into()),
            };
        }
        let StateIdentity::Legacy(expected_digest) = expected else {
            return Err("HA record root has not been committed".into());
        };
        let node = self.node.as_ref().ok_or("HA process is shut down")?;
        let committed = self
            .runtime
            .block_on(node.latest_envelope())
            .map_err(|error| error.to_string())?
            .ok_or("HA application state has not been committed")?;
        let descriptor = self
            .codec
            .open_committed_descriptor(
                committed.operation_id(),
                committed.digest(),
                committed.sealed(),
            )
            .map_err(|error| error.to_string())?;
        if committed.digest() != expected_digest
            || matches!(descriptor, CommittedStateDescriptor::RecordsV5(_))
        {
            return Err("HA application state is not converged on the committed identity".into());
        }
        Ok(())
    }

    pub fn trigger_snapshot(&self) -> Result<(), String> {
        let node = self
            .node
            .as_ref()
            .ok_or_else(|| "HA process is shut down".to_owned())?;
        self.block_on_read(node.snapshot_observed())
            .map(|_| ())
            .map_err(|error| error.to_string())
    }

    /// Replicate the next authoritative application state with a manifest as
    /// the sole publication point. HBSM3 separates logical chunk order from the
    /// bounded physical Raft chunk index so content-defined boundaries can reuse
    /// authenticated chunks after insertions/deletions instead of shifting every
    /// later fixed chunk. HBSM4 additionally carries the authenticated local
    /// owner-plan digest and changed-owner mask, so the record-oriented local
    /// delta cannot be replaced by an opaque whole-state fallback at the HA
    /// boundary. New chunks are staged into an unreferenced index/slot; the
    /// production manifest remains the only publication point.
    pub(crate) fn commit_state_with_owner_binding(
        &self,
        operation_id: &str,
        expected_base_digest: [u8; 32],
        bytes: &[u8],
        binding: OwnerPublicationBinding,
    ) -> Result<CommitReceipt, String> {
        validate_owner_binding(operation_id, bytes, binding)?;
        self.commit_state_inner(
            operation_id,
            expected_base_digest,
            bytes,
            Some((
                binding.owner_manifest_digest(),
                binding.changed_owner_mask(),
            )),
            false,
        )
    }

    /// Explicitly promote an HBSR1 whole-state envelope to an owner-bound
    /// HBSM4 manifest.  This is intentionally separate from ordinary state
    /// mutation: the latter must remain fail-closed until an operator invokes
    /// the authenticated migration route.
    pub(crate) fn commit_legacy_owner_migration_with_binding(
        &self,
        operation_id: &str,
        expected_base_digest: [u8; 32],
        bytes: &[u8],
        binding: OwnerPublicationBinding,
    ) -> Result<CommitReceipt, String> {
        validate_owner_binding(operation_id, bytes, binding)?;
        self.commit_state_inner(
            operation_id,
            expected_base_digest,
            bytes,
            Some((
                binding.owner_manifest_digest(),
                binding.changed_owner_mask(),
            )),
            true,
        )
    }

    pub fn commit_state(
        &self,
        operation_id: &str,
        expected_base_digest: [u8; 32],
        bytes: &[u8],
    ) -> Result<CommitReceipt, String> {
        self.commit_state_inner(operation_id, expected_base_digest, bytes, None, false)
    }

    fn commit_state_inner(
        &self,
        operation_id: &str,
        expected_base_digest: [u8; 32],
        bytes: &[u8],
        owner_binding: Option<([u8; 32], u8)>,
        allow_legacy_migration: bool,
    ) -> Result<CommitReceipt, String> {
        if bytes.is_empty() || bytes.len() > crate::MAX_APPLICATION_STATE_BYTES {
            return Err("HA application state is empty or exceeds the shared bound".into());
        }
        let node = self
            .node
            .as_ref()
            .ok_or_else(|| "HA process is shut down".to_owned())?;
        let local_id = node.id();
        let leader = self
            .runtime
            .block_on(node.current_leader())
            .ok_or_else(|| "HA cluster has no elected leader".to_owned())?;
        if leader != local_id {
            return Err(format!("HA write requires current leader node {leader}"));
        }
        self.block_on_read(node.ensure_linearizable())
            .map_err(|error| error.to_string())?;
        let latest = self
            .runtime
            .block_on(node.latest_envelope())
            .map_err(|error| error.to_string())?;
        if let Some(envelope) = latest.as_ref()
            && envelope.digest() != expected_base_digest
        {
            return Err("HA application base conflicts with latest committed state".into());
        }
        if allow_legacy_migration && latest.is_none() {
            return Err("legacy owner-manifest migration requires an HBSR1 base state".into());
        }

        let previous_manifest = match latest.as_ref() {
            None => None,
            Some(envelope) => {
                let descriptor = self
                    .codec
                    .open_committed_descriptor(
                        envelope.operation_id(),
                        envelope.digest(),
                        envelope.sealed(),
                    )
                    .map_err(|error| error.to_string())?;
                if allow_legacy_migration {
                    validate_legacy_migration_base(&descriptor, owner_binding.is_some())?;
                } else {
                    reject_legacy_mutation_fallback(&descriptor)?;
                }
                match descriptor {
                    CommittedStateDescriptor::Legacy(state) => {
                        if sha256(&state) != envelope.digest() {
                            return Err("legacy HA state digest readback failed".into());
                        }
                        None
                    }
                    CommittedStateDescriptor::Chunked(manifest) => Some(manifest),
                    CommittedStateDescriptor::RecordsV5(_) => {
                        return Err("record state cannot use whole-state publication".into());
                    }
                }
            }
        };

        let plans = plan_replicated_chunks(bytes, previous_manifest.as_ref())?;
        let mut refs = Vec::with_capacity(plans.len());
        for plan in plans {
            let reference = plan.reference.clone();
            if plan.reused {
                let staged = self
                    .runtime
                    .block_on(node.application_chunk_envelope(reference.index, reference.slot))
                    .map_err(|error| error.to_string())?
                    .ok_or_else(|| "HA committed manifest references a missing chunk".to_owned())?;
                if staged.digest() != reference.digest {
                    return Err("HA committed chunk digest metadata is inconsistent".into());
                }
                let opened = self
                    .codec
                    .open_chunk_parts(
                        reference.index,
                        reference.slot,
                        staged.operation_id(),
                        staged.digest(),
                        staged.sealed(),
                    )
                    .map_err(|error| error.to_string())?;
                if opened.as_slice() != plan.bytes
                    || opened.len() != usize::try_from(reference.bytes).unwrap_or(usize::MAX)
                    || sha256(&opened) != reference.digest
                {
                    return Err("HA committed reusable chunk failed authenticated readback".into());
                }
            } else {
                let chunk_operation =
                    chunk_operation_id(operation_id, reference.index, reference.slot);
                let proposal = self
                    .codec
                    .seal_chunk(
                        chunk_operation.clone(),
                        reference.index,
                        reference.slot,
                        plan.bytes,
                    )
                    .map_err(|error| error.to_string())?;
                let envelope = ReplicatedEnvelope::new(
                    proposal.operation_id().to_owned(),
                    proposal.digest(),
                    proposal.sealed().to_vec(),
                )
                .map_err(|error| error.to_string())?;
                let serial = self
                    .runtime
                    .block_on(node.next_production_client_serial())
                    .map_err(|error| error.to_string())?;
                let receipt = self
                    .runtime
                    .block_on(node.replicate_application_chunk(
                        reference.index,
                        reference.slot,
                        serial,
                        &envelope,
                    ))
                    .map_err(|error| error.to_string())?;
                if receipt.leader_id != local_id || receipt.envelope_digest != reference.digest {
                    return Err("HA chunk commit receipt did not bind the staged payload".into());
                }
            }
            refs.push(reference);
        }

        let proposal = match owner_binding {
            Some((owner_manifest_digest, changed_owner_mask)) => self
                .codec
                .seal_manifest_with_owner_binding(
                    operation_id.to_owned(),
                    expected_base_digest,
                    bytes,
                    refs,
                    owner_manifest_digest,
                    changed_owner_mask,
                )
                .map_err(|error| error.to_string())?,
            None => self
                .codec
                .seal_manifest(operation_id.to_owned(), expected_base_digest, bytes, refs)
                .map_err(|error| error.to_string())?,
        };
        let envelope = ReplicatedEnvelope::new(
            proposal.operation_id().to_owned(),
            proposal.digest(),
            proposal.sealed().to_vec(),
        )
        .map_err(|error| error.to_string())?;
        let serial = self
            .runtime
            .block_on(node.next_production_client_serial())
            .map_err(|error| error.to_string())?;
        let receipt = self
            .runtime
            .block_on(node.replicate(serial, &envelope))
            .map_err(|error| error.to_string())?;
        if receipt.leader_id != local_id || receipt.envelope_digest != proposal.digest() {
            return Err("HA commit receipt did not bind the submitted application manifest".into());
        }
        Ok(receipt)
    }

    /// Return the newest complete application state after a linearizable
    /// ReadIndex. HBSR1 whole-state envelopes and HBSM2 fixed-position manifests
    /// remain readable for online upgrade; HBSM3/HBSM4 resolve ordered logical
    /// chunks through authenticated position-independent physical index/slot
    /// references. HBSM4 also validates the owner-delta identity carried by the
    /// service publication binding.
    pub(crate) fn latest_committed_state(
        &self,
    ) -> Result<Option<CommittedApplicationState>, String> {
        match self.latest_committed_state_if_changed(None)? {
            CommittedStateRead::Absent => Ok(None),
            CommittedStateRead::Records(_) => {
                Err("record state requires its typed root and object reader".into())
            }
            CommittedStateRead::Materialized(state) => Ok(Some(state)),
            CommittedStateRead::Unchanged => {
                Err("HA read reused an absent verification cursor".into())
            }
        }
    }

    /// Authenticate the exact application kind/root observed under the runtime's
    /// opaque quorum/own-applied proof. Complete object materialization remains
    /// mandatory before an application uses this proof for supersession.
    pub(crate) fn application_identity_witness(
        &self,
    ) -> Result<
        (
            crate::state_record_root::StateIdentity,
            heptabao_raft_runtime::ApplicationReadWitness,
        ),
        String,
    > {
        self.application_identity_witness_inner(None)
    }

    /// The actual Service's typed local identity selects a read optimization,
    /// never the returned authority. A changed selection retains full recovery
    /// and returns its actual identity for the caller's existing comparison.
    pub(crate) fn application_identity_witness_for_local_root(
        &self,
        local_identity: crate::state_record_root::StateIdentity,
    ) -> Result<
        (
            crate::state_record_root::StateIdentity,
            heptabao_raft_runtime::ApplicationReadWitness,
        ),
        String,
    > {
        self.application_identity_witness_inner(Some(local_identity))
    }

    fn application_identity_witness_inner(
        &self,
        _local_identity: Option<crate::state_record_root::StateIdentity>,
    ) -> Result<
        (
            crate::state_record_root::StateIdentity,
            heptabao_raft_runtime::ApplicationReadWitness,
        ),
        String,
    > {
        use crate::state_record_root::StateIdentity;
        #[cfg(feature = "native-v6-ha")]
        if self.native_v6_enabled() {
            let deadline = crate::v6_native_custody::OriginalDeadline::capture()
                .map_err(|error| error.to_string())?;
            let read = match _local_identity {
                Some(StateIdentity::RecordsV6(digest)) => {
                    self.native_v6_committed_read_for_local_root(deadline, digest)?
                }
                _ => self.native_v6_committed_read(deadline)?,
            };
            if let Some(read) = read {
                // The real selected root includes its enrollment and full
                // publication provenance. Missing ciphertext is repaired only
                // through the actual pinned peers before this authentication.
                let identity = self.with_native_v6_source(&read, |codec, store| {
                    let closure = codec
                        .open_native_v6_committed_read(
                            read.enrollment(),
                            read.published(),
                            store,
                            &mut || {
                                self.verify_native_v6_committed_read(&read).map_err(|_| {
                                    crate::ha_state::native_v6::NativeV6CodecError::Gate
                                })
                            },
                        )
                        .map_err(|_| "native application witness closure unavailable".to_owned())?;
                    let identity = closure
                        .root()
                        .identity()
                        .map_err(|_| "native application witness root invalid".to_owned())?;
                    if identity != StateIdentity::RecordsV6(read.published().root_digest()) {
                        return Err("native application witness root mismatch".to_owned());
                    }
                    Ok(identity)
                })??;
                // Preserve this exact applied witness, including its original
                // capped deadline, generation, term and store identity. The
                // Service still owes full typed materialization and Actor /
                // audit / delivery gates; this is not a response permission.
                self.verify_native_v6_committed_read(&read)?;
                return Ok((identity, read.into_application_witness()));
            }
            // V6 may be absent before activation. The ordinary runtime API
            // atomically rejects native activation, including a race after the
            // preceding None, so retained V5 state cannot become a stale reply.
        }
        let node = self.node.as_ref().ok_or("HA process is shut down")?;
        let (witness, envelope, record) = self
            .block_on_read(node.application_read_witness())
            .map_err(|error| error.to_string())?;
        let identity = if let Some(published) = record {
            let envelope = published.envelope();
            let CommittedStateDescriptor::RecordsV5(decoded) = self
                .codec
                .open_committed_descriptor(
                    envelope.operation_id(),
                    envelope.digest(),
                    envelope.sealed(),
                )
                .map_err(|error| error.to_string())?
            else {
                return Err("application witness kind mismatch".into());
            };
            if decoded.base != published.base()
                || decoded
                    .root
                    .references()
                    .map(crate::ha_state::runtime_reference)
                    .collect::<Vec<_>>()
                    != published.direct_refs()
                || decoded.root.cluster_id != self.cluster_id
            {
                return Err("application witness record root mismatch".into());
            }
            StateIdentity::RecordsV5(envelope.digest())
        } else {
            let envelope = envelope.ok_or("application witness is absent")?;
            if matches!(
                self.codec
                    .open_committed_descriptor(
                        envelope.operation_id(),
                        envelope.digest(),
                        envelope.sealed()
                    )
                    .map_err(|error| error.to_string())?,
                CommittedStateDescriptor::RecordsV5(_)
            ) {
                return Err("application witness kind mismatch".into());
            }
            StateIdentity::Legacy(envelope.digest())
        };
        self.block_on_read(node.verify_application_read_witness(&witness))
            .map_err(|error| error.to_string())?;
        Ok((identity, witness))
    }

    /// The full RecordsV5 root and opaque applied witness come from the same
    /// atomic runtime snapshot after quorum ReadIndex. A later current witness
    /// must cover this one after complete application materialization; requiring
    /// the selected generation to remain current would reject a lawful commit.
    pub(crate) fn record_application_witness(
        &self,
    ) -> Result<
        Option<(
            CommittedRecordState,
            heptabao_raft_runtime::ApplicationReadWitness,
        )>,
        String,
    > {
        let node = self.node.as_ref().ok_or("HA process is shut down")?;
        let (witness, _, record) = self
            .block_on_read(node.application_read_witness())
            .map_err(|error| error.to_string())?;
        let Some(published) = record else {
            return Ok(None);
        };
        let envelope = published.envelope();
        let CommittedStateDescriptor::RecordsV5(decoded) = self
            .codec
            .open_committed_descriptor(
                envelope.operation_id(),
                envelope.digest(),
                envelope.sealed(),
            )
            .map_err(|error| error.to_string())?
        else {
            return Err("application witness kind mismatch".into());
        };
        if decoded.base != published.base()
            || decoded
                .root
                .references()
                .map(crate::ha_state::runtime_reference)
                .collect::<Vec<_>>()
                != published.direct_refs()
            || decoded.root.cluster_id != self.cluster_id
        {
            return Err("application witness record root mismatch".into());
        }
        Ok(Some((
            CommittedRecordState {
                identity: crate::state_record_root::StateIdentity::RecordsV5(envelope.digest()),
                root: decoded.root,
                root_bytes: decoded.bytes,
                read_cursor: None,
            },
            witness,
        )))
    }

    pub(crate) fn latest_committed_state_if_changed(
        &self,
        known: Option<&ValidatedReadCursor>,
    ) -> Result<CommittedStateRead, String> {
        if let Some(records) = self.read_record_root_if_present(known)? {
            return Ok(records);
        }
        let node = self
            .node
            .as_ref()
            .ok_or_else(|| "HA process is shut down".to_owned())?;
        read_committed_application(
            &self.codec,
            known,
            || {
                self.block_on_read(node.ensure_linearizable())
                    .map_err(|error| error.to_string())
            },
            || {
                self.runtime
                    .block_on(node.latest_envelope_at_generation())
                    .map_err(|error| error.to_string())
            },
            |index, slot| {
                self.runtime
                    .block_on(node.application_chunk_envelope(index, slot))
                    .map_err(|error| error.to_string())
            },
            || self.runtime.block_on(node.application_state_generation()),
        )
    }
}

/// Keep ReadIndex and manifest authentication ahead of every reuse decision.
/// The narrow callbacks also let tests prove that a warm read never loads chunks
/// and that authority loss or a changed mutable slot still fails closed.
fn read_committed_application(
    codec: &ClusterStateCodec,
    known: Option<&ValidatedReadCursor>,
    read_index: impl FnOnce() -> Result<(), String>,
    latest: impl FnOnce() -> Result<(u64, Option<ReplicatedEnvelope>), String>,
    mut load_chunk: impl FnMut(u16, u8) -> Result<Option<ReplicatedEnvelope>, String>,
    current_generation: impl FnOnce() -> u64,
) -> Result<CommittedStateRead, String> {
    read_index()?;
    let (generation, Some(envelope)) = latest()? else {
        return Ok(CommittedStateRead::Absent);
    };
    let descriptor = codec
        .open_committed_descriptor(
            envelope.operation_id(),
            envelope.digest(),
            envelope.sealed(),
        )
        .map_err(|error| error.to_string())?;
    let identity = manifest_envelope_identity(&envelope);
    let (bytes, legacy_whole_state, owner_manifest_digest, changed_owner_mask) = match descriptor {
        CommittedStateDescriptor::Legacy(bytes) => (bytes, true, None, None),
        CommittedStateDescriptor::RecordsV5(_) => {
            return Err("record state requires typed application materialization".into());
        }
        CommittedStateDescriptor::Chunked(manifest) => {
            if manifest.state_digest != envelope.digest() {
                return Err("HA manifest digest does not match production envelope".into());
            }
            // Only owner-bound HBSM4 has a local canonical publication identity
            // that Service can bind to admitted durable state before reusing.
            if manifest.owner_manifest_digest.is_some()
                && known.is_some_and(|cursor| {
                    !cursor.records_v5
                        && cursor.generation == generation
                        && cursor.envelope_identity == identity
                })
            {
                return Ok(CommittedStateRead::Unchanged);
            }
            let total = usize::try_from(manifest.total_bytes)
                .map_err(|_| "HA manifest total length overflow".to_owned())?;
            let mut assembled = Zeroizing::new(Vec::with_capacity(total));
            for chunk in &manifest.chunks {
                let staged = load_chunk(chunk.index, chunk.slot)?.ok_or_else(|| {
                    "HA manifest references an unavailable committed chunk".to_owned()
                })?;
                if staged.digest() != chunk.digest {
                    return Err("HA manifest/chunk digest binding mismatch".into());
                }
                let opened = codec
                    .open_chunk_parts(
                        chunk.index,
                        chunk.slot,
                        staged.operation_id(),
                        staged.digest(),
                        staged.sealed(),
                    )
                    .map_err(|error| error.to_string())?;
                if opened.len()
                    != usize::try_from(chunk.bytes)
                        .map_err(|_| "HA chunk length overflow".to_owned())?
                {
                    return Err("HA committed chunk length mismatch".into());
                }
                assembled.extend_from_slice(&opened);
                if assembled.len() > total {
                    return Err("HA committed chunk set exceeds manifest length".into());
                }
            }
            if assembled.len() != total || sha256(&assembled) != manifest.state_digest {
                return Err("HA committed chunk set does not reconstruct manifest state".into());
            }
            (
                assembled,
                false,
                manifest.owner_manifest_digest,
                manifest.changed_owner_mask,
            )
        }
    };
    if sha256(&bytes) != envelope.digest() {
        return Err("HA committed application digest readback failed".into());
    }
    // An apply or snapshot during materialization invalidates the observation,
    // even if it left the publication envelope itself untouched. Do not issue
    // evidence spanning that mutation; the next read can validate it afresh.
    let read_cursor = (owner_manifest_digest.is_some() && current_generation() == generation)
        .then_some(ValidatedReadCursor {
            records_v5: false,
            generation,
            envelope_identity: identity,
        });
    Ok(CommittedStateRead::Materialized(
        CommittedApplicationState {
            digest: envelope.digest(),
            bytes,
            legacy_whole_state,
            owner_manifest_digest,
            changed_owner_mask,
            read_cursor,
        },
    ))
}

fn manifest_envelope_identity(envelope: &ReplicatedEnvelope) -> [u8; 32] {
    let mut context = digest::Context::new(&digest::SHA256);
    context.update(b"heptabao-verified-ha-manifest-v1");
    context.update(&(envelope.operation_id().len() as u64).to_be_bytes());
    context.update(envelope.operation_id().as_bytes());
    context.update(&envelope.digest());
    context.update(&(envelope.sealed().len() as u64).to_be_bytes());
    context.update(envelope.sealed());
    let mut result = [0; 32];
    result.copy_from_slice(context.finish().as_ref());
    result
}

/// Reconcile the statically enrolled bootstrap set without conflating the
/// membership commit with learner catch-up. This function is intentionally
/// bounded and best-effort: a missing peer or lost leader leaves a durable
/// learner (when enrollment committed) and a fenced process. Once the exact
/// committed non-joint voter set is observed, the process may close that fence
/// without mutating membership. It never promotes a learner whose replication
/// frontier has not been observed.
fn bootstrap_membership_complete(
    expected: &BTreeSet<u64>,
    observed: &MembershipObservation,
) -> bool {
    observed.committed && !observed.joint && observed.voters == *expected
}

fn bootstrap_membership_operational(
    enrolled: &BTreeSet<u64>,
    observed: &MembershipObservation,
) -> bool {
    observed.committed
        && !observed.joint
        && observed.voters.len() >= 3
        && observed.voters.is_subset(enrolled)
        && observed.nodes.is_subset(enrolled)
}

fn legacy_bootstrap_marker_state(
    local_id: u64,
    expected: &BTreeSet<u64>,
    enrolled: &BTreeSet<u64>,
    observed: &MembershipObservation,
) -> Option<BootstrapMarkerState> {
    if bootstrap_membership_operational(enrolled, observed) {
        return Some(BootstrapMarkerState::Complete);
    }
    if !observed.committed
        || observed.joint
        || !observed.voters.is_subset(enrolled)
        || !observed.nodes.is_subset(enrolled)
    {
        return None;
    }
    let singleton = BTreeSet::from([local_id]);
    let pending_voters = observed.voters.is_empty() || observed.voters == singleton;
    let pending_nodes = observed.nodes.is_subset(expected)
        && (observed.nodes.is_empty() || observed.nodes.contains(&local_id));
    (pending_voters && pending_nodes).then_some(BootstrapMarkerState::Pending)
}

fn reconcile_bootstrap_membership(
    runtime: &Runtime,
    node: &ProcessRaftNode,
    initialize: bool,
    local_id: u64,
    voters: &BTreeSet<u64>,
) -> bool {
    // Health can resume this same bootstrap after process startup. Its read
    // waits inherit the ORIGINAL request deadline; startup without a request
    // retains the existing finite election/learner observation budgets.
    // Never cancel an initialization, enrollment or membership publication:
    // those operations keep their completion semantics, and a later probe
    // must observe the committed frontier before considering any next step.
    let request_deadline = crate::request_deadline::current();
    let request_live = || request_deadline.is_none_or(|until| Instant::now() < until);
    if !request_live() {
        return false;
    }
    let mut membership = match runtime.block_on(node.membership_observation()) {
        Ok(membership) => membership,
        Err(_) => return false,
    };
    if !request_live() {
        return false;
    }
    if (initialize || membership.voters.is_empty())
        && runtime.block_on(node.initialize_single()).is_err()
    {
        return false;
    }
    if initialize || membership.voters.is_empty() {
        membership = match runtime.block_on(node.membership_observation()) {
            Ok(membership) => membership,
            Err(_) => return false,
        };
    }
    // A reopened node may be a follower in an already-complete cluster. The
    // local process does not need to own reconciliation in that case; it may
    // become leader later and must not remain fenced merely because startup
    // happened on a standby.
    if bootstrap_membership_complete(voters, &membership) {
        return request_live();
    }
    let elected = runtime.block_on(async {
        let limit = tokio::time::Instant::now() + Duration::from_secs(5);
        let deadline = request_deadline.map_or(limit, |until| {
            limit.min(tokio::time::Instant::from_std(until))
        });
        loop {
            if tokio::time::Instant::now() >= deadline {
                break false;
            }
            if node.current_leader().await == Some(local_id) {
                break tokio::time::Instant::now() < deadline;
            }
            tokio::time::sleep_until(
                (tokio::time::Instant::now() + Duration::from_millis(20)).min(deadline),
            )
            .await;
        }
    });
    if !elected {
        return false;
    }

    for peer_id in voters.iter().copied().filter(|id| *id != local_id) {
        if !request_live() {
            return false;
        }
        if membership.nodes.contains(&peer_id) {
            continue;
        }
        if runtime.block_on(node.enroll_learner(peer_id)).is_err() {
            return false;
        }
        membership = match runtime.block_on(node.membership_observation()) {
            Ok(membership) => membership,
            Err(_) => return false,
        };
    }

    // Enrollment is a committed topology fact. Promotion requires the
    // stronger readiness observation for every requested voter.
    for peer_id in voters.iter().copied().filter(|id| *id != local_id) {
        if !request_live() {
            return false;
        }
        if !membership.voters.contains(&peer_id)
            && !runtime.block_on(async {
                let limit = tokio::time::Instant::now() + Duration::from_secs(2);
                let deadline = request_deadline.map_or(limit, |until| {
                    limit.min(tokio::time::Instant::from_std(until))
                });
                let remaining = deadline.saturating_duration_since(tokio::time::Instant::now());
                if remaining.is_zero() {
                    return false;
                }
                // This is solely a replication/heartbeat observation. Timing
                // it out leaves the already committed learner intact and
                // does not submit, cancel or repeat a membership mutation.
                let observed = tokio::time::timeout_at(
                    deadline,
                    node.wait_for_learner_replication(peer_id, remaining),
                )
                .await;
                matches!(observed, Ok(Ok(()))) && tokio::time::Instant::now() < deadline
            })
        {
            return false;
        }
    }
    if !request_live() {
        return false;
    }
    if membership.voters == *voters {
        return true;
    }
    runtime
        .block_on(node.change_membership(voters.clone()))
        .is_ok()
        && request_live()
}

impl Drop for HaProcess {
    fn drop(&mut self) {
        let supervisor = self.listener.as_ref().and_then(|listener| {
            listener
                .owns_current_worker()
                .then_some(listener.shutdown_supervisor)
        });
        let receipt = self.listener.as_ref().map_or_else(
            || Arc::new(peer_shutdown::PeerNodeShutdownReceipt::default()),
            |listener| Arc::clone(&listener.shutdown_receipt),
        );
        if let Some(listener) = self.listener.as_ref() {
            listener.stop.store(true, Ordering::Release);
        }
        let shutdown = peer_shutdown::OwnedHaShutdown {
            listener: self.listener.take(),
            #[cfg(feature = "native-v6-ha")]
            native_v6: self.native_v6.take(),
            node: self.node.take(),
            runtime: Arc::clone(&self.runtime),
            receipt,
        };
        if let Some(supervisor) = supervisor {
            // The current worker must return before it can be joined. Transfer
            // its exact handles AND the dependencies they still use; the queue
            // owns them until all workers join and original shutdown completes.
            supervisor.defer(shutdown);
        } else {
            shutdown.complete();
        }
    }
}

fn validate_config(config: &HaProcessConfig) -> Result<(), String> {
    if !valid_cluster_id(&config.cluster_id) {
        return Err("invalid HA cluster identity".into());
    }
    if config.outbound_legacy_peer_v1() && !config.allow_legacy_peer_v1 {
        return Err("legacy HA outbound requires explicit legacy inbound admission".into());
    }
    if config.initial_voters.as_ref().is_some_and(|v| {
        v.len() < 3
            || v.len() > 9
            || v.iter().any(|id| !config.peers.contains_key(id))
            || config.bootstrap && !v.contains(&config.node_id)
    }) {
        return Err("invalid initial voter subset".into());
    }
    if config.node_id == 0
        || config.peers.len() < 3
        || config.peers.len() > 9
        || !config.peers.contains_key(&config.node_id)
        // A zero listener port asks the OS to choose an ephemeral endpoint.
        // Peer addresses are statically enrolled, so allowing that choice can
        // leave a node listening on an address no peer can reach after a
        // restart.  Outbound peer endpoints have the same bound in
        // `TlsPeerEndpoint::new`.
        || config.listen.port() == 0
        || !(50..=5_000).contains(&config.peer_timeout_ms)
        || !(1_000..=60_000).contains(&config.forward_timeout_ms)
        || !(4..=256).contains(&config.max_inflight)
        || !config.raft_dir.is_absolute()
        || !config.ca_file.is_absolute()
        || !config.cert_file.is_absolute()
        || !config.key_file.is_absolute()
        || !config.replication_key_file.is_absolute()
        || config.ca_file.starts_with(&config.raft_dir)
        || config.cert_file.starts_with(&config.raft_dir)
        || config.key_file.starts_with(&config.raft_dir)
        || config.replication_key_file.starts_with(&config.raft_dir)
    {
        return Err("invalid bounded HA process configuration".into());
    }
    Ok(())
}

fn parse_peers(config: &HaProcessConfig) -> Result<Vec<ParsedPeer>, String> {
    let mut names = BTreeSet::new();
    let mut digests = BTreeSet::new();
    let mut peers = Vec::with_capacity(config.peers.len());
    for (id, peer) in &config.peers {
        if *id == 0 {
            return Err("HA peer id must be nonzero".into());
        }
        let node = NodeId::parse(peer.node_name.clone()).map_err(|error| error.to_string())?;
        let endpoint = TlsPeerEndpoint::new(peer.address, peer.server_name.clone())
            .map_err(|error| error.to_string())?;
        let certificate_sha256 = decode_hex_32(&peer.certificate_sha256)?;
        let certificate_sha256_next = peer
            .certificate_sha256_next
            .as_deref()
            .map(decode_hex_32)
            .transpose()?;
        let api_address = peer
            .api_address
            .as_deref()
            .map(parse_api_address)
            .transpose()?;
        let cluster_address = peer
            .cluster_address
            .as_deref()
            .map(parse_cluster_address)
            .transpose()?;
        if !names.insert(node.clone())
            || !digests.insert(certificate_sha256)
            || certificate_sha256_next.is_some_and(|digest| !digests.insert(digest))
        {
            return Err("HA peer identities and certificate digests must be unique".into());
        }
        peers.push(ParsedPeer {
            id: *id,
            node,
            endpoint,
            certificate_sha256,
            certificate_sha256_next,
            api_address,
            cluster_address,
        });
    }
    Ok(peers)
}

fn parse_api_address(address: &str) -> Result<String, String> {
    // Reuse the side-effect-free HTTPS authority parser, including IPv6 and
    // default port handling. An API base must not contain a query or path;
    // request paths must never be interpreted as part of an authority.
    let target = crate::outbound::parse_auth_https_target(
        address,
        Some(&crate::outbound::AuthHttpsTransport::default()),
    )
    .map_err(|_| "invalid HA peer API address".to_owned())?;
    if target.path != "/" {
        return Err("HA peer API address must be an HTTPS origin".into());
    }
    Ok(target.origin)
}

fn parse_cluster_address(address: &str) -> Result<String, String> {
    // An explicitly advertised native forwarding origin is an operator-owned
    // diagnostic value. Parsing performs no DNS or network request, and it
    // never changes the enrolled peer transport, pins or routing authority.
    parse_api_address(address).map_err(|_| "invalid HA peer cluster address".to_owned())
}

fn build_mutual_tls(config: &HaProcessConfig) -> Result<MutualTlsConfigs, String> {
    let ca = load_certificates(&config.ca_file)?;
    let certificates = load_certificates(&config.cert_file)?;
    let local_leaf = certificates
        .first()
        .ok_or_else(|| "HA certificate chain is empty".to_owned())?;
    let local_leaf_digest = sha256(local_leaf.as_ref());
    let key_bytes = read_private_bounded_regular_file(&config.key_file, MAX_TLS_FILE_BYTES)?;
    let key = rustls_pemfile::private_key(&mut BufReader::new(key_bytes.as_slice()))
        .map_err(|_| "invalid HA TLS private key".to_owned())?
        .ok_or_else(|| "missing HA TLS private key".to_owned())?;
    let provider = Arc::new(crate::tls_key_exchange::default_provider());

    let client_roots = root_store(&ca)?;
    let mut client = ClientConfig::builder_with_provider(provider.clone())
        .with_safe_default_protocol_versions()
        .map_err(|_| "HA TLS protocol versions unavailable".to_owned())?
        .with_root_certificates(client_roots)
        .with_client_auth_cert(certificates.clone(), clone_private_key(&key)?)
        .map_err(|_| "invalid HA TLS client identity".to_owned())?;
    client.alpn_protocols = vec![RAFT_ALPN_PROTOCOL.to_vec()];

    let verifier = WebPkiClientVerifier::builder_with_provider(
        Arc::new(root_store(&ca)?),
        Arc::new(crate::tls_key_exchange::default_provider()),
    )
    .build()
    .map_err(|_| "invalid HA TLS client verifier".to_owned())?;
    let mut server = ServerConfig::builder_with_provider(provider)
        .with_safe_default_protocol_versions()
        .map_err(|_| "HA TLS protocol versions unavailable".to_owned())?
        .with_client_cert_verifier(verifier)
        .with_single_cert(certificates, key)
        .map_err(|_| "invalid HA TLS server identity".to_owned())?;
    server.alpn_protocols = vec![RAFT_ALPN_PROTOCOL.to_vec()];
    Ok((Arc::new(client), Arc::new(server), local_leaf_digest))
}

fn root_store(certificates: &[CertificateDer<'static>]) -> Result<RootCertStore, String> {
    let mut roots = RootCertStore::empty();
    for certificate in certificates {
        roots
            .add(certificate.clone())
            .map_err(|_| "invalid HA TLS trust root".to_owned())?;
    }
    Ok(roots)
}

fn clone_private_key(key: &PrivateKeyDer<'static>) -> Result<PrivateKeyDer<'static>, String> {
    Ok(key.clone_key())
}

fn load_certificates(path: &Path) -> Result<Vec<CertificateDer<'static>>, String> {
    let bytes = read_bounded_regular_file(path, MAX_TLS_FILE_BYTES)?;
    let certificates = rustls_pemfile::certs(&mut BufReader::new(bytes.as_slice()))
        .collect::<Result<Vec<_>, _>>()
        .map_err(|_| "invalid HA TLS certificate file".to_owned())?;
    if certificates.is_empty() {
        return Err("HA TLS certificate file is empty".into());
    }
    Ok(certificates)
}

fn load_replication_key(path: &Path) -> Result<[u8; REPLICATION_KEY_BYTES], String> {
    let bytes = read_private_bounded_regular_file(path, REPLICATION_KEY_BYTES)?;
    if bytes.len() != REPLICATION_KEY_BYTES {
        return Err("HA replication key must contain exactly 32 raw bytes".into());
    }
    bytes
        .as_slice()
        .try_into()
        .map_err(|_| "HA replication key has invalid size".into())
}

fn read_bounded_regular_file(path: &Path, maximum: usize) -> Result<Zeroizing<Vec<u8>>, String> {
    read_bounded_regular_file_with_privacy(path, maximum, false)
}

fn read_private_bounded_regular_file(
    path: &Path,
    maximum: usize,
) -> Result<Zeroizing<Vec<u8>>, String> {
    read_bounded_regular_file_with_privacy(path, maximum, true)
}

fn read_bounded_regular_file_with_privacy(
    path: &Path,
    maximum: usize,
    private: bool,
) -> Result<Zeroizing<Vec<u8>>, String> {
    let mut options = OpenOptions::new();
    options.read(true);
    #[cfg(target_os = "linux")]
    {
        use std::os::unix::fs::OpenOptionsExt;
        options.custom_flags(libc::O_NOFOLLOW | libc::O_CLOEXEC | libc::O_NONBLOCK);
    }
    let file = options
        .open(path)
        .map_err(|_| "cannot open HA TLS or replication-key file".to_owned())?;
    let metadata = file
        .metadata()
        .map_err(|_| "cannot inspect HA TLS or replication-key file".to_owned())?;
    if !metadata.is_file() || metadata.len() > maximum as u64 {
        return Err("HA material must be a bounded regular file".into());
    }
    #[cfg(unix)]
    if private {
        use std::os::unix::fs::PermissionsExt;
        if metadata.permissions().mode() & 0o077 != 0 {
            return Err("HA private material must be owner only".into());
        }
    }
    let mut bytes = Zeroizing::new(Vec::new());
    file.take(u64::try_from(maximum).map_err(|_| "HA file bound overflow".to_owned())? + 1)
        .read_to_end(&mut bytes)
        .map_err(|_| "cannot read HA TLS or replication-key file".to_owned())?;
    if bytes.len() > maximum {
        return Err("HA material exceeds limit".into());
    }
    Ok(bytes)
}

fn durable_state_exists(root: &Path) -> Result<bool, String> {
    let log = root.join("log");
    let state = root.join("state-machine");
    match (log.exists(), state.exists()) {
        (false, false) => Ok(false),
        (true, true) => Ok(true),
        _ => Err("partial HA durable state requires operator recovery".into()),
    }
}

fn encode_raft_frame(frame: RaftWireFrame) -> Result<Vec<u8>, RemoteRaftError> {
    if frame.legacy_v1
        || !valid_cluster_id(&frame.cluster_id)
        || frame.source == 0
        || frame.target == 0
        || frame.source == frame.target
        || !matches!(frame.role, RAFT_FRAME_REQUEST | RAFT_FRAME_RESPONSE)
        || frame.payload.is_empty()
    {
        return Err(RemoteRaftError::InvalidRpc);
    }
    let cluster_length =
        u16::try_from(frame.cluster_id.len()).map_err(|_| RemoteRaftError::InvalidRpc)?;
    let payload_length =
        u32::try_from(frame.payload.len()).map_err(|_| RemoteRaftError::InvalidRpc)?;
    let mut encoded =
        Vec::with_capacity(RAFT_FRAME_HEADER_BYTES + frame.cluster_id.len() + frame.payload.len());
    encoded.extend_from_slice(RAFT_FRAME_MAGIC);
    encoded.push(frame.role);
    encoded.extend_from_slice(&frame.source.to_be_bytes());
    encoded.extend_from_slice(&frame.target.to_be_bytes());
    encoded.push(kind_tag(frame.kind));
    encoded.extend_from_slice(&cluster_length.to_be_bytes());
    encoded.extend_from_slice(&payload_length.to_be_bytes());
    encoded.extend_from_slice(frame.cluster_id.as_bytes());
    encoded.extend_from_slice(&frame.payload);
    if encoded.len() > MAX_RAFT_FRAME_BYTES {
        return Err(RemoteRaftError::InvalidRpc);
    }
    Ok(encoded)
}

fn decode_raft_frame(encoded: &[u8]) -> Result<RaftWireFrame, RemoteRaftError> {
    if encoded.len() < RAFT_FRAME_HEADER_BYTES
        || encoded.len() > MAX_RAFT_FRAME_BYTES
        || &encoded[..5] != RAFT_FRAME_MAGIC
    {
        return Err(RemoteRaftError::InvalidRpc);
    }
    let role = encoded[5];
    if !matches!(role, RAFT_FRAME_REQUEST | RAFT_FRAME_RESPONSE) {
        return Err(RemoteRaftError::InvalidRpc);
    }
    let source = u64::from_be_bytes(
        encoded[6..14]
            .try_into()
            .map_err(|_| RemoteRaftError::InvalidRpc)?,
    );
    let target = u64::from_be_bytes(
        encoded[14..22]
            .try_into()
            .map_err(|_| RemoteRaftError::InvalidRpc)?,
    );
    let kind = decode_kind(encoded[22])?;
    let cluster_length = u16::from_be_bytes(
        encoded[23..25]
            .try_into()
            .map_err(|_| RemoteRaftError::InvalidRpc)?,
    ) as usize;
    let length = u32::from_be_bytes(
        encoded[25..29]
            .try_into()
            .map_err(|_| RemoteRaftError::InvalidRpc)?,
    ) as usize;
    let payload_start = RAFT_FRAME_HEADER_BYTES
        .checked_add(cluster_length)
        .ok_or(RemoteRaftError::InvalidRpc)?;
    if source == 0
        || target == 0
        || source == target
        || cluster_length == 0
        || cluster_length > MAX_CLUSTER_ID_BYTES
        || length == 0
        || encoded.len()
            != payload_start
                .checked_add(length)
                .ok_or(RemoteRaftError::InvalidRpc)?
    {
        return Err(RemoteRaftError::InvalidRpc);
    }
    let cluster_id = std::str::from_utf8(&encoded[RAFT_FRAME_HEADER_BYTES..payload_start])
        .map_err(|_| RemoteRaftError::InvalidRpc)?
        .to_owned();
    if !valid_cluster_id(&cluster_id) {
        return Err(RemoteRaftError::InvalidRpc);
    }
    Ok(RaftWireFrame {
        cluster_id,
        role,
        source,
        target,
        kind,
        payload: encoded[payload_start..].to_vec(),
        legacy_v1: false,
    })
}

fn encode_legacy_raft_frame_for_transition(
    frame: RaftWireFrame,
) -> Result<Vec<u8>, RemoteRaftError> {
    if !frame.legacy_v1
        || !valid_cluster_id(&frame.cluster_id)
        || frame.source == 0
        || frame.target == 0
        || frame.source == frame.target
        || !matches!(frame.role, RAFT_FRAME_REQUEST | RAFT_FRAME_RESPONSE)
        || matches!(
            frame.kind,
            RaftRpcKind::TransferLeader | RaftRpcKind::ReadIndex
        )
        || frame.payload.is_empty()
    {
        return Err(RemoteRaftError::InvalidRpc);
    }
    let payload_length =
        u32::try_from(frame.payload.len()).map_err(|_| RemoteRaftError::InvalidRpc)?;
    let mut encoded = Vec::with_capacity(LEGACY_RAFT_FRAME_HEADER_BYTES + frame.payload.len());
    encoded.extend_from_slice(RAFT_FRAME_MAGIC);
    encoded.push(frame.role);
    encoded.extend_from_slice(&frame.source.to_be_bytes());
    encoded.extend_from_slice(&frame.target.to_be_bytes());
    encoded.push(kind_tag(frame.kind));
    encoded.extend_from_slice(&payload_length.to_be_bytes());
    encoded.extend_from_slice(&frame.payload);
    if encoded.len() > MAX_RAFT_FRAME_BYTES {
        return Err(RemoteRaftError::InvalidRpc);
    }
    Ok(encoded)
}

fn decode_legacy_raft_frame_for_transition(
    encoded: &[u8],
    expected_cluster_id: &str,
) -> Result<RaftWireFrame, RemoteRaftError> {
    if !valid_cluster_id(expected_cluster_id) {
        return Err(RemoteRaftError::InvalidTopology);
    }
    if encoded.len() < LEGACY_RAFT_FRAME_HEADER_BYTES
        || encoded.len() > MAX_RAFT_FRAME_BYTES
        || &encoded[..5] != RAFT_FRAME_MAGIC
    {
        return Err(RemoteRaftError::InvalidRpc);
    }
    let role = encoded[5];
    if !matches!(role, RAFT_FRAME_REQUEST | RAFT_FRAME_RESPONSE) {
        return Err(RemoteRaftError::InvalidRpc);
    }
    let source = u64::from_be_bytes(
        encoded[6..14]
            .try_into()
            .map_err(|_| RemoteRaftError::InvalidRpc)?,
    );
    let target = u64::from_be_bytes(
        encoded[14..22]
            .try_into()
            .map_err(|_| RemoteRaftError::InvalidRpc)?,
    );
    let kind = decode_kind(encoded[22])?;
    let length = u32::from_be_bytes(
        encoded[23..27]
            .try_into()
            .map_err(|_| RemoteRaftError::InvalidRpc)?,
    ) as usize;
    if source == 0
        || target == 0
        || source == target
        || matches!(kind, RaftRpcKind::TransferLeader | RaftRpcKind::ReadIndex)
        || length == 0
        || encoded.len()
            != LEGACY_RAFT_FRAME_HEADER_BYTES
                .checked_add(length)
                .ok_or(RemoteRaftError::InvalidRpc)?
    {
        return Err(RemoteRaftError::InvalidRpc);
    }
    Ok(RaftWireFrame {
        cluster_id: expected_cluster_id.to_owned(),
        role,
        source,
        target,
        kind,
        payload: encoded[LEGACY_RAFT_FRAME_HEADER_BYTES..].to_vec(),
        legacy_v1: true,
    })
}

fn valid_cluster_id(value: &str) -> bool {
    if value.is_empty() || value.len() > MAX_CLUSTER_ID_BYTES {
        return false;
    }
    if value
        .bytes()
        .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'-' | b'_' | b'.'))
    {
        return true;
    }
    STANDARD
        .decode(value)
        .is_ok_and(|bytes| bytes.len() == 16 && STANDARD.encode(bytes) == value)
}

fn decode_raft_frame_for_cluster(
    encoded: &[u8],
    expected_cluster_id: &str,
) -> Result<RaftWireFrame, RemoteRaftError> {
    if !valid_cluster_id(expected_cluster_id) {
        return Err(RemoteRaftError::InvalidTopology);
    }
    let frame = decode_raft_frame(encoded)?;
    if frame.cluster_id != expected_cluster_id {
        return Err(RemoteRaftError::InvalidTopology);
    }
    Ok(frame)
}

fn decode_raft_frame_for_cluster_compatible(
    encoded: &[u8],
    expected_cluster_id: &str,
    allow_legacy_peer_v1: bool,
) -> Result<RaftWireFrame, RemoteRaftError> {
    match decode_raft_frame_for_cluster(encoded, expected_cluster_id) {
        Ok(frame) => Ok(frame),
        Err(strict_error) if allow_legacy_peer_v1 && encoded.starts_with(RAFT_FRAME_MAGIC) => {
            decode_legacy_raft_frame_for_transition(encoded, expected_cluster_id)
                .map_err(|_| strict_error)
        }
        Err(error) => Err(error),
    }
}

fn kind_tag(kind: RaftRpcKind) -> u8 {
    match kind {
        RaftRpcKind::AppendEntries => 1,
        RaftRpcKind::Vote => 2,
        RaftRpcKind::PreVote => 3,
        RaftRpcKind::SnapshotChunk => 4,
        RaftRpcKind::TransferLeader => 5,
        RaftRpcKind::ReadIndex => 6,
    }
}

fn decode_kind(value: u8) -> Result<RaftRpcKind, RemoteRaftError> {
    match value {
        1 => Ok(RaftRpcKind::AppendEntries),
        2 => Ok(RaftRpcKind::Vote),
        3 => Ok(RaftRpcKind::PreVote),
        4 => Ok(RaftRpcKind::SnapshotChunk),
        5 => Ok(RaftRpcKind::TransferLeader),
        6 => Ok(RaftRpcKind::ReadIndex),
        _ => Err(RemoteRaftError::InvalidRpc),
    }
}

fn map_remote_service_error(error: RemoteRaftError) -> heptabao_ha_service::HaError {
    match error {
        RemoteRaftError::InvalidTopology => heptabao_ha_service::HaError::InvalidCluster,
        RemoteRaftError::InvalidRpc | RemoteRaftError::InvalidSnapshot => {
            heptabao_ha_service::HaError::InvalidFrame
        }
        RemoteRaftError::Transport(_) | RemoteRaftError::Consensus(_) | RemoteRaftError::Io(_) => {
            heptabao_ha_service::HaError::Transport
        }
    }
}

struct ReplicatedChunkPlan<'a> {
    bytes: &'a [u8],
    reference: ReplicatedChunkRef,
    reused: bool,
}

fn validate_owner_binding(
    operation_id: &str,
    bytes: &[u8],
    binding: OwnerPublicationBinding,
) -> Result<(), String> {
    binding
        .verify(operation_id, bytes)
        .map_err(|_| "local owner publication does not bind the HA state".to_owned())
}

fn reject_legacy_mutation_fallback(descriptor: &CommittedStateDescriptor) -> Result<(), String> {
    if matches!(descriptor, CommittedStateDescriptor::Legacy(_)) {
        return Err(
            "legacy HA state requires explicit owner-manifest migration before mutation".into(),
        );
    }
    Ok(())
}

fn validate_legacy_migration_base(
    descriptor: &CommittedStateDescriptor,
    owner_bound: bool,
) -> Result<(), String> {
    if !owner_bound {
        return Err("legacy owner-manifest migration requires an owner publication binding".into());
    }
    if !matches!(descriptor, CommittedStateDescriptor::Legacy(_)) {
        return Err("legacy owner-manifest migration requires an HBSR1 base state".into());
    }
    Ok(())
}

fn plan_replicated_chunks<'a>(
    bytes: &'a [u8],
    previous: Option<&ReplicatedStateManifest>,
) -> Result<Vec<ReplicatedChunkPlan<'a>>, String> {
    let chunks = replicated_content_defined_chunks(bytes);
    if chunks.is_empty() || chunks.len() > MAX_REPLICATED_STATE_CHUNKS {
        return Err("HA content-defined chunk count exceeds bounded physical index space".into());
    }

    let previous_chunks = previous
        .map(|manifest| manifest.chunks.as_slice())
        .unwrap_or(&[]);
    let mut reserved = BTreeSet::new();
    let mut matches = Vec::with_capacity(chunks.len());
    for chunk in &chunks {
        let digest = sha256(chunk);
        let chunk_bytes =
            u32::try_from(chunk.len()).map_err(|_| "HA application chunk length overflow")?;
        let found = previous_chunks
            .iter()
            .find(|reference| {
                !reserved.contains(&reference.index)
                    && reference.digest == digest
                    && reference.bytes == chunk_bytes
            })
            .cloned();
        if let Some(reference) = found.as_ref() {
            reserved.insert(reference.index);
        }
        matches.push(found);
    }

    let old_by_index = previous_chunks
        .iter()
        .map(|reference| (reference.index, reference))
        .collect::<BTreeMap<_, _>>();
    let mut used = reserved;
    let mut plans = Vec::with_capacity(chunks.len());
    for (chunk, matched) in chunks.into_iter().zip(matches) {
        if let Some(reference) = matched {
            plans.push(ReplicatedChunkPlan {
                bytes: chunk,
                reference,
                reused: true,
            });
            continue;
        }
        let index = (0..MAX_REPLICATED_STATE_CHUNKS)
            .find_map(|value| {
                let index = u16::try_from(value).ok()?;
                (!used.contains(&index)).then_some(index)
            })
            .ok_or_else(|| "HA physical chunk index space exhausted".to_owned())?;
        used.insert(index);
        let slot = old_by_index
            .get(&index)
            .map_or(0, |reference| 1 - reference.slot);
        plans.push(ReplicatedChunkPlan {
            bytes: chunk,
            reference: ReplicatedChunkRef {
                index,
                slot,
                bytes: u32::try_from(chunk.len())
                    .map_err(|_| "HA application chunk length overflow")?,
                digest: sha256(chunk),
            },
            reused: false,
        });
    }
    Ok(plans)
}

fn replicated_content_defined_chunks(bytes: &[u8]) -> Vec<&[u8]> {
    let mut chunks = Vec::new();
    let mut start = 0_usize;
    let mut rolling = 0_u64;
    for (index, byte) in bytes.iter().copied().enumerate() {
        rolling = rolling.rotate_left(1) ^ replicated_chunk_byte_hash(byte);
        if index >= REPLICATED_CHUNK_WINDOW_BYTES {
            rolling ^= replicated_chunk_byte_hash(bytes[index - REPLICATED_CHUNK_WINDOW_BYTES])
                .rotate_left((REPLICATED_CHUNK_WINDOW_BYTES % u64::BITS as usize) as u32);
        }
        let length = index + 1 - start;
        if length >= REPLICATED_CHUNK_MIN_BYTES
            && ((rolling & REPLICATED_CHUNK_MASK) == 0 || length >= REPLICATED_STATE_CHUNK_BYTES)
        {
            chunks.push(&bytes[start..=index]);
            start = index + 1;
        }
    }
    if start < bytes.len() {
        chunks.push(&bytes[start..]);
    }
    chunks
}

fn replicated_chunk_byte_hash(byte: u8) -> u64 {
    let mut value = u64::from(byte).wrapping_add(0x9e37_79b9_7f4a_7c15);
    value = (value ^ (value >> 30)).wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value = (value ^ (value >> 27)).wrapping_mul(0x94d0_49bb_1331_11eb);
    value ^ (value >> 31)
}

fn chunk_operation_id(operation_id: &str, index: u16, slot: u8) -> String {
    let suffix = format!(":c:{index:03}:{slot}");
    let keep = operation_id
        .len()
        .min(128_usize.saturating_sub(suffix.len()));
    format!("{}{}", &operation_id[..keep], suffix)
}

fn decode_hex_32(value: &str) -> Result<[u8; 32], String> {
    if value.len() != 64 || !value.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        return Err("HA certificate digest must be 64 hex characters".into());
    }
    let mut output = [0_u8; 32];
    let bytes = value.as_bytes();
    for (index, output_byte) in output.iter_mut().enumerate() {
        let high = decode_hex_nibble(bytes[index * 2])?;
        let low = decode_hex_nibble(bytes[index * 2 + 1])?;
        *output_byte = (high << 4) | low;
    }
    Ok(output)
}

fn decode_hex_nibble(value: u8) -> Result<u8, String> {
    match value {
        b'0'..=b'9' => Ok(value - b'0'),
        b'a'..=b'f' => Ok(value - b'a' + 10),
        b'A'..=b'F' => Ok(value - b'A' + 10),
        _ => Err("invalid HA certificate digest".into()),
    }
}

fn sha256(bytes: &[u8]) -> [u8; 32] {
    let value = digest::digest(&digest::SHA256, bytes);
    let mut output = [0_u8; 32];
    output.copy_from_slice(value.as_ref());
    output
}

#[path = "ha_leader_status.rs"]
mod leader_status;

#[cfg(test)]
#[path = "ha_read_tests.rs"]
pub(crate) mod read_tests;

#[cfg(test)]
#[path = "ha_bootstrap_deadline_tests.rs"]
mod bootstrap_deadline_tests;

#[cfg(test)]
mod tests {
    use super::*;

    fn membership(voters: BTreeSet<u64>, committed: bool, joint: bool) -> MembershipObservation {
        MembershipObservation {
            local_id: 1,
            leader: Some(1),
            term: 7,
            membership_index: Some(11),
            committed,
            joint,
            nodes: voters.clone(),
            voters,
            applied_index: Some(11),
            snapshot_index: None,
            purged_index: None,
            peer_matched: BTreeMap::new(),
            peer_contact_ms: BTreeMap::new(),
        }
    }

    #[test]
    fn bootstrap_fence_can_close_only_from_exact_committed_non_joint_membership() {
        let expected = BTreeSet::from([1, 2, 3]);
        assert!(bootstrap_membership_complete(
            &expected,
            &membership(expected.clone(), true, false)
        ));
        assert!(!bootstrap_membership_complete(
            &expected,
            &membership(expected.clone(), false, false)
        ));
        assert!(!bootstrap_membership_complete(
            &expected,
            &membership(expected.clone(), true, true)
        ));
        assert!(!bootstrap_membership_complete(
            &expected,
            &membership(BTreeSet::from([1, 2]), true, false)
        ));
        assert!(!bootstrap_membership_complete(
            &expected,
            &membership(BTreeSet::from([1, 2, 3, 4]), true, false)
        ));
    }

    #[test]
    fn completed_bootstrap_history_waits_for_current_safe_membership() {
        let enrolled = BTreeSet::from([1, 2, 3, 4]);
        for current in [BTreeSet::new(), BTreeSet::from([1]), BTreeSet::from([1, 2])] {
            assert!(!bootstrap_membership_operational(
                &enrolled,
                &membership(current, true, false),
            ));
        }
        for current in [
            BTreeSet::from([1, 2, 3]),
            BTreeSet::from([2, 3, 4]),
            enrolled.clone(),
        ] {
            assert!(bootstrap_membership_operational(
                &enrolled,
                &membership(current, true, false),
            ));
        }
        assert!(!bootstrap_membership_operational(
            &enrolled,
            &membership(BTreeSet::from([1, 2, 3]), false, false),
        ));
        assert!(!bootstrap_membership_operational(
            &enrolled,
            &membership(BTreeSet::from([1, 2, 3]), true, true),
        ));
        assert!(!bootstrap_membership_operational(
            &enrolled,
            &membership(BTreeSet::from([1, 2, 9]), true, false),
        ));
    }

    #[test]
    fn legacy_bootstrap_marker_adoption_distinguishes_pending_from_later_topology() {
        let expected = BTreeSet::from([1, 2, 3, 4]);
        let enrolled = BTreeSet::from([1, 2, 3, 4, 5]);
        assert_eq!(
            legacy_bootstrap_marker_state(
                1,
                &expected,
                &enrolled,
                &membership(expected.clone(), true, false),
            ),
            Some(BootstrapMarkerState::Complete)
        );
        for current in [
            BTreeSet::from([1, 2, 3]),
            BTreeSet::from([2, 3, 4]),
            BTreeSet::from([1, 2, 3, 5]),
        ] {
            assert_eq!(
                legacy_bootstrap_marker_state(
                    1,
                    &expected,
                    &enrolled,
                    &membership(current, true, false),
                ),
                Some(BootstrapMarkerState::Complete)
            );
        }
        for current in [BTreeSet::new(), BTreeSet::from([1])] {
            assert_eq!(
                legacy_bootstrap_marker_state(
                    1,
                    &expected,
                    &enrolled,
                    &membership(current, true, false),
                ),
                Some(BootstrapMarkerState::Pending)
            );
        }
        for observed in [
            membership(BTreeSet::from([2]), true, false),
            membership(BTreeSet::from([1, 2]), true, false),
            membership(BTreeSet::from([1]), false, false),
            membership(BTreeSet::from([1]), true, true),
            membership(BTreeSet::from([1, 2, 3, 9]), true, false),
        ] {
            assert_eq!(
                legacy_bootstrap_marker_state(1, &expected, &enrolled, &observed,),
                None
            );
        }
    }

    #[test]
    fn bootstrap_admission_marker_is_bound_durable_and_recovers_partial_completion()
    -> Result<(), Box<dyn std::error::Error>> {
        let root = std::env::temp_dir().join(format!(
            "heptabao-bootstrap-marker-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)?
                .as_nanos()
        ));
        fs::create_dir(&root)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(&root, fs::Permissions::from_mode(0o700))?;
        }
        let raft = root.join("raft");
        fs::create_dir(&raft)?;
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(&raft, fs::Permissions::from_mode(0o700))?;
        }
        let voters = BTreeSet::from([1, 2, 3, 4]);
        assert!(BootstrapAdmission::load(&raft, "cluster-a", &voters)?.is_none());
        let admission = BootstrapAdmission::create_pending(&raft, "cluster-a", &voters)?;
        assert_eq!(
            BootstrapAdmission::load(&raft, "cluster-a", &voters)?
                .ok_or("pending marker missing")?
                .1,
            BootstrapMarkerState::Pending
        );
        let mut interrupted = OpenOptions::new().append(true).open(&admission.path)?;
        interrupted.write_all(&BOOTSTRAP_COMPLETE_SUFFIX[..3])?;
        interrupted.sync_all()?;
        drop(interrupted);
        assert_eq!(
            BootstrapAdmission::load(&raft, "cluster-a", &voters)?
                .ok_or("partial marker missing")?
                .1,
            BootstrapMarkerState::Pending
        );
        admission.mark_complete()?;
        admission.mark_complete()?;
        assert_eq!(
            BootstrapAdmission::load(&raft, "cluster-a", &voters)?
                .ok_or("complete marker missing")?
                .1,
            BootstrapMarkerState::Complete
        );
        assert!(BootstrapAdmission::load(&raft, "cluster-a", &BTreeSet::from([1, 2, 3])).is_err());
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn advertised_api_addresses_are_https_origins_with_no_request_or_header_input()
    -> Result<(), String> {
        for (input, expected) in [
            ("https://Bao.Example", "https://bao.example:443"),
            ("https://127.0.0.1:8200/", "https://127.0.0.1:8200"),
            ("https://[::1]:8200", "https://[::1]:8200"),
        ] {
            assert_eq!(parse_api_address(input)?, expected);
        }
        for input in [
            "http://bao.example:8200",
            "https://bao.example:0",
            "https://user@bao.example",
            "https://bao.example?token=secret",
            "https://bao.example/#fragment",
            "https://bao.example/v1/sys/health",
            "https://bao.example/../",
            "https://bao.example/%0d%0aLocation:x",
            "https://bao.example\r\nLocation: x",
            "https://bao.example\\@other.example",
        ] {
            assert!(parse_api_address(input).is_err());
        }
        let old: HaPeerConfig = serde_json::from_value(serde_json::json!({
            "node_name":"node-1", "address":"127.0.0.1:8201",
            "server_name":"node-1.example", "certificate_sha256":"11".repeat(32),
        }))
        .map_err(|_| "old peer configuration")?;
        assert!(old.api_address.is_none());
        assert!(old.cluster_address.is_none());
        assert!(old.certificate_sha256_next.is_none());
        let rotating: HaPeerConfig = serde_json::from_value(serde_json::json!({
            "node_name":"node-1", "address":"127.0.0.1:8201",
            "server_name":"node-1.example", "certificate_sha256":"11".repeat(32),
            "certificate_sha256_next":"22".repeat(32),
        }))
        .map_err(|_| "rotating peer configuration")?;
        assert_eq!(rotating.certificate_sha256_next, Some("22".repeat(32)));
        Ok(())
    }

    #[test]
    fn advertised_cluster_address_is_explicit_https_origin_with_no_network_effects()
    -> Result<(), String> {
        for (input, expected) in [
            (
                "https://Cluster.Example:8201/",
                "https://cluster.example:8201",
            ),
            ("https://127.0.0.1:18201", "https://127.0.0.1:18201"),
            ("https://[::1]:8201", "https://[::1]:8201"),
        ] {
            assert_eq!(parse_cluster_address(input)?, expected);
        }
        for input in [
            "http://cluster.example:8201",
            "https://cluster.example:0",
            "https://user@cluster.example:8201",
            "https://cluster.example:8201?token=secret",
            "https://cluster.example:8201/#fragment",
            "https://cluster.example:8201/v1/sys/leader",
            "https://cluster.example:8201/%0d%0aLocation:x",
            "https://cluster.example:8201\r\nLocation: x",
            "https://cluster.example:8201\\@other.example",
        ] {
            assert_eq!(
                parse_cluster_address(input),
                Err("invalid HA peer cluster address".to_owned())
            );
        }
        let admitted: HaPeerConfig = serde_json::from_value(serde_json::json!({
            "node_name":"node-1", "address":"127.0.0.1:18201",
            "server_name":"node-1.example", "certificate_sha256":"11".repeat(32),
            "api_address":"https://api.example:8200",
            "cluster_address":"https://cluster.example:8201/",
        }))
        .map_err(|_| "explicit cluster configuration")?;
        assert_eq!(
            admitted
                .cluster_address
                .as_deref()
                .map(parse_cluster_address)
                .transpose()?,
            Some("https://cluster.example:8201".to_owned())
        );
        // The advertised value is not a transport endpoint: the enrolled socket
        // and TLS name remain exactly the separately configured peer identity.
        assert_eq!(admitted.address.to_string(), "127.0.0.1:18201");
        assert_eq!(admitted.server_name, "node-1.example");
        Ok(())
    }

    #[test]
    fn forwarding_timeout_defaults_and_validation_do_not_change_peer_timeout()
    -> Result<(), Box<dyn std::error::Error>> {
        let legacy = serde_json::json!({
            "node_id":1,"cluster_id":"cluster-a","raft_dir":"/private/raft",
            "listen":"127.0.0.1:8201","ca_file":"/private/ca",
            "cert_file":"/private/cert","key_file":"/private/key",
            "replication_key_file":"/private/replication",
            "peer_timeout_ms":500,
            "peers": {
                "1":{"node_name":"n1","address":"127.0.0.1:8201","server_name":"n1.invalid","certificate_sha256":"11".repeat(32)},
                "2":{"node_name":"n2","address":"127.0.0.1:8202","server_name":"n2.invalid","certificate_sha256":"22".repeat(32)},
                "3":{"node_name":"n3","address":"127.0.0.1:8203","server_name":"n3.invalid","certificate_sha256":"33".repeat(32)}
            }
        });
        let mut config: HaProcessConfig = serde_json::from_value(legacy.clone())?;
        assert_eq!(config.peer_timeout_ms, 500);
        assert_eq!(config.forward_timeout_ms, 15_000);
        assert!(!config.allow_legacy_peer_v1);
        validate_config(&config)?;
        for value in [1_000, 15_000, 60_000] {
            config.forward_timeout_ms = value;
            validate_config(&config)?;
            assert_eq!(config.peer_timeout_ms, 500);
        }
        for value in [0, 999, 60_001, u64::MAX] {
            config.forward_timeout_ms = value;
            assert!(validate_config(&config).is_err());
        }
        config.forward_timeout_ms = 15_000;
        config.peer_timeout_ms = 5_001;
        assert!(validate_config(&config).is_err());
        let mut defaults = legacy;
        defaults
            .as_object_mut()
            .ok_or("config object")?
            .remove("peer_timeout_ms");
        let config: HaProcessConfig = serde_json::from_value(defaults)?;
        assert_eq!(config.peer_timeout_ms, 750);
        assert_eq!(config.forward_timeout_ms, 15_000);
        Ok(())
    }

    #[test]
    fn invalid_cluster_identity_is_rejected_before_peer_validation() -> Result<(), String> {
        let config = HaProcessConfig {
            node_id: 0,
            cluster_id: "cluster/with-invalid-delimiter".into(),
            raft_dir: PathBuf::new(),
            listen: "127.0.0.1:1"
                .parse()
                .map_err(|_| "synthetic listener address")?,
            ca_file: PathBuf::new(),
            cert_file: PathBuf::new(),
            key_file: PathBuf::new(),
            replication_key_file: PathBuf::new(),
            peers: BTreeMap::new(),
            bootstrap: false,
            initial_voters: None,
            peer_timeout_ms: 750,
            forward_timeout_ms: 15_000,
            max_inflight: 64,
            allow_legacy_peer_v1: false,
            emit_legacy_peer_v1: None,
        };
        assert_eq!(
            validate_config(&config),
            Err("invalid HA cluster identity".into())
        );
        Ok(())
    }

    #[test]
    fn zero_listener_port_is_rejected_for_static_peer_enrollment() -> Result<(), String> {
        let config = HaProcessConfig {
            node_id: 1,
            cluster_id: "cluster-a".into(),
            raft_dir: PathBuf::from("/var/lib/heptabao/node-1/raft"),
            listen: "127.0.0.1:0"
                .parse()
                .map_err(|_| "synthetic listener address")?,
            ca_file: PathBuf::from("/var/lib/heptabao/ca.crt"),
            cert_file: PathBuf::from("/var/lib/heptabao/node-1/tls.crt"),
            key_file: PathBuf::from("/var/lib/heptabao/node-1/tls.key"),
            replication_key_file: PathBuf::from("/var/lib/heptabao/replication.key"),
            peers: BTreeMap::from([
                (
                    1,
                    HaPeerConfig {
                        node_name: "node-1".into(),
                        api_address: None,
                        cluster_address: None,
                        address: "127.0.0.1:8201".parse().map_err(|_| "peer address")?,
                        server_name: "node-1.example.internal".into(),
                        certificate_sha256: "11".repeat(32),
                        certificate_sha256_next: None,
                    },
                ),
                (
                    2,
                    HaPeerConfig {
                        node_name: "node-2".into(),
                        api_address: None,
                        cluster_address: None,
                        address: "127.0.0.1:8202".parse().map_err(|_| "peer address")?,
                        server_name: "node-2.example.internal".into(),
                        certificate_sha256: "22".repeat(32),
                        certificate_sha256_next: None,
                    },
                ),
                (
                    3,
                    HaPeerConfig {
                        node_name: "node-3".into(),
                        api_address: None,
                        cluster_address: None,
                        address: "127.0.0.1:8203".parse().map_err(|_| "peer address")?,
                        server_name: "node-3.example.internal".into(),
                        certificate_sha256: "33".repeat(32),
                        certificate_sha256_next: None,
                    },
                ),
            ]),
            bootstrap: false,
            initial_voters: None,
            peer_timeout_ms: 750,
            forward_timeout_ms: 15_000,
            max_inflight: 64,
            allow_legacy_peer_v1: false,
            emit_legacy_peer_v1: None,
        };
        assert_eq!(
            validate_config(&config),
            Err("invalid bounded HA process configuration".into())
        );
        Ok(())
    }

    #[test]
    fn raft_wire_frame_binds_direction_kind_and_payload() -> Result<(), Box<dyn std::error::Error>>
    {
        for kind in [
            RaftRpcKind::AppendEntries,
            RaftRpcKind::Vote,
            RaftRpcKind::PreVote,
            RaftRpcKind::SnapshotChunk,
            RaftRpcKind::TransferLeader,
            RaftRpcKind::ReadIndex,
        ] {
            let encoded = encode_raft_frame(RaftWireFrame {
                cluster_id: "cluster-a".into(),
                role: RAFT_FRAME_REQUEST,
                source: 1,
                target: 2,
                kind,
                payload: b"bounded-raft-rpc".to_vec(),
                legacy_v1: false,
            })?;
            let decoded = decode_raft_frame(&encoded)?;
            assert_eq!(decoded.cluster_id, "cluster-a");
            assert_eq!(decoded.role, RAFT_FRAME_REQUEST);
            assert_eq!(decoded.source, 1);
            assert_eq!(decoded.target, 2);
            assert_eq!(decoded.kind, kind);
            assert_eq!(decoded.payload, b"bounded-raft-rpc");
        }
        assert!(decode_kind(7).is_err());
        Ok(())
    }

    #[test]
    fn ha_commit_rejects_owner_binding_for_different_operation_or_state()
    -> Result<(), Box<dyn std::error::Error>> {
        let logical = br#"{"schema":9,"cluster_id":"cluster"}"#;
        let plan = crate::service::OwnerWritePlan::new(
            logical,
            "owner-op-binding",
            9,
            "cluster",
            0,
            vec![
                ("namespaces", br#"{"next_incarnation":1}"#.to_vec()),
                ("auth", br#"{"tokens":[]}"#.to_vec()),
                ("engines", br#"{"mounts":[]}"#.to_vec()),
                ("database", br#"{"connections":[]}"#.to_vec()),
                ("raft_admin", br#"{"policy":null}"#.to_vec()),
            ],
            None,
            Vec::new(),
        )?;
        let binding = plan.publication_binding("owner-op-binding", logical)?;
        assert!(validate_owner_binding("owner-op-binding", logical, binding).is_ok());
        assert!(validate_owner_binding("owner-op-other", logical, binding).is_err());
        let mut altered = logical.to_vec();
        altered[0] ^= 1;
        assert!(validate_owner_binding("owner-op-binding", &altered, binding).is_err());
        Ok(())
    }

    #[test]
    fn ha_commit_rejects_legacy_whole_state_fallback() -> Result<(), Box<dyn std::error::Error>> {
        let legacy = CommittedStateDescriptor::Legacy(Zeroizing::new(b"legacy-state".to_vec()));
        let error = match reject_legacy_mutation_fallback(&legacy) {
            Ok(()) => return Err("mutation must not promote HBSR1 implicitly".into()),
            Err(error) => error,
        };
        assert!(error.contains("explicit owner-manifest migration"));
        Ok(())
    }

    #[test]
    fn legacy_migration_requires_owner_binding_and_hbsr1_base() {
        let legacy = CommittedStateDescriptor::Legacy(Zeroizing::new(b"legacy-state".to_vec()));
        assert!(validate_legacy_migration_base(&legacy, false).is_err());
        assert!(validate_legacy_migration_base(&legacy, true).is_ok());

        let manifest = CommittedStateDescriptor::Chunked(ReplicatedStateManifest {
            base_digest: [0; 32],
            state_digest: [7; 32],
            total_bytes: 0,
            chunks: Vec::new(),
            owner_manifest_digest: None,
            changed_owner_mask: None,
        });
        assert!(validate_legacy_migration_base(&manifest, true).is_err());
    }

    #[test]
    fn raft_wire_frame_rejects_direction_and_length_drift() -> Result<(), Box<dyn std::error::Error>>
    {
        let mut encoded = encode_raft_frame(RaftWireFrame {
            cluster_id: "cluster-a".into(),
            role: RAFT_FRAME_RESPONSE,
            source: 2,
            target: 1,
            kind: RaftRpcKind::Vote,
            payload: b"vote".to_vec(),
            legacy_v1: false,
        })?;
        encoded[26] ^= 1;
        assert!(decode_raft_frame(&encoded).is_err());
        let cross_cluster = encode_raft_frame(RaftWireFrame {
            cluster_id: "cluster-b".into(),
            role: RAFT_FRAME_REQUEST,
            source: 1,
            target: 2,
            kind: RaftRpcKind::Vote,
            payload: b"vote".to_vec(),
            legacy_v1: false,
        })?;
        let decoded = decode_raft_frame(&cross_cluster)?;
        assert_ne!(decoded.cluster_id, "cluster-a");
        assert!(decode_raft_frame_for_cluster(&cross_cluster, "cluster-a").is_err());
        Ok(())
    }

    #[test]
    fn legacy_raft_wire_is_explicit_transition_only() -> Result<(), Box<dyn std::error::Error>> {
        let legacy = encode_legacy_raft_frame_for_transition(RaftWireFrame {
            cluster_id: "cluster-a".into(),
            role: RAFT_FRAME_REQUEST,
            source: 1,
            target: 2,
            kind: RaftRpcKind::Vote,
            payload: b"legacy-vote".to_vec(),
            legacy_v1: true,
        })?;
        assert!(decode_raft_frame(&legacy).is_err());
        assert!(decode_raft_frame_for_cluster_compatible(&legacy, "cluster-a", false).is_err());
        let decoded = decode_raft_frame_for_cluster_compatible(&legacy, "cluster-a", true)?;
        assert!(decoded.legacy_v1);
        assert_eq!(decoded.cluster_id, "cluster-a");
        assert_eq!(decoded.source, 1);
        assert_eq!(decoded.target, 2);
        assert_eq!(decoded.kind, RaftRpcKind::Vote);
        assert_eq!(decoded.payload, b"legacy-vote");

        assert!(
            encode_raft_frame(RaftWireFrame {
                cluster_id: "cluster-a".into(),
                role: RAFT_FRAME_REQUEST,
                source: 1,
                target: 2,
                kind: RaftRpcKind::Vote,
                payload: b"strict".to_vec(),
                legacy_v1: true,
            })
            .is_err()
        );
        assert!(
            encode_legacy_raft_frame_for_transition(RaftWireFrame {
                cluster_id: "cluster-a".into(),
                role: RAFT_FRAME_REQUEST,
                source: 1,
                target: 2,
                kind: RaftRpcKind::TransferLeader,
                payload: b"transfer".to_vec(),
                legacy_v1: true,
            })
            .is_err()
        );
        Ok(())
    }

    #[test]
    fn dropping_peer_pool_stops_and_joins_every_worker() -> Result<(), Box<dyn std::error::Error>> {
        let stop = Arc::new(AtomicBool::new(false));
        let (sender, receiver) = std::sync::mpsc::channel();
        let mut pool = PeerListener {
            shutdown_supervisor: peer_shutdown::PeerShutdownSupervisor::global()?,
            shutdown_receipt: Arc::new(peer_shutdown::PeerNodeShutdownReceipt::default()),
            stop: stop.clone(),
            workers: Vec::new(),
            #[cfg(all(
                feature = "native-v6-ha",
                any(test, feature = "experimental-native-v6-ha")
            ))]
            native_capacity_installed: false,
        };
        for _ in 0..4 {
            let flag = stop.clone();
            let sender = sender.clone();
            pool.workers.push(thread::spawn(move || {
                while !flag.load(Ordering::Acquire) {
                    thread::yield_now();
                }
                let _ = sender.send(());
            }));
        }
        drop(pool);
        assert!(stop.load(Ordering::Acquire));
        for _ in 0..4 {
            receiver.recv_timeout(Duration::from_secs(1))?;
        }
        Ok(())
    }

    #[test]
    fn position_independent_chunk_plan_reuses_tail_after_prefix_insertion()
    -> Result<(), Box<dyn std::error::Error>> {
        const STATE_BYTES: usize = 4 * 1024 * 1024;
        let mut state = Vec::with_capacity(STATE_BYTES);
        let mut value = 0x1234_5678_9abc_def0_u64;
        for _ in 0..STATE_BYTES {
            value ^= value << 13;
            value ^= value >> 7;
            value ^= value << 17;
            state.push((value >> 24) as u8);
        }
        let first = plan_replicated_chunks(&state, None)?;
        assert!(first.len() >= 8);
        let previous = ReplicatedStateManifest {
            base_digest: [1; 32],
            state_digest: sha256(&state),
            total_bytes: u64::try_from(state.len())?,
            chunks: first.iter().map(|plan| plan.reference.clone()).collect(),
            owner_manifest_digest: None,
            changed_owner_mask: None,
        };

        let insertion = b"ha-prefix-insertion-".repeat(7);
        let mut changed = Vec::with_capacity(state.len() + insertion.len());
        changed.extend_from_slice(&state[..96 * 1024]);
        changed.extend_from_slice(&insertion);
        changed.extend_from_slice(&state[96 * 1024..]);
        let second = plan_replicated_chunks(&changed, Some(&previous))?;
        let reused = second.iter().filter(|plan| plan.reused).count();
        assert!(
            reused >= previous.chunks.len().saturating_sub(2),
            "content-defined HA chunking should resynchronize and preserve most physical indices"
        );
        assert_eq!(
            second
                .iter()
                .map(|plan| plan.reference.index)
                .collect::<BTreeSet<_>>()
                .len(),
            second.len()
        );
        Ok(())
    }

    #[test]
    fn changed_chunk_uses_opposite_slot_without_overwriting_previous_manifest()
    -> Result<(), Box<dyn std::error::Error>> {
        let state = vec![0x5a; 512 * 1024];
        let first = plan_replicated_chunks(&state, None)?;
        let previous = ReplicatedStateManifest {
            base_digest: [2; 32],
            state_digest: sha256(&state),
            total_bytes: u64::try_from(state.len())?,
            chunks: first.iter().map(|plan| plan.reference.clone()).collect(),
            owner_manifest_digest: None,
            changed_owner_mask: None,
        };
        let mut changed = state.clone();
        changed[0] ^= 1;
        let next = plan_replicated_chunks(&changed, Some(&previous))?;
        for plan in next.iter().filter(|plan| !plan.reused) {
            if let Some(old) = previous
                .chunks
                .iter()
                .find(|old| old.index == plan.reference.index)
            {
                assert_eq!(plan.reference.slot, 1 - old.slot);
            }
        }
        Ok(())
    }

    #[test]
    fn certificate_digest_is_strict_hex() {
        assert_eq!(decode_hex_32(&"ab".repeat(32)), Ok([0xab; 32]));
        assert!(decode_hex_32("ab").is_err());
        assert!(decode_hex_32(&"gg".repeat(32)).is_err());
    }
}

#[cfg(test)]
#[path = "ha_request_deadline_tests.rs"]
pub(crate) mod request_deadline_tests;

#[cfg(test)]
#[path = "ha_snapshot_test_support.rs"]
pub(crate) mod snapshot_test_support;

#[cfg(test)]
#[path = "ha_peer_wire_upgrade_tests.rs"]
mod peer_wire_upgrade_tests;

#[cfg(test)]
#[path = "ha_rpc_deadline_tests.rs"]
mod rpc_deadline_tests;
