#!/usr/bin/env python3
"""Read-only candidate and final recovery evidence gates.

The old runtime module is imported at its fixed SHA, without modifying its
STAGES or monkey-patching functions. Its original worker/RPC/output validators
are reused under a separate explicit four-stage policy and exact argv binding.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
CORE_SHA = "209aaa29adbb9c89eb060b8349ecc4519e45fbc1b5ca92a687a6fededf64f46d"
RUNTIME_SHA = "b9f2d80cbdc797b02b835cf913aeff3b13e9c2a2076cf548a3fd6655fed36e79"
GATE_SHA = "cb59884d7d1de41797062c698064169b6a9b6ec584a9a772faeadb8c13c27499"
FULL34_CONTROLLER_SHA = "4d82e3c71b431c96b390931760ed9831bbca0ae009947521dbf78ca4f1af8018"
CUSTODY_SHA = "c32a4f3091a1ff7b105ac54099fbdeaf68c6e9aeb41aa5ff829b507857ee31cb"
PREREQUISITES = ("mac_build", "mac_server", "mac_ha", "mac_aggregate", "linux_release",
                 "linux_libtest", "linux_server", "linux_ha", "linux_aggregate", "full34")
RECOVERY_STAGES = ("backup", "mac_oracle", "linux_target", "source_verify")
FINAL_SCHEMA = "heptabao.formal-kv2-cold-recovery.v3"


def load_file_module(binding, name, expected):
    path = Path(binding["path"])
    if binding["sha256"] != expected or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError("fixed_admission_module_changed")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


core = load_file_module({"path": str(HERE / "formal_kv2_recovery_core.py"), "sha256": CORE_SHA},
                        "formal_recovery_gate_core", CORE_SHA)
need = core.need


def runtime_module(binding):
    return load_file_module(binding, "formal_recovery_original_runtime", RUNTIME_SHA)


def value_arg(argv, name):
    need(isinstance(argv, list) and argv.count(name) == 1 and argv.index(name) + 1 < len(argv),
         "unique_original_argument")
    return argv[argv.index(name) + 1]


def validate_candidate(binding):
    plan = core.pinned(binding)
    need(set(plan) == {"schema", "source", "source_commit", "source_tree", "linux_builder_host",
                      "cross_host_gate", "cross_host_inputs", "runtime_validator", "executor_bindings",
                      "mac_build", "full34", "full34_semantics"}, "candidate_plan_exact_fields")
    need(plan["schema"] == "heptabao.formal-kv2-recovery-candidate-plan.v2", "candidate_plan_schema")
    need(all(re.fullmatch(r"[0-9a-f]{40}", plan[k]) for k in ("source_commit", "source_tree")),
         "candidate_commit_tree")
    gate = load_file_module(plan["cross_host_gate"], "formal_recovery_cross_host", GATE_SHA)
    inputs = core.pinned(plan["cross_host_inputs"])
    need((inputs["source"], inputs["commit"], inputs["tree"]) ==
         (plan["source"], plan["source_commit"], plan["source_tree"]), "candidate_source_same_as_gate")
    admission = gate.validate_inputs(inputs)
    need(inputs["schema"] == "heptabao.full34-cross-host-admission-inputs.v3"
         and inputs["linux_host"] == plan["linux_builder_host"] == admission["actual_linux_host"]
         and admission["schema"] == "heptabao.full34-cross-host-regression-admission.v3"
         and admission["original_executor_terminal_paths_and_bytes_bound"] is True
         and admission["required_observer_tests_each_host"] == 16
         and admission["required_actual_executor_stages"] == 13
         and admission["runtime_prerequisites"]["required"] == admission["runtime_prerequisites"]["passed"] == 13,
         "actual_original181_observer16_and_thirteen_executor_contract")
    built = core.pinned(plan["mac_build"])
    need(plan["mac_build"]["path"] == inputs["build_result"], "candidate_mac_build_origin")
    full = core.pinned(plan["full34"])
    semantics = core.load_full34_semantics(plan["full34_semantics"])
    need(full["schema"] == "heptabao.unified-formal-file-kv2-full34.v1"
         and full["controller_sha256"] == FULL34_CONTROLLER_SHA
         and full["driver_sha256"] == core.FULL34_DRIVER_SHA256
         and full["custody_module_sha256"] == CUSTODY_SHA, "frozen_original_full31_implementation")
    need(full["status"] == "passed" and full["full34_qualified"] is True
         and full["passed_count"] == full["required_count"] == 31
         and len(full["required_checks"]) == 31 and set(full["required_checks"]) == set(semantics.CHECKS),
         "original_full31_complete_denominator")
    need(full["exit_code"] == 0 and full["timed_out"] is False and full["automatic_retry"] is False
         and full["submission_count"] == 1 and full["owned_child_reaped"] is True
         and full["owned_group_survivors"] == [] and full["all_owned_processes_reconciled"] is True
         and full["source_unchanged"] is True and full["binary_unchanged"] is True, "original_full31_owned_integrity")
    need((full["source_commit"], full["source_tree"]) == (plan["source_commit"], plan["source_tree"])
         and full["build_result_sha256"] == plan["mac_build"]["sha256"]
         and full["regression_result_sha256"] == inputs["regression_sha256"], "full31_same_candidate_chain")
    need(full["binary_sha256"] == admission["mac"]["server_sha256"]
         and full["linux_server_sha256"] == admission["linux"]["server_sha256"]
         and full["linux_aggregate_sha256"] == inputs["linux_aggregate_sha256"]
         and full["cross_host_gate_module_sha256"] == GATE_SHA
         and full["required_observer_tests_each_host"] == 16
         and full["required_actual_executor_stages"] == 13
         and full["observer_admission_sha256"] == admission["observer_admission_sha256"]
         and full["cross_host_admission_sha256"] == hashlib.sha256(core.canonical(admission)).hexdigest(),
         "full31_exact_dual_host_admission")
    work = Path(value_arg(full["argv"], "--private-work-root"))
    need(work == Path(plan["full34"]["path"]).parent / "private-run"
         and work.resolve(strict=True) == work, "original_full31_work_path")
    summary_binding = {"path": str(work / "summary.json"), "sha256": full["summary_sha256"]}
    summary = core.pinned(summary_binding, private=True)
    rows = summary["checks"]
    need(summary["status"] == "passed" and summary["full34_qualified"] is True
         and len(rows) == 31 and {r["case"] for r in rows} == set(semantics.CHECKS)
         and all(r["passed"] is True for r in rows) and summary["missing_checks"] == []
         and summary["live_payload_bytes"] == 35651584
         and summary["candidate_startup"]["storage_profile"] == "native_v6_file"
         and summary["candidate_startup"]["fixture_options"] is False, "actual_original_full31_summary")
    need(summary["production_authority"] is False and summary["replacement_authority"] is False
         and full["production_changed"] is False, "isolated_full31_scope")
    mac = core.pinned({"path": inputs["regression_result"], "sha256": inputs["regression_sha256"]})
    linux = core.pinned({"path": inputs["linux_aggregate"], "sha256": inputs["linux_aggregate_sha256"]})
    mac_children = {r["suite"]: r for r in mac["children"]}
    linux_children = {r["suite"]: r for r in linux["children"]}
    linux_prep = core.pinned({"path": inputs["linux_preparation"], "sha256": inputs["linux_preparation_sha256"]})
    linux_build = core.pinned({"path": inputs["linux_libtest_build"], "sha256": inputs["linux_libtest_build_sha256"]})
    linux_root = Path(linux_prep["controller_path"]).parent.parent
    def result(path, sha, runtime_path=None):
        return {"path": path, "sha256": sha, "runtime_path": path if runtime_path is None else runtime_path}
    expected = {
        "mac_build": result(plan["mac_build"]["path"], plan["mac_build"]["sha256"]),
        "mac_server": result(mac_children["server"]["path"], mac_children["server"]["sha256"]),
        "mac_ha": result(mac_children["ha"]["path"], mac_children["ha"]["sha256"]),
        "mac_aggregate": result(inputs["regression_result"], inputs["regression_sha256"]),
        "linux_release": result(inputs["linux_release_controller"], inputs["linux_release_controller_sha256"],
                                linux_build["normal_release_result_path"]),
        "linux_libtest": result(inputs["linux_libtest_build"], inputs["linux_libtest_build_sha256"],
                                str(linux_root / "libtest-build-r1/build-result.public.json")),
        "linux_server": result(inputs["linux_server_result"], inputs["linux_server_result_sha256"], linux_children["server"]["path"]),
        "linux_ha": result(inputs["linux_ha_result"], inputs["linux_ha_result_sha256"], linux_children["ha"]["path"]),
        "linux_aggregate": result(inputs["linux_aggregate"], inputs["linux_aggregate_sha256"], str(linux_root / "regression-r1/result.public.json")),
        "full34": result(plan["full34"]["path"], plan["full34"]["sha256"]),
    }
    runtime = runtime_module(plan["runtime_validator"])
    executors = runtime.validate_runtime_prerequisites(plan["executor_bindings"], required_stages=PREREQUISITES,
                                                       expected_results=expected, linux_host=plan["linux_builder_host"])
    need({r["stage"]: r for r in executors["rows"] if r["stage"] != "full34"}
         == {r["stage"]: r for r in admission["original_runtime_prerequisites"]["rows"]},
         "same_nine_original_executor_rows_as_original181_gate")
    original_full31 = [r for r in executors["rows"] if r["stage"] == "full34"]
    joined = admission["runtime_prerequisites"]["rows"] + original_full31
    expected_stages = set(PREREQUISITES) | {
        "mac_observer_build", "mac_observer16", "linux_observer_build", "linux_observer16"}
    need(len(original_full31) == 1 and len(joined) == 14
         and {r["stage"] for r in joined} == expected_stages
         and len({(r["host"], r["job_id"]) for r in joined}) == 14,
         "same_candidate_fourteen_distinct_original_jobs")
    need(all(r["host"] == (plan["linux_builder_host"] if r["stage"].startswith("linux_") else "mac")
             for r in joined), "fourteen_graph_actual_hosts")
    complete_executors = {
        "schema": "heptabao.formal-kv2-fourteen-runtime-admission.v1", "status": "admitted",
        "required": 14, "passed": 14, "linux_host": plan["linux_builder_host"],
        "original_ten": executors,
        "observer_four": admission["observer_admission"]["runtime_admission"],
        "rows": sorted(joined, key=lambda r: r["stage"]),
        "suite_derivatives_not_relabelled_as_executors": True,
    }
    return {"schema": "heptabao.formal-kv2-recovery-candidate-admission.v2", "status": "admitted",
            "source_commit": plan["source_commit"], "source_tree": plan["source_tree"],
            "candidate_plan": binding, "cross_host_admission": admission, "original_executors": complete_executors,
            "full34": plan["full34"], "full34_summary": summary_binding, "original_work_root": str(work),
            "mac_server_sha256": admission["mac"]["server_sha256"], "linux_server_sha256": admission["linux"]["server_sha256"],
            "original31_retained": True, "observer16_each_host_retained": True,
            "actual_prerequisite_jobs": 14, "products_started": False}


def validate_recovery_executors(binding, *, runtime_binding, expected_results, expected_invocations,
                                target_host, prerequisite_jobs):
    runtime = runtime_module(runtime_binding)
    index = runtime.pinned(binding)
    need(set(index) == {"schema", "jobs"} and index["schema"] == "heptabao.formal-kv2-recovery-executor-bindings.v1",
         "recovery_runtime_index_schema")
    rows = index["jobs"]
    need(isinstance(rows, list) and len(rows) == 4 and {r["stage"] for r in rows} == set(RECOVERY_STAGES)
         and all(set(r) == runtime.ROW_FIELDS for r in rows), "recovery_runtime_exact_four_stages")
    need(target_host in ("x230", "rog", "pocket4"), "actual_recovery_linux_host")
    need(set(expected_results) == set(expected_invocations) == set(RECOVERY_STAGES), "recovery_runtime_expected_denominator")
    pairs = {(r["host"], r["job_id"]) for r in rows}
    need(len(pairs) == 4 and not pairs.intersection(set(map(tuple, prerequisite_jobs))), "reused_recovery_or_prerequisite_job")
    verified = []
    for row in rows:
        stage, expected = row["stage"], expected_results[row["stage"]]
        need(row["host"] == (target_host if stage == "linux_target" else "mac"), "recovery_actual_stage_host")
        need(set(expected) == {"path", "sha256", "runtime_path"}
             and row["result"] == {"path": expected["path"], "sha256": expected["sha256"]}, "recovery_result_binding")
        if row["host"] == "mac":
            need(expected["path"] == expected["runtime_path"], "mac_recovery_result_origin")
        result = runtime.pinned(row["result"])
        worker, started = runtime.worker_files(row)
        api = runtime.api_originals(row, worker)
        terminal = runtime.terminal_record(row, worker, started)
        output = runtime.complete_output(row, terminal)
        # All recovery stages emit exactly one final object. They are explicit
        # recovery names; no product/recovery job is relabelled as a regression.
        lines = [line for line in output["stdout"].splitlines() if line.strip()]
        need(len(lines) == 1 and output["stderr"] == b"", "recovery_unique_complete_stdout")
        final = runtime.decode(lines[0])
        need(set(final) == {"status", "result", "result_sha256", "production_changed"}
             and final["status"] == result["status"] == "passed" and final["production_changed"] is False
             and final["result"] == expected["runtime_path"] and final["result_sha256"] == expected["sha256"],
             "recovery_terminal_stdout_exact_result")
        invocation = expected_invocations[stage]
        need(set(invocation) == {"executable", "args", "cwd", "timeout_seconds", "nice", "spec_sha256", "driver_sha256"},
             "recovery_expected_invocation_fields")
        need(all(worker[key] == invocation[key] for key in ("executable", "args", "cwd", "timeout_seconds", "nice")),
             "recovery_original_invocation_mismatch")
        need(value_arg(worker["args"], "--stage") == stage
             and value_arg(worker["args"], "--spec-sha256") == invocation["spec_sha256"]
             and value_arg(worker["args"], "--output") == str(Path(expected["runtime_path"]).parent)
             and "--admission-only" not in worker["args"] and result["controller_sha256"] == invocation["driver_sha256"],
             "recovery_actual_full_stage_invocation")
        verified.append({"stage": stage, "host": row["host"], "job_id": row["job_id"],
                         "launch_nonce": worker["launch_nonce"], "request_digest": worker["request_digest"],
                         "result": expected, "original_api": api, "worker_request": row["worker_request"],
                         "terminal_capture": row["terminal_capture"], "read_captures": row["read_captures"],
                         "worker_started": row["worker_started"], "worker_capture": row["worker_capture"],
                         "started_at_unix_ms": started["at_unix_ms"], "terminal_at_unix_ms": terminal["at_unix_ms"],
                         "stdout_sha256": hashlib.sha256(output["stdout"]).hexdigest(),
                         "complete_stdout_bytes": len(output["stdout"]), "original_invocation": invocation})
    return {"schema": "heptabao.formal-kv2-recovery-runtime-admission.v1", "status": "admitted",
            "runtime_module_sha256": RUNTIME_SHA, "required": 4, "passed": 4,
            "index": binding, "target_host": target_host, "rows": sorted(verified, key=lambda x: x["stage"])}


def mapped_stage_binding(row, binding):
    """Map an original worker output path to its exact retained local copy."""
    need(isinstance(binding, dict) and set(binding) == {"path", "sha256"}
         and core.HEX64.fullmatch(binding["sha256"]), "stage_artifact_binding")
    path = core.absolute(binding["path"])
    origin = core.absolute(row["runtime_result_path"]).parent
    need(path != origin and path.is_relative_to(origin), "stage_artifact_original_output_scope")
    return {"path": str(Path(row["result"]["path"]).parent / path.relative_to(origin)), "sha256": binding["sha256"]}


def private_stage_json(row, binding, full31=None, maximum=128 * core.MIB):
    mapped = mapped_stage_binding(row, binding)
    raw = core.read_bytes(mapped["path"], maximum)
    need(hashlib.sha256(raw).hexdigest() == mapped["sha256"], "stage_private_artifact_changed")
    return full31.decode(raw) if full31 is not None else core.decode_json(raw)


def stage_leaf(row, runtime_path, maximum=core.MIB):
    origin = core.absolute(row["runtime_result_path"]).parent
    path = core.absolute(runtime_path)
    need(path != origin and path.is_relative_to(origin), "owned_receipt_original_output_scope")
    return core.decode_json(core.read_bytes(Path(row["result"]["path"]).parent / path.relative_to(origin), maximum))


def check_owned_runtime(driver, row, stage, spec, binary_sha256):
    expected_product_count = 1 if row["stage"] == "mac_oracle" else 3
    expected_probe_count = 0 if row["stage"] == "mac_oracle" else 3
    closure = private_stage_json(row, stage["custody_result"])
    need(closure["nonce"] == spec["run_id"] and closure["integrity"] is True
         and closure["all_registered_original_children_reaped"] is True
         and closure["all_registered_session_groups_empty_before_reap"] is True
         and closure["cancellation_signal"] is None and closure["signals_sent_using_enumerated_pid"] is False
         and closure["registered_original_children"] == len(closure["children"])
         == expected_product_count + expected_probe_count, "all_original_owned_children_complete")
    children = closure["children"]
    need(len({c["pid"] for c in children}) == len(children)
         and all(c["guardian"] is True and c["original_Popen"] is True
                 and c["source_requested_session"] is True and c["original_child_reaped"] is True
                 and c["session"]["group_empty_before_first_reap"] is True
                 and c["session"]["unexpected_descendants"] is False
                 and c["session"]["signals_after_reap"] == 0 for c in children),
         "all_original_group_closures_before_first_reap")
    fresh = stage["fresh_custody_observation"]
    need(fresh["all_members_absent"] is True and fresh["registered_sessions"] == len(children),
         "fresh_all_sessions_empty_not_only_primary_group")
    launches, probes = stage["product_launches"], stage.get("abi_commands", [])
    need(len(launches) == expected_product_count and len(probes) == expected_probe_count,
         "every_product_and_abi_launch_count")
    expected_program = str(Path(spec["clone_root"]) / "heptabao-server")
    product_argv = [expected_program, "--config", str(Path(spec["clone_root"]) / "server.json")]
    identified = set()
    for item in launches + probes:
        prefix = Path(item["custody_prefix"])
        birth = stage_leaf(row, str(prefix.with_suffix(".birth.json")))
        started = stage_leaf(row, str(prefix.with_suffix(".started.json")))
        need(birth["nonce"] == started["nonce"] == spec["run_id"] and birth["guardian"] is True
             and birth["original_Popen_registered_before_admission"] is True
             and birth["pid"] == started["guardian_pid"] == started["guardian_pgid"] == item["guardian_pid"]
             and started["target_original_Popen"] is True and started["owned_signals_unblocked"] is True,
             "original_guardian_and_target_receipts")
        need(item["guardian_pid"] not in identified, "reused_original_custody_identity")
        identified.add(item["guardian_pid"])
        original_argv_sha = hashlib.sha256(driver.custody.canonical(item["argv"])).hexdigest()
        need(birth["original_caller_argv_sha256"] == started["target_argv_sha256"] == original_argv_sha,
             "actual_owned_argv_receipt_pin")
        if item in launches:
            need(item["argv"] == product_argv and item["start_completed"] is True
                 and item["actual_product_pid"] == started["target_pid"]
                 and item["kernel_executable"] == expected_program
                 and item["executable_sha256"] == started["target_executable_sha256"] == binary_sha256
                 and item["original_guardian_birth"] == birth["session_birth"]
                 and item["stop"]["group_empty_before_first_reap"] is True,
                 "actual_normal_product_identity_and_cold_restart")
        else:
            need(item["outcome"] == "completed" and item["exit_code"] == 0 and item["budget_seconds"] == 15
                 and item["program"]["sha256"] == started["target_executable_sha256"], "actual_abi_probe_original_owner")
            for key in ("stdout", "stderr"):
                bound = mapped_stage_binding(row, item[key])
                raw = core.read_bytes(bound["path"], core.MIB)
                need(hashlib.sha256(raw).hexdigest() == bound["sha256"] and (key != "stderr" or not raw),
                     "actual_abi_probe_complete_output")
    need(identified == {c["pid"] for c in children}, "unlisted_owned_child_in_stage")
    need(stage["binary_and_config_unchanged"] is True, "normal_product_inputs_changed")


def inspect_run_graph(plan_binding, *, expected_controls, expected_candidate, expected_full34_sha256,
                      expected_binaries, expected_target_host):
    """Recompute every edge from actual artifacts and original executor captures.

    Control pins are supplied by the already-frozen HA caller, never loaded
    from the recovery result being admitted. This function starts no process.
    """
    need(set(expected_controls) == {"driver_sha256", "core_sha256", "wire_sha256", "custody_sha256",
                                    "admission_sha256", "runtime_sha256", "cross_host_gate_sha256",
                                    "transfer_sha256"},
         "externally_frozen_control_pin_set")
    need(expected_controls["admission_sha256"] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
         and expected_controls["core_sha256"] == CORE_SHA
         and expected_controls["runtime_sha256"] == RUNTIME_SHA
         and expected_controls["cross_host_gate_sha256"] == GATE_SHA
         and expected_controls["custody_sha256"] == CUSTODY_SHA, "approved_recovery_control_identity")
    plan = core.pinned(plan_binding)
    need(set(plan) == {"schema", "run_id", "driver", "candidate_plan", "candidate_admission",
                       "runtime_validator", "executor_bindings", "target_host", "stages", "transfer", "transfers"}
         and plan["schema"] == "heptabao.formal-kv2-recovery-review-plan.v3"
         and re.fullmatch(r"[0-9a-f]{32}", plan["run_id"])
         and plan["target_host"] == expected_target_host, "recovery_review_plan_exact_shape")
    driver = load_file_module(plan["driver"], "formal_recovery_reviewed_driver", expected_controls["driver_sha256"])
    transfer = load_file_module(plan["transfer"], "formal_recovery_reviewed_transfer", expected_controls["transfer_sha256"])
    need(transfer.DRIVER_SHA == expected_controls["driver_sha256"], "same_reviewed_transfer_and_product_controller")
    need(driver.PINS == {"formal_kv2_recovery_core.py": CORE_SHA,
                        "formal_kv2_shared_deadline_wire.py": expected_controls["wire_sha256"],
                        "full34_process_custody.py": CUSTODY_SHA,
                        "formal_kv2_recovery_admission.py": expected_controls["admission_sha256"]},
         "frozen_driver_dependency_closure")
    candidate = validate_candidate(plan["candidate_plan"])
    candidate_sha = hashlib.sha256(core.canonical(candidate)).hexdigest()
    need(core.pinned(plan["candidate_admission"]) == candidate
         and plan["candidate_admission"]["sha256"] == candidate_sha
         and (candidate["source_commit"], candidate["source_tree"]) == expected_candidate
         and candidate["full34"]["sha256"] == expected_full34_sha256
         and expected_binaries == {"mac": candidate["mac_server_sha256"], "linux": candidate["linux_server_sha256"]},
         "recovery_same_actual_candidate_and_original31")
    rows = plan["stages"]
    need(isinstance(rows, list) and len(rows) == 4 and {r["stage"] for r in rows} == set(RECOVERY_STAGES)
         and all(set(r) == {"stage", "spec", "runtime_spec_path", "result", "runtime_result_path", "cwd"} for r in rows),
         "review_plan_four_exact_stage_origins")
    stage_rows, specs, results, expected_results, invocations = {}, {}, {}, {}, {}
    for row in rows:
        name = row["stage"]
        stage_rows[name] = row
        spec, result = core.pinned(row["spec"], private=True), core.pinned(row["result"])
        specs[name], results[name] = spec, result
        need(set(spec) == driver.COMMON_SPEC_FIELDS | driver.STAGE_SPEC_FIELDS[name]
             and spec["stage"] == name and spec["schema"] == "heptabao.formal-kv2-cold-recovery-stage-plan.v1"
             and spec["limits"] == driver.LIMITS and spec["controller"]["sha256"] == expected_controls["driver_sha256"]
             and spec["run_id"] == plan["run_id"] and spec["candidate_admission_sha256"] == candidate_sha
             and spec["candidate_admission"]["sha256"] == candidate_sha
             and (spec["source_commit"], spec["source_tree"], spec["full34_sha256"])
                 == (*expected_candidate, expected_full34_sha256), "actual_stage_spec_same_source_and_budget")
        host = expected_target_host if name == "linux_target" else "mac"
        need(spec["host_label"] == host and spec["expected_host"]["label"] == host
             and (spec["expected_host"]["system"], spec["expected_host"]["hostname"])
                 == driver.ACTUAL_HOSTS[host][:2] and result["actual_host"] == spec["expected_host"],
             "actual_stage_physical_identity")
        need(spec["output_root"] == str(Path(row["runtime_result_path"]).parent)
             and Path(row["runtime_result_path"]).name == "result.public.json"
             and (host != "mac" or (row["result"]["path"] == row["runtime_result_path"]
                                     and row["spec"]["path"] == row["runtime_spec_path"])),
             "actual_stage_origin_not_relabelled")
        expected_results[name] = {**row["result"], "runtime_path": row["runtime_result_path"]}
        invocations[name] = {"executable": spec["interpreter"]["path"],
            "args": ["-I", "-S", "-B", spec["controller"]["path"], "--stage", name,
                     "--spec", row["runtime_spec_path"], "--spec-sha256", row["spec"]["sha256"],
                     "--output", spec["output_root"]],
            "cwd": row["cwd"], "timeout_seconds": driver.LIMITS["stage_seconds"], "nice": 10,
            "spec_sha256": row["spec"]["sha256"], "driver_sha256": expected_controls["driver_sha256"]}
        checks = result["checks"]
        need(result["schema"] == driver.SCHEMA and result["stage"] == name and result["status"] == "passed"
             and result["run_id"] == plan["run_id"]
             and result["required_checks"] == list(driver.CHECKS[name])
             and result["required_count"] == result["passed_count"] == len(driver.CHECKS[name])
             and len(checks) == len(driver.CHECKS[name])
             and {r["case"] for r in checks} == set(driver.CHECKS[name])
             and all(r["passed"] is True and not r.get("not_run", False) for r in checks)
             and result["full_denominator_retained"] is True and "failure" not in result,
             "actual_stage_complete_positive_denominator")
        need((result["source_commit"], result["source_tree"], result["full34_sha256"])
                 == (*expected_candidate, expected_full34_sha256)
             and result["candidate_admission_sha256"] == candidate_sha
             and result["controller_sha256"] == expected_controls["driver_sha256"]
             and result["dependencies"] == driver.PINS and result["limits"] == driver.LIMITS
             and result["spec"] == {"path": row["runtime_spec_path"], "sha256": row["spec"]["sha256"]}
             and result["interpreter"] == spec["interpreter"]
             and result["elapsed_ns"] <= driver.LIMITS["stage_seconds"] * 1_000_000_000
             and result["production_changed"] is False and result["automatic_retry"] is False
             and result["original31_replaced"] is False and result["snapshot_only_empty_cluster_supported"] is False,
             "actual_stage_implementation_source_scope_and_deadline")
    prerequisite_jobs = [(r["host"], r["job_id"]) for r in candidate["original_executors"]["rows"]]
    runtime = validate_recovery_executors(plan["executor_bindings"], runtime_binding=plan["runtime_validator"],
        expected_results=expected_results, expected_invocations=invocations, target_host=expected_target_host,
        prerequisite_jobs=prerequisite_jobs)
    backup = results["backup"]
    manifest_binding = backup["backup_manifest"]
    need(manifest_binding["path"] == str(Path(specs["backup"]["backup_root"]) / "manifest.private.json"),
         "original_backup_manifest_origin")
    manifest = driver.validate_bundle_manifest(specs["backup"]["backup_root"], manifest_binding)
    need((manifest["source_commit"], manifest["source_tree"], manifest["full34_sha256"])
                 == (*expected_candidate, expected_full34_sha256)
         and manifest["run_id"] == plan["run_id"] and manifest["candidate_admission_sha256"] == candidate_sha,
         "sealed_backup_same_source_and_run")
    for name in ("mac_oracle", "linux_target", "source_verify"):
        need(specs[name]["backup_result"]["sha256"] == stage_rows["backup"]["result"]["sha256"]
             and results[name]["backup_result"] == specs[name]["backup_result"]
             and specs[name]["backup_manifest"]["sha256"] == manifest_binding["sha256"]
             and results[name]["backup_manifest"] == specs[name]["backup_manifest"], "backup_edge_into_every_later_stage")
    need(specs["linux_target"]["mac_oracle_result"]["sha256"] == stage_rows["mac_oracle"]["result"]["sha256"]
         and results["linux_target"]["mac_oracle_result"] == specs["linux_target"]["mac_oracle_result"]
         and specs["source_verify"]["linux_target_result"]["sha256"] == stage_rows["linux_target"]["result"]["sha256"]
         and results["source_verify"]["completed_target_result"] == specs["source_verify"]["linux_target_result"],
         "ordered_oracle_target_and_source_recheck_edges")
    summary = core.pinned(candidate["full34_summary"], private=True)
    need(manifest["original_openbao_oracle_sha256"] == backup["original_openbao_oracle_sha256"]
         == summary["source_history_sha256"] and manifest["secret_bytes_in_manifest"] is False,
         "independent_original_openbao_oracle_not_substituted")
    original_inventory = private_stage_json(stage_rows["backup"], backup["original_tree_inventory"])
    need(original_inventory == manifest["original_tree"]
         and hashlib.sha256(core.canonical(original_inventory)).hexdigest()
             == backup["original_tree_sha256"] == results["source_verify"]["original_tree_sha256"],
         "complete_original_tree_before_after_bound")
    need(backup["original_process_observation"]["all_members_absent"] is True
         and results["source_verify"]["original_process_observation"]["all_members_absent"] is True
         and results["source_verify"]["source_recheck"]["complete_original_source_unchanged"] is True
         and results["source_verify"]["source_recheck"]["original_products_reopened"] is False,
         "original_source_stopped_and_unchanged_after_all_recovery")
    full31 = core.load_full34_semantics(specs["backup"]["semantics"])
    backup_root = Path(specs["backup"]["backup_root"])
    api = {str(n): core.read_bytes(backup_root / f"oracle/version-{n:04d}.json") for n in range(1, 20)}
    original, bundle = core.reconstruct_original_oracle(full31, core.read_bytes(backup_root / "oracle/source-bundle.json"),
                                                       api, summary["source_history_sha256"])
    for name, kind in (("mac_oracle", "mac"), ("linux_target", "linux")):
        spec, result, row = specs[name], results[name], stage_rows[name]
        need(spec["binary"]["sha256"] == result["binary_sha256"] == expected_binaries[kind],
             "same_admitted_normal_binary_on_each_clone")
        config = private_stage_json(row, result["config_evidence"])
        root = Path(spec["clone_root"])
        expected_config = {"listen": f"127.0.0.1:{spec['port']}", "data_dir": str(root / "data"),
            "audit_file": str(root / "audit.jsonl"), "tls_cert_file": str(root / "tls.crt"),
            "tls_key_file": str(root / "tls.key"), "storage": {"native_v6_file": {"path": str(root / "data")}}}
        need(config == expected_config and result["config_evidence"]["sha256"] == result["config_binding"]["sha256"],
             "actual_normal_file_config_no_old_path_or_fixture")
        clone = private_stage_json(row, result["clone_data_manifest"])
        projection = lambda rows: [(r["leaf"], r["bytes"], r["sha256"]) for r in rows]
        need(projection(clone["leaves"]) == projection(manifest["durable"]["leaves"])
             and result["original_directory_identity"] == manifest["durable"]["source_directory_identity"]
             and (result["new_directory_identity"]["dev"], result["new_directory_identity"]["ino"])
                 != (result["original_directory_identity"]["dev"], result["original_directory_identity"]["ino"]),
             "complete_fresh_independent_inode_clone_not_subset")
        check_owned_runtime(driver, row, result, spec, expected_binaries[kind])
    mac_row, mac = stage_rows["mac_oracle"], results["mac_oracle"]
    linux_row, linux = stage_rows["linux_target"], results["linux_target"]
    A = private_stage_json(mac_row, mac["A_oracle"], full31)
    core.final_delta_expected(full31, original, api, A)
    core.validate_complete_observation(full31, A, A, private_stage_json(mac_row, mac["A_raw_witnesses"], full31), bundle, final_state=True)
    need(linux["mac_oracle_file"]["sha256"] == mac["A_oracle"]["sha256"], "Linux_A_exact_complete_Mac_oracle_bytes")
    core.validate_complete_observation(full31, private_stage_json(linux_row, linux["A_observation"], full31), A,
        private_stage_json(linux_row, linux["A_raw_witnesses"], full31), bundle, final_state=True)
    B = private_stage_json(linux_row, linux["B_observation"], full31)
    core.validate_complete_observation(full31, B, original,
        private_stage_json(linux_row, linux["B_raw_witnesses"], full31), bundle, final_state=False)
    snapshot_rows = [r for r in linux["mutations"] if (r["method"], r["path"]) == ("POST", "sys/storage/raft/snapshot")]
    restore = linux["snapshot_restore"]
    need(len(snapshot_rows) == restore["count"] == 1 and snapshot_rows[0]["retried"] is False
         and snapshot_rows[0]["outcome"] == "response_received" and snapshot_rows[0]["status"] == 204
         and snapshot_rows[0]["ordinal"] == restore["mutating_request_ordinal"], "exactly_one_original_snapshot_restore")
    snapshot_file = next(r for r in manifest["backup_files"] if r["relative"] == "snapshots/original.snap")
    need(restore["archive_sha256"] == snapshot_file["sha256"], "B_restored_original_full31_snapshot_bytes")
    receipt = stage_leaf(linux_row, str(Path(specs["linux_target"]["output_root"]) /
                                       f"http-{restore['mutating_request_ordinal']:04d}.public.json"))
    need(receipt["metadata"] == restore["wire_receipt"] and receipt["method"] == "POST"
         and receipt["path"] == "sys/storage/raft/snapshot" and receipt["clock_domain"] == driver.wire.CLOCK_DOMAIN
         and all(restore["wire_receipt"][k] is True for k in
                 ("raw_tls_http204", "peer_eof_observed", "tls_close_notify_observed")), "actual_strict204_restore_receipt")
    empty = mapped_stage_binding(linux_row, receipt["private_response"])
    need(core.read_bytes(empty["path"]) == b"" and empty["sha256"] == hashlib.sha256(b"").hexdigest(),
         "strict204_actual_raw_body_empty")
    before = private_stage_json(linux_row, linux["pre_cas_observation"], full31)
    # Exactly one undelete changes v1. Destroyed v2 and every other old field stay exact.
    import copy
    before_expected = copy.deepcopy(original)
    before_expected["metadata"]["versions"]["1"]["deletion_time"] = ""
    before_expected["versions"]["1"]["status"] = 200
    before_expected["versions"]["1"]["data"]["metadata"]["deletion_time"] = ""
    before_expected["versions"]["1"]["data"]["data"] = full31.decode(api["1"])["data"]["data"]
    need(full31.same_json_tokens(before, before_expected), "B_undelete_and_destroy_exact_before_CAS")
    cold = private_stage_json(linux_row, linux["persistent_cas_observation"], full31)
    probe = full31.payload(20, 19, 1024)
    driver.validate_post_cas(full31, before, cold, probe)
    witnesses = private_stage_json(linux_row, linux["persistent_cas_raw_witnesses"], full31)
    need(set(witnesses) == {str(n) for n in range(1, 21)}, "all_twenty_post_CAS_raw_witnesses")
    for n in range(1, 21):
        payload = None if n == 2 else probe if n == 20 else full31.payload(n, 17, 2 * core.MIB)
        full31.verify_storage_witness(witnesses[str(n)], n, cold["metadata"]["versions"][str(n)], payload)
    need(linux["actual_abi"]["binary_sha256"] == expected_binaries["linux"]
         and linux["actual_abi"]["elf"] == "ELF64-LSB-EM_X86_64"
         and linux["actual_abi"]["program_entry_executed_by_abi_probe"] is False
         and len(linux["actual_abi"]["resolved_libraries"]) > 0, "actual_linux_loader_compatibility_not_ABI_label_only")
    # Both private copy directions are part of the provenance graph. The raw
    # package and every returned artifact are read again; a receiver boolean
    # does not replace the actual Linux stage or its complete original executor.
    transfer_rows = plan["transfers"]
    need(isinstance(transfer_rows, list) and len(transfer_rows) == 2
         and {r["kind"] for r in transfer_rows} == {"linux_inputs", "linux_evidence_return"},
         "two_exact_private_transfer_edges")
    transfer_by_kind = {r["kind"]: r for r in transfer_rows}
    mac_root = str(Path(specs["backup"]["backup_root"]).parent)
    linux_root = str(Path(specs["linux_target"]["backup_root"]).parent)
    return_root = str(Path(mac_root) / "returned-linux-target")
    need(stage_rows["linux_target"]["result"]["path"] == str(Path(return_root) / "stage-output/result.public.json")
         and stage_rows["linux_target"]["spec"]["path"] == str(Path(return_root) / "control/linux_target.private.json"),
         "full_linux_output_and_spec_return_paths")
    common_transfer = {"run_id": plan["run_id"], "stage_spec_sha256": stage_rows["linux_target"]["spec"]["sha256"],
                       "backup_manifest_sha256": manifest_binding["sha256"]}
    transfer_evidence = [transfer.validate_receipt_set(transfer_by_kind["linux_inputs"], kind="linux_inputs",
        source_host=results["mac_oracle"]["actual_host"], destination_host=results["linux_target"]["actual_host"],
        source_root=mac_root, destination_root=linux_root, **common_transfer)]
    input_plan = core.pinned(transfer_by_kind["linux_inputs"]["plan"], private=True, maximum=32 * core.MIB)
    input_hashes = {r["relative"]: r["sha256"] for r in input_plan["entries"]}
    required_hashes = {"sealed-backup/" + r["relative"]: r["sha256"] for r in manifest["backup_files"]}
    required_hashes.update({"sealed-backup/manifest.private.json": manifest_binding["sha256"],
        "control/candidate-admission.public.json": candidate_sha,
        "control/prior-backup-result.public.json": stage_rows["backup"]["result"]["sha256"],
        "control/prior-mac-oracle-result.public.json": stage_rows["mac_oracle"]["result"]["sha256"],
        "control/mac-final-api-oracle.private.json": mac["A_oracle"]["sha256"],
        "control/linux_target.private.json": stage_rows["linux_target"]["spec"]["sha256"]})
    need(input_hashes == required_hashes, "private_input_exact_whole_backup_and_stage_controls")
    transfer_evidence.append(transfer.validate_receipt_set(transfer_by_kind["linux_evidence_return"],
        kind="linux_evidence_return", source_host=results["linux_target"]["actual_host"],
        destination_host=results["mac_oracle"]["actual_host"], source_root=linux_root,
        destination_root=return_root, local_receiver_root=return_root,
        stage_result={"path": stage_rows["linux_target"]["runtime_result_path"],
                      "sha256": stage_rows["linux_target"]["result"]["sha256"]}, **common_transfer))
    checks = [c for name in RECOVERY_STAGES for c in results[name]["checks"]]
    need(len(checks) == len(driver.ALL_CHECKS) == 25 and len({c["case"] for c in checks}) == 25,
         "complete_new_recovery_denominator")
    return driver, {"schema": FINAL_SCHEMA, "status": "passed", "plan": plan_binding,
        "run_id": plan["run_id"], "source_commit": expected_candidate[0], "source_tree": expected_candidate[1],
        "full34_sha256": expected_full34_sha256, "binaries": expected_binaries, "target_host": expected_target_host,
        "controls": expected_controls, "driver": plan["driver"], "candidate_admission_sha256": candidate_sha,
        "runtime_admission": runtime, "runtime_admission_sha256": hashlib.sha256(core.canonical(runtime)).hexdigest(),
        "required_checks": list(driver.ALL_CHECKS), "required_count": 25, "passed_count": 25, "checks": checks,
        "stages": [{"stage": s, "result": stage_rows[s]["result"]} for s in RECOVERY_STAGES],
        "private_transfers": transfer_evidence,
        "backup_manifest_sha256": manifest_binding["sha256"], "original_openbao_oracle_sha256": summary["source_history_sha256"],
        "A_oracle_sha256": mac["A_oracle"]["sha256"], "original31_retained": True,
        "original_source_unchanged": True, "all_owned_processes_reaped": True,
        "same_seal_cold_set_new_root": True, "snapshot_only_empty_cluster_supported": False,
        "production_credentials_or_clients_migrated": False, "production_changed": False}


def build_final_document(plan_binding, **expected):
    driver, document = inspect_run_graph(plan_binding, **expected)
    need(driver.DRAFT_ONLY is False, "draft_control_cannot_qualify_formal_recovery")
    return document


def validate_final_recovery(binding, *, expected_controls, expected_candidate, expected_full34_sha256,
                            expected_binaries, expected_target_host):
    """Only public final gate: reruns real upstream/executor/private-evidence chains.

    The frozen HA caller provides all expected pins and candidate identities.
    No runtime-admitted boolean or caller-created summary is accepted instead.
    """
    result = core.pinned(binding, maximum=32 * core.MIB)
    need(result.get("schema") == FINAL_SCHEMA and result.get("status") == "passed", "formal_recovery_final_status")
    expected = build_final_document(result["plan"], expected_controls=expected_controls,
        expected_candidate=expected_candidate, expected_full34_sha256=expected_full34_sha256,
        expected_binaries=expected_binaries, expected_target_host=expected_target_host)
    need(result == expected, "formal_recovery_final_document_not_exact_recomputed_graph")
    return {"schema": "heptabao.formal-kv2-cold-recovery-admission.v3", "status": "admitted",
            "result": binding, "required": 25, "passed": 25, "original31_replaced": False,
            "source_commit": expected_candidate[0], "source_tree": expected_candidate[1],
            "full34_sha256": expected_full34_sha256, "binaries": expected_binaries,
            "target_host": expected_target_host, "same_seal_cold_set_new_root": True,
            "snapshot_only_empty_cluster_supported": False, "production_credentials_or_clients_migrated": False}

