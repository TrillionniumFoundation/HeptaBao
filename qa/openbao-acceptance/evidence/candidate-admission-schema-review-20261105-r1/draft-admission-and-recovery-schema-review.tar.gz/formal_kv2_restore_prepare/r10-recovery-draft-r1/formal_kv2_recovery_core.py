#!/usr/bin/env python3
"""Closed-file cold backup and exact, independently bound KV2 oracles.

This module never starts a product and never initializes or imports a cluster.
Secret bytes are copied only between private file descriptors, never JSON.
"""
from __future__ import annotations

import contextlib
import copy
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import time

SCHEMA = "heptabao.formal-kv2-cold-backup.v1"
MIB = 1024 * 1024
MAX_BACKUP_BYTES = 512 * MIB
MAX_INPUT_BYTES = 128 * MIB
MAX_LEAVES = 16384
CORE = frozenset(("state.hbs", "journal.hbj", "ledger.hbl", "seal.json"))
NV6 = re.compile(r"nv6\.[0-9a-f]{32}\.[0-9a-f]{64}\.hbo")
AUDIT = re.compile(r"audit\.jsonl(?:\.(?:hmac-key|rotation-lock|rotation\.json|segment-[0-9]{20}\.jsonl))?")
HEX64 = re.compile(r"[0-9a-f]{64}")
FULL34_DRIVER_SHA256 = "15cc68f3bd2442e4e4d3047f4fb30eecf826d8c4f54258732f97090005f542d4"
METADATA_VERSION_FIELDS = ("created_time", "deletion_time", "destroyed")


class Refusal(RuntimeError):
    """Fixed labels only; callers must not interpolate credentials or OS errors."""


def need(value, code):
    if not value:
        raise Refusal(code)


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()


def decode_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            need(key not in result, "duplicate_evidence_json_key")
            result[key] = value
        return result
    def constant(_):
        raise Refusal("nonfinite_evidence_json")
    try:
        return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)
    except (ValueError, UnicodeError, RecursionError):
        raise Refusal("invalid_evidence_json") from None


def now_ns():
    return time.clock_gettime_ns(time.CLOCK_MONOTONIC)


def live(deadline_ns):
    need(type(deadline_ns) is int and now_ns() < deadline_ns, "operation_original_deadline")


def stamp(row):
    # atime can legitimately advance on read. It is recorded separately, never
    # silently mistaken for application mutation or used as immutable authority.
    return {k: getattr(row, "st_" + k) for k in (
        "dev", "ino", "uid", "gid", "mode", "nlink", "size", "mtime_ns", "ctime_ns")}


def absolute(path):
    path = Path(path)
    need(path.is_absolute() and str(path) == os.path.normpath(str(path))
         and all(x not in (".", "..") for x in path.parts), "absolute_normal_path")
    return path


def directory_fd(path, *, private=False):
    """Walk every actual ancestor without following a symlink."""
    path = absolute(path)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open("/", flags)
    try:
        for part in path.parts[1:]:
            nxt = os.open(part, flags, dir_fd=fd)
            os.close(fd)
            fd = nxt
        row = os.fstat(fd)
        need(stat.S_ISDIR(row.st_mode), "directory_shape")
        if private:
            need(row.st_uid == os.geteuid() and stat.S_IMODE(row.st_mode) == 0o700,
                 "private_directory_0700_owner")
        result, fd = fd, None
        return result
    finally:
        if fd is not None:
            os.close(fd)


def file_fd(path, *, private=True, source_directory_fd=None):
    path = absolute(path)
    parent = directory_fd(path.parent) if source_directory_fd is None else os.dup(source_directory_fd)
    try:
        fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC,
                     dir_fd=parent)
    finally:
        os.close(parent)
    try:
        row = os.fstat(fd)
        need(stat.S_ISREG(row.st_mode) and row.st_nlink == 1
             and row.st_uid == os.geteuid(), "owned_single_regular_input")
        need(stat.S_IMODE(row.st_mode) == 0o600 if private else not row.st_mode & 0o022,
             "input_mode")
        result, fd = fd, None
        return result
    finally:
        if fd is not None:
            os.close(fd)


def read_bytes(path, maximum=MAX_INPUT_BYTES, *, private=True, deadline_ns=None):
    fd = file_fd(path, private=private)
    try:
        before = os.fstat(fd)
        need(before.st_size <= maximum, "input_byte_bound")
        chunks, count = [], 0
        while True:
            if deadline_ns is not None:
                live(deadline_ns)
            block = os.read(fd, min(65536, maximum + 1 - count))
            if not block:
                break
            chunks.append(block)
            count += len(block)
            need(count <= maximum, "input_byte_bound")
        need(count == before.st_size and stamp(before) == stamp(os.fstat(fd)), "input_changed")
        return b"".join(chunks)
    finally:
        os.close(fd)


def sha_file(path, *, private=False, deadline_ns=None):
    fd = file_fd(path, private=private)
    try:
        before, digest = os.fstat(fd), hashlib.sha256()
        count = 0
        while True:
            if deadline_ns is not None:
                live(deadline_ns)
            block = os.read(fd, 65536)
            if not block:
                break
            digest.update(block)
            count += len(block)
        need(count == before.st_size and stamp(before) == stamp(os.fstat(fd)), "hash_input_changed")
        return digest.hexdigest()
    finally:
        os.close(fd)


def pinned(binding, *, private=False, maximum=8 * MIB):
    need(isinstance(binding, dict) and set(binding) == {"path", "sha256"}
         and HEX64.fullmatch(binding["sha256"]) is not None, "exact_file_binding")
    raw = read_bytes(binding["path"], maximum, private=private)
    need(hashlib.sha256(raw).hexdigest() == binding["sha256"], "file_pin_changed")
    value = decode_json(raw)
    need(isinstance(value, dict), "bound_json_object")
    return value


def write_new(path, raw):
    path = absolute(path)
    if not isinstance(raw, bytes):
        raw = canonical(raw)
    parent = directory_fd(path.parent, private=True)
    fd = None
    try:
        fd = os.open(path.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
                     | os.O_CLOEXEC, 0o600, dir_fd=parent)
        need(stat.S_IMODE(os.fstat(fd).st_mode) == 0o600, "private_output_mode")
        view = memoryview(raw)
        while view:
            amount = os.write(fd, view)
            need(amount > 0, "output_write")
            view = view[amount:]
        os.fsync(fd)
        os.fsync(parent)
    finally:
        if fd is not None:
            os.close(fd)
        os.close(parent)
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}


def new_directory(path):
    path = absolute(path)
    parent = directory_fd(path.parent)
    try:
        row = os.fstat(parent)
        need(row.st_uid == os.geteuid() and not row.st_mode & 0o022, "owned_output_parent")
        os.mkdir(path.name, 0o700, dir_fd=parent)
        os.fsync(parent)
    finally:
        os.close(parent)
    fd = directory_fd(path, private=True)
    try:
        return stamp(os.fstat(fd))
    finally:
        os.close(fd)


def data_names(fd):
    names = sorted(os.listdir(fd))
    need(4 < len(names) <= MAX_LEAVES and CORE <= set(names), "complete_four_core_and_nv6")
    need(all(name in CORE or NV6.fullmatch(name) is not None for name in names),
         "unknown_durable_asset_requires_review")
    return names


def data_limit(name):
    if name == "seal.json":
        return 65536
    return 512 * 1024 if NV6.fullmatch(name) else 64 * MIB


@contextlib.contextmanager
def stopped_directory(path):
    fd = directory_fd(path, private=True)
    try:
        # Same directory-inode flock boundary as std::fs::File::try_lock.
        # No lock file, source chmod, temporary leaf or product reopen is used.
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise Refusal("original_directory_writer_still_active") from None
        before = stamp(os.fstat(fd))
        yield fd, before
        need(stamp(os.fstat(fd)) == before, "original_directory_changed")
        check_directory_name(path, before)
    finally:
        os.close(fd)


def check_directory_name(path, expected):
    current = directory_fd(path, private=True)
    try:
        need(stamp(os.fstat(current)) == expected, "original_directory_name_rebound")
    finally:
        os.close(current)


def copy_one(source, destination, *, maximum, private=True, deadline_ns, source_directory_fd=None):
    """Copy exact bytes, sync/read back, and verify source fd and name identity."""
    source, destination = absolute(source), absolute(destination)
    fd = file_fd(source, private=private, source_directory_fd=source_directory_fd)
    out = parent = None
    try:
        before = os.fstat(fd)
        need(before.st_size <= maximum, "copy_input_bound")
        parent = directory_fd(destination.parent, private=True)
        out = os.open(destination.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW
                      | os.O_CLOEXEC, 0o600, dir_fd=parent)
        digest, count = hashlib.sha256(), 0
        while True:
            live(deadline_ns)
            block = os.read(fd, 65536)
            if not block:
                break
            digest.update(block)
            count += len(block)
            need(count <= maximum, "copy_stream_byte_bound")
            view = memoryview(block)
            while view:
                amount = os.write(out, view)
                need(amount > 0, "copy_write")
                view = view[amount:]
        os.fsync(out)
        os.fsync(parent)
        need(count == before.st_size and stamp(before) == stamp(os.fstat(fd)), "source_copy_changed")
        current = file_fd(source, private=private, source_directory_fd=source_directory_fd)
        try:
            need(stamp(os.fstat(current)) == stamp(before), "source_name_rebound")
        finally:
            os.close(current)
        need(sha_file(destination, private=True, deadline_ns=deadline_ns) == digest.hexdigest(),
             "copy_readback_changed")
        target = os.fstat(out)
        need((target.st_dev, target.st_ino) != (before.st_dev, before.st_ino), "copy_not_independent_inode")
        return {"source": str(source), "source_identity": stamp(before),
                "source_atime_ns_before": before.st_atime_ns,
                "source_atime_ns_after": os.fstat(fd).st_atime_ns,
                "bytes": count, "sha256": digest.hexdigest(), "destination_identity": stamp(target)}
    finally:
        for opened in (out, parent, fd):
            if opened is not None:
                os.close(opened)


def copy_durable_closure(source, destination, deadline_ns):
    new_directory(destination)
    rows, total = [], 0
    with stopped_directory(source) as (fd, root_identity):
        names = data_names(fd)
        for name in names:
            check_directory_name(source, root_identity)
            row = copy_one(Path(source) / name, Path(destination) / name,
                           maximum=data_limit(name), deadline_ns=deadline_ns, source_directory_fd=fd)
            total += row["bytes"]
            need(total <= MAX_BACKUP_BYTES, "closed_backup_total_bound")
            rows.append({"leaf": name, **row})
        need(data_names(fd) == names, "durable_leaf_set_changed")
        check_directory_name(source, root_identity)
        for row in rows:
            need(sha_file(row["source"], private=True, deadline_ns=deadline_ns) == row["sha256"],
                 "source_postcopy_hash_changed")
    return {"source_directory": str(source), "source_directory_identity": root_identity,
            "complete_leaf_count": len(rows), "immutable_ciphertext_count": len(rows) - 4,
            "bytes": total, "leaves": rows, "original_directory_fence_held_during_copy": True,
            "atime_is_read_bookkeeping_only": True, "source_reopened_by_product": False}


def clone_verified_data(backup, destination, expected, deadline_ns):
    observed = copy_durable_closure(backup, destination, deadline_ns)
    projection = lambda rows: [(x["leaf"], x["bytes"], x["sha256"]) for x in rows]
    need(projection(observed["leaves"]) == projection(expected["leaves"]), "backup_data_manifest_mismatch")
    return observed


def load_full34_semantics(binding):
    need(binding["sha256"] == FULL34_DRIVER_SHA256, "frozen_full31_semantics_required")
    need(sha_file(binding["path"]) == FULL34_DRIVER_SHA256, "frozen_full31_source_changed")
    spec = importlib.util.spec_from_file_location("formal_recovery_original_full31", binding["path"])
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    need(len(module.CHECKS) == 31 and module.PROFILES["full34"] == (17, 2 * MIB, True),
         "full31_semantics_shape")
    return module


def reconstruct_original_oracle(full31, bundle, source_api_raw, expected_history_sha256):
    """No HeptaBao response participates in construction of the B baseline."""
    value = full31.decode(bundle)
    need(value.get("schema") == "openbao270-kv2-lossless-v1"
         and set(value["entries"]) == {"history"}, "original_bundle_schema")
    entry = value["entries"]["history"]
    need(entry["current_version"] == 19 and set(entry["versions"]) == {str(i) for i in range(1, 20)},
         "original_nineteen_complete_versions")
    metadata = {key: copy.deepcopy(val) for key, val in entry.items() if key != "versions"}
    metadata["versions"] = {version: {k: item[k] for k in METADATA_VERSION_FIELDS}
                            for version, item in entry["versions"].items()}
    versions = {}
    for number in range(1, 20):
        version, item = str(number), entry["versions"][str(number)]
        observed = full31.decode(source_api_raw[version])["data"]
        need(isinstance(observed, dict) and set(observed) == {"data", "metadata"}, "original_api_shape")
        observed = copy.deepcopy(observed)
        observed["metadata"].update({k: item[k] for k in METADATA_VERSION_FIELDS})
        observed["metadata"]["custom_metadata"] = copy.deepcopy(entry["custom_metadata"])
        observed["data"] = None if number in (1, 2) else observed["data"]
        versions[version] = {"status": 404 if number in (1, 2) else 200, "data": observed}
        expected_payload = None if number == 2 else full31.payload(number, 17, 2 * MIB)
        need(full31.same_json_tokens(item["data"], expected_payload), "original_raw_payload_precision")
    oracle = {"config": value["config"], "metadata": metadata, "versions": versions}
    need(hashlib.sha256(full31.canonical(oracle)).hexdigest() == expected_history_sha256,
         "reconstructed_original_oracle_must_match_original_full31_digest")
    return oracle, value


def final_delta_expected(full31, original, source_api_raw, actual):
    """Only the five precisely located effects of original full31 are allowed.

    The final timestamp first observed from this independent Mac clone is
    explicitly retained as such. It is not presented as an original OpenBao
    timestamp. The Linux clone must then match that complete observation.
    """
    expected = copy.deepcopy(original)
    old_meta = original["metadata"]
    meta = expected["metadata"]
    meta["versions"]["1"]["deletion_time"] = ""
    meta["current_metadata_version"] = old_meta["current_metadata_version"] + 1
    meta["custom_metadata"] = {"revision": "target"}
    observed_time = actual["metadata"]["updated_time"]
    need(isinstance(observed_time, str) and re.fullmatch(
        r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,9})?Z", observed_time),
        "final_metadata_time_format")
    # RFC3339 fractions differ in width; use Decimal rather than lexicographic order.
    def timestamp(raw):
        import calendar
        from decimal import Decimal
        base, _, fraction = raw[:-1].partition(".")
        return Decimal(calendar.timegm(time.strptime(base, "%Y-%m-%dT%H:%M:%S"))) + Decimal("0." + (fraction or "0"))
    need(timestamp(observed_time) >= timestamp(old_meta["updated_time"]), "final_metadata_clock_not_regressed")
    meta["updated_time"] = observed_time
    for version, row in expected["versions"].items():
        row["data"]["metadata"]["custom_metadata"] = {"revision": "target"}
        if version == "1":
            row["status"] = 200
            row["data"]["data"] = full31.decode(source_api_raw[version])["data"]["data"]
            row["data"]["metadata"]["deletion_time"] = ""
    need(full31.same_json_tokens(actual, expected), "final_state_not_exact_original_full31_transform")
    return expected


def validate_complete_observation(full31, actual, expected, witnesses, bundle, *, final_state):
    need(full31.same_json_tokens(actual, expected), "complete_api_observation_mismatch")
    need(set(witnesses) == {str(i) for i in range(1, 20)}, "all_nineteen_storage_witnesses")
    checked = {}
    for number in range(1, 20):
        metadata = copy.deepcopy(bundle["entries"]["history"]["versions"][str(number)])
        if final_state and number == 1:
            metadata["deletion_time"] = ""
        expected_payload = None if number == 2 else full31.payload(number, 17, 2 * MIB)
        checked[str(number)] = full31.verify_storage_witness(
            witnesses[str(number)], number, metadata, expected_payload)
    return checked


def recheck_original_inputs(private_manifest, deadline_ns):
    """Source files remain stopped; no original product is restarted."""
    closure = private_manifest["durable"]
    with stopped_directory(closure["source_directory"]) as (fd, identity):
        need(identity == closure["source_directory_identity"], "original_directory_identity_changed")
        need(data_names(fd) == [r["leaf"] for r in closure["leaves"]], "original_leaf_set_changed")
        rows = closure["leaves"] + private_manifest["inputs"]
        for row in rows:
            opened = file_fd(row["source"], private=row.get("source_private", True))
            try:
                need(stamp(os.fstat(opened)) == row["source_identity"], "original_input_identity_changed")
            finally:
                os.close(opened)
            need(sha_file(row["source"], private=row.get("source_private", True), deadline_ns=deadline_ns)
                 == row["sha256"], "original_input_bytes_changed")
    return {"status": "passed", "input_count": len(rows), "complete_original_source_unchanged": True,
            "original_products_reopened": False, "atime_excluded_explicitly": True}


def inventory_original_tree(root, deadline_ns):
    """Hash the complete stopped private full31 tree, including excluded assets.

    No file body leaves this function. Key/token files are covered by their
    private manifest entries; public receipts expose only the manifest digest.
    """
    root = absolute(root)
    top = directory_fd(root, private=True)
    rows, total = [], 0
    try:
        def visit(fd, relative):
            nonlocal total
            live(deadline_ns)
            before = stamp(os.fstat(fd))
            names = sorted(os.listdir(fd))
            need(len(rows) + len(names) <= 50000, "original_inventory_entry_bound")
            rows.append({"path": relative or ".", "kind": "directory", "identity": before, "names": names})
            for name in names:
                need(name not in (".", "..") and "/" not in name and "\x00" not in name,
                     "original_inventory_leaf")
                row = os.stat(name, dir_fd=fd, follow_symlinks=False)
                rel = name if not relative else relative + "/" + name
                need(row.st_uid == os.geteuid() and not row.st_mode & 0o022,
                     "original_inventory_ownership")
                if stat.S_ISDIR(row.st_mode):
                    child = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
                    try:
                        need(stamp(os.fstat(child)) == stamp(row), "original_inventory_directory_rebound")
                        visit(child, rel)
                    finally:
                        os.close(child)
                else:
                    need(stat.S_ISREG(row.st_mode) and row.st_nlink == 1 and row.st_size <= 512 * MIB,
                         "original_inventory_regular_file")
                    child = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC, dir_fd=fd)
                    try:
                        need(stamp(os.fstat(child)) == stamp(row), "original_inventory_file_rebound")
                        h, count = hashlib.sha256(), 0
                        while True:
                            live(deadline_ns)
                            block = os.read(child, 65536)
                            if not block:
                                break
                            count += len(block)
                            need(count <= row.st_size, "original_inventory_file_grew")
                            h.update(block)
                        need(count == row.st_size and stamp(os.fstat(child)) == stamp(row)
                             == stamp(os.stat(name, dir_fd=fd, follow_symlinks=False)),
                             "original_inventory_file_changed")
                        total += count
                        need(total <= 2 * 1024 * MIB, "original_inventory_total_bound")
                        rows.append({"path": rel, "kind": "file", "identity": stamp(row), "sha256": h.hexdigest()})
                    finally:
                        os.close(child)
            need(names == sorted(os.listdir(fd)) and stamp(os.fstat(fd)) == before,
                 "original_inventory_directory_changed")
        visit(top, "")
        check_directory_name(root, rows[0]["identity"])
    finally:
        os.close(top)
    return {"schema": "heptabao.formal-kv2-original-tree-inventory.v1", "root": str(root),
            "bytes": total, "entries": rows, "atime_excluded_explicitly": True}
