#!/usr/bin/env python3
"""Formal KV2 cold-set recovery controls, candidate independent and DRAFT ONLY.

Stages are separate durable executor jobs. A source backup never reopens the
original product. Both normal product instances use new private persistent roots.
All public results exclude credentials and preserve the complete denominator.
"""
from __future__ import annotations

import argparse
import base64
import copy
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import ssl
import stat
import struct
import subprocess
import sys
import time

DRAFT_ONLY = True
HERE = Path(__file__).resolve().parent
PINS = {
    "formal_kv2_recovery_core.py": "209aaa29adbb9c89eb060b8349ecc4519e45fbc1b5ca92a687a6fededf64f46d",
    "formal_kv2_shared_deadline_wire.py": "f9ca592b4f1df03f5344923d926c4064429f2f9390cad4a3b8f9d87ffc06fb76",
    "full34_process_custody.py": "c32a4f3091a1ff7b105ac54099fbdeaf68c6e9aeb41aa5ff829b507857ee31cb",
    "formal_kv2_recovery_admission.py": "efb9426173dc6d044f3261544467a5e3747d4633dd36f7f827b0997f8721f08c",
}
SCHEMA = "heptabao.formal-kv2-cold-recovery-stage.v1"
LIMITS = {"http_seconds": 15, "startup_seconds": 15, "stop_seconds": 5,
          "stage_seconds": 1800, "backup_seconds": 360}
CHECKS = {
    "backup": (
        "candidate_full31_and_executor_gate", "original_processes_stopped_and_directory_fenced",
        "complete_sealed_copy_all_leaves", "original_openbao_baseline_digest",
        "source_full_tree_unchanged_after_copy"),
    "mac_oracle": (
        "mac_fresh_root_no_original_path", "mac_normal_sealed_unseal",
        "mac_final_api_exact_known_delta", "mac_final_raw_all_19", "mac_all_owned_processes_reaped"),
    "linux_target": (
        "linux_actual_elf_loader_compatibility", "linux_fresh_root_no_original_path",
        "linux_normal_sealed_unseal", "linux_A_api_exact_mac_clone_oracle", "linux_A_raw_all_19",
        "linux_B_snapshot_once_strict_204", "linux_B_cold_api_exact_openbao",
        "linux_B_cold_raw_all_19", "linux_B_soft_and_destroyed_restored",
        "linux_cas_denials_no_effect", "linux_cas_success_persistent_after_cold",
        "linux_private_key_custody", "linux_all_owned_processes_reaped"),
    "source_verify": ("original_complete_input_tree_unchanged_at_end", "backup_set_unchanged_at_end"),
}
ALL_CHECKS = tuple(name for group in CHECKS.values() for name in group)
COMMON_SPEC_FIELDS = frozenset(("schema", "stage", "run_id", "source_commit", "source_tree",
    "full34_sha256", "candidate_admission_sha256", "candidate_admission", "source_root", "host_label",
    "expected_host", "interpreter", "controller", "semantics", "limits", "output_root"))
STAGE_SPEC_FIELDS = {
    "backup": frozenset(("candidate_plan", "full34", "full34_summary", "original_work_root", "backup_root")),
    "mac_oracle": frozenset(("backup_root", "backup_manifest", "backup_result", "clone_root", "binary", "port")),
    "linux_target": frozenset(("backup_root", "backup_manifest", "backup_result", "clone_root", "binary", "port",
                               "mac_oracle_result", "mac_oracle_file")),
    "source_verify": frozenset(("backup_root", "backup_manifest", "backup_result", "linux_target_result", "full34")),
}
ACTUAL_HOSTS = {
    "mac": ("Darwin", "MacBook-Pro.local", "/Volumes/T5"),
    "x230": ("Linux", "qian-ThinkPad-X230", "/home/qian"),
    "rog": ("Linux", "qian-qi-ROG-Flow-Z13-GZ302EA-GZ302EA", "/home/qian-qi"),
    "pocket4": ("Linux", "alex-G1628-04", "/home/alex"),
}


def helper(filename, name):
    path = HERE / filename
    if hashlib.sha256(path.read_bytes()).hexdigest() != PINS[filename]:
        raise RuntimeError("frozen_control_dependency_changed")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


core = helper("formal_kv2_recovery_core.py", "formal_kv2_core")
wire = helper("formal_kv2_shared_deadline_wire.py", "formal_kv2_wire")
custody = helper("full34_process_custody.py", "formal_kv2_custody")
need = core.need


def local_host(label, expected):
    need(label in ACTUAL_HOSTS and ACTUAL_HOSTS[label][:2] == (os.uname().sysname, socket.gethostname()),
         "actual_configured_host_mapping")
    actual = {"label": label, "system": os.uname().sysname, "hostname": socket.gethostname(),
              "machine": os.uname().machine, "uid": os.geteuid(), "python_version": sys.version.split()[0]}
    need(isinstance(expected, dict) and set(expected) == set(actual), "complete_bound_host_preflight")
    need(all(actual.get(k) == v for k, v in expected.items()), "actual_host_differs_from_bound_preflight")
    need(sys.version_info >= (3, 11) and __debug__, "normal_python_runtime_required")
    return actual


def system_executable(path):
    """Pin the actual interpreter/loader without requiring it to be user-owned."""
    path = Path(path).resolve(strict=True)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_uid in (0, os.geteuid())
             and not before.st_mode & 0o022 and 0 < before.st_size <= 256 * core.MIB,
             "trusted_system_executable")
        digest, count = hashlib.sha256(), 0
        while True:
            block = os.read(fd, 65536)
            if not block:
                break
            count += len(block)
            need(count <= before.st_size, "system_executable_grew")
            digest.update(block)
        need(count == before.st_size and core.stamp(before) == core.stamp(os.fstat(fd)),
             "system_executable_changed")
        return {"path": str(path), "sha256": digest.hexdigest()}
    finally:
        os.close(fd)


def validate_stage_spec(spec, stage, output):
    need(isinstance(spec, dict) and set(spec) == COMMON_SPEC_FIELDS | STAGE_SPEC_FIELDS[stage],
         "exact_stage_plan_fields")
    need(spec["schema"] == "heptabao.formal-kv2-cold-recovery-stage-plan.v1"
         and spec["stage"] == stage and spec["limits"] == LIMITS
         and str(core.absolute(output)) == spec["output_root"], "fixed_stage_plan_schema_and_budgets")
    need(re.fullmatch(r"[0-9a-f]{32}", spec["run_id"]) and all(re.fullmatch(r"[0-9a-f]{40}", spec[k])
         for k in ("source_commit", "source_tree")), "stage_candidate_identity")
    need(spec["host_label"] == "mac" if stage != "linux_target" else spec["host_label"] in ("x230", "rog", "pocket4"),
         "stage_host_policy")
    need(set(spec["controller"]) == {"path", "sha256"}
         and Path(spec["controller"]["path"]) == Path(__file__).resolve()
         and spec["controller"]["sha256"] == core.sha_file(__file__), "same_frozen_stage_controller")
    need(set(spec["interpreter"]) == {"path", "sha256", "runtime_path", "runtime_sha256"},
         "interpreter_binding_shape")
    launcher = system_executable(spec["interpreter"]["path"])
    runtime = system_executable(actual_executable(os.getpid()))
    need(launcher["sha256"] == spec["interpreter"]["sha256"]
         and runtime == {"path": spec["interpreter"]["runtime_path"], "sha256": spec["interpreter"]["runtime_sha256"]},
         "actual_interpreter_runtime_pin")
    # This same, byte-bound central admission is copied to the Linux worker.
    # Backup reruns it; the final gate reruns it again and joins all original
    # worker requests. A copied boolean alone can never qualify the final run.
    admitted = core.pinned(spec["candidate_admission"])
    need(spec["candidate_admission"]["sha256"] == spec["candidate_admission_sha256"]
         and admitted["schema"] == "heptabao.formal-kv2-recovery-candidate-admission.v2"
         and admitted["observer16_each_host_retained"] is True
         and admitted["actual_prerequisite_jobs"] == 14
         and admitted["original_executors"]["required"] == admitted["original_executors"]["passed"] == 14
         and admitted["status"] == "admitted"
         and (admitted["source_commit"], admitted["source_tree"], admitted["full34"]["sha256"])
         == (spec["source_commit"], spec["source_tree"], spec["full34_sha256"]), "copied_candidate_ticket_binding")
    if stage in ("mac_oracle", "linux_target"):
        need(spec["binary"]["sha256"] == admitted["mac_server_sha256" if stage == "mac_oracle" else "linux_server_sha256"]
             and type(spec["port"]) is int and 1024 <= spec["port"] <= 65535, "stage_candidate_binary_and_port")
    return admitted


def scoped_new_root(path, label, forbidden):
    path = core.absolute(path)
    prefix = Path(ACTUAL_HOSTS[label][2])
    need(path != prefix and path.is_relative_to(prefix) and not path.exists(), "new_persistent_host_root")
    for old in forbidden:
        old = core.absolute(old)
        need(path != old and not path.is_relative_to(old) and not old.is_relative_to(path),
             "new_root_overlaps_original_input")
    parent = path.parent
    fd = core.directory_fd(parent)
    try:
        row = os.fstat(fd)
        need(row.st_uid == os.geteuid() and not row.st_mode & 0o022, "persistent_root_parent_owner")
        free = os.fstatvfs(fd).f_bavail * os.fstatvfs(fd).f_frsize
        need(free >= 8 * 1024 ** 3, "persistent_disk_reserve_8gib")
    finally:
        os.close(fd)
    if os.uname().sysname == "Linux":
        # Reject an otherwise ample tmpfs/overlay target. Match actual mount ID
        # through fdinfo, not the spelling of /home or the native_abi label.
        fd = core.directory_fd(parent)
        try:
            rows = Path(f"/proc/self/fdinfo/{fd}").read_text().splitlines()
            ids = [int(x.split()[1]) for x in rows if x.startswith("mnt_id:")]
            need(len(ids) == 1, "actual_target_mount_id")
            mounts = [x for x in Path("/proc/self/mountinfo").read_text().splitlines()
                      if x.split()[0] == str(ids[0])]
            need(len(mounts) == 1, "actual_target_mount_entry")
            fs = mounts[0].split(" - ", 1)[1].split()[0]
            need(fs in ("ext4", "xfs", "btrfs", "zfs"), "persistent_target_filesystem")
        finally:
            os.close(fd)
    return {"path": str(path), "prefix": str(prefix), "free_bytes_before": free}


class Stage:
    def __init__(self, stage, spec, spec_binding, output):
        self.stage, self.spec, self.output = stage, spec, core.absolute(output)
        candidate = core.pinned(spec["candidate_admission"])
        output_admission = scoped_new_root(self.output, spec["host_label"],
            [spec["source_root"], candidate["original_work_root"], spec["backup_root"]]
            + ([spec["clone_root"]] if "clone_root" in spec else []))
        core.new_directory(self.output)
        self.started = core.now_ns()
        self.deadline = self.started + LIMITS["stage_seconds"] * 1_000_000_000
        self.report = {"schema": SCHEMA, "stage": stage, "status": "running", "limits": LIMITS,
                       "run_id": spec["run_id"], "source_commit": spec["source_commit"],
                       "source_tree": spec["source_tree"], "full34_sha256": spec["full34_sha256"],
                       "candidate_admission_sha256": spec["candidate_admission_sha256"],
                       "spec": spec_binding, "candidate_admission": spec["candidate_admission"],
                       "interpreter": spec["interpreter"],
                       "source_driver_sha256": core.FULL34_DRIVER_SHA256,
                       "controller_sha256": core.sha_file(__file__), "dependencies": PINS,
                       "configured_host": spec["host_label"], "production_changed": False,
                       "original31_replaced": False, "snapshot_only_empty_cluster_supported": False,
                       "automatic_retry": False, "mutations": [], "checks": [],
                       "output_root_admission": output_admission,
                       "required_checks": list(CHECKS[stage]), "required_count": len(CHECKS[stage])}
        self.physical = local_host(spec["host_label"], spec["expected_host"])
        self.report["actual_host"] = self.physical
        if "backup_manifest" in spec:
            self.report["backup_manifest"] = spec["backup_manifest"]
            self.report["backup_result"] = spec["backup_result"]
        self.report["backup_root"] = spec["backup_root"]
        self.registry = None
        self.secrets = []

    def check(self, name, passed):
        need(name in CHECKS[self.stage] and name not in {r["case"] for r in self.report["checks"]},
             "unique_declared_recovery_check")
        self.report["checks"].append({"case": name, "passed": passed is True})
        need(passed is True, name)

    def private(self, name, value, full31=None):
        raw = value if isinstance(value, bytes) else full31.canonical(value) if full31 is not None else core.canonical(value)
        return core.write_new(self.output / name, raw)

    def finish(self):
        if self.registry is not None:
            try:
                receipt = self.registry.finish()
                self.report["custody_result"] = {"path": str(self.output / "process-custody/result.public.json"),
                                                 "sha256": core.sha_file(self.output / "process-custody/result.public.json")}
                valid = (receipt["integrity"] is True and receipt["all_registered_original_children_reaped"] is True
                         and receipt["all_registered_session_groups_empty_before_reap"] is True)
                name = "mac_all_owned_processes_reaped" if self.stage == "mac_oracle" else "linux_all_owned_processes_reaped"
                self.check(name, valid)
                final = custody.observe_registered_sessions(self.output / "process-custody", self.spec["run_id"],
                                                             time.monotonic() + LIMITS["stop_seconds"])
                self.report["fresh_custody_observation"] = final
                need(final["all_members_absent"] is True, "fresh_final_owned_session_not_empty")
            except BaseException as error:
                self.report.setdefault("failure", "owned_cleanup_" + type(error).__name__)
        existing = {r["case"] for r in self.report["checks"]}
        for name in CHECKS[self.stage]:
            if name not in existing:
                self.report["checks"].append({"case": name, "passed": False, "not_run": True})
        self.report["passed_count"] = sum(row["passed"] is True for row in self.report["checks"])
        self.report["full_denominator_retained"] = len(self.report["checks"]) == self.report["required_count"]
        self.report["status"] = "passed" if (self.report["passed_count"] == self.report["required_count"]
                                                and "failure" not in self.report) else "failed"
        self.report["elapsed_ns"] = core.now_ns() - self.started
        if self.report["elapsed_ns"] > LIMITS["stage_seconds"] * 1_000_000_000:
            self.report["failure"] = "original_stage_deadline_exceeded"
            self.report["status"] = "failed"
        raw = core.canonical(self.report)
        need(not any(value and value.encode() in raw for value in self.secrets), "public_result_contains_credential")
        binding = core.write_new(self.output / "result.public.json", raw)
        print(json.dumps({"status": self.report["status"], "result": binding["path"],
                          "result_sha256": binding["sha256"], "production_changed": False}))
        return 0 if self.report["status"] == "passed" else 1


def validate_bundle_manifest(backup, binding):
    backup = core.absolute(backup)
    manifest = core.pinned(binding, private=True, maximum=32 * core.MIB)
    need(manifest["schema"] == core.SCHEMA, "closed_backup_manifest_schema")
    need(Path(binding["path"]) == backup / "manifest.private.json", "backup_manifest_exact_root")
    leaves = manifest["durable"]["leaves"]
    names = [r["leaf"] for r in leaves]
    need(names == sorted(set(names)) and core.CORE <= set(names) and len(names) > 4
         and all(n in core.CORE or core.NV6.fullmatch(n) for n in names)
         and manifest["durable"]["complete_leaf_count"] == len(names)
         and manifest["durable"]["immutable_ciphertext_count"] == len(names) - 4,
         "backup_all_core_and_ciphertext_names")
    allowed = set()
    for item in manifest["backup_files"]:
        relative = item["relative"]
        path = backup / relative
        need(path.is_relative_to(backup) and ".." not in Path(relative).parts and path != backup,
             "backup_relative_path")
        need(relative not in allowed, "duplicate_backup_manifest_leaf")
        allowed.add(relative)
        need(core.sha_file(path, private=True) == item["sha256"] and path.stat().st_size == item["bytes"],
             "backup_file_pin")
    data_rows = {r["relative"][5:]: (r["bytes"], r["sha256"]) for r in manifest["backup_files"]
                 if r["relative"].startswith("data/")}
    need(data_rows == {r["leaf"]: (r["bytes"], r["sha256"]) for r in leaves},
         "backup_complete_durable_manifest_projection")
    expected_nondata = {"runtime/server.template.json", "private/root.token", "private/unseal.key",
                        "tls/tls.key", "tls/tls.crt", "tls/ca.crt", "snapshots/original.snap",
                        "oracle/source-bundle.json", "oracle/original-openbao-observations.json"}
    expected_nondata.update(f"oracle/version-{n:04d}.json" for n in range(1, 20))
    audit = {p for p in allowed if p.startswith("runtime/") and core.AUDIT.fullmatch(Path(p).name)}
    need({"runtime/audit.jsonl", "runtime/audit.jsonl.hmac-key"} <= audit
         and allowed == {"data/" + n for n in names} | expected_nondata | audit,
         "backup_complete_known_key_runtime_oracle_closure")
    allowed_directories = {str(p) for name in allowed for p in Path(name).parents if str(p) != "."}
    actual = set()
    for parent, dirs, files in os.walk(backup, followlinks=False):
        for name in dirs:
            path = Path(parent) / name
            need(not path.is_symlink() and str(path.relative_to(backup)) in allowed_directories,
                 "unknown_or_symlink_backup_directory")
        for name in files:
            relative = str((Path(parent) / name).relative_to(backup))
            if relative == "manifest.private.json":
                need(Path(binding["path"]) == Path(parent) / name, "backup_manifest_location")
                continue
            actual.add(relative)
    need(actual == allowed, "unknown_or_missing_backup_asset")
    return manifest


def prepare_backup(stage):
    spec = stage.spec
    # The central admission module reruns both host regressions, normal build
    # chains, original full31 and original executor records. A boolean receipt
    # in a caller-created plan cannot substitute this call.
    admission_module = helper("formal_kv2_recovery_admission.py", "formal_recovery_admission")
    admission = admission_module.validate_candidate(spec["candidate_plan"])
    need(hashlib.sha256(core.canonical(admission)).hexdigest() == spec["candidate_admission_sha256"],
         "candidate_admission_different_from_reviewed_plan")
    stage.report["candidate_admission"] = stage.private("candidate-admission.public.json", admission)
    stage.check("candidate_full31_and_executor_gate", True)
    full31 = core.load_full34_semantics(spec["semantics"])
    full = core.pinned(spec["full34"])
    summary = core.pinned(spec["full34_summary"], private=True)
    source_root = Path(spec["original_work_root"])
    candidate = Path(summary["owned_roots"]["target"])
    need(candidate == source_root / "candidate", "original_candidate_root")
    old_custody = custody.observe_registered_sessions(
        Path(spec["full34"]["path"]).parent / "process-custody", full["custody_nonce"], time.monotonic() + 5)
    need(old_custody["all_members_absent"] is True, "original_owned_processes_still_present")
    stage.report["original_process_observation"] = old_custody
    config_raw = core.read_bytes(candidate / "server.json", 65536)
    need(hashlib.sha256(config_raw).hexdigest() == summary["candidate_startup"]["config_sha256"],
         "original_normal_config_pin")
    config = core.decode_json(config_raw)
    need(set(config) == {"listen", "data_dir", "audit_file", "tls_cert_file", "tls_key_file", "storage"}
         and config["data_dir"] == str(candidate / "data")
         and config["storage"] == {"native_v6_file": {"path": str(candidate / "data")}}
         and config["audit_file"] == str(candidate / "audit.jsonl")
         and config["tls_cert_file"] == str(candidate / "tls.crt")
         and config["tls_key_file"] == str(candidate / "tls.key"), "exact_original_normal_file_config")
    known = {"data", "server.json", "server.log", "ca.key", "ca.crt", "tls.key", "tls.crt",
             "tls.csr", "leaf.ext", "ca.srl", "root.token", "unseal.key"}
    names = sorted(os.listdir(candidate))
    need(all(name in known or core.AUDIT.fullmatch(name) for name in names), "unknown_candidate_asset_requires_review")
    backup = Path(spec["backup_root"])
    stage.report["backup_root_admission"] = scoped_new_root(backup, "mac", (source_root, spec["source_root"]))
    core.new_directory(backup)
    for name in ("runtime", "private", "tls", "oracle", "snapshots"):
        core.new_directory(backup / name)
    end = min(stage.deadline, core.now_ns() + LIMITS["backup_seconds"] * 1_000_000_000)
    before = core.inventory_original_tree(source_root, end)
    durable = core.copy_durable_closure(candidate / "data", backup / "data", end)
    stage.check("original_processes_stopped_and_directory_fenced", True)
    inputs, files = [], []
    for row in durable["leaves"]:
        files.append({"relative": "data/" + row["leaf"], "bytes": row["bytes"], "sha256": row["sha256"]})
    selected = [
        (candidate / "server.json", "runtime/server.template.json", True),
        (candidate / "root.token", "private/root.token", True),
        (candidate / "unseal.key", "private/unseal.key", True),
        (candidate / "tls.key", "tls/tls.key", True),
        (candidate / "tls.crt", "tls/tls.crt", False),
        (candidate / "ca.crt", "tls/ca.crt", False),
        (source_root / "native-snapshot.tar.gz", "snapshots/original.snap", True),
        (source_root / "source-bundle.json", "oracle/source-bundle.json", True),
    ]
    selected.extend((candidate / name, "runtime/" + name, True) for name in names if core.AUDIT.fullmatch(name))
    need("audit.jsonl" in names and "audit.jsonl.hmac-key" in names, "complete_original_audit_key_and_log")
    wire_rows = summary["source_api_wire_observations"]
    need(len(wire_rows) == 19, "nineteen_original_wire_records")
    for number in range(1, 20):
        original = source_root / "source-api-oracle" / f"version-{number:04d}.json"
        rows = [r for r in wire_rows if r["path"] == f"secret/data/history?version={number}"]
        need(len(rows) == 1 and rows[0]["endpoint"] == "source" and rows[0]["method"] == "GET"
             and rows[0]["status"] == 200 and rows[0]["private_body_path"] == str(original)
             and core.sha_file(original, private=True) == rows[0]["body_sha256"], "original_api_wire_file_binding")
        selected.append((original, f"oracle/version-{number:04d}.json", True))
    for source, relative, private in selected:
        row = core.copy_one(source, backup / relative, maximum=core.MAX_INPUT_BYTES,
                            private=private, deadline_ns=end)
        inputs.append({**row, "source_private": private, "relative": relative})
        files.append({"relative": relative, "bytes": row["bytes"], "sha256": row["sha256"]})
    need(core.sha_file(backup / "snapshots/original.snap", private=True) == summary["snapshot"]["archive_sha256"],
         "original_snapshot_input_pin")
    stage.check("complete_sealed_copy_all_leaves", True)
    api = {str(v): core.read_bytes(backup / f"oracle/version-{v:04d}.json") for v in range(1, 20)}
    oracle, _ = core.reconstruct_original_oracle(full31, core.read_bytes(backup / "oracle/source-bundle.json"),
                                               api, summary["source_history_sha256"])
    oracle_binding = core.write_new(backup / "oracle/original-openbao-observations.json", full31.canonical(oracle))
    files.append({"relative": "oracle/original-openbao-observations.json", "bytes": Path(oracle_binding["path"]).stat().st_size,
                  "sha256": oracle_binding["sha256"]})
    stage.check("original_openbao_baseline_digest", True)
    after = core.inventory_original_tree(source_root, end)
    need(before == after, "complete_original_tree_changed_during_backup")
    stage.check("source_full_tree_unchanged_after_copy", True)
    manifest = {"schema": core.SCHEMA, "run_id": spec["run_id"], "source_commit": spec["source_commit"],
                "source_tree": spec["source_tree"], "full34_sha256": spec["full34_sha256"],
                "candidate_admission_sha256": spec["candidate_admission_sha256"],
                "durable": durable, "inputs": inputs, "backup_files": files, "original_tree": before,
                "original_openbao_oracle_sha256": summary["source_history_sha256"],
                "excluded_runtime_assets": sorted(set(names) - {"data"} - {p.name for p, _, _ in selected}),
                "exclusion_policy": "known TLS signing/intermediate files and server log remain in original-tree inventory; no durable leaf excluded",
                "secret_bytes_in_manifest": False, "snapshot_only_empty_cluster_supported": False}
    binding = core.write_new(backup / "manifest.private.json", manifest)
    stage.report.update(backup_manifest=binding, durable_leaf_count=len(durable["leaves"]),
                        nv6_ciphertext_count=durable["immutable_ciphertext_count"],
                        durable_bytes=durable["bytes"], original_tree_sha256=hashlib.sha256(core.canonical(before)).hexdigest(),
                        original_openbao_oracle_sha256=summary["source_history_sha256"])
    stage.report["original_tree_inventory"] = stage.private("original-tree.private.json", before)
    stage.report["public_durable_inventory"] = [{k: row[k] for k in ("leaf", "bytes", "sha256")} for row in durable["leaves"]]


def copied_runtime(stage, manifest):
    spec, backup = stage.spec, Path(stage.spec["backup_root"])
    root = Path(spec["clone_root"])
    forbid = (manifest["original_tree"]["root"], manifest["durable"]["source_directory"], backup, spec["source_root"])
    admission = scoped_new_root(root, spec["host_label"], forbid)
    core.new_directory(root)
    copy_receipt = core.clone_verified_data(backup / "data", root / "data", manifest["durable"], stage.deadline)
    binary = Path(spec["binary"]["path"])
    need(core.sha_file(binary) == spec["binary"]["sha256"], "actual_candidate_binary_pin")
    core.copy_one(binary, root / "heptabao-server", maximum=256 * core.MIB, private=False, deadline_ns=stage.deadline)
    (root / "heptabao-server").chmod(0o700)
    for relative in ("tls/ca.crt", "tls/tls.crt", "tls/tls.key", "private/root.token", "private/unseal.key",
                     "snapshots/original.snap"):
        name = "restore.snap" if relative.endswith("original.snap") else Path(relative).name
        core.copy_one(backup / relative, root / name, maximum=core.MAX_INPUT_BYTES, deadline_ns=stage.deadline)
    for row in manifest["backup_files"]:
        relative = row["relative"]
        if relative.startswith("runtime/") and core.AUDIT.fullmatch(Path(relative).name):
            core.copy_one(backup / relative, root / Path(relative).name,
                          maximum=core.MAX_INPUT_BYTES, deadline_ns=stage.deadline)
    config = core.decode_json(core.read_bytes(backup / "runtime/server.template.json", 65536))
    config.update(listen=f"127.0.0.1:{spec['port']}", data_dir=str(root / "data"), audit_file=str(root / "audit.jsonl"),
                  tls_cert_file=str(root / "tls.crt"), tls_key_file=str(root / "tls.key"),
                  storage={"native_v6_file": {"path": str(root / "data")}})
    config_binding = core.write_new(root / "server.json", config)
    text = core.canonical(config).decode()
    need(all(str(old) not in text for old in forbid), "configuration_references_original_root")
    need(set(config) == {"listen", "data_dir", "audit_file", "tls_cert_file", "tls_key_file", "storage"},
         "normal_file_config_only")
    token = core.read_bytes(root / "root.token", 65536).decode().strip()
    key = core.read_bytes(root / "unseal.key", 65536).decode().strip()
    stage.secrets.extend((token, key))
    ca_raw = core.read_bytes(root / "ca.crt")
    leaf = ssl.PEM_cert_to_DER_cert(core.read_bytes(root / "tls.crt").decode())
    physical_pin = hashlib.sha256(core.canonical(stage.physical)).hexdigest()
    transport = {"schema": wire.SCHEMA, "run_id": spec["run_id"], "scope": "formal_kv2_recovery",
                 "engine": "heptabao", "cohort": "formal-kv2-cold-restore-full34", "production_authority": False,
                 "source_commit": spec["source_commit"], "source_tree": spec["source_tree"], "root": str(root),
                 "nodes": [{"id": "recovered", "label": spec["host_label"], "alias": spec["host_label"],
                            "actual_hostname": stage.physical["hostname"], "physical_binding_sha256": physical_pin,
                            "ip": "127.0.0.1", "port": spec["port"], "ca_file": str(root / "ca.crt"),
                            "ca_sha256": hashlib.sha256(ca_raw).hexdigest(), "leaf_sha256": hashlib.sha256(leaf).hexdigest()}],
                 "archive_files": [{"path": str(root / "restore.snap"), "kind": "snapshot"}],
                 "tls_policy": "native128-original"}
    transport_binding = core.write_new(root / "wire-admission.json", transport)
    stage.report.update(clone_root_admission=admission, clone_data_manifest_sha256=hashlib.sha256(core.canonical(copy_receipt)).hexdigest(),
                        binary_sha256=spec["binary"]["sha256"], config_binding=config_binding,
                        original_directory_identity=manifest["durable"]["source_directory_identity"],
                        new_directory_identity=core.stamp((root / "data").stat()), physical_binding_sha256=physical_pin)
    stage.report["clone_data_manifest"] = stage.private("clone-data-manifest.private.json", copy_receipt)
    stage.report["wire_admission"] = transport_binding
    stage.report["config_evidence"] = stage.private("server-config.private.json", core.read_bytes(root / "server.json", 65536))
    stage.report["wire_admission_evidence"] = stage.private("wire-admission.private.json", core.read_bytes(root / "wire-admission.json", 65536))
    return root, token, key, transport_binding


class Endpoint:
    def __init__(self, stage, root, token, binding, full31):
        self.stage, self.root, self.token, self.binding, self.full31 = stage, root, token, binding, full31
        self.ordinal = 0

    def call(self, method, path, body=None, *, archive=None, public=False, deadline_ns=None):
        core.live(self.stage.deadline)
        end = min(self.stage.deadline, wire.clock_ns() + 15_000_000_000,
                  deadline_ns if deadline_ns is not None else self.stage.deadline)
        self.ordinal += 1
        mutation = None
        if method not in ("GET", "LIST"):
            mutation = {"ordinal": self.ordinal, "method": method, "path": path,
                        "outcome": "unknown", "retried": False}
            self.stage.report["mutations"].append(mutation)
        packet = {"clock_domain": wire.CLOCK_DOMAIN, "deadline_ns": end, "node_id": "recovered",
                  "token": "" if public else self.token, "method": method, "path": path,
                  "body": None if body is None else base64.b64encode(self.full31.canonical(body)).decode(),
                  "archive_in": None if archive is None else str(archive),
                  "archive_sha256": None if archive is None else core.sha_file(archive, private=True, deadline_ns=end),
                  "archive_out": None}
        metadata, raw = wire.perform(self.binding["path"], self.binding["sha256"], packet, end)
        decoded = self.full31.decode(raw) if raw else {}
        response = self.stage.private(f"http-{self.ordinal:04d}.private.json", raw)
        receipt = {"ordinal": self.ordinal, "method": method, "path": path, "metadata": metadata,
                   "private_response": response, "deadline_ns": end, "clock_domain": wire.CLOCK_DOMAIN}
        self.stage.private(f"http-{self.ordinal:04d}.public.json", receipt)
        wire.remaining(end)  # Include decode, evidence fsync and receipt in this original request budget.
        if mutation is not None:
            mutation.update(outcome="response_received", status=metadata["status"])
        return metadata["status"], decoded, metadata

    def observe(self, count=19):
        status, config, _ = self.call("GET", "secret/config")
        need(status == 200 and isinstance(config.get("data"), dict), "read_config")
        status, meta, _ = self.call("GET", "secret/metadata/history")
        need(status == 200 and isinstance(meta.get("data"), dict), "read_metadata")
        versions = {}
        for n in range(1, count + 1):
            status, body, _ = self.call("GET", f"secret/data/history?version={n}")
            need(status in (200, 404) and isinstance(body.get("data"), dict), "read_retained_version")
            versions[str(n)] = {"status": status, "data": body["data"]}
        return {"config": config["data"], "metadata": meta["data"], "versions": versions}

    def witnesses(self, count=19):
        rows = {}
        for n in range(1, count + 1):
            status, body, _ = self.call("POST", "sys/internal/storage/kv2-version-witness",
                                       {"mount": "secret", "path": "history", "version": n})
            need(status == 200, "actual_native_storage_witness")
            rows[str(n)] = body
        return rows


def actual_executable(pid):
    if os.uname().sysname == "Linux":
        return Path(os.readlink(f"/proc/{pid}/exe"))
    library = ctypes.CDLL("/usr/lib/libproc.dylib", use_errno=True)
    buffer = ctypes.create_string_buffer(4096)
    size = library.proc_pidpath(pid, buffer, len(buffer))
    need(size > 0, "kernel_product_executable_unavailable")
    return Path(buffer.value.decode())


class Product:
    def __init__(self, stage, root, endpoint, key):
        self.stage, self.root, self.endpoint, self.key = stage, root, endpoint, key
        self.child = None
        self.launches = []

    def start(self):
        need(self.child is None, "product_already_owned")
        need(not DRAFT_ONLY, "draft_product_execution_closed")
        core.live(self.stage.deadline)
        log = self.root / (f"server-{len(self.launches)+1:02d}.private.log")
        fd = os.open(log, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
        try:
            argv = [str(self.root / "heptabao-server"), "--config", str(self.root / "server.json")]
            self.child = subprocess.Popen(argv, cwd=self.root, stdin=subprocess.DEVNULL, stdout=fd, stderr=fd,
                                          env={"PATH": "/usr/bin:/bin", "LC_ALL": "C", "TZ": "UTC"},
                                          start_new_session=True)
        finally:
            os.close(fd)
        launch = {"guardian_pid": self.child.pid, "actual_product_pid": None,
                  "original_guardian_birth": self.child.custody_birth, "argv": argv,
                  "custody_prefix": str(self.child.custody_prefix), "start_completed": False}
        self.launches.append(launch)
        self.stage.report["product_launches"] = self.launches
        started = custody.private_json(self.child.custody_prefix.with_suffix(".started.json"))
        target_pid = started["target_pid"]
        launch["actual_product_pid"] = target_pid
        path = actual_executable(target_pid)
        need(path == self.root / "heptabao-server" and core.sha_file(path) == self.stage.spec["binary"]["sha256"],
             "actual_kernel_product_binary_not_candidate")
        launch.update(kernel_executable=str(path), executable_sha256=core.sha_file(path))
        end = min(self.stage.deadline, core.now_ns() + 15_000_000_000)
        while True:
            need(self.child.poll() is None, "normal_product_exited_before_listener")
            try:
                status, body, _ = self.endpoint.call("GET", "sys/init", public=True, deadline_ns=end)
                need(status == 200 and body.get("initialized") is True, "restored_product_initialized_without_init")
                break
            except (ConnectionError, OSError):
                need(core.now_ns() < end, "original_product_startup_deadline")
                time.sleep(min(0.05, (end - core.now_ns()) / 1_000_000_000))
        status, health, _ = self.endpoint.call("GET", "sys/health", public=True)
        need(status == 503 and health.get("sealed") is True, "fresh_product_must_start_sealed")
        status, unsealed, _ = self.endpoint.call("POST", "sys/unseal", {"key": self.key}, public=True)
        need(status == 200 and unsealed.get("sealed") is False, "normal_original_shamir_unseal")
        status, capacity, _ = self.endpoint.call("GET", "sys/internal/capacity")
        capacity = capacity.get("data", capacity)
        need(status == 200 and capacity.get("state_storage_format") == "heptabao-state-records-v6"
             and capacity.get("native_kv2_reader_format") == 2, "normal_native_v6_file_recovered")
        launch["start_completed"] = True

    def stop(self):
        if self.child is None:
            return
        child = self.child
        if child.custody_lifeline is not None:
            os.close(child.custody_lifeline)
            child.custody_lifeline = None
        child.wait(timeout=5)
        need(child.custody_group_result["group_empty_before_first_reap"] is True,
             "owned_product_group_not_empty_before_reap")
        self.launches[-1]["stop"] = child.custody_group_result
        self.child = None


def bounded_command(argv, stage):
    core.live(stage.deadline)
    # These are real readelf/loader probes, not product launches. They still get
    # the same original-Popen guardian and parent-EOF cleanup as every product.
    ordinal = len(stage.report.setdefault("abi_commands", [])) + 1
    stdout_path = stage.output / (f"abi-{ordinal:02d}.stdout.private.log")
    stderr_path = stage.output / (f"abi-{ordinal:02d}.stderr.private.log")
    out = os.open(stdout_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    err = os.open(stderr_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    child = None
    row = {"argv": argv, "outcome": "unknown", "budget_seconds": 15, "program": system_executable(argv[0])}
    stage.report["abi_commands"].append(row)
    try:
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                 env={"PATH": "/usr/bin:/bin", "LC_ALL": "C"}, start_new_session=True)
        row["guardian_pid"] = child.pid
        row["custody_prefix"] = str(child.custody_prefix)
        end = min(stage.deadline, core.now_ns() + 15_000_000_000)
        while child.poll() is None:
            core.live(end)
            need(os.fstat(out).st_size <= core.MIB and os.fstat(err).st_size <= core.MIB,
                 "abi_output_byte_bound")
            time.sleep(min(0.02, max(0, (end - core.now_ns()) / 1_000_000_000)))
    finally:
        if child is not None and child.returncode is None:
            if child.custody_lifeline is not None:
                os.close(child.custody_lifeline)
                child.custody_lifeline = None
            child.wait(timeout=5)
        os.fsync(out)
        os.fsync(err)
        os.close(out)
        os.close(err)
        row["stdout"] = {"path": str(stdout_path), "sha256": core.sha_file(stdout_path, private=True)}
        row["stderr"] = {"path": str(stderr_path), "sha256": core.sha_file(stderr_path, private=True)}
        row["exit_code"] = None if child is None else child.returncode
    stdout = core.read_bytes(stdout_path, core.MIB)
    stderr = core.read_bytes(stderr_path, core.MIB)
    need(child.returncode == 0 and not stderr and len(stdout) <= core.MIB, "bounded_abi_command_failed")
    row["outcome"] = "completed"
    return stdout.decode("utf-8")


def actual_linux_abi(stage, binary):
    need(os.uname().sysname == "Linux" and os.uname().machine == "x86_64", "actual_linux_x86_64_target")
    with binary.open("rb") as stream:
        header = stream.read(64)
    need(header[:4] == b"\x7fELF" and header[4:6] == b"\x02\x01" and struct.unpack_from("<H", header, 18)[0] == 62,
         "actual_elf64_little_x86_64")
    readelf = shutil.which("readelf")
    need(readelf is not None, "readelf_required_for_actual_abi")
    output = bounded_command([readelf, "-l", "-d", "-V", str(binary)], stage)
    need(not re.search(r"\((?:RPATH|RUNPATH)\)", output), "candidate_runtime_search_path_refused")
    rows = re.findall(r"Requesting program interpreter:\s*([^\]\n]+)\]", output)
    need(len(rows) == 1 and rows[0] == "/lib64/ld-linux-x86-64.so.2", "actual_gnu_interpreter_contract")
    loader = Path(rows[0]).resolve(strict=True)
    need(loader.is_file() and loader.stat().st_uid == 0 and not loader.stat().st_mode & 0o022,
         "trusted_actual_loader")
    verified = bounded_command([str(loader), "--verify", str(binary)], stage)
    mapped = bounded_command([str(loader), "--list", str(binary)], stage)
    libraries = []
    for name in re.findall(r"(?:=>\s*)?(/[^\s]+)\s+\(0x[0-9a-f]+\)", mapped):
        path = Path(name).resolve(strict=True)
        need(path.is_file() and path.stat().st_uid == 0 and not path.stat().st_mode & 0o022,
             "actual_dynamic_dependency_owner")
        libraries.append({"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    need(libraries, "actual_dynamic_dependencies_observed")
    return {"elf": "ELF64-LSB-EM_X86_64", "interpreter": str(loader),
            "interpreter_sha256": hashlib.sha256(loader.read_bytes()).hexdigest(),
            "host_glibc": os.confstr("CS_GNU_LIBC_VERSION"),
            "required_glibc_versions": sorted(set(re.findall(r"GLIBC_[0-9]+\.[0-9]+(?:\.[0-9]+)?", output))),
            "loader_verify_stdout": verified, "loader_list_stdout": mapped, "resolved_libraries": libraries,
            "readelf_stdout_sha256": hashlib.sha256(output.encode()).hexdigest(),
            "binary_sha256": core.sha_file(binary), "program_entry_executed_by_abi_probe": False}


def run_clone(stage):
    spec = stage.spec
    manifest = validate_bundle_manifest(spec["backup_root"], spec["backup_manifest"])
    need((manifest["source_commit"], manifest["source_tree"], manifest["full34_sha256"], manifest["candidate_admission_sha256"])
         == (spec["source_commit"], spec["source_tree"], spec["full34_sha256"], spec["candidate_admission_sha256"]),
         "clone_backup_candidate_binding")
    previous = core.pinned(spec["backup_result"])
    need(previous["schema"] == SCHEMA and previous["stage"] == "backup" and previous["status"] == "passed"
         and previous["backup_manifest"]["sha256"] == spec["backup_manifest"]["sha256"]
         and previous["run_id"] == spec["run_id"] and previous["full34_sha256"] == spec["full34_sha256"]
         and previous["candidate_admission_sha256"] == spec["candidate_admission_sha256"]
         and previous["required_count"] == previous["passed_count"] == len(CHECKS["backup"]),
         "complete_backup_required_before_new_product")
    oracle_receipt = None
    if stage.stage == "linux_target":
        oracle_receipt = core.pinned(spec["mac_oracle_result"])
        need(oracle_receipt["schema"] == SCHEMA and oracle_receipt["status"] == "passed"
             and oracle_receipt["stage"] == "mac_oracle" and oracle_receipt["run_id"] == spec["run_id"]
             and oracle_receipt["source_commit"] == spec["source_commit"]
             and oracle_receipt["source_tree"] == spec["source_tree"]
             and oracle_receipt["full34_sha256"] == spec["full34_sha256"]
             and oracle_receipt["backup_manifest"]["sha256"] == spec["backup_manifest"]["sha256"]
             and oracle_receipt["required_count"] == oracle_receipt["passed_count"] == len(CHECKS["mac_oracle"])
             and oracle_receipt["fresh_custody_observation"]["all_members_absent"] is True,
             "complete_independent_mac_oracle_required_before_linux_product")
    full31 = core.load_full34_semantics(spec["semantics"])
    backup = Path(spec["backup_root"])
    api = {str(v): core.read_bytes(backup / f"oracle/version-{v:04d}.json") for v in range(1, 20)}
    original, bundle = core.reconstruct_original_oracle(full31, core.read_bytes(backup / "oracle/source-bundle.json"),
                                                       api, manifest["original_openbao_oracle_sha256"])
    root, token, key, transport = copied_runtime(stage, manifest)
    stage.registry = custody.Registry(stage.output / "process-custody", spec["run_id"]).install()
    prefix = "mac" if stage.stage == "mac_oracle" else "linux"
    if prefix == "linux":
        stage.report["actual_abi"] = actual_linux_abi(stage, root / "heptabao-server")
        stage.check("linux_actual_elf_loader_compatibility", True)
        # Actual Linux host cannot read any original Mac input. No mount or
        # network endpoint is used to make that path appear during this run.
        need(not Path(manifest["original_tree"]["root"]).exists(), "old_mac_root_visible_on_linux")
    stage.check(prefix + "_fresh_root_no_original_path", True)
    endpoint = Endpoint(stage, root, token, transport, full31)
    product = Product(stage, root, endpoint, key)
    try:
        product.start()
        stage.check(prefix + "_normal_sealed_unseal", True)
        observed, raw = endpoint.observe(), endpoint.witnesses()
        if prefix == "mac":
            expected = core.final_delta_expected(full31, original, api, observed)
            stage.check("mac_final_api_exact_known_delta", True)
            witnesses = core.validate_complete_observation(full31, observed, expected, raw, bundle, final_state=True)
            stage.check("mac_final_raw_all_19", True)
            stage.report["A_oracle"] = stage.private("final-api-oracle.private.json", observed, full31)
            stage.report["A_raw_witnesses"] = stage.private("final-raw-witnesses.private.json", raw, full31)
            stage.report["A_oracle_basis"] = "independent normal Mac clone of exact sealed backup plus exact original31 semantic delta; final updated_time first observed here"
            return
        expected_raw = core.read_bytes(spec["mac_oracle_file"]["path"])
        need(hashlib.sha256(expected_raw).hexdigest() == spec["mac_oracle_file"]["sha256"]
             == oracle_receipt["A_oracle"]["sha256"], "complete_mac_oracle_bytes_binding")
        expected = full31.decode(expected_raw)
        need(full31.same_json_tokens(observed, expected), "linux_A_full_api_not_equal_mac_oracle")
        stage.check("linux_A_api_exact_mac_clone_oracle", True)
        core.validate_complete_observation(full31, observed, expected, raw, bundle, final_state=True)
        stage.check("linux_A_raw_all_19", True)
        stage.report["A_observation"] = stage.private("A-api.private.json", observed, full31)
        stage.report["A_raw_witnesses"] = stage.private("A-raw-witnesses.private.json", raw, full31)
        stage.report["mac_oracle_result"] = spec["mac_oracle_result"]
        stage.report["mac_oracle_file"] = spec["mac_oracle_file"]
        snapshot = root / "restore.snap"
        status, body, wire_receipt = endpoint.call("POST", "sys/storage/raft/snapshot", archive=snapshot)
        need(status == 204 and body == {} and wire_receipt["raw_tls_http204"] is True
             and wire_receipt["peer_eof_observed"] is True and wire_receipt["tls_close_notify_observed"] is True,
             "B_restore_exact_raw_204")
        stage.check("linux_B_snapshot_once_strict_204", True)
        stage.report["snapshot_restore"] = {"count": 1, "archive_sha256": core.sha_file(snapshot, private=True),
                                            "wire_receipt": wire_receipt, "mutating_request_ordinal": endpoint.ordinal}
        product.stop()
        product.start()
        restored, restored_raw = endpoint.observe(), endpoint.witnesses()
        need(full31.same_json_tokens(restored, original), "B_original_openbao_api_history_mismatch")
        stage.check("linux_B_cold_api_exact_openbao", True)
        core.validate_complete_observation(full31, restored, original, restored_raw, bundle, final_state=False)
        stage.check("linux_B_cold_raw_all_19", True)
        stage.report["B_observation"] = stage.private("B-api.private.json", restored, full31)
        stage.report["B_raw_witnesses"] = stage.private("B-raw-witnesses.private.json", restored_raw, full31)
        need(restored["versions"]["1"]["status"] == 404 and restored["versions"]["2"]["status"] == 404,
             "B_deleted_and_destroyed_initially_hidden")
        need(endpoint.call("POST", "secret/undelete/history", {"versions": [1]})[0] == 204,
             "B_soft_undelete_ack")
        status, data, _ = endpoint.call("GET", "secret/data/history?version=1")
        need(status == 200 and full31.same_json_tokens(data["data"]["data"], full31.decode(api["1"])["data"]["data"]),
             "B_retained_soft_payload_exact")
        need(endpoint.call("POST", "secret/undelete/history", {"versions": [2]})[0] == 204,
             "B_destroy_undelete_response")
        status, data, _ = endpoint.call("GET", "secret/data/history?version=2")
        need(status == 404 and data["data"]["data"] is None and data["data"]["metadata"]["destroyed"] is True,
             "B_destroyed_payload_not_resurrected")
        stage.check("linux_B_soft_and_destroyed_restored", True)
        before = endpoint.observe()
        need(endpoint.call("POST", "secret/data/history", {"data": {"must_not_commit": True}, "options": {"cas": 0}})[0] == 400,
             "restored_data_cas_refusal")
        need(full31.same_json_tokens(before, endpoint.observe()), "restored_bad_data_cas_changed_history")
        need(endpoint.call("POST", "secret/metadata/history", {"custom_metadata": {"must_not_commit": "true"}, "metadata_cas": 0})[0] == 400,
             "restored_metadata_cas_refusal")
        need(full31.same_json_tokens(before, endpoint.observe()), "restored_bad_metadata_cas_changed_history")
        stage.check("linux_cas_denials_no_effect", True)
        probe = full31.payload(20, 19, 1024)
        need(endpoint.call("POST", "secret/data/history", {"data": probe, "options": {"cas": 19}})[0] == 200,
             "restored_valid_data_cas_ack")
        need(endpoint.call("POST", "secret/metadata/history", {"custom_metadata": {"revision": "dr-verified"},
             "metadata_cas": before["metadata"]["current_metadata_version"]})[0] == 204, "restored_valid_metadata_cas_ack")
        after, after_raw = endpoint.observe(20), endpoint.witnesses(20)
        validate_post_cas(full31, before, after, probe)
        stage.report["pre_cas_observation"] = stage.private("pre-cas.private.json", before, full31)
        product.stop()
        product.start()
        cold, cold_raw = endpoint.observe(20), endpoint.witnesses(20)
        need(full31.same_json_tokens(after, cold), "restored_ack_not_persistent_after_cold")
        for n in range(1, 21):
            expected_payload = None if n == 2 else probe if n == 20 else full31.payload(n, 17, 2 * core.MIB)
            meta = after["metadata"]["versions"][str(n)]
            full31.verify_storage_witness(after_raw[str(n)], n, meta, expected_payload)
            full31.verify_storage_witness(cold_raw[str(n)], n, meta, expected_payload)
        stage.check("linux_cas_success_persistent_after_cold", True)
        stage.report["persistent_cas_observation"] = stage.private("post-cas-cold.private.json", cold, full31)
        stage.report["persistent_cas_raw_witnesses"] = stage.private("post-cas-cold-raw.private.json", cold_raw, full31)
        for name in ("unseal.key", "root.token", "tls.key", "audit.jsonl.hmac-key"):
            fd = core.file_fd(root / name, private=True)
            os.close(fd)
        stage.check("linux_private_key_custody", True)
    finally:
        product.stop()
        need(core.sha_file(root / "heptabao-server") == spec["binary"]["sha256"]
             and core.sha_file(root / "server.json", private=True) == stage.report["config_binding"]["sha256"],
             "normal_product_binary_or_config_changed")
        stage.report["binary_and_config_unchanged"] = True


def validate_post_cas(full31, before, after, probe):
    """All old public fields remain exact; only the two acknowledged writes differ."""
    expected = copy.deepcopy(before)
    need(set(before["versions"]) == {str(n) for n in range(1, 20)}
         and set(after["versions"]) == {str(n) for n in range(1, 21)}, "post_cas_complete_history")
    new_version = after["metadata"]["versions"]["20"]
    need(set(new_version) == {"created_time", "deletion_time", "destroyed"}
         and new_version["deletion_time"] == "" and new_version["destroyed"] is False,
         "post_cas_new_version_metadata")
    timestamp_pattern = r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,9})?Z"
    need(all(isinstance(t, str) and re.fullmatch(timestamp_pattern, t) for t in
             (new_version["created_time"], after["metadata"]["updated_time"])), "post_cas_actual_timestamp_shape")
    def timestamp(raw):
        import calendar
        from decimal import Decimal
        base, _, fraction = raw[:-1].partition(".")
        return Decimal(calendar.timegm(time.strptime(base, "%Y-%m-%dT%H:%M:%S"))) + Decimal("0." + (fraction or "0"))
    need(timestamp(before["metadata"]["updated_time"]) <= timestamp(new_version["created_time"])
         <= timestamp(after["metadata"]["updated_time"]), "post_cas_acknowledged_clock_order")
    expected["metadata"]["current_version"] = 20
    expected["metadata"]["versions"]["20"] = copy.deepcopy(new_version)
    expected["metadata"]["current_metadata_version"] += 1
    expected["metadata"]["custom_metadata"] = {"revision": "dr-verified"}
    expected["metadata"]["updated_time"] = after["metadata"]["updated_time"]
    for row in expected["versions"].values():
        row["data"]["metadata"]["custom_metadata"] = {"revision": "dr-verified"}
    expected["versions"]["20"] = {"status": 200, "data": {"data": probe,
        "metadata": {**new_version, "version": 20, "custom_metadata": {"revision": "dr-verified"}}}}
    need(full31.same_json_tokens(after, expected), "post_cas_exact_full_public_effect")
    return expected


def verify_source(stage):
    manifest = validate_bundle_manifest(stage.spec["backup_root"], stage.spec["backup_manifest"])
    target = core.pinned(stage.spec["linux_target_result"])
    need(target["stage"] == "linux_target" and target["status"] == "passed"
         and target["source_commit"] == stage.spec["source_commit"]
         and target["full34_sha256"] == stage.spec["full34_sha256"], "target_result_required_before_final_source_read")
    stage.report["completed_target_result"] = stage.spec["linux_target_result"]
    full = core.pinned(stage.spec["full34"])
    fresh = custody.observe_registered_sessions(Path(stage.spec["full34"]["path"]).parent / "process-custody",
                                                 full["custody_nonce"], time.monotonic() + 5)
    need(fresh["all_members_absent"] is True, "original_owned_process_reappeared")
    stage.report["original_process_observation"] = fresh
    need(core.inventory_original_tree(manifest["original_tree"]["root"], stage.deadline) == manifest["original_tree"],
         "complete_original_source_changed_after_recovery")
    stage.report["source_recheck"] = core.recheck_original_inputs(manifest, stage.deadline)
    stage.report["original_tree_sha256"] = hashlib.sha256(core.canonical(manifest["original_tree"])).hexdigest()
    stage.check("original_complete_input_tree_unchanged_at_end", True)
    validate_bundle_manifest(stage.spec["backup_root"], stage.spec["backup_manifest"])
    stage.check("backup_set_unchanged_at_end", True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=tuple(CHECKS), required=True)
    parser.add_argument("--spec", required=True)
    parser.add_argument("--spec-sha256", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--admission-only", action="store_true")
    args = parser.parse_args(argv)
    spec = core.pinned({"path": args.spec, "sha256": args.spec_sha256}, private=True)
    validate_stage_spec(spec, args.stage, args.output)
    local_host(spec["host_label"], spec["expected_host"])
    if args.admission_only:
        print(json.dumps({"status": "draft_shape_admitted_only", "stage": args.stage, "product_started": False}))
        return 0
    need(not DRAFT_ONLY, "draft_execution_requires_final_control_freeze")
    os.umask(0o077)
    stage = Stage(args.stage, spec, {"path": args.spec, "sha256": args.spec_sha256}, args.output)
    try:
        {"backup": prepare_backup, "mac_oracle": run_clone, "linux_target": run_clone,
         "source_verify": verify_source}[args.stage](stage)
    except BaseException as error:
        stage.report["failure"] = str(error) if isinstance(error, (core.Refusal, wire.Refusal)) else type(error).__name__
    return stage.finish()


if __name__ == "__main__":
    raise SystemExit(main())
