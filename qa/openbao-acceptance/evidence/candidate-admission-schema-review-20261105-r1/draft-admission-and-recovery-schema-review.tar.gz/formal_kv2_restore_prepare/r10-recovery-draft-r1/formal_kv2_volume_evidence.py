#!/usr/bin/env python3
"""Independent, read-only Mac external-volume evidence before/after recovery.

This adds no KV2 check and starts no product. The only child is the exact
diskutil query, retained with original Popen custody and its raw plist output.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import plistlib
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
DRIVER_SHA = "1e77c21e0aba593601c3721122f411adbc98a987e51e92a0b0078aade0ea78a5"
path = HERE / "formal_kv2_recovery_driver.py"
if hashlib.sha256(path.read_bytes()).hexdigest() != DRIVER_SHA:
    raise RuntimeError("volume_evidence_controller_pin")
spec = importlib.util.spec_from_file_location("formal_volume_frozen_driver", path)
driver = importlib.util.module_from_spec(spec); sys.modules[spec.name] = driver; spec.loader.exec_module(driver)
core, custody, need = driver.core, driver.custody, driver.need
EXPECTED_UUID = "FB804D1B-24CB-4D6E-AEA7-A9E180807758"
MOUNT = "/Volumes/T5"
SCHEMA = "heptabao.formal-kv2-volume-binding.v1"


def directory_identity(path):
    fd = core.directory_fd(path)
    try: return {"path": str(core.absolute(path)), **core.stamp(os.fstat(fd))}
    finally: os.close(fd)


def validate_volume(value, identities, phase, before=None):
    need(phase in ("before", "after"), "volume_phase")
    need(isinstance(value, dict) and value.get("VolumeUUID") == EXPECTED_UUID
         and value.get("MountPoint") == MOUNT and value.get("Mounted") is True,
         "actual_expected_external_volume_uuid_and_mount")
    expected = {"volume", "frozen_source", "original_data", "clone_parent"}
    if phase == "after": expected.add("clone_data")
    need(set(identities) == expected and identities["volume"]["path"] == MOUNT,
         "volume_exact_directory_identities")
    device = identities["volume"]["dev"]
    need(all(row["dev"] == device and row["path"].startswith(MOUNT + "/")
             for name, row in identities.items() if name != "volume"), "source_and_clone_actual_same_volume_device")
    if phase == "before":
        need(before is None, "volume_before_no_prior_substitute")
    else:
        need(isinstance(before, dict) and before.get("schema") == SCHEMA
             and before.get("status") == "passed" and before.get("phase") == "before"
             and before.get("expected_volume_uuid") == EXPECTED_UUID, "original_before_volume_evidence_required")
        for name in ("volume", "frozen_source", "original_data", "clone_parent"):
            old, new = before["identities"][name], identities[name]
            need((old["path"], old["dev"], old["ino"]) == (new["path"], new["dev"], new["ino"]),
                 "original_volume_or_directory_identity_changed")
    return {"expected_volume_uuid": EXPECTED_UUID, "actual_mount_point": MOUNT,
            "actual_device": device, "clone_exists_in_this_observation": phase == "after"}


def query(output, nonce, deadline):
    executable = driver.system_executable("/usr/sbin/diskutil")
    argv = ["/usr/sbin/diskutil", "info", "-plist", MOUNT]
    stdout = output / "diskutil.original.plist"
    stderr = output / "diskutil.original.stderr"
    out = os.open(stdout, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    err = os.open(stderr, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    registry = custody.Registry(output / "process-custody", nonce).install()
    child = None
    report = {"argv": argv, "executable": executable, "query_seconds": 15, "stop_seconds": 5}
    try:
        end = min(deadline, core.now_ns() + 15_000_000_000)
        child = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                                 env={"PATH": "/usr/bin:/bin", "LC_ALL": "C"}, start_new_session=True)
        report["guardian_pid"] = child.pid
        report["custody_prefix"] = str(child.custody_prefix)
        while child.poll() is None:
            core.live(end)
            need(os.fstat(out).st_size <= core.MIB and os.fstat(err).st_size <= core.MIB,
                 "volume_query_output_bound")
            time.sleep(min(.02, max(0, (end - core.now_ns()) / 1_000_000_000)))
        core.live(end)
        need(child.returncode == 0, "volume_query_original_exit")
    finally:
        try:
            if child is not None and child.returncode is None:
                if child.custody_lifeline is not None:
                    os.close(child.custody_lifeline); child.custody_lifeline = None
                child.wait(timeout=5)
        finally:
            try:
                os.fsync(out); os.fsync(err)
            finally:
                os.close(out); os.close(err)
                closed = registry.finish()
                report["custody_result"] = {"path": str(output / "process-custody/result.public.json"),
                                             "sha256": core.sha_file(output / "process-custody/result.public.json")}
                report["all_owned_processes_reaped"] = (closed["integrity"] is True
                    and closed["registered_original_children"] == 1
                    and closed["all_registered_original_children_reaped"] is True
                    and closed["all_registered_session_groups_empty_before_reap"] is True)
                report["fresh_custody_observation"] = custody.observe_registered_sessions(
                    output / "process-custody", nonce, time.monotonic() + 5)
    need(report["all_owned_processes_reaped"] is True
         and report["fresh_custody_observation"]["all_members_absent"] is True, "volume_query_owned_cleanup")
    raw = core.read_bytes(stdout, core.MIB, deadline_ns=deadline)
    need(not core.read_bytes(stderr, core.MIB, deadline_ns=deadline), "volume_query_unexpected_stderr")
    report["stdout"] = {"path": str(stdout), "sha256": hashlib.sha256(raw).hexdigest()}
    report["stderr"] = {"path": str(stderr), "sha256": core.sha_file(stderr)}
    report["exit_code"] = child.returncode
    return plistlib.loads(raw), report


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("before", "after"), required=True)
    for key in ("candidate", "placement"):
        parser.add_argument("--" + key, required=True); parser.add_argument("--" + key + "-sha256", required=True)
    parser.add_argument("--before"); parser.add_argument("--before-sha256")
    parser.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    os.umask(0o077)
    candidate_binding = {"path": args.candidate, "sha256": args.candidate_sha256}
    placement_binding = {"path": args.placement, "sha256": args.placement_sha256}
    candidate, placement = core.pinned(candidate_binding), core.pinned(placement_binding, private=True)
    need(candidate["schema"] == "heptabao.formal-kv2-recovery-candidate-admission.v2"
         and candidate["status"] == "admitted" and placement["schema"] == "heptabao.formal-kv2-recovery-placement.v1",
         "volume_bound_candidate_and_placement")
    mac = placement["mac"]
    actual_host = driver.local_host("mac", mac["expected_host"])
    need(mac["label"] == "mac" and mac["controller"] == {"path": str(HERE / "formal_kv2_recovery_driver.py"),
                                                        "sha256": DRIVER_SHA}, "volume_exact_controller_placement")
    output = core.absolute(args.output)
    need(output != Path(MOUNT) and output.is_relative_to(MOUNT), "volume_evidence_external_output_scope")
    core.new_directory(output)
    deadline = core.now_ns() + 30_000_000_000
    report = {"schema": SCHEMA, "status": "failed", "phase": args.phase, "candidate": candidate_binding,
              "placement": placement_binding, "run_id": placement["run_id"], "actual_host": actual_host,
              "source_commit": candidate["source_commit"], "source_tree": candidate["source_tree"],
              "full34_sha256": candidate["full34"]["sha256"], "expected_volume_uuid": EXPECTED_UUID,
              "helper_sha256": core.sha_file(__file__), "products_started": 0, "recovery25_replaced": False}
    try:
        value, command = query(output, placement["run_id"], deadline)
        report["command"] = command
        source_plan = core.pinned(candidate["candidate_plan"])
        paths = {"volume": MOUNT, "frozen_source": source_plan["source"],
                 "original_data": str(Path(candidate["original_work_root"]) / "candidate/data"),
                 "clone_parent": mac["root"]}
        if args.phase == "after": paths["clone_data"] = str(Path(mac["root"]) / "clone/data")
        identities = {name: directory_identity(path) for name, path in paths.items()}
        before = None
        if args.phase == "after":
            need(args.before is not None and args.before_sha256 is not None, "volume_before_binding_required")
            report["before"] = {"path": args.before, "sha256": args.before_sha256}
            before = core.pinned(report["before"])
            need(before["candidate"] == candidate_binding and before["placement"] == placement_binding
                 and before["run_id"] == placement["run_id"] and before["actual_host"] == actual_host,
                 "volume_same_candidate_placement_and_physical_host")
        report.update(validate_volume(value, identities, args.phase, before))
        report["identities"] = identities
        core.live(deadline)
        report["status"] = "passed"
    except BaseException as error:
        report["failure"] = str(error) if isinstance(error, core.Refusal) else type(error).__name__
    result = core.write_new(output / "result.public.json", report)
    core.live(deadline)
    print(json.dumps({"status": report["status"], "result": result["path"], "result_sha256": result["sha256"],
                      "products_started": 0}))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__": raise SystemExit(main())
