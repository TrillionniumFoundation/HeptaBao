#!/usr/bin/env python3
"""Prepare reviewed stage inputs or aggregate existing evidence; never launch products.

Every command is create-only. This revision pins the draft controls. Changing
the executable draft flag requires a new reviewed operator/control revision.
"""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
PINNED = {
    "formal_kv2_recovery_driver.py": "1e77c21e0aba593601c3721122f411adbc98a987e51e92a0b0078aade0ea78a5",
    "formal_kv2_recovery_admission.py": "efb9426173dc6d044f3261544467a5e3747d4633dd36f7f827b0997f8721f08c",
    "formal_kv2_private_transfer.py": "77424c921e667ad560f4684089288f98d132521176812c19d2eeaf95eaa49676",
    "formal_kv2_volume_evidence.py": "a6e20486227f3f7e3dcb23287fe6db1f40e188bc6c5a9ef6b9536f4bcfb2381b",
}


def load(name):
    path = HERE / name
    if hashlib.sha256(path.read_bytes()).hexdigest() != PINNED[name]:
        raise RuntimeError("reviewed_operator_dependency_changed")
    spec = importlib.util.spec_from_file_location(name.replace(".py", "_operator"), path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


driver = load("formal_kv2_recovery_driver.py")
admission = load("formal_kv2_recovery_admission.py")
transfer = load("formal_kv2_private_transfer.py")
core, need = driver.core, driver.need
CONTROLS = {"driver_sha256": PINNED["formal_kv2_recovery_driver.py"],
    "admission_sha256": PINNED["formal_kv2_recovery_admission.py"], "core_sha256": admission.CORE_SHA,
    "wire_sha256": driver.PINS["formal_kv2_shared_deadline_wire.py"], "custody_sha256": admission.CUSTODY_SHA,
    "runtime_sha256": admission.RUNTIME_SHA, "cross_host_gate_sha256": admission.GATE_SHA,
    "transfer_sha256": PINNED["formal_kv2_private_transfer.py"]}


def same_stage(result, name, candidate, run_id):
    names = driver.CHECKS[name]
    need(result["schema"] == driver.SCHEMA and result["stage"] == name and result["status"] == "passed"
         and result["run_id"] == run_id and result["source_commit"] == candidate["source_commit"]
         and result["source_tree"] == candidate["source_tree"]
         and result["full34_sha256"] == candidate["full34"]["sha256"]
         and result["controller_sha256"] == CONTROLS["driver_sha256"]
         and result["required_count"] == result["passed_count"] == len(names)
         and len(result["checks"]) == len(names) and {r["case"] for r in result["checks"]} == set(names)
         and all(r["passed"] is True for r in result["checks"]), "complete_prior_stage_required")


def prepare_spec(stage, candidate_binding, ticket_binding, placement_binding, priors_binding):
    candidate = admission.validate_candidate(candidate_binding)
    need(core.pinned(ticket_binding) == candidate
         and ticket_binding["sha256"] == hashlib.sha256(core.canonical(candidate)).hexdigest(),
         "ticket_is_exact_recomputed_candidate_admission")
    placement = core.pinned(placement_binding, private=True)
    need(set(placement) == {"schema", "run_id", "mac", "linux"}
         and placement["schema"] == "heptabao.formal-kv2-recovery-placement.v1"
         and re.fullmatch(r"[0-9a-f]{32}", placement["run_id"]), "reviewed_placement_shape")
    for role in ("mac", "linux"):
        host = placement[role]
        need(set(host) == {"root", "label", "expected_host", "interpreter", "controller", "semantics", "binary"},
             "exact_host_placement_fields")
        need(host["label"] == "mac" if role == "mac" else host["label"] in ("x230", "rog", "pocket4"),
             "placement_physical_host")
        root = core.absolute(host["root"])
        need(root != Path(driver.ACTUAL_HOSTS[host["label"]][2])
             and root.is_relative_to(driver.ACTUAL_HOSTS[host["label"]][2])
             and host["controller"]["sha256"] == CONTROLS["driver_sha256"]
             and host["semantics"]["sha256"] == core.FULL34_DRIVER_SHA256
             and host["binary"]["sha256"] == candidate[role + "_server_sha256"],
             "fixed_controller_semantics_and_candidate_binary_placement")
    need(ticket_binding["path"] == str(Path(placement["mac"]["root"]) / "control/candidate-admission.public.json"),
         "candidate_ticket_in_exact_private_mac_control_root")
    priors = core.pinned(priors_binding, private=True)
    needed = {"backup": set(), "mac_oracle": {"backup"}, "linux_target": {"backup", "mac_oracle"},
              "source_verify": {"backup", "mac_oracle", "linux_target"}}[stage]
    need(set(priors) == {"schema", "results"} and priors["schema"] == "heptabao.formal-kv2-recovery-prior-results.v1"
         and set(priors["results"]) == needed, "exact_completed_stage_prefix")
    results = {}
    for name, binding in priors["results"].items():
        results[name] = core.pinned(binding)
        same_stage(results[name], name, candidate, placement["run_id"])
    local = placement["linux" if stage == "linux_target" else "mac"]
    root = Path(local["root"])
    runtime_spec = root / "control" / (stage + ".private.json")
    runtime_ticket = root / "control/candidate-admission.public.json"
    output = root / "output" / stage
    spec = {"schema": "heptabao.formal-kv2-cold-recovery-stage-plan.v1", "stage": stage,
        "run_id": placement["run_id"], "source_commit": candidate["source_commit"], "source_tree": candidate["source_tree"],
        "full34_sha256": candidate["full34"]["sha256"], "candidate_admission_sha256": ticket_binding["sha256"],
        "candidate_admission": ({"path": str(runtime_ticket), "sha256": ticket_binding["sha256"]}
                                if stage == "linux_target" else ticket_binding),
        "source_root": core.pinned(candidate_binding)["source"], "host_label": local["label"],
        "expected_host": local["expected_host"], "interpreter": local["interpreter"],
        "controller": local["controller"], "semantics": local["semantics"], "limits": driver.LIMITS,
        "output_root": str(output), "backup_root": str(root / "sealed-backup")}
    transfers = ([{"source": ticket_binding, "destination": str(runtime_ticket), "private": False}]
                 if stage == "linux_target" else [])
    if stage == "backup":
        spec.update(candidate_plan=candidate_binding, full34=candidate["full34"],
                    full34_summary=candidate["full34_summary"], original_work_root=candidate["original_work_root"])
    else:
        original_manifest = results["backup"]["backup_manifest"]
        manifest = core.pinned(original_manifest, private=True, maximum=32 * core.MIB)
        need(manifest["run_id"] == placement["run_id"]
             and manifest["candidate_admission_sha256"] == ticket_binding["sha256"], "actual_closed_backup_prefix")
        spec["backup_manifest"] = ({"path": str(root / "sealed-backup/manifest.private.json"),
                                    "sha256": original_manifest["sha256"]}
                                   if stage == "linux_target" else original_manifest)
        spec["backup_result"] = ({"path": str(root / "control/prior-backup-result.public.json"),
                                  "sha256": priors["results"]["backup"]["sha256"]}
                                 if stage == "linux_target" else priors["results"]["backup"])
        if stage == "linux_target":
            # The complete known closed set is copied byte-for-byte, including
            # private keys. This plan never includes their plaintext content.
            backup_root = Path(original_manifest["path"]).parent
            transfers.append({"source": priors["results"]["backup"], "destination": spec["backup_result"]["path"], "private": False})
            transfers.append({"source": original_manifest, "destination": spec["backup_manifest"]["path"], "private": True})
            for item in manifest["backup_files"]:
                transfers.append({"source": {"path": str(backup_root / item["relative"]), "sha256": item["sha256"]},
                                  "destination": str(root / "sealed-backup" / item["relative"]), "private": True})
        if stage in ("mac_oracle", "linux_target"):
            # Fixed distinct local ports are proposed; normal launch verifies
            # the owned process and TLS peer, and never attaches to a listener.
            spec.update(clone_root=str(root / "clone"), binary=local["binary"], port=18671 if stage == "mac_oracle" else 18672)
        if stage == "linux_target":
            spec["mac_oracle_result"] = {"path": str(root / "control/prior-mac-oracle-result.public.json"),
                                         "sha256": priors["results"]["mac_oracle"]["sha256"]}
            oracle = results["mac_oracle"]["A_oracle"]
            need(core.sha_file(oracle["path"], private=True) == oracle["sha256"], "actual_A_oracle_source_pin")
            spec["mac_oracle_file"] = {"path": str(root / "control/mac-final-api-oracle.private.json"), "sha256": oracle["sha256"]}
            transfers.extend(({"source": priors["results"]["mac_oracle"], "destination": spec["mac_oracle_result"]["path"], "private": False},
                              {"source": oracle, "destination": spec["mac_oracle_file"]["path"], "private": True}))
        if stage == "source_verify":
            spec["full34"] = candidate["full34"]
            spec["linux_target_result"] = priors["results"]["linux_target"]
            need(spec["linux_target_result"]["path"] == str(root / "returned-linux-target/stage-output/result.public.json"),
                 "source_verify_requires_complete_linux_stage_return")
    need(set(spec) == driver.COMMON_SPEC_FIELDS | driver.STAGE_SPEC_FIELDS[stage], "prepared_exact_stage_contract")
    raw = core.canonical(spec)
    digest = hashlib.sha256(raw).hexdigest()
    invocation = {"host": local["label"], "executable": local["interpreter"]["path"],
        "args": ["-I", "-S", "-B", local["controller"]["path"], "--stage", stage, "--spec", str(runtime_spec),
                 "--spec-sha256", digest, "--output", str(output)], "cwd": str(root / "control"),
        "timeout_seconds": driver.LIMITS["stage_seconds"], "nice": 10,
        "idempotency_key": "formal-kv2-recovery-" + placement["run_id"] + "-" + stage}
    return spec, {"schema": "heptabao.formal-kv2-recovery-stage-preparation.v1", "status": "prepared",
        "draft_execution_blocked": driver.DRAFT_ONLY, "stage": stage, "spec_sha256": digest,
        "local_spec_path": str(Path(placement["mac"]["root"]) / "control" / (stage + ".private.json")),
        "runtime_spec_path": str(runtime_spec), "invocation": invocation, "transfer_inputs": transfers,
        "private_directory_mode": "0700", "private_file_mode": "0600", "products_started": 0,
        "operator_must_capture_original_executor_metadata": True}


def binding(args, name):
    return {"path": getattr(args, name), "sha256": getattr(args, name + "_sha256")}


def add_binding(parser, name):
    parser.add_argument("--" + name.replace("_", "-"), required=True)
    parser.add_argument("--" + name.replace("_", "-") + "-sha256", required=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="command", required=True)
    describe = subs.add_parser("describe")
    describe.add_argument("--output", required=True)
    candidate = subs.add_parser("candidate")
    add_binding(candidate, "candidate_plan"); candidate.add_argument("--output", required=True)
    initialize = subs.add_parser("initialize-mac-root")
    add_binding(initialize, "candidate_plan"); add_binding(initialize, "placement")
    initialize.add_argument("--output", required=True)
    volume = subs.add_parser("volume-evidence")
    volume.add_argument("--phase", choices=("before", "after"), required=True)
    add_binding(volume, "candidate"); add_binding(volume, "placement")
    volume.add_argument("--before"); volume.add_argument("--before-sha256")
    volume.add_argument("--output", required=True)
    stage = subs.add_parser("stage-spec")
    stage.add_argument("--stage", choices=admission.RECOVERY_STAGES, required=True)
    for name in ("candidate_plan", "ticket", "placement", "priors"): add_binding(stage, name)
    stage.add_argument("--output", required=True); stage.add_argument("--preparation-output", required=True)
    aggregate = subs.add_parser("aggregate")
    add_binding(aggregate, "review_plan")
    for name in ("commit", "tree", "full34-sha256", "mac-server-sha256", "linux-server-sha256", "target-host", "output"):
        aggregate.add_argument("--" + name, required=True)
    args = parser.parse_args()
    if args.command == "volume-evidence":
        module = load("formal_kv2_volume_evidence.py")
        arguments = ["--phase", args.phase, "--candidate", args.candidate, "--candidate-sha256", args.candidate_sha256,
                     "--placement", args.placement, "--placement-sha256", args.placement_sha256, "--output", args.output]
        if args.before is not None: arguments += ["--before", args.before]
        if args.before_sha256 is not None: arguments += ["--before-sha256", args.before_sha256]
        return module.main(arguments)
    if args.command == "describe":
        document = {"schema": "heptabao.formal-kv2-recovery-control-contract.v3",
            "status": "draft" if driver.DRAFT_ONLY else "execution_enabled_exact_admission_required",
            "controls": CONTROLS, "stage_checks": driver.CHECKS, "new_required_count": len(driver.ALL_CHECKS),
            "original31_replaced": False, "limits": driver.LIMITS, "stage_fields": {
                name: sorted(driver.COMMON_SPEC_FIELDS | driver.STAGE_SPEC_FIELDS[name]) for name in admission.RECOVERY_STAGES},
            "final_result_schema": admission.FINAL_SCHEMA, "final_validator": "validate_final_recovery",
            "candidate_plan_schema": "heptabao.formal-kv2-recovery-candidate-plan.v2",
            "candidate_admission_schema": "heptabao.formal-kv2-recovery-candidate-admission.v2",
            "upstream_actual_jobs": 14, "recovery_actual_jobs": 4,
            "separate_observer_tests_each_host": 16,
            "products_started": 0, "snapshot_only_empty_cluster_supported": False,
            "volume_evidence": {"module_sha256": PINNED["formal_kv2_volume_evidence.py"],
                                "expected_uuid": "FB804D1B-24CB-4D6E-AEA7-A9E180807758",
                                "before_and_after_required_as_separate_evidence": True}}
    elif args.command == "initialize-mac-root":
        candidate = admission.validate_candidate(binding(args, "candidate_plan"))
        placement = core.pinned(binding(args, "placement"), private=True)
        mac = placement["mac"]
        physical = driver.local_host("mac", mac["expected_host"])
        root = core.absolute(mac["root"])
        admitted = driver.scoped_new_root(root, "mac", [core.pinned(binding(args, "candidate_plan"))["source"],
                                                        candidate["original_work_root"]])
        core.new_directory(root); core.new_directory(root / "control"); core.new_directory(root / "output")
        document = {"schema": "heptabao.formal-kv2-recovery-local-root.v1", "status": "initialized",
                    "run_id": placement["run_id"], "root": str(root), "root_admission": admitted,
                    "actual_host": physical, "candidate_admission_sha256": hashlib.sha256(core.canonical(candidate)).hexdigest(),
                    "products_started": 0, "linux_root_created_by_private_receiver_only": True}
    elif args.command == "candidate":
        document = admission.validate_candidate(binding(args, "candidate_plan"))
    elif args.command == "stage-spec":
        document, prepared = prepare_spec(args.stage, binding(args, "candidate_plan"), binding(args, "ticket"),
                                         binding(args, "placement"), binding(args, "priors"))
        need(args.output == prepared["local_spec_path"], "prepared_spec_exact_local_path")
        core.write_new(args.preparation_output, prepared)
    else:
        document = admission.build_final_document(binding(args, "review_plan"), expected_controls=CONTROLS,
            expected_candidate=(args.commit, args.tree), expected_full34_sha256=args.full34_sha256,
            expected_binaries={"mac": args.mac_server_sha256, "linux": args.linux_server_sha256}, expected_target_host=args.target_host)
    result = core.write_new(args.output, document)
    print(json.dumps({"status": document.get("status", "prepared"), "result": result, "products_started": 0}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
