#!/usr/bin/env python3
"""Create-only, byte-bound private transfers for the formal recovery stages.

This is a file carrier, never a network client or product launcher. Its private
package is not tar: one canonical, hash-bound plan is followed by exactly the
listed raw byte streams. No archive pathname is used without the frozen plan.
The caller transports the 0600 package through its already-authorized SSH path
and supplies both original plan and package SHA-256 to the receiving command.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import struct
import sys

HERE = Path(__file__).resolve().parent
DRIVER_SHA = "1e77c21e0aba593601c3721122f411adbc98a987e51e92a0b0078aade0ea78a5"
path = HERE / "formal_kv2_recovery_driver.py"
if hashlib.sha256(path.read_bytes()).hexdigest() != DRIVER_SHA:
    raise RuntimeError("private_transfer_driver_pin")
module_spec = importlib.util.spec_from_file_location("formal_transfer_driver", path)
driver = importlib.util.module_from_spec(module_spec)
sys.modules[module_spec.name] = driver
module_spec.loader.exec_module(driver)
core, need = driver.core, driver.need

SCHEMA = "heptabao.formal-kv2-private-transfer-plan.v1"
RECEIPT_SCHEMA = "heptabao.formal-kv2-private-transfer-receipt.v1"
MAGIC = b"HEPTABAO-FORMAL-PRIVATE-COPY-V1\n"
MAX_MANIFEST = 32 * core.MIB
MAX_TOTAL = 2 * 1024 * core.MIB
MAX_FILE = 128 * core.MIB
MAX_FILES = 16384
SECONDS = 360
EVIDENCE_FILES = frozenset((
    "result.public.json", "clone-data-manifest.private.json", "server-config.private.json",
    "wire-admission.private.json", "A-api.private.json", "A-raw-witnesses.private.json",
    "B-api.private.json", "B-raw-witnesses.private.json", "pre-cas.private.json",
    "post-cas-cold.private.json", "post-cas-cold-raw.private.json", "process-custody/result.public.json"))
EVIDENCE_PATTERN = re.compile(
    r"(?:http-[0-9]{4}\.(?:private|public)\.json|abi-0[1-3]\.(?:stdout|stderr)\.private\.log|"
    r"process-custody/child-[0-9]{5}\.(?:birth|started|terminal|abort)\.json)")


def digest(value):
    return hashlib.sha256(core.canonical(value)).hexdigest()


def relative(value):
    need(isinstance(value, str) and value and not value.startswith("/")
         and value == os.path.normpath(value) and all(p not in (".", "..") for p in Path(value).parts)
         and "\x00" not in value and "\\" not in value, "private_transfer_relative_path")
    return value


def root_scope(path, label):
    path = core.absolute(path)
    need(label in driver.ACTUAL_HOSTS, "private_transfer_known_host")
    prefix = Path(driver.ACTUAL_HOSTS[label][2])
    need(path != prefix and path.is_relative_to(prefix), "private_transfer_owned_prefix")
    return path


def host_shape(value):
    need(isinstance(value, dict) and set(value) == {"label", "system", "hostname", "machine", "uid", "python_version"}
         and value["label"] in driver.ACTUAL_HOSTS
         and (value["system"], value["hostname"]) == driver.ACTUAL_HOSTS[value["label"]][:2]
         and value["machine"] in ("arm64", "aarch64", "x86_64") and type(value["uid"]) is int
         and value["uid"] >= 0 and isinstance(value["python_version"], str), "private_transfer_exact_host_preflight")


def validate_plan(plan):
    need(isinstance(plan, dict) and set(plan) == {"schema", "kind", "run_id", "source_host", "destination_host",
         "source_root", "destination_root", "driver_sha256", "proof", "entries", "empty_directories",
         "total_bytes", "file_count", "limits"} and plan["schema"] == SCHEMA
         and plan["kind"] in ("linux_inputs", "linux_evidence_return")
         and re.fullmatch(r"[0-9a-f]{32}", plan["run_id"]) and plan["driver_sha256"] == DRIVER_SHA,
         "private_transfer_exact_plan")
    host_shape(plan["source_host"]); host_shape(plan["destination_host"])
    source = root_scope(plan["source_root"], plan["source_host"]["label"])
    destination = root_scope(plan["destination_root"], plan["destination_host"]["label"])
    need((plan["source_host"]["label"] == "mac") == (plan["kind"] == "linux_inputs")
         and (plan["destination_host"]["label"] == "mac") == (plan["kind"] == "linux_evidence_return"),
         "private_transfer_direction")
    need(plan["limits"] == {"seconds": SECONDS, "maximum_total_bytes": MAX_TOTAL,
         "maximum_file_bytes": MAX_FILE, "maximum_files": MAX_FILES, "maximum_manifest_bytes": MAX_MANIFEST},
         "private_transfer_fixed_bounds")
    need(isinstance(plan["proof"], dict) and set(plan["proof"]) == {"stage_spec", "stage_result", "backup_manifest"},
         "private_transfer_proof_shape")
    for binding in plan["proof"].values():
        need(binding is None or (isinstance(binding, dict) and set(binding) == {"path", "sha256"}
             and core.HEX64.fullmatch(binding["sha256"]) and core.absolute(binding["path"])),
             "private_transfer_proof_binding")
    entries = plan["entries"]
    need(isinstance(entries, list) and 0 < len(entries) <= MAX_FILES, "private_transfer_member_bound")
    names, source_names, total = [], [], 0
    for row in entries:
        need(isinstance(row, dict) and set(row) == {"relative", "source", "bytes", "sha256", "source_stamp"},
             "private_transfer_entry_fields")
        names.append(relative(row["relative"]))
        p = core.absolute(row["source"])
        need(p != source and p.is_relative_to(source), "private_transfer_source_scope")
        source_names.append(str(p))
        need(type(row["bytes"]) is int and 0 <= row["bytes"] <= MAX_FILE
             and isinstance(row["sha256"], str) and core.HEX64.fullmatch(row["sha256"])
             and isinstance(row["source_stamp"], dict)
             and set(row["source_stamp"]) == {"dev", "ino", "uid", "gid", "mode", "nlink", "size", "mtime_ns", "ctime_ns"}
             and row["source_stamp"]["size"] == row["bytes"]
             and row["source_stamp"]["uid"] == plan["source_host"]["uid"]
             and row["source_stamp"]["nlink"] == 1
             and stat.S_ISREG(row["source_stamp"]["mode"])
             and stat.S_IMODE(row["source_stamp"]["mode"]) == 0o600, "private_transfer_entry_metadata")
        total += row["bytes"]
        need(total <= MAX_TOTAL, "private_transfer_total_bound")
    need(names == sorted(set(names)) and len(set(source_names)) == len(source_names)
         and plan["total_bytes"] == total and plan["file_count"] == len(names), "private_transfer_exact_denominator")
    dirs = plan["empty_directories"]
    need(dirs == (["output"] if plan["kind"] == "linux_inputs" else [])
         and all(relative(x) for x in dirs), "private_transfer_explicit_empty_directories")
    name_set = set(names)
    need(not any(str(parent) in name_set for name in names for parent in Path(name).parents
                 if str(parent) != "."), "private_transfer_file_directory_collision")
    need(not any(a == b or a.startswith(b + "/") for a in names for b in dirs),
         "private_transfer_empty_directory_collision")
    return source, destination


def carrier_path(plan, side):
    need(side in ("source", "destination"), "private_transfer_carrier_side")
    root = Path(plan[side + "_root"])
    # The Mac return goes into a new child of the original recovery run root;
    # both directions share one sibling private carrier directory on that Mac.
    if side == "destination" and plan["kind"] == "linux_evidence_return":
        need(root.name == "returned-linux-target", "private_return_fixed_directory")
        root = root.parent
    result = root.parent / (root.name + "-private-transfer") / (plan["kind"].replace("_", "-") + ".private.bin")
    root_scope(result, plan[side + "_host"]["label"])
    return result


def initialize_carrier(plan_binding, side):
    plan = core.pinned(plan_binding, private=True, maximum=MAX_MANIFEST)
    validate_plan(plan)
    host = plan[side + "_host"]
    actual = driver.local_host(host["label"], host)
    path = carrier_path(plan, side).parent
    identity = core.new_directory(path)
    return {"schema": "heptabao.formal-kv2-private-carrier-root.v1", "status": "initialized",
            "plan": plan_binding, "side": side, "run_id": plan["run_id"], "path": str(path),
            "identity": identity, "actual_host": actual, "products_started": 0}


def bound_source(path, expected_sha, deadline):
    path = core.absolute(path)
    parent = core.directory_fd(path.parent, private=True)
    fd = None
    try:
        parent_before = core.stamp(os.fstat(parent))
        fd = core.file_fd(path, source_directory_fd=parent)
        before = core.stamp(os.fstat(fd))
        need(before["size"] <= MAX_FILE, "private_transfer_file_bound")
        count, sha = 0, hashlib.sha256()
        while True:
            core.live(deadline)
            data = os.read(fd, 65536)
            if not data: break
            count += len(data)
            need(count <= MAX_FILE, "private_transfer_growing_source")
            sha.update(data)
        need(count == before["size"] and core.stamp(os.fstat(fd)) == before
             and sha.hexdigest() == expected_sha, "private_transfer_source_changed")
        core.check_directory_name(path.parent, parent_before)
        return before
    finally:
        if fd is not None: os.close(fd)
        os.close(parent)


def make_plan(kind, run_id, source_host, destination_host, source_root, destination_root, sources, proof):
    deadline = core.now_ns() + SECONDS * 1_000_000_000
    driver.local_host(source_host["label"], source_host)
    entries = []
    for item in sources:
        stamp = bound_source(item["source"]["path"], item["source"]["sha256"], deadline)
        entries.append({"relative": relative(item["relative"]), "source": item["source"]["path"],
                        "bytes": stamp["size"], "sha256": item["source"]["sha256"], "source_stamp": stamp})
    plan = {"schema": SCHEMA, "kind": kind, "run_id": run_id, "source_host": source_host,
        "destination_host": destination_host, "source_root": str(source_root), "destination_root": str(destination_root),
        "driver_sha256": DRIVER_SHA, "proof": proof, "entries": sorted(entries, key=lambda x: x["relative"]),
        "empty_directories": ["output"] if kind == "linux_inputs" else [],
        "total_bytes": sum(x["bytes"] for x in entries), "file_count": len(entries),
        "limits": {"seconds": SECONDS, "maximum_total_bytes": MAX_TOTAL, "maximum_file_bytes": MAX_FILE,
                   "maximum_files": MAX_FILES, "maximum_manifest_bytes": MAX_MANIFEST}}
    validate_plan(plan)
    core.live(deadline)
    return plan


def input_plan(spec_binding, preparation_binding, placement_binding):
    spec, prepared = core.pinned(spec_binding, private=True), core.pinned(preparation_binding, private=True)
    placement = core.pinned(placement_binding, private=True)
    need(spec["stage"] == prepared["stage"] == "linux_target" and prepared["spec_sha256"] == spec_binding["sha256"]
         and spec["run_id"] == placement["run_id"]
         and spec["controller"]["sha256"] == DRIVER_SHA, "private_input_actual_stage_binding")
    mac, linux = placement["mac"], placement["linux"]
    origin, destination = Path(mac["root"]), Path(linux["root"])
    need(spec["host_label"] == linux["label"] and spec["expected_host"] == linux["expected_host"]
         and spec["backup_root"] == str(destination / "sealed-backup")
         and prepared["runtime_spec_path"] == str(destination / "control/linux_target.private.json"),
         "private_input_exact_target_paths")
    manifest_binding = {"path": str(origin / "sealed-backup/manifest.private.json"), "sha256": spec["backup_manifest"]["sha256"]}
    manifest = driver.validate_bundle_manifest(origin / "sealed-backup", manifest_binding)
    sources = [{"source": x["source"], "relative": str(Path(x["destination"]).relative_to(destination))}
               for x in prepared["transfer_inputs"]]
    sources.append({"source": spec_binding, "relative": "control/linux_target.private.json"})
    names = {x["relative"] for x in sources}
    expected = {"control/candidate-admission.public.json", "control/prior-backup-result.public.json",
                "control/prior-mac-oracle-result.public.json", "control/mac-final-api-oracle.private.json",
                "control/linux_target.private.json", "sealed-backup/manifest.private.json"}
    expected.update("sealed-backup/" + x["relative"] for x in manifest["backup_files"])
    need(names == expected and len(names) == len(sources), "private_input_complete_backup_and_controls_only")
    by_name = {x["relative"]: x["source"] for x in sources}
    for row in manifest["backup_files"]:
        need(by_name["sealed-backup/" + row["relative"]] == {"path": str(origin / "sealed-backup" / row["relative"]),
             "sha256": row["sha256"]}, "private_input_exact_backup_bytes")
    need(by_name["sealed-backup/manifest.private.json"] == manifest_binding, "private_input_original_manifest")
    for name, key in (("control/candidate-admission.public.json", "candidate_admission"),
                      ("control/prior-backup-result.public.json", "backup_result"),
                      ("control/prior-mac-oracle-result.public.json", "mac_oracle_result"),
                      ("control/mac-final-api-oracle.private.json", "mac_oracle_file")):
        need(by_name[name]["sha256"] == spec[key]["sha256"], "private_input_original_control_hash")
    return make_plan("linux_inputs", spec["run_id"], mac["expected_host"], linux["expected_host"],
                     origin, destination, sources,
                     {"stage_spec": spec_binding, "stage_result": None, "backup_manifest": manifest_binding})


def evidence_sources(output, deadline, *, require_complete=True):
    output = core.absolute(output)
    root_fd = core.directory_fd(output, private=True)
    root_before = core.stamp(os.fstat(root_fd))
    try:
        result = []
        for parent, dirs, files in os.walk(output, followlinks=False):
            for name in dirs:
                path = Path(parent) / name
                need(str(path.relative_to(output)) == "process-custody" and not path.is_symlink(),
                     "unknown_private_stage_directory")
                os.close(core.directory_fd(path, private=True))
            for name in files:
                path = Path(parent) / name
                rel = str(path.relative_to(output))
                need(rel in EVIDENCE_FILES or EVIDENCE_PATTERN.fullmatch(rel), "unknown_private_stage_asset")
                sha = core.sha_file(path, private=True, deadline_ns=deadline)
                result.append({"source": {"path": str(path), "sha256": sha}, "relative": "stage-output/" + rel})
        names = {x["relative"][13:] for x in result}
        need("result.public.json" in names, "original_private_stage_result_required")
        if require_complete:
            need(EVIDENCE_FILES <= names and all(f"abi-0{n}.{stream}.private.log" in names
                 for n in (1, 2, 3) for stream in ("stdout", "stderr")), "complete_private_stage_evidence")
        core.check_directory_name(output, root_before)
        return result
    finally:
        os.close(root_fd)


def return_plan(spec_binding, result_binding, placement_binding):
    spec, result = core.pinned(spec_binding, private=True), core.pinned(result_binding)
    placement = core.pinned(placement_binding, private=True)
    mac, linux = placement["mac"], placement["linux"]
    need(spec["stage"] == result["stage"] == "linux_target" and result["spec"] == spec_binding
         and result["controller_sha256"] == spec["controller"]["sha256"] == DRIVER_SHA
         and spec["run_id"] == result["run_id"] == placement["run_id"]
         and result_binding["path"] == str(Path(spec["output_root"]) / "result.public.json")
         and result["actual_host"] == spec["expected_host"] == linux["expected_host"],
         "private_return_actual_original_stage")
    # Failed stages are also transferable for diagnosis; transfer never changes
    # their result or supplies a qualification. Final admission still requires
    # all 13 target checks, exact executor chain and all owned closures.
    need(result["status"] in ("passed", "failed"), "private_return_terminal_stage")
    sources = evidence_sources(spec["output_root"], core.now_ns() + SECONDS * 1_000_000_000,
                               require_complete=result["status"] == "passed")
    sources.append({"source": spec_binding, "relative": "control/linux_target.private.json"})
    return make_plan("linux_evidence_return", spec["run_id"], linux["expected_host"], mac["expected_host"],
        linux["root"], str(Path(mac["root"]) / "returned-linux-target"), sources,
        {"stage_spec": spec_binding, "stage_result": result_binding, "backup_manifest": spec["backup_manifest"]})


def write_all(fd, raw):
    view = memoryview(raw)
    while view:
        count = os.write(fd, view)
        need(count > 0, "private_transfer_write")
        view = view[count:]


def stream_source(row, output, deadline):
    path = core.absolute(row["source"])
    parent, fd = core.directory_fd(path.parent, private=True), None
    try:
        before_parent = core.stamp(os.fstat(parent))
        fd = core.file_fd(path, source_directory_fd=parent)
        need(core.stamp(os.fstat(fd)) == row["source_stamp"], "private_transfer_source_identity_changed")
        count, sha = 0, hashlib.sha256()
        while True:
            core.live(deadline)
            data = os.read(fd, 65536)
            if not data: break
            count += len(data)
            need(count <= row["bytes"], "private_transfer_source_grew")
            write_all(output, data); sha.update(data)
        need(count == row["bytes"] and sha.hexdigest() == row["sha256"]
             and core.stamp(os.fstat(fd)) == row["source_stamp"], "private_transfer_source_changed")
        core.check_directory_name(path.parent, before_parent)
    finally:
        if fd is not None: os.close(fd)
        os.close(parent)


def pack(plan_binding, output):
    plan = core.pinned(plan_binding, private=True, maximum=MAX_MANIFEST)
    validate_plan(plan)
    driver.local_host(plan["source_host"]["label"], plan["source_host"])
    deadline = core.now_ns() + SECONDS * 1_000_000_000
    raw = core.canonical(plan)
    need(len(raw) <= MAX_MANIFEST, "private_transfer_manifest_bound")
    output = core.absolute(output)
    need(output == carrier_path(plan, "source"), "private_transfer_exact_sender_carrier_path")
    need(not output.is_relative_to(plan["source_root"]) and not output.is_relative_to(plan["destination_root"]),
         "private_transfer_carrier_outside_source_and_destination")
    parent, fd = core.directory_fd(output.parent, private=True), None
    try:
        fd = os.open(output.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                     0o600, dir_fd=parent)
        write_all(fd, MAGIC + struct.pack(">Q", len(raw)) + raw)
        for row in plan["entries"]: stream_source(row, fd, deadline)
        os.fsync(fd); os.fsync(parent)
    finally:
        if fd is not None: os.close(fd)
        os.close(parent)
    sha = core.sha_file(output, private=True, deadline_ns=deadline)
    need(output.stat().st_size == len(MAGIC) + 8 + len(raw) + plan["total_bytes"], "private_transfer_package_size")
    core.live(deadline)
    return {"schema": RECEIPT_SCHEMA, "status": "packed", "kind": plan["kind"], "run_id": plan["run_id"],
        "plan": plan_binding, "plan_document_sha256": digest(plan), "package": {"path": str(output), "sha256": sha},
        "package_bytes": output.stat().st_size, "file_count": plan["file_count"], "total_bytes": plan["total_bytes"],
        "actual_host": plan["source_host"], "products_started": 0, "secret_bytes_in_receipt": False}


def read_exact(fd, amount, deadline):
    chunks, left = [], amount
    while left:
        core.live(deadline)
        raw = os.read(fd, min(65536, left))
        need(raw, "private_transfer_truncated_package")
        chunks.append(raw); left -= len(raw)
    return b"".join(chunks)


def receive(plan_binding, archive_binding):
    plan = core.pinned(plan_binding, private=True, maximum=MAX_MANIFEST)
    _, root = validate_plan(plan)
    actual = driver.local_host(plan["destination_host"]["label"], plan["destination_host"])
    deadline = core.now_ns() + SECONDS * 1_000_000_000
    archive = core.absolute(archive_binding["path"])
    need(archive == carrier_path(plan, "destination"), "private_transfer_exact_receiver_carrier_path")
    need(not archive.is_relative_to(root) and core.HEX64.fullmatch(archive_binding["sha256"]),
         "private_transfer_carrier_pin_and_scope")
    raw_plan = core.canonical(plan)
    expected_size = len(MAGIC) + 8 + len(raw_plan) + plan["total_bytes"]
    fd = core.file_fd(archive)
    root_fd = None
    try:
        before = core.stamp(os.fstat(fd))
        need(before["size"] == expected_size, "private_transfer_exact_package_length")
        count, sha = 0, hashlib.sha256()
        while True:
            core.live(deadline)
            raw = os.read(fd, 65536)
            if not raw: break
            count += len(raw); need(count <= expected_size, "private_transfer_package_grew"); sha.update(raw)
        need(count == expected_size and sha.hexdigest() == archive_binding["sha256"]
             and core.stamp(os.fstat(fd)) == before, "private_transfer_complete_package_pin")
        os.lseek(fd, 0, os.SEEK_SET)
        need(read_exact(fd, len(MAGIC), deadline) == MAGIC
             and struct.unpack(">Q", read_exact(fd, 8, deadline))[0] == len(raw_plan)
             and read_exact(fd, len(raw_plan), deadline) == raw_plan, "private_transfer_exact_canonical_plan_header")
        core.new_directory(root)  # Existing roots are never overwritten or reused.
        root_fd = core.directory_fd(root, private=True)
        root_identity = {k: core.stamp(os.fstat(root_fd))[k] for k in ("dev", "ino", "uid", "mode")}
        directories = set(plan["empty_directories"])
        for row in plan["entries"]:
            directories.update(str(p) for p in Path(row["relative"]).parents if str(p) != ".")
        for name in sorted(directories, key=lambda p: (len(Path(p).parts), p)):
            core.new_directory(root / name)
        received = []
        for row in plan["entries"]:
            current = core.directory_fd(root, private=True)
            try:
                need({k: core.stamp(os.fstat(current))[k] for k in root_identity} == root_identity,
                     "private_transfer_destination_name_rebound")
            finally: os.close(current)
            target = root / row["relative"]
            parent, out = core.directory_fd(target.parent, private=True), None
            try:
                before_parent = {k: core.stamp(os.fstat(parent))[k] for k in ("dev", "ino", "uid", "mode")}
                out = os.open(target.name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                              0o600, dir_fd=parent)
                left, sha = row["bytes"], hashlib.sha256()
                while left:
                    raw = read_exact(fd, min(65536, left), deadline)
                    write_all(out, raw); sha.update(raw); left -= len(raw)
                need(sha.hexdigest() == row["sha256"], "private_transfer_member_digest")
                os.fsync(out); os.fsync(parent)
                need(stat.S_IMODE(os.fstat(out).st_mode) == 0o600 and os.fstat(out).st_nlink == 1,
                     "private_transfer_destination_private_regular")
                out_stamp = core.stamp(os.fstat(out))
            finally:
                if out is not None: os.close(out)
                os.close(parent)
            parent = core.directory_fd(target.parent, private=True)
            try:
                need({k: core.stamp(os.fstat(parent))[k] for k in before_parent} == before_parent,
                     "private_transfer_destination_parent_rebound")
            finally: os.close(parent)
            need(core.sha_file(target, private=True, deadline_ns=deadline) == row["sha256"],
                 "private_transfer_receiver_readback_digest")
            received.append({"relative": row["relative"], "bytes": row["bytes"], "sha256": row["sha256"],
                             "receiver_stamp": out_stamp})
        need(not os.read(fd, 1) and core.stamp(os.fstat(fd)) == before, "private_transfer_extra_or_changed_carrier_bytes")
        actual_files, actual_dirs = set(), set()
        for parent, dirs, files in os.walk(root, followlinks=False):
            actual_dirs.update(str((Path(parent) / n).relative_to(root)) for n in dirs)
            actual_files.update(str((Path(parent) / n).relative_to(root)) for n in files)
        need(actual_files == {r["relative"] for r in received} and actual_dirs == directories,
             "private_transfer_exact_received_tree")
        current = core.directory_fd(root, private=True)
        try:
            need({k: core.stamp(os.fstat(current))[k] for k in root_identity} == root_identity,
                 "private_transfer_destination_name_rebound")
        finally: os.close(current)
        os.fsync(root_fd)
        core.live(deadline)
        return {"schema": RECEIPT_SCHEMA, "status": "received", "kind": plan["kind"], "run_id": plan["run_id"],
            "plan": plan_binding, "plan_document_sha256": digest(plan), "package": archive_binding,
            "package_bytes": expected_size, "file_count": len(received), "total_bytes": plan["total_bytes"],
            "destination_root": str(root), "destination_identity": root_identity,
            "received_files": received, "receiver_digest": digest([{k: r[k] for k in ("relative", "bytes", "sha256")}
                                                                      for r in received]),
            "actual_host": actual, "all_private_0600_and_directories_0700": True,
            "all_members_fsynced_and_read_back": True, "products_started": 0, "secret_bytes_in_receipt": False}
    finally:
        if root_fd is not None: os.close(root_fd)
        os.close(fd)


def audit_package(plan, binding):
    """Read the actual local carrier again; neither receipt can attest its bytes."""
    deadline = core.now_ns() + SECONDS * 1_000_000_000
    raw_plan = core.canonical(plan)
    fd = core.file_fd(binding["path"])
    try:
        before = core.stamp(os.fstat(fd))
        expected_size = len(MAGIC) + 8 + len(raw_plan) + plan["total_bytes"]
        need(before["size"] == expected_size, "private_transfer_audit_package_size")
        prefix = read_exact(fd, len(MAGIC) + 8 + len(raw_plan), deadline)
        need(prefix == MAGIC + struct.pack(">Q", len(raw_plan)) + raw_plan,
             "private_transfer_audit_exact_plan")
        sha = hashlib.sha256(prefix)
        for row in plan["entries"]:
            member, left = hashlib.sha256(), row["bytes"]
            while left:
                block = read_exact(fd, min(65536, left), deadline)
                sha.update(block); member.update(block); left -= len(block)
            need(member.hexdigest() == row["sha256"], "private_transfer_audit_member")
        need(not os.read(fd, 1) and core.stamp(os.fstat(fd)) == before
             and sha.hexdigest() == binding["sha256"], "private_transfer_audit_complete_bytes")
        core.live(deadline)
        return expected_size
    finally:
        os.close(fd)


def validate_receipt_set(bindings, *, kind, run_id, source_host, destination_host,
                         source_root, destination_root, stage_spec_sha256,
                         backup_manifest_sha256, stage_result=None, local_receiver_root=None):
    """Join original copies and actual local carrier to the already-bound stages.

    The upstream final gate still reopens every original oracle, all returned
    payload/custody artifacts, and the actual Linux stage's executor result.
    This routine cannot grant recovery authority or authenticate a host by a
    receipt's boolean. It verifies this narrower transfer edge and its bytes.
    """
    need(isinstance(bindings, dict) and set(bindings) == {"kind", "plan", "pack", "receive"}
         and bindings["kind"] == kind, "private_transfer_review_binding_fields")
    plan = core.pinned(bindings["plan"], private=True, maximum=MAX_MANIFEST)
    validate_plan(plan)
    packed, received = core.pinned(bindings["pack"]), core.pinned(bindings["receive"], maximum=MAX_MANIFEST)
    need(plan["kind"] == kind and plan["run_id"] == run_id
         and plan["source_host"] == source_host and plan["destination_host"] == destination_host
         and plan["source_root"] == source_root and plan["destination_root"] == destination_root
         and plan["proof"]["stage_spec"]["sha256"] == stage_spec_sha256
         and plan["proof"]["backup_manifest"]["sha256"] == backup_manifest_sha256,
         "private_transfer_stage_and_physical_origins")
    need(plan["proof"]["stage_result"] == stage_result, "private_transfer_original_terminal_result")
    for receipt, status, host in ((packed, "packed", source_host), (received, "received", destination_host)):
        need(receipt["schema"] == RECEIPT_SCHEMA and receipt["status"] == status
             and receipt["kind"] == kind and receipt["run_id"] == run_id
             and receipt["plan"]["sha256"] == bindings["plan"]["sha256"]
             and receipt["plan_document_sha256"] == digest(plan)
             and receipt["file_count"] == plan["file_count"] and receipt["total_bytes"] == plan["total_bytes"]
             and receipt["actual_host"] == host and receipt["products_started"] == 0
             and receipt["secret_bytes_in_receipt"] is False, "private_transfer_original_receipt_edge")
        root_scope(receipt["package"]["path"], host["label"])
    need(packed["package"]["path"] == str(carrier_path(plan, "source"))
         and received["package"]["path"] == str(carrier_path(plan, "destination")),
         "private_transfer_original_exact_carrier_paths")
    need(packed["package"]["sha256"] == received["package"]["sha256"]
         and received["destination_root"] == destination_root
         and received["all_private_0600_and_directories_0700"] is True
         and received["all_members_fsynced_and_read_back"] is True, "private_transfer_same_carrier_and_target")
    carrier = packed["package"] if kind == "linux_inputs" else received["package"]
    package_bytes = audit_package(plan, carrier)
    need(package_bytes == packed["package_bytes"] == received["package_bytes"], "private_transfer_actual_package_bytes")
    rows = received["received_files"]
    expected = [{k: row[k] for k in ("relative", "bytes", "sha256")} for row in plan["entries"]]
    need(isinstance(rows, list) and len(rows) == len(expected)
         and [{k: row[k] for k in ("relative", "bytes", "sha256")} for row in rows] == expected
         and received["receiver_digest"] == digest(expected), "private_transfer_actual_receiver_digest")
    for row in rows:
        stamp = row["receiver_stamp"]
        need(stat.S_ISREG(stamp["mode"]) and stat.S_IMODE(stamp["mode"]) == 0o600
             and stamp["nlink"] == 1 and stamp["size"] == row["bytes"]
             and stamp["uid"] == destination_host["uid"], "private_transfer_receiver_metadata")
    if local_receiver_root is not None:
        need(kind == "linux_evidence_return" and str(local_receiver_root) == destination_root,
             "private_transfer_local_return_origin")
        root = core.absolute(local_receiver_root)
        os.close(core.directory_fd(root, private=True))
        expected_dirs = set(plan["empty_directories"])
        for row in rows:
            expected_dirs.update(str(p) for p in Path(row["relative"]).parents if str(p) != ".")
            path = root / row["relative"]
            need(core.sha_file(path, private=True) == row["sha256"]
                 and core.stamp(path.stat()) == row["receiver_stamp"], "private_transfer_local_return_changed")
        found_files, found_dirs = set(), set()
        for parent, dirs, files in os.walk(root, followlinks=False):
            for name in dirs:
                path = Path(parent) / name
                os.close(core.directory_fd(path, private=True))
                found_dirs.add(str(path.relative_to(root)))
            found_files.update(str((Path(parent) / name).relative_to(root)) for name in files)
        need(found_files == {row["relative"] for row in rows} and found_dirs == expected_dirs,
             "private_transfer_return_tree_closed")
    return {"kind": kind, "plan": bindings["plan"], "pack": bindings["pack"], "receive": bindings["receive"],
            "package_sha256": carrier["sha256"], "receiver_digest": received["receiver_digest"],
            "files": len(rows), "bytes": plan["total_bytes"],
            "actual_local_carrier_rehashed": True, "remote_files_requeried_by_transfer_gate": False}


def add_binding(parser, name):
    parser.add_argument("--" + name.replace("_", "-"), required=True)
    parser.add_argument("--" + name.replace("_", "-") + "-sha256", required=True)


def main():
    deadline = core.now_ns() + SECONDS * 1_000_000_000
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="command", required=True)
    for name in ("input-plan", "return-plan"):
        sub = subs.add_parser(name)
        for key in ("spec", "preparation" if name == "input-plan" else "result", "placement"): add_binding(sub, key)
        sub.add_argument("--output", required=True)
    sub = subs.add_parser("pack"); add_binding(sub, "plan")
    sub.add_argument("--archive", required=True); sub.add_argument("--output", required=True)
    sub = subs.add_parser("receive"); add_binding(sub, "plan"); add_binding(sub, "archive")
    sub.add_argument("--output", required=True)
    sub = subs.add_parser("initialize-carrier"); add_binding(sub, "plan")
    sub.add_argument("--side", choices=("source", "destination"), required=True)
    sub.add_argument("--output", required=True)
    args = parser.parse_args()
    binding = lambda key: {"path": getattr(args, key), "sha256": getattr(args, key + "_sha256")}
    os.umask(0o077)
    if args.command == "input-plan": doc = input_plan(binding("spec"), binding("preparation"), binding("placement"))
    elif args.command == "return-plan": doc = return_plan(binding("spec"), binding("result"), binding("placement"))
    elif args.command == "pack": doc = pack(binding("plan"), args.archive)
    elif args.command == "initialize-carrier": doc = initialize_carrier(binding("plan"), args.side)
    else: doc = receive(binding("plan"), binding("archive"))
    result = core.write_new(args.output, doc)
    core.live(deadline)
    print(json.dumps({"status": doc.get("status", "prepared"), "result": result["path"],
                      "result_sha256": result["sha256"], "products_started": 0}))
    return 0


if __name__ == "__main__":
    try: raise SystemExit(main())
    except core.Refusal as exc:
        print(json.dumps({"status": "refused", "failure": str(exc), "products_started": 0}), file=sys.stderr)
        raise SystemExit(2)
