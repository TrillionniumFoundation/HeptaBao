# Observer admission input and evidence contract

This document describes the current control draft. The public gate and full31
wrapper remain closed by `DRAFT_ONLY`. No actual 13-job admission or observer
execution is established by the local parser/model controls.

## Input object

The `observer_inputs` and `observer_inputs_sha256` arguments in the new outer
gate bind one JSON object with exactly these fields:

| Field | Required value |
| --- | --- |
| `schema` | `heptabao.readindex-observer-admission-inputs.v1` |
| `source_commit`, `source_tree` | The same frozen source as the actual original181 admission |
| `linux_host` | The same configured Linux builder as all five original Linux stages |
| `manifest` | `{path, sha256}` for the shared 16-test manifest |
| `executors` | `{path, sha256}` for the four original observer executor rows |
| `mac`, `linux` | Platform evidence objects defined below |

Each platform object has exactly seven fields: `runtime_build`,
`normal_cargo_stdout`, `runtime_cargo_stdout`, `joint_result`, `builder`,
`runner`, and `commands_helper`. Every value except Mac `commands_helper` is
an origin binding `{path, sha256, runtime_path}`. `path` identifies the actual
local file or the independently copied original Linux bytes; `runtime_path`
is the exact path in the original producer. Mac original paths must coincide
with local paths. Mac `commands_helper` is null. Linux's helper is separately
hash-checked and must equal the helper in its actual normal/libtest chain.

The normal build binding is derived from the unchanged original181 gate;
inputs cannot replace it. Mac uses the combined build result. Linux uses
`libtest-build-r1/build-result.public.json` and follows its actual
`normal_release_result_path` and `release_result_sha256` to the original
normal-release controller. A normal attempt may be r1, r2, and so on as
admitted by the unchanged original gate; attempts cannot be mixed.

The original Mac combined receipt has no Cargo.lock field. The new gate reads
the canonical same-candidate source file against the runtime receipt's hash
and labels the result as a current frozen-source observation. It does not
rewrite the normal receipt or misattribute that observation to the earlier
normal build. Linux uses its actually recorded normal source-before/after
Cargo.lock values. Both remain tied to the same source commit and tree.

## Fixed origin paths

For each platform's already admitted candidate root:

| Evidence | Required original path under that root |
| --- | --- |
| Runtime controller | `control/build_runtime_observer_mac.py` or `control/build_runtime_observer_linux.py` |
| Joint controller | `control/run_observer16.py` |
| Linux command helper | `control/owned_build_commands.py` |
| Shared observer manifest | `control/observer-regression-manifest.public.json` |
| Runtime result | `runtime-observer-libtest-build-r1/result.public.json` |
| Runtime retained libtest | `runtime-observer-libtest-build-r1/retained-heptabao-raft-runtime-libtest` |
| Runtime process/logs | `runtime-observer-libtest-build-r1/runtime-observer-libtest-build.{public.json,stdout,stderr}` |
| Joint result | `observer-regressions-r1/result.public.json` |
| Derived suites | `observer-regressions-r1/{server_observer,runtime_observer}-result.public.json` |

Normal Cargo stdout is derived from the admitted normal receipt's actual
`normal-release-build` record. Runtime Cargo stdout is derived from the new
runtime build record. Both original byte streams are parsed in full, require
one final successful build-finished event, and bind the actual feature/profile
and exact source/manifest/compiler-executable fields. The recorded physical
line index is one-based and the line hash includes its LF.

## Files to preserve for the joint copy

Keep the original relative tree under the joint output directory. It includes
the joint result, both suite results, both inventory results, both list
process receipts/stdout/stderr, and all sixteen `test-0001` through
`test-0016` process receipts/stdout/stderr. The gate re-reads their hashes,
parses the two full libtest inventories and every exact-test stdout, checks
all eighteen processes and the complete cleanup inventory, and requires the
two derived suites to be the exact ordered union in the joint result. The
retained product/libtest binaries do not become locally rehashed on Linux
merely because these receipts were copied; physical launch admission must
rehash the real retained executables.

## Original executor rows and final deadline

The index schema is `heptabao.readindex-observer-executor-bindings.v1`, with
exactly four original rows: `mac_observer_build`, `mac_observer16`,
`linux_observer_build`, `linux_observer16`. Rows use the unchanged b9f worker,
API, terminal, complete-output and result binding fields. All four API
submission/start pairs are mandatory. No suite gets a fabricated executor row.
All four `(host, job_id)` pairs must be distinct and absent from the original
nine-job admission.

The runtime builder stdout is exactly one JSON line with `status`, `result`,
`result_sha256`, and `runtime_tests_started`. The joint stdout is exactly one
JSON line with eight fields: `status`, `result`, `result_sha256`,
`expected_unique_tests`, `passed`, `pool_deadline_satisfied_after_final_fsync`,
`final_fsync_completed_monotonic_ns`, and
`original_pool_deadline_monotonic_ns`. It must agree with the original joint
result and its one 600-second pool, and final fsync must finish strictly before
that original deadline. Successful durable executor exit 0 is independently
required after the runner's final stdout/clock check. A disk result saying
passed cannot excuse a late final return or failed terminal.

Linux runtime compilation additionally binds its actual before/after unit
snapshots, ancestry limits, unchanged command helper, 12 GiB limit, fixed
1.5 GiB host-memory reserve, eight-GiB persistent floor plus unwritten retained
artifact/log reservations, polling bounds, and original WNOWAIT/reap receipt.
The joint binds its bounded raw kernel cgroup/memory observation to the exact
original API/worker unit. Runner PID and supervisor PID remain distinct roles.

## Current limitations and activation sequence

The copied Linux runtime producer pin in this draft is the read Pocket R9
controller, pending explicit binding of the new R10 controller/helper bytes.
Supporting a different producer requires a new reviewed pin and its own real
source/build/executor evidence. The unchanged old181 gate's
general ability to accept ROG does not create a ROG observer build result.

After independent review, a new enabled pure-admission revision can validate
the real thirteen-stage graph while the product wrapper remains draft-closed.
Only after that actual admission is independently checked may a separately
frozen wrapper enable one new original31 run. Formal recovery then binds that
fourteenth actual job and later adds its four original recovery jobs. The
25 recovery checks and original 31 checks remain separate denominators.
