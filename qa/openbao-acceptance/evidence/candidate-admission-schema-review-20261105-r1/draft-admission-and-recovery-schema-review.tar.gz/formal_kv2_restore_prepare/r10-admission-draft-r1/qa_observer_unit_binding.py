#!/usr/bin/env python3
"""Finite modeled unit/cgroup controls; no actual observer job is admitted."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def main():
    target = HERE / "observer_runtime_bindings.py"
    spec = importlib.util.spec_from_file_location("observer_unit_binding_under_test", target)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    output = Path(sys.argv[1]); output.mkdir(mode=0o700)
    job_id = "abc123-cdef-0123"
    bare = "hepta-runtime-job-" + job_id
    worker = {"job_id": job_id, "unit": bare, "platform": "linux", "supervisor_pid": 444}
    start = {"job": {"id": job_id, "unit": bare}, "launch": {"unit": bare, "backend": "systemd"}}
    proc = "0::/user.slice/modeled.slice/" + bare + ".service\n"
    path = "/sys/fs/cgroup/user.slice/modeled.slice/" + bare + ".service"
    memory = "12884901888\n"
    resource = {"schema": "heptabao.observer-actual-execution-resource.v1", "system": "Linux",
        "linux_cgroup_applicable": True, "process_id": 555, "proc_cgroup_path": "/proc/self/cgroup",
        "proc_cgroup_text": proc, "proc_cgroup_sha256": hashlib.sha256(proc.encode()).hexdigest(),
        "unit_path": path, "memory_max_path": path + "/memory.max", "memory_max_text": memory,
        "memory_max_sha256": hashlib.sha256(memory.encode()).hexdigest(), "memory_max_bytes": 12884901888,
        "scope": "read-only actual executor cgroup and hard MemoryMax before any inventory or exact test"}
    rows = []
    def check(name, value, w=worker, s=start, refusal=None):
        observed = None
        try: m.validate_actual_execution_resource(value, worker=w, original_start=s)
        except m.Refusal as error: observed = str(error)
        rows.append({"case": name, "passed": observed == refusal, "expected_refusal": refusal, "actual_refusal": observed})
    check("modeled_exact_bare_api_worker_to_service_cgroup", resource)
    check("runner_pid_may_differ_from_supervisor", dict(resource, process_id=777))
    changed = copy.deepcopy(start); changed["job"]["unit"] += "-other"
    check("different_original_api_unit_refused", resource, s=changed,
          refusal="observer_original_linux_unit_exact_bare_identity")
    changed = dict(worker, unit=bare + ".service")
    check("pre_suffixed_worker_not_stripped_or_double_normalized", resource, w=changed,
          refusal="observer_original_linux_unit_exact_bare_identity")
    changed = dict(worker, job_id="abc123-cdef-0124")
    check("full_job_id_mismatch_refused", resource, w=changed,
          refusal="observer_original_linux_unit_exact_bare_identity")
    changed = dict(resource, proc_cgroup_text=proc.replace(job_id, "abc123-cdef-0124"))
    changed["proc_cgroup_sha256"] = hashlib.sha256(changed["proc_cgroup_text"].encode()).hexdigest()
    check("another_valid_service_suffix_refused", changed,
          refusal="observer_actual_cgroup_matches_original_unit")
    check("duplicate_unified_cgroup_line_refused", dict(resource, proc_cgroup_text=proc + proc),
          refusal="observer_actual_unified_cgroup_text")
    check("parent_component_refused", dict(resource, proc_cgroup_text=proc.replace("modeled.slice", "..")),
          refusal="observer_actual_cgroup_matches_original_unit")
    changed = dict(resource, memory_max_bytes=24 * 1024 ** 3, memory_max_text=str(24 * 1024 ** 3) + "\n")
    changed["memory_max_sha256"] = hashlib.sha256(changed["memory_max_text"].encode()).hexdigest()
    check("larger_actual_memory_even_with_consistent_hash_refused", changed,
          refusal="observer_actual_cgroup_exact_memory_limit")
    check("wrong_memory_original_hash_refused", dict(resource, memory_max_sha256="b" * 64),
          refusal="observer_actual_cgroup_exact_memory_limit")
    check("wrong_proc_original_hash_refused", dict(resource, proc_cgroup_sha256="b" * 64),
          refusal="observer_actual_cgroup_path_and_original_bytes")
    check("different_memory_file_path_refused", dict(resource, memory_max_path="/sys/fs/cgroup/other/memory.max"),
          refusal="observer_actual_cgroup_path_and_original_bytes")
    check("boolean_is_not_runner_pid", dict(resource, process_id=True),
          refusal="observer_actual_runner_resource_origin")
    darwin = {"schema": "heptabao.observer-actual-execution-resource.v1", "system": "Darwin",
        "linux_cgroup_applicable": False,
        "scope": "Linux cgroup not applicable on Darwin; native worker policy checked independently"}
    check("darwin_explicit_not_applicable", darwin, w={"platform": "macos"}, s={})
    check("linux_observation_not_relabelled_darwin", resource, w={"platform": "macos"}, s={},
          refusal="observer_actual_darwin_resource_scope")
    raw_module = target.read_bytes()
    with (output / "observer_runtime_bindings.tested.py").open("xb") as stream:
        stream.write(raw_module); stream.flush(); os.fsync(stream.fileno())
    result = {"schema": "heptabao.observer-unit-cgroup-controls.v1",
        "status": "passed" if all(row["passed"] for row in rows) else "failed",
        "required": len(rows), "passed": sum(row["passed"] for row in rows), "checks": rows,
        "module_sha256": hashlib.sha256(raw_module).hexdigest(),
        "qa_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "all_unit_and_kernel_values_modeled": True, "actual_original_worker_unit_observed_by_this_qa": False,
        "actual_observer_executor_admissions": 0, "compiler_or_product_processes_started": 0}
    raw = (json.dumps(result, sort_keys=True, indent=2) + "\n").encode()
    p = output / "result.public.json"
    with p.open("xb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    p.chmod(0o600)
    fd = os.open(output, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)
    print(json.dumps({"status": result["status"], "required": len(rows), "passed": result["passed"],
        "result": str(p), "sha256": hashlib.sha256(raw).hexdigest()}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
