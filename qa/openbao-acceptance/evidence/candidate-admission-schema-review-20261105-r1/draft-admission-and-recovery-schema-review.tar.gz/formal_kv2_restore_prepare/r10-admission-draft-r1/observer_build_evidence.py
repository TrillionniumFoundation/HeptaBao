#!/usr/bin/env python3
"""Read immutable normal/runtime Cargo evidence for an observer libtest build.

The enclosing gate supplies the original181 build receipt and fixed controller
policy. This module starts no subprocess, and a returned record still requires
the original successful executor and the complete observer16 joint evidence.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import sys

BASE_SHA = "8a25a3bb32d7a78a2884b34b036d227dfb7e984a2b5078f86cea384bb57dae95"
CARGO_SHA = "426249ea6a695e48d02906b5b91bc5507ef9d3299d4d830dc5c2ea6cfcd41fc4"
LINUX_EVIDENCE_SHA = "bea1dd81d535ae0cea3e13c6a294403d7321fe92cfb9968f1db3062c8f987153"
FEATURES = ["default", "native-v6-raft-objects"]
LABEL = "runtime-observer-libtest-build"
ARTIFACT_NAME = "retained-heptabao-raft-runtime-libtest"


class Refusal(RuntimeError):
    pass


def need(value, label):
    if not value:
        raise Refusal(label)


def module(filename, name, pin):
    path = Path(__file__).resolve().with_name(filename)
    need(path.resolve(strict=True) == path and hashlib.sha256(path.read_bytes()).hexdigest() == pin,
         "observer_build_fixed_module")
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); sys.modules[spec.name] = result
    spec.loader.exec_module(result)
    return result


def base_module():
    return module("full34_cross_host_gate_r4.py", "observer_build_original_reader", BASE_SHA)


def cargo_module():
    return module("observer_cargo_evidence.py", "observer_build_original_cargo", CARGO_SHA)


def origin_binding(value, *, expected_origin=None, expected_sha=None, mac=False):
    need(isinstance(value, dict) and set(value) == {"path", "sha256", "runtime_path"},
         "observer_build_origin_binding")
    base = base_module()
    actual = base.origin(value["runtime_path"])
    base.digest(value["sha256"])
    if expected_origin is not None:
        need(str(actual) == str(expected_origin), "observer_build_original_path")
    if expected_sha is not None:
        need(value["sha256"] == expected_sha, "observer_build_original_sha")
    if mac:
        need(value["path"] == value["runtime_path"], "observer_build_mac_original_location")
    return value


def original_bytes(value, *, expected_origin, expected_sha, mac=False):
    origin_binding(value, expected_origin=expected_origin, expected_sha=expected_sha, mac=mac)
    return base_module().raw_file(value["path"], value["sha256"])[0]


def sibling_bytes(binding, filename, expected_sha):
    """Only a sibling of this original result, with the result's declared SHA."""
    need(isinstance(filename, str) and PurePosixPath(filename).name == filename,
         "observer_build_sibling_name")
    local = Path(binding["path"]).parent / filename
    raw, actual = base_module().raw_file(local, expected_sha)
    return raw, {**actual, "runtime_path": str(PurePosixPath(binding["runtime_path"]).parent / filename)}


def normal_cargo_origin(*, platform, normal, normal_binding, release, release_binding):
    base = base_module()
    if platform == "mac":
        need(release is None and release_binding is None, "observer_mac_combined_normal_build")
        call, receipt_origin = normal["release_build"], normal_binding["runtime_path"]
    else:
        need(platform == "linux" and isinstance(release, dict) and isinstance(release_binding, dict),
             "observer_linux_normal_release_required")
        need(normal["normal_release_result_path"] == release_binding["runtime_path"]
             and normal["release_result_sha256"] == release_binding["sha256"]
             and release["source_commit"] == normal["source_commit"]
             and release["source_tree"] == normal["source_tree"]
             and release["status"] == "passed", "observer_linux_original_normal_release_chain")
        call, receipt_origin = release["build"], release_binding["runtime_path"]
    base.command_ok(call, "observer_original_normal_cargo")
    need(call["label"] == "normal-release-build", "observer_original_normal_cargo_label")
    return str(PurePosixPath(receipt_origin).parent / "normal-release-build.stdout"), call["stdout_sha256"]


def verify_cargo_lock_evidence(build, normal, *, platform, source_root):
    """Mac's original combined receipt has no independently recorded lock key.

    Read its canonical frozen source explicitly. Linux retains its actual
    original before/after source-lock receipt. Do not manufacture a Mac field
    or silently call this current read an original normal-build observation.
    """
    base = base_module()
    expected = base.digest(build["cargo_lock_sha256"])
    source = base.origin(source_root)
    common = {"schema": "heptabao.observer-cargo-lock-binding.v1",
              "source_commit": build["source_commit"], "source_tree": build["source_tree"],
              "source_origin_path": str(source / "Cargo.lock"), "sha256": expected}
    if platform == "mac":
        need("cargo_lock_sha256" not in normal and "source_before" not in normal,
             "observer_mac_original_normal_lock_fields_must_not_be_invented")
        _, actual = base.raw_file(Path(source_root) / "Cargo.lock", expected, retain=False)
        need(actual["bytes"] > 0, "observer_mac_actual_frozen_source_lock_empty")
        return {**common, "origin": "current_canonical_frozen_mac_source", "local_file": actual,
                "scope": "Actual current source bytes at the same admitted commit/tree; not a nonexistent field in the original Mac combined normal receipt."}
    need(platform == "linux", "observer_source_lock_platform")
    need(expected == base.digest(normal["source_before"]["cargo_lock_sha256"])
         == base.digest(normal["source_after"]["cargo_lock_sha256"]),
         "observer_runtime_same_normal_cargo_lock")
    return {**common, "origin": "original_linux_normal_build_source_before_and_after",
            "local_file": None, "scope": "Original Linux normal build receipt; no current remote file rehash is claimed by this gate."}


def verify_runtime_build(binding, *, platform, source_root, normal, normal_binding,
                         release, release_binding, normal_cargo_binding,
                         runtime_cargo_binding, controller_sha256, original_unit=None):
    base, cargo = base_module(), cargo_module()
    source = base.origin(source_root)
    root = source.parent
    output = root / "runtime-observer-libtest-build-r1"
    origin_binding(binding, expected_origin=output / "result.public.json", mac=(platform == "mac"))
    build = base.read_receipt(binding["path"], binding["sha256"])["document"]
    need(build["schema"] == "heptabao.r6-readindex-runtime-libtest-build.v1"
         and build["status"] == "built"
         and build["controller_sha256"] == controller_sha256
         and build["source_commit"] == normal["source_commit"]
         and build["source_tree"] == normal["source_tree"], "observer_runtime_actual_build_identity")
    need(build["normal_build"] == {"path": normal_binding["runtime_path"], "sha256": normal_binding["sha256"]}
         and build["normal_server_sha256"] == normal["artifacts"]["heptabao-server"]["sha256"]
         and build["profile"] == normal["profile"], "observer_runtime_exact_normal_build_context")
    need(build["source_unchanged"] is True and build["normal_artifacts_unchanged"] is True
         and build["production_changed"] is False and build["runtime_tests_started"] is False
         and build["full_replacement_qualified"] is False
         and build["cohort"] == "independent-readindex-runtime-libtest"
         and build["stage_caps_seconds"] == {"runtime_observer_libtest": 900}
         and type(build["stage_caps_seconds"]["runtime_observer_libtest"]) is int
         and "failure" not in build and "failure_type" not in build,
         "observer_runtime_success_scope_and_original_cap")
    before, after = build["source_before"], build["source_after"]
    need(before == after and before["commit"] == normal["source_commit"]
         and before["tree"] == normal["source_tree"] and before["status"] == "",
         "observer_runtime_actual_source_closure")
    lock_evidence = verify_cargo_lock_evidence(build, normal, platform=platform, source_root=source_root)
    need(type(build["jobs"]) is int and build["jobs"] > 0
         and str(build["jobs"]) == normal["profile"]["CARGO_BUILD_JOBS"],
         "observer_runtime_same_normal_parallelism")
    abi = "aarch64-apple-darwin" if platform == "mac" else "x86_64-unknown-linux-gnu"
    need("release: 1.98.0\n" in build["rustc_vv"] and "host: " + abi + "\n" in build["rustc_vv"],
         "observer_runtime_actual_rustc_abi")
    need(build["compiler_artifact_features_verified"] == FEATURES,
         "observer_runtime_features_not_fixture")
    call = build["runtime_libtest_build"]
    base.command_ok(call, "observer_runtime_cargo")
    cap_key = "outer_cap_seconds" if platform == "mac" else "cap_seconds"
    cargo_path = str(base.origin(normal["profile"]["PATH"].split(":")[0]) / "cargo")
    need(call["label"] == LABEL and call["argv"] == [cargo_path, "test", "--release", "--locked", "--offline",
         "-p", "heptabao-raft-runtime", "--features", "native-v6-raft-objects", "--lib", "--no-run",
         "--message-format=json-render-diagnostics"]
         and type(call[cap_key]) in (int, float) and call[cap_key] == 900
         and type(call["elapsed_seconds"]) in (int, float) and math.isfinite(call["elapsed_seconds"])
         and call["elapsed_seconds"] >= 0 and type(call["owned_pgid"]) is int and call["owned_pgid"] > 0,
         "observer_runtime_original_cargo_invocation")
    artifact = build["runtime_libtest_artifact"]
    artifact_fields = {"path", "sha256", "bytes", "compiler_executable", "features", "profile", "fresh"}
    if platform == "linux":
        artifact_fields.add("cargo_events_sha256")
    need(isinstance(artifact, dict) and set(artifact) == artifact_fields
         and artifact["path"] == str(output / ARTIFACT_NAME)
         and type(artifact["bytes"]) is int and artifact["bytes"] > 0
         and type(artifact["fresh"]) is bool,
         "observer_runtime_retained_artifact_shape")
    base.digest(artifact["sha256"])
    if platform == "linux":
        need(artifact["cargo_events_sha256"] == call["stdout_sha256"],
             "observer_linux_runtime_artifact_cargo_stream")
    cargo.verify_profile(artifact["profile"], test=True)
    need(sorted(artifact["features"]) == FEATURES
         and base.origin(artifact["compiler_executable"]).is_relative_to(
             base.origin(normal["profile"]["CARGO_TARGET_DIR"])),
         "observer_runtime_artifact_normal_features_and_target")
    normal_path, normal_sha = normal_cargo_origin(platform=platform, normal=normal,
        normal_binding=normal_binding, release=release, release_binding=release_binding)
    normal_raw = original_bytes(normal_cargo_binding, expected_origin=normal_path,
                                expected_sha=normal_sha, mac=(platform == "mac"))
    closure = cargo.verify_normal_dependency(build["normal_runtime_dependency"], normal_raw,
        source_root=str(source), stdout_origin=normal_path, stdout_sha256=normal_sha)
    runtime_path = str(output / (LABEL + ".stdout"))
    runtime_raw = original_bytes(runtime_cargo_binding, expected_origin=runtime_path,
        expected_sha=call["stdout_sha256"], mac=(platform == "mac"))
    compiler_event = cargo.verify_runtime_libtest_event(runtime_raw, source_root=str(source),
        stdout_origin=runtime_path, stdout_sha256=call["stdout_sha256"], normal_dependency=closure,
        artifact=artifact)
    _, stderr = sibling_bytes(binding, LABEL + ".stderr", call["stderr_sha256"])
    process_path = Path(binding["path"]).parent / (LABEL + ".public.json")
    process_raw = (json.dumps(call, indent=2, sort_keys=True) + "\n").encode()
    process_sha = hashlib.sha256(process_raw).hexdigest()
    record = base.read_receipt(process_path, process_sha)["document"]
    need(record == call, "observer_runtime_original_process_record")
    process_binding = {"path": str(process_path), "sha256": process_sha,
                       "runtime_path": str(output / (LABEL + ".public.json"))}
    linux_resource = None
    if platform == "mac":
        need(original_unit is None, "observer_mac_has_no_systemd_unit")
        cleanup = build["cleanup"]
        need(isinstance(cleanup, list) and len(cleanup) == 1
             and cleanup[0] == {"label": LABEL, "pid": call["owned_pgid"], "exit_code": 0,
                 "direct_child_reaped": True, "remaining": []},
             "observer_runtime_complete_original_cleanup")
        _, artifact_now = base.raw_file(artifact["path"], artifact["sha256"], retain=False)
        need(artifact_now["bytes"] == artifact["bytes"], "observer_runtime_current_mac_artifact")
    else:
        need(platform == "linux", "observer_runtime_platform")
        linux = module("observer_linux_build_evidence.py", "observer_linux_original_build_evidence", LINUX_EVIDENCE_SHA)
        linux_resource = linux.verify_linux_runtime(build, normal=normal, source_root=source_root,
                                                    original_unit=original_unit)
    return {"result": build, "binding": binding, "normal_binding": normal_binding,
            "normal_runtime_dependency": closure, "runtime_compiler_event": compiler_event,
            "process": process_binding, "stderr": stderr, "artifact": artifact,
            "cargo_lock_evidence": lock_evidence,
            "linux_resource_and_custody": linux_resource,
            "original_executor_still_required": True}
