#!/usr/bin/env python3
"""Finite pure controls for exact libtest logs, one pool, and late-fsync refusal.

All logs and timestamps here are modeled. No actual observer job, compiler,
product, successful source/build chain, or physical-host claim is constructed.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent


def load(filename, name):
    p = HERE / filename
    spec = importlib.util.spec_from_file_location(name, p)
    value = importlib.util.module_from_spec(spec); spec.loader.exec_module(value)
    return value


def main():
    output = Path(sys.argv[1]); output.mkdir(mode=0o700)
    joint = load("observer_joint_evidence.py", "observer_qa_joint")
    executor = load("observer_runtime_bindings.py", "observer_qa_executor")
    gate = load("readindex_observer_gate.py", "observer_qa_gate")
    rows = []
    def check(name, action, refusal=None):
        error = None
        try:
            action()
        except (joint.Refusal, executor.Refusal, gate.Refusal) as exc:
            error = str(exc)
        rows.append({"case": name, "passed": error == refusal,
                     "expected_refusal": refusal, "actual_refusal": error})
    name = "modeled::exact_case"
    raw = ("\nrunning 1 test\ntest " + name + " ... ok\n\n"
           "test result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 32 filtered out; finished in 0.01s\n").encode()
    check("single_exact_log", lambda: joint.exact_test_stdout(raw, name))
    check("nocapture_multiline_does_not_false_fail", lambda: joint.exact_test_stdout(
        raw.replace(b" ... ok", b" ... test diagnostic\nanother diagnostic\nok"), name))
    check("another_case_log_refused", lambda: joint.exact_test_stdout(raw, "modeled::other"),
          "joint_exact_name_in_original_stdout")
    check("zero_test_log_refused", lambda: joint.exact_test_stdout(raw.replace(b"running 1 test", b"running 0 tests"), name),
          "joint_exact_one_actual_test")
    check("ignored_test_log_refused", lambda: joint.exact_test_stdout(raw.replace(b"1 passed; 0 failed; 0 ignored", b"0 passed; 0 failed; 1 ignored"), name),
          "joint_exact_one_actual_test")
    check("duplicate_named_case_line_refused", lambda: joint.exact_test_stdout(raw + ("test " + name + " ... ok\n").encode(), name),
          "joint_exact_name_in_original_stdout")
    pool = {"seconds": 600, "per_test_seconds": 120, "started_monotonic_ns": 1_000_000_000,
            "deadline_monotonic_ns": 601_000_000_000, "inventories_included": False,
            "inventory_seconds_per_artifact": 60, "post_verification_and_final_fsync_included": True,
            "pool_reset_between_suites": False}
    check("original_single_pool_shape", lambda: joint.validate_pool(pool))
    for field, value, label, refusal in (
        ("seconds", 601, "longer_pool_refused", "joint_original_pool_caps"),
        ("per_test_seconds", 121, "longer_exact_cap_refused", "joint_original_pool_caps"),
        ("pool_reset_between_suites", True, "suite_boundary_reset_refused", "joint_one_actual_absolute_pool"),
        ("deadline_monotonic_ns", 601_000_000_001, "one_ns_extension_refused", "joint_one_actual_absolute_pool"),
    ):
        changed = dict(pool); changed[field] = value
        check(label, lambda changed=changed: joint.validate_pool(changed), refusal)
    result = {"schema": "heptabao.readindex-observer-joint-result.v1", "status": "passed",
              "original_test_pool": pool, "completed_monotonic_ns_before_result_fsync": 600_000_000_000}
    final = {"status": "passed", "result": "/modeled/output/result.public.json", "result_sha256": "a" * 64,
             "expected_unique_tests": 16, "passed": 16, "pool_deadline_satisfied_after_final_fsync": True,
             "final_fsync_completed_monotonic_ns": 600_500_000_000,
             "original_pool_deadline_monotonic_ns": pool["deadline_monotonic_ns"]}
    check("modeled_final_fsync_within_original_pool", lambda: executor.validate_joint_final_stdout(final, result))
    for field, value, label, refusal in (
        ("final_fsync_completed_monotonic_ns", pool["deadline_monotonic_ns"], "equal_deadline_refused", "observer_joint_actual_post_fsync_deadline"),
        ("final_fsync_completed_monotonic_ns", pool["deadline_monotonic_ns"] + 1, "late_fsync_despite_disk_passed_refused", "observer_joint_actual_post_fsync_deadline"),
        ("final_fsync_completed_monotonic_ns", result["completed_monotonic_ns_before_result_fsync"] - 1, "reversed_final_clock_refused", "observer_joint_actual_post_fsync_deadline"),
        ("original_pool_deadline_monotonic_ns", pool["deadline_monotonic_ns"] + 1, "stdout_pool_extension_refused", "observer_joint_actual_post_fsync_deadline"),
        ("pool_deadline_satisfied_after_final_fsync", False, "failed_final_deadline_flag_refused", "observer_joint_actual_post_fsync_deadline"),
        ("status", "failed", "failed_final_status_refused", "observer_joint_stdout_contract"),
        ("passed", True, "boolean_does_not_substitute_sixteen", "observer_joint_stdout_contract"),
    ):
        changed = dict(final); changed[field] = value
        check(label, lambda changed=changed: executor.validate_joint_final_stdout(changed, result), refusal)
    missing = dict(final); del missing["final_fsync_completed_monotonic_ns"]
    check("missing_post_fsync_evidence_refused", lambda: executor.validate_joint_final_stdout(missing, result),
          "observer_joint_stdout_contract")
    extra = dict(final); extra["caller_approved"] = True
    check("extra_stdout_authority_refused", lambda: executor.validate_joint_final_stdout(extra, result),
          "observer_joint_stdout_contract")
    controller = "/candidate/control/run_observer16.py"
    flags = {"source": "/candidate/source", "commit": "a" * 40}
    argv = ["-I", "-S", "-B", controller, "--commit", flags["commit"], "--source", flags["source"]]
    check("exact_flags_accept_actual_order", lambda: gate.exact_cli_values(argv, controller_origin=controller, expected_values=flags))
    duplicate = argv[:-2] + ["--commit", flags["commit"]]
    check("duplicate_flag_refused", lambda: gate.exact_cli_values(duplicate, controller_origin=controller, expected_values=flags),
          "observer_duplicate_or_unknown_cli_flag")
    wrong = list(argv); wrong[-1] = "/other-candidate/source"
    check("cross_candidate_source_flag_refused", lambda: gate.exact_cli_values(wrong, controller_origin=controller, expected_values=flags),
          "observer_original_cli_candidate_context")
    check("extra_flag_refused", lambda: gate.exact_cli_values(argv + ["--retry", "1"], controller_origin=controller, expected_values=flags),
          "observer_original_python_cli")
    linux_argv = ["-B", controller, *argv[4:]]
    check("linux_runtime_exact_nonisolated_local_helper_import", lambda: gate.exact_cli_values(
        linux_argv, controller_origin=controller, expected_values=flags, python_flags=("-B",)))
    check("mac_flags_do_not_replace_linux_runtime_contract", lambda: gate.exact_cli_values(
        argv, controller_origin=controller, expected_values=flags, python_flags=("-B",)),
        "observer_original_python_cli")
    check("linux_runtime_flags_do_not_replace_joint_contract", lambda: gate.exact_cli_values(
        linux_argv, controller_origin=controller, expected_values=flags), "observer_original_python_cli")
    check("unfinished_graph_remains_draft_closed", lambda: gate.validate_observer_inputs({}, base_inputs={}, base_admission={}),
          "observer_joint_producer_contract_not_frozen")
    result = {"schema": "heptabao.observer-evidence-edge-controls.v1",
        "status": "passed" if all(row["passed"] for row in rows) else "failed",
        "required": len(rows), "passed": sum(row["passed"] for row in rows), "checks": rows,
        "modules": {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in (
            "observer_joint_evidence.py", "observer_runtime_bindings.py", "readindex_observer_gate.py")},
        "qa_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "inputs_are_modeled_logs_and_timestamps": True, "actual_observer_executor_bindings_tested": 0,
        "actual_candidate_admissions_tested": 0, "compiler_or_product_processes_started": 0, "network_calls": 0}
    target = output / "result.public.json"
    raw = (json.dumps(result, sort_keys=True, indent=2) + "\n").encode()
    copies = output / "tested-modules"; copies.mkdir(mode=0o700)
    for name, expected in result["modules"].items():
        content = (HERE / name).read_bytes()
        assert hashlib.sha256(content).hexdigest() == expected
        with (copies / name).open("xb") as stream:
            stream.write(content); stream.flush(); os.fsync(stream.fileno())
    with (output / "qa.tested.py").open("xb") as stream:
        stream.write(Path(__file__).read_bytes()); stream.flush(); os.fsync(stream.fileno())
    with target.open("xb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    target.chmod(0o600)
    fd = os.open(output, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)
    print(json.dumps({"status": result["status"], "required": len(rows), "passed": result["passed"],
                      "result": str(target), "sha256": hashlib.sha256(raw).hexdigest()}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
