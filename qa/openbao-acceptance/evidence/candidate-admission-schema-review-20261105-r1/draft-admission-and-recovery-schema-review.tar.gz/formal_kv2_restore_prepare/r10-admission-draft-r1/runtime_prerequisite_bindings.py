#!/usr/bin/env python3
"""Read-only prerequisite admission from captured runtime RPCs and original worker files.

No subprocesses, network access, source edits, signal delivery or test execution.
The caller pins the index and expected result bindings after independently reading
the configured hosts. Captures preserve actual RPC request values and responses;
this is an evidence linkage check, not a cryptographic attestation of a host.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat

SCHEMA = "heptabao.runtime-prerequisite-bindings.v2"
CAPTURE_SCHEMA = "heptabao.runtime-rpc-capture.v1"
STAGES = frozenset((
    "mac_build", "mac_server", "mac_ha", "mac_aggregate",
    "linux_release", "linux_libtest", "linux_server", "linux_ha", "linux_aggregate",
    "full34", "matched_kv2",
))
TOOLS = {
    "worker": "heptaruntime_mac_controller.read_multiple_files",
    "terminal": "heptaruntime_mac_controller.process_status",
    "read": "heptaruntime_mac_controller.process_read",
}
ROW_FIELDS = frozenset((
    "stage", "host", "job_id", "worker_request", "worker_started",
    "worker_capture", "terminal_capture", "read_captures", "result",
    "api_submission", "api_start",
))


class AdmissionFailure(RuntimeError):
    pass


def require(ok, code):
    if not ok:
        raise AdmissionFailure(code)


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False) + "\n").encode()


def pairs(items):
    value = {}
    for key, item in items:
        require(key not in value, "duplicate_json_key")
        value[key] = item
    return value


def decode(raw):
    def invalid(_):
        raise AdmissionFailure("nonfinite_json")
    try:
        return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid)
    except (ValueError, UnicodeError) as error:
        raise AdmissionFailure("invalid_json_document") from error


def digest(value):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
            "invalid_sha256")
    return value


def origin(value):
    require(isinstance(value, str) and value.startswith("/") and "\0" not in value,
            "invalid_origin_path")
    path = PurePosixPath(value)
    require(str(path) == value and ".." not in path.parts, "noncanonical_origin_path")
    return path


def raw_file(path, maximum=16 * 1024 * 1024):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, "noncanonical_input")
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
            and before.st_nlink == 1 and not before.st_mode & 0o022
            and before.st_size <= maximum, "input_identity")
    identity = (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(maximum + 1)
        after = os.fstat(fd)
        require(identity == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
                "input_changed_during_read")
    finally:
        os.close(fd)
    end = path.lstat()
    require(len(raw) <= maximum and (end.st_dev, end.st_ino) == identity[:2], "input_read_bound")
    return raw


def pinned(binding, *, document=True):
    require(isinstance(binding, dict) and set(binding) == {"path", "sha256"}, "binding_fields")
    raw = raw_file(binding["path"])
    require(hashlib.sha256(raw).hexdigest() == digest(binding["sha256"]), "binding_hash_mismatch")
    return decode(raw) if document else raw


def capture(binding, kind, host, job_id=None):
    value = pinned(binding)
    require(isinstance(value, dict) and set(value) == {"schema", "tool", "request", "response"}
            and value["schema"] == CAPTURE_SCHEMA and value["tool"] == TOOLS[kind],
            "rpc_capture_schema")
    request, response = value["request"], value["response"]
    require(isinstance(request, dict) and request.get("host") == host, "rpc_configured_host_mismatch")
    if job_id is not None:
        require(request.get("job_id") == job_id and isinstance(response, dict)
                and response.get("job_id") == job_id, "rpc_job_identity_mismatch")
    return request, response


def worker_files(row):
    request_raw = pinned(row["worker_request"], document=False)
    started_raw = pinned(row["worker_started"], document=False)
    request, started = decode(request_raw), decode(started_raw)
    require(isinstance(request, dict) and isinstance(started, dict), "worker_document_shape")
    require(request.get("job_id") == started.get("job_id") == row["job_id"], "worker_job_mismatch")
    nonce = request.get("launch_nonce")
    require(isinstance(nonce, str) and re.fullmatch(r"[0-9a-f]{32}", nonce) is not None
            and started.get("launch_nonce") == nonce, "worker_start_nonce_mismatch")
    require(request.get("request_fingerprint") == digest(request.get("request_digest")),
            "worker_request_digest_mismatch")
    require(request.get("terminal_publication_protocol") == 1
            and request.get("execution_mode") == "operator", "worker_execution_protocol")
    require(request.get("platform") == ("macos" if row["host"] == "mac" else "linux"),
            "worker_platform_host_mismatch")
    directory = origin(request["job_dir"])
    require(directory.name == row["job_id"] and directory.parent.name == "jobs", "worker_directory_job")
    require(isinstance(request.get("executable"), str) and bool(request["executable"])
            and isinstance(request.get("args"), list)
            and all(isinstance(a, str) for a in request["args"]), "worker_invocation_shape")
    require(isinstance(request.get("env"), dict)
            and all(isinstance(k, str) and isinstance(v, str) for k, v in request["env"].items()),
            "worker_environment_shape")
    require(type(request.get("timeout_seconds")) in (int, float)
            and request["timeout_seconds"] > 0
            and type(request.get("nice")) is int and 0 <= request["nice"] <= 19,
            "worker_resource_shape")
    require(type(started.get("at_unix_ms")) is int and started["at_unix_ms"] > 0
            and type(started.get("supervisor_pid")) is int and started["supervisor_pid"] > 0
            and type(started.get("supervisor_uid")) is int and started["supervisor_uid"] >= 0,
            "worker_start_identity")
    identity = started.get("supervisor_identity")
    require(isinstance(identity, dict) and set(identity) == {"kind", "value"}
            and isinstance(identity["kind"], str) and bool(identity["kind"])
            and isinstance(identity["value"], (str, int)) and bool(identity["value"]),
            "worker_supervisor_identity")
    query, observed = capture(row["worker_capture"], "worker", row["host"])
    require(isinstance(observed, dict) and observed.get("truncated") is False
            and observed.get("encoding") == "utf-8", "worker_capture_incomplete")
    files = observed.get("files")
    require(isinstance(files, list) and files and len(files) <= 16
            and len({f["path"] for f in files}) == len(files)
            and set(query["paths"]) == {f["path"] for f in files}, "worker_capture_inventory")
    for name, raw, binding in (("request.json", request_raw, row["worker_request"]),
                               ("started.json", started_raw, row["worker_started"])):
        path = str(directory / name)
        matched = [entry for entry in files if entry["path"] == path]
        require(len(matched) == 1, "worker_origin_not_observed")
        entry = matched[0]
        require(entry.get("eof") is True and entry.get("text", "").encode() == raw
                and entry["size"] == len(raw) and entry["sha256"] == binding["sha256"]
                and isinstance(entry.get("version"), str) and bool(entry["version"]),
                "worker_origin_bytes_not_bound")
    return request, started


def api_originals(row, worker):
    request_binding, start_binding = row["api_submission"], row["api_start"]
    require((request_binding is None) == (start_binding is None), "incomplete_api_original_pair")
    if request_binding is None:
        return {"available": False, "authority": "independently_read_original_worker_request_and_started"}
    submitted, response = pinned(request_binding), pinned(start_binding)
    require(isinstance(submitted, dict) and isinstance(response, dict), "api_original_shape")
    job = response.get("job")
    require(isinstance(job, dict) and job.get("id") == row["job_id"]
            and job.get("host") == submitted.get("host") == row["host"],
            "api_original_host_job")
    require(job.get("launch_state") == "launched" and job.get("launch_error") is None,
            "api_original_not_launched")
    require(job.get("request_digest") == worker["request_digest"], "api_worker_request_digest")
    for key in ("executable", "args"):
        require(job.get(key) == submitted.get(key) == worker[key], "api_worker_invocation_mismatch")
    require(job.get("idempotency_key") == submitted.get("idempotency_key")
            and isinstance(job["idempotency_key"], str) and bool(job["idempotency_key"]),
            "api_idempotency_key_mismatch")
    require(submitted.get("env", {}) == worker["env"], "api_worker_environment_mismatch")
    require(submitted.get("cwd") == worker["cwd"], "api_worker_cwd_mismatch")
    for key in ("timeout_seconds", "nice", "memory_max_bytes", "cpu_quota_percent"):
        if key in submitted:
            require(submitted[key] == worker[key], "api_worker_resource_mismatch")
    # process_start.job has no launch_nonce. Its integer fingerprint is not
    # the worker's 64-character digest string; never invent a cross-type match.
    return {"available": True, "authority": "original_api_request_start_and_original_worker_files",
            "idempotency_key": submitted["idempotency_key"]}


def terminal_record(row, worker, started):
    _, terminal = capture(row["terminal_capture"], "terminal", row["host"], row["job_id"])
    require(terminal.get("audit_recorded") is True and terminal.get("state") == "succeeded"
            and type(terminal.get("exit_code")) is int and terminal["exit_code"] == 0,
            "executor_not_successful")
    require(terminal.get("launch_nonce") == worker["launch_nonce"] == started["launch_nonce"],
            "terminal_worker_nonce_mismatch")
    for flag in ("terminal_publication_confirmed", "output_complete", "output_durable"):
        require(terminal.get(flag) is True, "terminal_" + flag)
    for flag in ("timed_out", "cancelled", "automatic_retry"):
        require(terminal.get(flag) is False, "terminal_" + flag)
    require(terminal.get("terminal_publication_protocol") == 1
            and type(terminal.get("at_unix_ms")) is int
            and terminal["at_unix_ms"] >= started["at_unix_ms"], "terminal_order_or_protocol")
    for key in ("log_truncated", "log_errors", "log_synced", "log_bytes"):
        require(isinstance(terminal.get(key), dict) and set(terminal[key]) == {"stdout", "stderr"},
                "terminal_stream_inventory")
    for name in ("stdout", "stderr"):
        require(terminal["log_truncated"][name] is False
                and terminal["log_errors"][name] is None
                and terminal["log_synced"][name] is True, "terminal_stream_integrity")
        counts = terminal["log_bytes"][name]
        require(set(counts) == {"seen", "stored"} and type(counts["seen"]) is int
                and type(counts["stored"]) is int and 0 <= counts["seen"] <= 16 * 1024 * 1024
                and counts["seen"] == counts["stored"], "terminal_stream_counts")
    return terminal


def complete_output(row, terminal):
    bindings = row["read_captures"]
    require(isinstance(bindings, list) and 1 <= len(bindings) <= 1024, "read_page_count")
    output = {name: bytearray() for name in ("stdout", "stderr")}
    complete = {name: False for name in output}
    for binding in bindings:
        query, page = capture(binding, "read", row["host"], row["job_id"])
        require(page.get("audit_recorded") is True, "read_not_audited")
        for name in output:
            stream = page.get(name)
            require(isinstance(stream, dict), "missing_output_stream")
            require(type(stream.get("offset")) is int and type(stream.get("next_offset")) is int
                    and type(stream.get("size")) is int and type(stream.get("eof")) is bool,
                    "read_cursor_types")
            require(query.get(name + "_offset", 0) == stream["offset"] == len(output[name]),
                    "read_cursor_overlap_or_gap")
            encoded = stream.get("bytes_hex")
            require(isinstance(encoded, str) and re.fullmatch(r"(?:[0-9a-f]{2})*", encoded) is not None,
                    "read_bytes_hex")
            chunk = bytes.fromhex(encoded)
            require(len(chunk) <= 16384 and stream["next_offset"] == stream["offset"] + len(chunk)
                    and stream["size"] == terminal["log_bytes"][name]["stored"]
                    and stream["next_offset"] <= stream["size"], "read_size_or_terminal_mismatch")
            require(isinstance(stream.get("text"), str)
                    and stream["text"] == chunk.decode("utf-8", errors="replace"), "read_text_byte_mismatch")
            require(not complete[name] or not chunk, "output_after_eof")
            require(stream["eof"] is (stream["next_offset"] == stream["size"]), "read_eof_inconsistent")
            output[name].extend(chunk)
            complete[name] = stream["eof"]
    require(all(complete.values()) and all(len(output[name]) == terminal["log_bytes"][name]["stored"]
            for name in output), "incomplete_terminal_output")
    return {name: bytes(raw) for name, raw in output.items()}


def terminal_stdout(stage, stdout, stderr):
    try:
        lines = [line for line in stdout.decode("utf-8").splitlines() if line.strip()]
    except UnicodeError as error:
        raise AdmissionFailure("stdout_not_complete_utf8") from error
    require(lines, "empty_stdout")
    objects = []
    for line in lines:
        value = decode(line)
        require(isinstance(value, dict), "stdout_record_not_object")
        objects.append(value)
    path_key = "result_path" if stage == "linux_release" else "result"
    candidates = [item for item in objects if
                  "result" in item or "result_path" in item or "result_sha256" in item]
    require(len(candidates) == 1 and objects[-1] is candidates[0], "unique_terminal_stdout_result")
    final = candidates[0]
    require(path_key in final and "result_sha256" in final and "status" in final,
            "terminal_stdout_shape")
    require(("result_path" if path_key == "result" else "result") not in final,
            "ambiguous_terminal_result_path")
    require(final["status"] == ("built" if stage in ("mac_build", "linux_libtest") else "passed"),
            "terminal_stdout_not_success")
    origin(final[path_key]); digest(final["result_sha256"])
    if stage == "matched_kv2":
        require(len(objects) == 1 and not stderr
                and set(final) == {"status", "result", "result_sha256", "ha_qualified", "replacement_qualified"}
                and final["ha_qualified"] is False and final["replacement_qualified"] is False,
                "matched_exact_stdout_contract")
    return final, path_key


def validate_runtime_prerequisites(binding, *, required_stages, expected_results, linux_host):
    """Return one deterministic admission receipt; raises AdmissionFailure on any gap.

    binding: {path,sha256} to a SCHEMA index containing {"schema","jobs"}.
    required_stages: an explicit nonempty sequence of distinct names from STAGES.
    expected_results[stage]: {"path": local result/copy, "sha256": hash,
                             "runtime_path": exact origin path in original stdout}.
    linux_host: exactly "rog" or "pocket4". All linux_* stages use that host.
    """
    require(isinstance(required_stages, (list, tuple)) and required_stages
            and len(set(required_stages)) == len(required_stages)
            and set(required_stages) <= STAGES, "required_stage_inventory")
    require(linux_host in ("rog", "pocket4"), "linux_host_policy")
    require(isinstance(expected_results, dict) and set(expected_results) == set(required_stages),
            "expected_result_stage_inventory")
    document = pinned(binding)
    require(isinstance(document, dict) and set(document) == {"schema", "jobs"}
            and document["schema"] == SCHEMA, "runtime_index_schema")
    rows = document["jobs"]
    require(isinstance(rows, list) and len(rows) == len(required_stages)
            and all(isinstance(row, dict) and set(row) == ROW_FIELDS for row in rows)
            and {row["stage"] for row in rows} == set(required_stages), "runtime_stage_denominator")
    require(len({(row["host"], row["job_id"]) for row in rows}) == len(rows), "reused_runtime_job")
    for row in rows:
        require(row["host"] == (linux_host if row["stage"].startswith("linux_") else "mac"),
                "stage_physical_host_mismatch")
        require(isinstance(row["job_id"], str)
                and re.fullmatch(r"[0-9a-f]+-[0-9a-f]+-[0-9a-f]+", row["job_id"]) is not None,
                "runtime_job_id_shape")
    verified = []
    for row in rows:
        stage = row["stage"]
        expected = expected_results[stage]
        require(isinstance(expected, dict) and set(expected) == {"path", "sha256", "runtime_path"},
                "expected_result_binding_fields")
        origin(expected["runtime_path"])
        require(row["result"] == {"path": expected["path"], "sha256": digest(expected["sha256"])},
                "stage_result_binding_mismatch")
        if row["host"] == "mac":
            require(expected["path"] == expected["runtime_path"], "mac_result_origin_path_mismatch")
        result = pinned(row["result"])
        worker, started = worker_files(row)
        api = api_originals(row, worker)
        terminal = terminal_record(row, worker, started)
        output = complete_output(row, terminal)
        final, path_key = terminal_stdout(stage, output["stdout"], output["stderr"])
        require(final[path_key] == expected["runtime_path"]
                and final["result_sha256"] == expected["sha256"], "stdout_result_binding_mismatch")
        require(isinstance(result, dict) and result.get("status") == final["status"],
                "result_document_status_mismatch")
        verified.append({
            "stage": stage, "host": row["host"], "job_id": row["job_id"],
            "launch_nonce": worker["launch_nonce"], "request_digest": worker["request_digest"],
            "executable": worker["executable"], "args": worker["args"], "cwd": worker["cwd"],
            "timeout_seconds": worker["timeout_seconds"], "nice": worker["nice"],
            "memory_max_bytes": worker.get("memory_max_bytes"),
            "cpu_quota_percent": worker.get("cpu_quota_percent"),
            "started_at_unix_ms": started["at_unix_ms"], "terminal_at_unix_ms": terminal["at_unix_ms"],
            "original_api": api, "result": expected, "worker_request": row["worker_request"],
            "worker_started": row["worker_started"], "worker_capture": row["worker_capture"],
            "terminal_capture": row["terminal_capture"], "read_captures": row["read_captures"],
            "stdout_sha256": hashlib.sha256(output["stdout"]).hexdigest(),
            "stderr_sha256": hashlib.sha256(output["stderr"]).hexdigest(),
            "stdout_bytes": len(output["stdout"]), "stderr_bytes": len(output["stderr"]),
            "terminal_stdout_path_key": path_key, "complete_output_bound": True,
        })
    return {
        "schema": "heptabao.runtime-prerequisite-admission.v2", "status": "admitted",
        "module_sha256": hashlib.sha256(raw_file(Path(__file__).resolve())).hexdigest(),
        "index": binding, "required_stages": sorted(required_stages),
        "required": len(required_stages), "passed": len(verified),
        "linux_host": linux_host, "actual_linux_stages": sum(r["stage"].startswith("linux_") for r in verified),
        "all_host_job_pairs_unique": True, "all_original_worker_nonces_bound": True,
        "all_complete_outputs_bound_to_exact_results": True,
        "scope": "Captured configured-host RPCs and independently read original worker metadata; no new execution.",
        "product_processes_started": False, "rows": sorted(verified, key=lambda row: row["stage"]),
    }
