#!/usr/bin/env python3
"""Resource/context predicates using retained Mac schema and modeled Linux values.

This neither validates an observer executor nor runs a compiler or product.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
path = HERE / "observer_runtime_bindings.py"
spec = importlib.util.spec_from_file_location("resource_policy_under_test", path)
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)


def main():
    reference, output = Path(sys.argv[1]), Path(sys.argv[2])
    original_raw = reference.read_bytes(); original = json.loads(original_raw)
    output.mkdir(mode=0o700)
    rows = []
    def check(name, worker, expected, refusal=None):
        observed = None
        try:
            module.validate_resource_context(worker, expected)
        except module.Refusal as error:
            observed = str(error)
        rows.append({"case": name, "passed": observed == refusal,
                     "expected_refusal": refusal, "actual_refusal": observed})
    mac = module.fixed_execution_policy("mac_observer16")
    linux = module.fixed_execution_policy("linux_observer_build")
    check("retained_actual_mac_worker_resource_schema", original, mac)
    check("modeled_exact_linux_12gib_policy", copy.deepcopy(linux), linux)
    for value, label in ((None,"unbounded"),(24*1024**3,"24gib")):
        changed=copy.deepcopy(linux);changed["memory_max_bytes"]=value
        check("linux_memory_"+label+"_refused",changed,linux,
              "observer_original_resource_context_changed_memory_max_bytes")
    changed=copy.deepcopy(linux);del changed["memory_max_bytes"]
    check("missing_memory_not_treated_as_null",changed,linux,
          "observer_original_resource_context_missing")
    changed=copy.deepcopy(linux);changed["cpu_quota_percent"]=200
    check("different_cpu_quota_refused",changed,linux,
          "observer_original_resource_context_changed_cpu_quota_percent")
    changed=copy.deepcopy(linux);del changed["cpu_quota_percent"]
    check("missing_cpu_not_treated_as_null",changed,linux,
          "observer_original_resource_context_missing")
    changed=copy.deepcopy(linux);changed["execution_mode"]="different-mode"
    check("different_execution_mode_refused",changed,linux,
          "observer_original_resource_context_changed_execution_mode")
    changed=copy.deepcopy(linux);changed["allow_job_network"]=False
    check("different_network_context_refused",changed,linux,
          "observer_original_resource_context_changed_allow_job_network")
    changed=copy.deepcopy(linux);changed["allow_job_network"]=1
    check("integer_does_not_substitute_boolean_network_context",changed,linux,
          "observer_original_resource_context_changed_allow_job_network")
    changed=copy.deepcopy(mac);changed["memory_max_bytes"]=0
    check("zero_does_not_substitute_actual_mac_null",changed,mac,
          "observer_original_resource_context_changed_memory_max_bytes")
    result={"schema":"heptabao.observer-resource-control-qa.v1",
        "status":"passed" if all(row["passed"] for row in rows) else "failed",
        "required":len(rows),"passed":sum(row["passed"] for row in rows),"checks":rows,
        "module_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
        "qa_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "reference_worker_request":{"path":str(reference),"sha256":hashlib.sha256(original_raw).hexdigest()},
        "reference_scope":"Only four actual retained Mac worker resource/context fields; this is not an observer executor positive.",
        "actual_observer_executor_bindings_tested":0,"linux_inputs_modeled":True,
        "product_or_compiler_processes_started":0,"network_calls":0,
        "execution_policy":{name:module.fixed_execution_policy(name) for name in module.STAGES}}
    raw=(json.dumps(result,sort_keys=True,indent=2)+"\n").encode();target=output/"result.public.json"
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:assert os.write(fd,raw)==len(raw);os.fsync(fd)
    finally:os.close(fd)
    print(json.dumps({"status":result["status"],"required":len(rows),"passed":result["passed"],
        "result":str(target),"sha256":hashlib.sha256(raw).hexdigest()}))
    return 0 if result["status"]=="passed" else 1


if __name__=="__main__":raise SystemExit(main())
