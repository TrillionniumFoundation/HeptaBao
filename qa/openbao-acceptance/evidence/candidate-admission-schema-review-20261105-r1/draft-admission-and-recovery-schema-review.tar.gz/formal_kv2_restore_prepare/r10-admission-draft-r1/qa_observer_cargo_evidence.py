#!/usr/bin/env python3
"""Modeled Cargo byte/parser controls; no compiler or product is executed."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
path = HERE / "observer_cargo_evidence.py"
spec = importlib.util.spec_from_file_location("observer_cargo_under_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
SOURCE = "/modeled-only/candidate/source"
STDOUT = "/modeled-only/candidate/normal-release-r1/normal-release-build.stdout"


def event(test=False):
    return {"reason": "compiler-artifact", "package_id": "modeled-runtime-package",
        "manifest_path": SOURCE + "/crates/heptabao-raft-runtime/Cargo.toml",
        "target": {"name": "heptabao_raft_runtime", "kind": ["lib"], "crate_types": ["lib"],
                   "src_path": SOURCE + "/crates/heptabao-raft-runtime/src/lib.rs"},
        "features": list(module.FEATURES), "fresh": False,
        "profile": {"opt_level": "3", "debuginfo": 0, "debug_assertions": True,
                    "overflow_checks": True, "test": test},
        "executable": "/modeled-only/cache/runtime-libtest" if test else None}


def encoded(rows):
    return b"".join((json.dumps(row, sort_keys=True) + "\n").encode() for row in rows)


def stream(e=None):
    return encoded([event() if e is None else e, {"reason": "build-finished", "success": True}])


def normal(raw):
    return module.normal_runtime_dependency(raw, source_root=SOURCE, stdout_origin=STDOUT,
                                             stdout_sha256=hashlib.sha256(raw).hexdigest())


def main():
    output = Path(sys.argv[1]); output.mkdir(mode=0o700)
    rows = []
    def check(name, action, refusal=None):
        observed = None
        try:
            action()
        except module.Refusal as error:
            observed = str(error)
        rows.append({"case": name, "passed": observed == refusal,
                     "expected_refusal": refusal, "actual_refusal": observed})
    raw = stream(); dep = normal(raw)
    def good():
        assert dep["event_index"] == 1
        assert dep["event_line_sha256"] == hashlib.sha256(raw.splitlines(keepends=True)[0]).hexdigest()
        assert module.verify_normal_dependency(dep, raw, source_root=SOURCE,
            stdout_origin=STDOUT, stdout_sha256=hashlib.sha256(raw).hexdigest()) == dep
    check("normal_event_original_line_and_byte_digest", good)
    def changed_index():
        changed = copy.deepcopy(dep); changed["event_index"] = 2
        module.verify_normal_dependency(changed, raw, source_root=SOURCE,
            stdout_origin=STDOUT, stdout_sha256=hashlib.sha256(raw).hexdigest())
    check("wrong_original_event_index_refused", changed_index,
          "observer_normal_dependency_matches_original_event")
    check("libtest_event_cannot_prove_normal_closure", lambda: normal(stream(event(True))),
          "observer_cargo_unique_runtime_event")
    def wrong_source():
        e=event();e["target"]["src_path"]="/modeled-only/old-candidate/src/lib.rs"
        normal(stream(e))
    check("old_candidate_source_path_refused", wrong_source,
          "observer_cargo_exact_runtime_source_paths")
    def fixture_feature():
        e=event();e["features"].append("experimental-fixture")
        normal(stream(e))
    check("wrong_actual_feature_closure_refused", fixture_feature,
          "observer_cargo_actual_runtime_features")
    def changed_profile():
        e=event();e["profile"]["debug_assertions"]=False
        normal(stream(e))
    check("different_release_profile_refused", changed_profile,
          "observer_cargo_exact_normal_profile")
    check("data_after_build_terminal_refused", lambda: normal(raw+encoded([{"reason":"compiler-message"}])),
          "observer_cargo_unique_success_last_event")
    check("duplicate_build_terminal_refused", lambda: normal(raw+encoded([{"reason":"build-finished","success":True}])),
          "observer_cargo_unique_success_last_event")
    check("duplicate_json_key_refused", lambda: normal(raw.replace(b'"reason": "compiler-artifact"',
        b'"reason":"compiler-artifact","reason":"compiler-artifact"',1)),
          "observer_cargo_duplicate_json_key")
    check("nonfinite_json_refused", lambda: normal(raw.replace(b'"debuginfo": 0',b'"debuginfo": NaN',1)),
          "observer_cargo_nonfinite_json")
    check("partial_final_physical_line_refused", lambda: normal(raw[:-1]),
          "observer_cargo_partial_or_blank_line")
    rt_event=event(True);rt_raw=stream(rt_event)
    artifact={"compiler_executable":rt_event["executable"],"features":rt_event["features"],
        "profile":rt_event["profile"],"fresh":False,"sha256":"a"*64}
    def runtime(a=artifact, normal_dep=dep):
        return module.verify_runtime_libtest_event(rt_raw,source_root=SOURCE,
            stdout_origin="/modeled-only/runtime-build/runtime-observer-libtest-build.stdout",
            stdout_sha256=hashlib.sha256(rt_raw).hexdigest(),normal_dependency=normal_dep,artifact=a)
    check("runtime_libtest_matches_same_normal_package",runtime)
    def wrong_executable():
        a=copy.deepcopy(artifact);a["compiler_executable"]="/modeled-only/another-cache/runtime-libtest"
        runtime(a)
    check("different_retained_compiler_executable_refused",wrong_executable,
          "observer_runtime_retained_artifact_event")
    def wrong_package():
        d=copy.deepcopy(dep);d["package_id"]="modeled-old-candidate-package"
        runtime(normal_dep=d)
    check("different_normal_package_refused",wrong_package,
          "observer_runtime_same_normal_dependency")
    check("wrong_original_stdout_hash_refused", lambda: module.normal_runtime_dependency(raw,
        source_root=SOURCE,stdout_origin=STDOUT,stdout_sha256="0"*64),
          "observer_normal_cargo_original_hash")
    result={"schema":"heptabao.observer-cargo-control-qa.v1",
        "status":"passed" if all(row["passed"] for row in rows) else "failed",
        "module_sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
        "qa_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "required":len(rows),"passed":sum(row["passed"] for row in rows),"checks":rows,
        "scope":"Modeled Cargo byte/parser predicates only; no actual compiler artifacts or executor evidence.",
        "actual_normal_cargo_closure_validated":False,"observer_qualification":False,
        "compilers_started":0,"products_started":0,"network_calls":0}
    data=(json.dumps(result,sort_keys=True,indent=2)+"\n").encode();target=output/"result.public.json"
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        assert os.write(fd,data)==len(data);os.fsync(fd)
    finally:os.close(fd)
    print(json.dumps({"status":result["status"],"required":len(rows),"passed":result["passed"],
        "result":str(target),"sha256":hashlib.sha256(data).hexdigest()}))
    return 0 if result["status"]=="passed" else 1


if __name__=="__main__":
    raise SystemExit(main())
