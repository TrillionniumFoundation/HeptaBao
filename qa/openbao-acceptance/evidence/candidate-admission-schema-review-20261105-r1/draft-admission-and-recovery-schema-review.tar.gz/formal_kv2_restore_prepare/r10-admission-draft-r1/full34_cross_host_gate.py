#!/usr/bin/env python3
"""New candidate admission: unchanged original181 gate plus two observer16 cohorts.

Draft entry points remain closed until the observer gate and producer contracts
are frozen and independently reviewed. No products or subprocesses are started.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

DRAFT_ONLY = True
SCHEMA = "heptabao.full34-cross-host-regression-admission.v3"
INPUT_SCHEMA = "heptabao.full34-cross-host-admission-inputs.v3"
LEGACY_GATE_SHA256 = "8a25a3bb32d7a78a2884b34b036d227dfb7e984a2b5078f86cea384bb57dae95"
OBSERVER_GATE_SHA256 = "d73e88180ba17fff701c0a687a3c4c54d4a377a2cd951115ad0eac706a8d61b2"
OBSERVER_ARGUMENTS = ("observer-inputs", "observer-inputs-sha256")


class AdmissionError(RuntimeError):
    pass


def require(value, code):
    if not value:
        raise AdmissionError(code)


def canonical(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode()


def pinned_module(filename, name, pin):
    path = Path(__file__).resolve().with_name(filename)
    require(path.resolve(strict=True) == path
            and hashlib.sha256(path.read_bytes()).hexdigest() == pin,
            "new_outer_fixed_dependency_changed")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def legacy_module():
    return pinned_module("full34_cross_host_gate_r4.py", "unchanged_full34_r4_gate", LEGACY_GATE_SHA256)


def observer_module():
    return pinned_module("readindex_observer_gate.py", "frozen_readindex_observer_gate", OBSERVER_GATE_SHA256)


def join_original_jobs(original, observer, linux_host):
    require(original["schema"] == "heptabao.runtime-prerequisite-admission.v2"
            and original["status"] == "admitted" and original["required"] == original["passed"] == 9,
            "new_outer_original_nine_runtime")
    require(observer["schema"] == "heptabao.readindex-observer-runtime-admission.v1"
            and observer["status"] == "admitted" and observer["required"] == observer["passed"] == 4,
            "new_outer_observer_four_runtime")
    require(original["linux_host"] == observer["linux_host"] == linux_host,
            "new_outer_one_actual_linux_builder")
    rows = original["rows"] + observer["rows"]
    expected = {
        "mac_build", "mac_server", "mac_ha", "mac_aggregate", "linux_release",
        "linux_libtest", "linux_server", "linux_ha", "linux_aggregate",
        "mac_observer_build", "mac_observer16", "linux_observer_build", "linux_observer16",
    }
    require(len(rows) == 13 and {row["stage"] for row in rows} == expected,
            "new_outer_exact_thirteen_actual_stages")
    require(len({(row["host"], row["job_id"]) for row in rows}) == 13,
            "new_outer_reused_actual_job")
    require(all(row["host"] == (linux_host if row["stage"].startswith("linux_") else "mac") for row in rows),
            "new_outer_actual_stage_host")
    return {
        "schema": "heptabao.full34-thirteen-runtime-admission.v1", "status": "admitted",
        "required": 13, "passed": 13, "linux_host": linux_host,
        "original_nine": original, "observer_four": observer,
        "rows": sorted(rows, key=lambda row: row["stage"]),
        "all_host_job_pairs_unique": True,
        "suite_outputs_are_derivatives_not_separate_executors": True,
    }


def admit(args):
    require(DRAFT_ONLY is False, "new_outer_draft_admission_closed")
    legacy = legacy_module()
    original_inputs = {key: (legacy.INPUT_SCHEMA if key == "schema" else getattr(args, key))
                       for key in legacy.INPUT_FIELDS}
    try:
        original = legacy.validate_inputs(original_inputs)
    except legacy.AdmissionError as error:
        raise AdmissionError("original181_" + str(error)) from None
    module = observer_module()
    observer_binding = {"path": args.observer_inputs, "sha256": args.observer_inputs_sha256}
    try:
        observer = module.validate_observer_inputs(observer_binding,
            base_inputs=original_inputs, base_admission=original)
    except module.Refusal as error:
        raise AdmissionError("observer16_" + str(error)) from None
    require(observer["schema"] == "heptabao.readindex-observer-admission.v1"
            and observer["status"] == "admitted"
            and observer["source_commit"] == original["source_commit"] == args.commit
            and observer["source_tree"] == original["source_tree"] == args.tree
            and observer["actual_linux_host"] == original["actual_linux_host"] == args.linux_host
            and observer["required_each_host"] == 16
            and observer["mac"]["passed"] == observer["linux"]["passed"] == 16,
            "new_outer_same_actual_candidate_observer_cohorts")
    joined = join_original_jobs(original["runtime_prerequisites"], observer["runtime_admission"], args.linux_host)
    return {
        **original,
        "schema": SCHEMA,
        "original_181_gate_module_sha256": LEGACY_GATE_SHA256,
        "original_181_admission_sha256": hashlib.sha256(canonical(original)).hexdigest(),
        "original_181_admission": original,
        "observer_gate_module_sha256": OBSERVER_GATE_SHA256,
        "observer_inputs": observer_binding,
        "observer_admission": observer,
        "observer_admission_sha256": hashlib.sha256(canonical(observer)).hexdigest(),
        "required_observer_tests_each_host": 16,
        "original_runtime_prerequisites": original["runtime_prerequisites"],
        "runtime_prerequisites": joined,
        "required_actual_executor_stages": 13,
        "full34_executed_by_gate": False,
        "products_started_by_gate": False,
    }


def validate_inputs(inputs):
    require(DRAFT_ONLY is False, "new_outer_draft_admission_closed")
    legacy = legacy_module()
    fields = set(legacy.INPUT_FIELDS) | {"observer_inputs", "observer_inputs_sha256"}
    require(isinstance(inputs, dict) and set(inputs) == fields
            and inputs["schema"] == INPUT_SCHEMA
            and all(isinstance(value, str) for value in inputs.values()),
            "new_outer_exact_inputs_schema")
    return admit(SimpleNamespace(**{key: value for key, value in inputs.items() if key != "schema"}))
