# Candidate admission transition, R10 schema revision — no product execution

## Current status

This is a new control revision proposal. The accepted R5 recovery revision r3,
its 30 control checks, and its pending read-only executor requests remain
unchanged. No formal recovery product stage has been run. R5 has a retained
31/31 formal-file result and a failed matched comparison. The parent has
confirmed a separate fresh read-only TLS diagnostic found missing
`close_notify` after a complete HTTP 204 response. R5 cannot become the final
recovery candidate by copying its old qualification into a new source version.

The prior r8 and r9 draft directories and their review records are preserved.
R8's real normal Mac compilation failed. R9's normal release succeeded but its
server libtest compilation failed, so it has no complete normal-build,
original181 or observer16 qualification. Neither failed attempt is replaced
by this revision. The current announced source target is R10 commit
`b33b8d0de9c7689ff89f8ed11cd2151726972f4f`, tree
`89a8af5b7bcb1d7472e1f12e1dec7adb7d2cf726`. These names document preparation;
they do not assert that any R10 build, test or formal recovery passed.

The copied Linux producer/helper pins still identify the independently read
R9 implementations and must be explicitly rebound to the actual new R10
controller/helper bytes before activation. All entry gates remain draft-closed.
The shared standalone joint and Mac runtime builder have no candidate-root
literal, but their real R10 invocations and outputs are still mandatory.

This revision fixes one identified control false-fail: the original Mac
combined normal builder never records a `cargo_lock_sha256` or `source_before`
field. The gate now reads canonical current frozen `source/Cargo.lock`
explicitly against the runtime build's real hash, returns that independent
source-file evidence, and does not invent either field in the old receipt.
Linux retains its actual recorded before/after lock binding. The first local
lock-control harness run stopped on an unhandled reloaded exception class;
that failure is preserved separately from the corrected 8/8 control result.

The parent authorized preparation of a new candidate outer full31 admission gate,
the minimal full31 wrapper derivation, and a recovery admission derivation.
Actual product execution remains closed pending the new source freeze,
normal builds, both original 181 cohorts, both new observer16 cohorts, their
original runtime evidence, and independent parent review of the controls.

## Real executor inventory

The original r4 gate is imported and executed at its existing fixed SHA. Its
181 = server172 + HA9 denominator and original176/original60 requirements are
unchanged. Its nine original runtime rows are retained by value.

| Layer | Actual executor stages | Cumulative actual jobs |
| --- | --- | ---: |
| Original regressions | `mac_build`, `mac_server`, `mac_ha`, `mac_aggregate`, `linux_release`, `linux_libtest`, `linux_server`, `linux_ha`, `linux_aggregate` | 9 |
| Separate observer cohorts | `mac_observer_build`, `mac_observer16`, `linux_observer_build`, `linux_observer16` | 13 |
| Original full31, new candidate run | `full34` | 14 |
| Formal recovery | `backup`, `mac_oracle`, `linux_target`, `source_verify` | 18 |

Each observer build has its original 900 second cap. Each joint observer job
has one 600 second pool and each exact test has at most 120 seconds. The
server5 and runtime11 suite outputs are derived files of one actual joint
executor; they do not receive fabricated independent executor rows. Every
`(configured_host, job_id)` must be distinct across the complete accumulated
graph. All Linux qualification jobs must use the same actual builder host,
Pocket4 or ROG. The later recovery target may be X230 and is separately bound
to its actual host, normal executable, and ELF/loader compatibility probes.

## Admission layers

1. `full34_cross_host_gate_r4.py` is an unchanged copy of the accepted r4 gate
   (`8a25a3bb32d7a78a2884b34b036d227dfb7e984a2b5078f86cea384bb57dae95`).
   It validates newly produced candidate receipts with their actual source hashes,
   build provenance, manifests, baseline exact names, results and nine original
   executor captures. No R5 admission boolean is an input.
2. A new fixed `readindex_observer_gate.py` will validate both separate
   observer16 cohorts and their four actual executors. Exact input/result
   fields will follow the builders and joint runner that are being prepared;
   the current design document is not a substitute for their real schema.
3. A new `full34_cross_host_gate.py` will call both validators, preserve the
   original `mac` and `linux` result mappings, join all thirteen original
   executor rows, reject reused jobs and mixed builder hosts, and return a new
   admission schema. It will expose the existing `admit(args)` and
   `validate_inputs(dict)` entry points for the wrapper and read-only callers.
4. The new full31 wrapper will require the observer input binding before
   starting any product. Its only intended functional changes are the new
   gate pin and new mandatory observer arguments. Original product argv,
   CHECKS hash, budgets, original Popen custody, and cleanup remain unchanged.
5. The new recovery candidate-plan and candidate-admission schemas will bind
   that new outer gate, its exact inputs, the actual new full31 wrapper/result,
   and the fourteen-job graph. The final recovery gate will then add the four
   real recovery stages. A plan with an old schema cannot silently omit the
   observer requirement.

The runtime implementation
`b9f2d80cbdc797b02b835cf913aeff3b13e9c2a2076cf548a3fd6655fed36e79`
is reused without changing its `STAGES`. Its original worker file, API start,
terminal and complete-output functions can validate the new explicit cohort
policy. The new policy will parse each actual builder/joint stdout contract,
not relabel an observer job as an old regression stage to obtain admission.

The four new observer jobs must retain the original API submission/start pair
as well as worker request/started, terminal and every complete output page.
The historical old-runtime fallback for an unavailable API start is not used
for these new jobs. Each runtime build's outer timeout is 1200 seconds; each
joint's outer timeout is 900 seconds. Both are nice 10. The original internal
900-second compilation cap and the two 60-second inventories plus one
600-second exact-test pool remain separate and unchanged.

Mac requests use `/opt/homebrew/bin/python3`, null memory/CPU overrides, and
`-I -S -B`. Pocket uses `/usr/bin/python3`, exactly 12 GiB MemoryMax and a null
CPU override. Its standalone joint also uses `-I -S -B`; its runtime builder
uses exactly `-B` so that the already frozen local command helper can be
imported. Both platforms must actually record operator mode, network allowed,
empty submitted environment and the exact candidate-root working directory.
These fields are compared with the original worker, not inferred from a
producer's success boolean.

The observed Linux API uses a bare `hepta-runtime-job-<complete-job-id>` unit
name. New original worker, API `job.unit`, and API `launch.unit` must all
match that exact bare name. The kernel cgroup must end in precisely that name
plus one `.service` suffix. No prefix matching or arbitrary suffix stripping
is allowed. The normal job that established this schema used 8 GiB; it is not
evidence that an observer job ran with 12 GiB. Every new observer job must
provide its own original worker and current resource observation.

## Required observer evidence

Both platforms must bind the same source commit/tree, original181 manifest
bytes, normal server and server-libtest artifacts, observer manifests, and
normal release profile. Server5 uses that platform's retained normal
server-libtest. Runtime11 uses the newly built runtime libtest.

The runtime feature closure must be derived from that candidate on that
physical platform: the normal release's pinned original Cargo JSON stream,
the exact `heptabao_raft_runtime` normal library compiler event and its line or
index, then the new runtime libtest compiler event. Actual features must be
`default` and `native-v6-raft-objects`, with the expected normal release
profile. A string copied from an old Pocket receipt, Cargo.toml default, or a
`features_verified: true` flag is insufficient.

The planned joint result schema is
`heptabao.readindex-observer-joint-result.v1`; the derived suite schema is
`heptabao.readindex-observer-suite-result.v1`. The producer owns the precise
fields. The gate will re-read their exact bytes and original process/log
closure, prove exactly server5 plus runtime11, and bind each suite to the
same joint output root, controller, source, manifests, normal build, runtime
build and shared deadline. A failed, omitted, duplicated or zero-test row
cannot count as passed. Neither suite artifact is a substitute for the joint
job's original successful, complete and durable executor terminal.

## Recovery semantics retained

The 25 checks, 4 stages and exact A/B oracles remain separate from the original
31. A still proves the complete sealed cold set restored to new independent
Mac and Linux roots, using the new Mac clone as the timestamp oracle and
checking the known final delta. B still restores the original snapshot once
inside the same seal identity and verifies the independent original OpenBao
baseline after a cold restart. Snapshot-only recovery into an independently
initialized empty cluster remains an unsupported capability, not a claimed
result of this procedure.

All four core files and all NV6 ciphertext leaves are copied. Unknown assets
remain a refusal. Complete original source, keys, snapshot and backup inputs
are immutable. Actual independent inodes, permissions, all owned process
closure, real Linux ELF/loader probes and actual volume identity remain
required. Request15, backup360, stage1800 and stop5 budgets do not change.
The strict formal wire (`f9ca592b4f1df03f5344923d926c4064429f2f9390cad4a3b8f9d87ffc06fb76`)
retains its actual TLS EOF/close_notify requirements.

The product environment is already an explicit whitelist (`PATH`, `LC_ALL`,
`TZ`) in the accepted driver. An inherited ReadIndex observation environment
cannot silently change these standalone recovery launches. Any future desire
to observe a recovery launch would need an explicit new reviewed scope.

## Expected unchanged files and functions

The core, formal wire, custody and original full31 pure semantics can remain
byte-identical if the final candidate source has not changed their referenced
production storage or Python support contracts. They will be independently
checked against the final source; no assumption based only on the words
"TLS-only" grants compatibility.

The recovery driver will need a new admission pin and explicit new candidate
schema acceptance. Its product/backup/ABI/oracle functions and CHECKS/LIMITS
must remain AST-identical. The transfer helper and volume helper require the
new driver pin only. The operator's control pins and output schema descriptions
must follow the new files. Existing R5 files and result directories are never
overwritten or relabeled.

## Targeted control acceptance before products

Use actual new candidate evidence for the positive thirteen-stage admission. Retain
the original r4 QA and original recovery control evidence as historical
evidence. Add focused negative controls for an absent observer cohort, a
reused original job, a mixed Linux builder host, a substituted suite-as-job,
wrong candidate/runtime artifact or Cargo event, incomplete terminal output,
an old full31 result, and cross-candidate backup/result bindings. These tests
must fail at the intended validation boundary; no all-purpose fabricated
successful chain is acceptable evidence of real product qualification.

Control-only static preservation checks are useful before the source is
frozen. They cannot prove that a new source compiled, that any observer test
ran, or that a recovery stage succeeded.
