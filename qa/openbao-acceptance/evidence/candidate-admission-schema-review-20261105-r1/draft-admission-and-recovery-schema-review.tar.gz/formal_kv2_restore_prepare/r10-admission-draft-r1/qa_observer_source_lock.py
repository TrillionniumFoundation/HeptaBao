#!/usr/bin/env python3
"""Finite controls for the real Mac receipt's absent lock field.

The original Mac normal result used here is a retained failed build, solely to
check its real field layout. Source files and runtime lock claims are modeled.
This never validates that failed build, admits a candidate, or runs a product.
"""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
ORIGINAL_BUILDER = "47afd2c97d8ba1e25b2f74b7014f510f21e36bc85e217d8cb067a394a023018e"


def main():
    normal_path, builder_path, output = map(Path, sys.argv[1:4])
    output.mkdir(mode=0o700)
    mp = HERE / "observer_build_evidence.py"
    spec = importlib.util.spec_from_file_location("observer_source_lock_under_test", mp)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    base = m.base_module()
    normal_raw, builder_raw = normal_path.read_bytes(), builder_path.read_bytes()
    normal = json.loads(normal_raw)
    assert normal["controller_sha256"] == hashlib.sha256(builder_raw).hexdigest() == ORIGINAL_BUILDER
    assert normal["schema"] == "heptabao.unified-release-libtest-build.v1" and normal["status"] == "failed"
    assert b"cargo_lock" not in builder_raw and "cargo_lock_sha256" not in normal and "source_before" not in normal
    source = output / "modeled-source"; source.mkdir(mode=0o700)
    lock = source / "Cargo.lock"
    lock_bytes = b"# Modeled non-product source-lock bytes for this file-binding predicate.\nversion = 4\n"
    lock.write_bytes(lock_bytes); lock.chmod(0o600)
    pin = hashlib.sha256(lock_bytes).hexdigest()
    runtime = {"source_commit": normal["source_commit"], "source_tree": normal["source_tree"], "cargo_lock_sha256": pin}
    rows = []
    def check(name, action, refusal=None):
        error, returned, error_type, accepted_type = None, None, None, True
        try: returned = action()
        except Exception as exc:
            error = str(exc)
            error_type = type(exc).__module__ + "." + type(exc).__name__
            accepted_type = (isinstance(exc, m.Refusal) or error_type == "observer_build_original_reader.AdmissionError")
        rows.append({"case": name, "passed": error == refusal and accepted_type,
                     "expected_refusal": refusal, "actual_refusal": error, "actual_exception_type": error_type})
        return returned
    check("old_field_lookup_rejects_real_absent_mac_lock", lambda: base.digest(
        normal.get("cargo_lock_sha256", normal.get("source_before", {}).get("cargo_lock_sha256"))), "invalid_sha256")
    actual = check("new_mac_explicit_current_source_read_accepts_original_no_lock_layout", lambda: m.verify_cargo_lock_evidence(
        runtime, normal, platform="mac", source_root=str(source)))
    assert actual["origin"] == "current_canonical_frozen_mac_source"
    assert actual["local_file"]["sha256"] == pin and actual["local_file"]["bytes"] == len(lock_bytes)
    assert normal.get("cargo_lock_sha256") is None and "source_before" not in normal
    lock.write_bytes(lock_bytes + b"# changed\n")
    check("changed_current_source_lock_refused", lambda: m.verify_cargo_lock_evidence(
        runtime, normal, platform="mac", source_root=str(source)), "evidence_digest_mismatch")
    lock.write_bytes(lock_bytes)
    target = source / "other.lock"; target.write_bytes(lock_bytes); target.chmod(0o600)
    lock.unlink(); lock.symlink_to(target.name)
    check("linked_source_lock_refused", lambda: m.verify_cargo_lock_evidence(
        runtime, normal, platform="mac", source_root=str(source)), "noncanonical_local_evidence_path")
    lock.unlink(); lock.write_bytes(lock_bytes); lock.chmod(0o600)
    for key, value in (("cargo_lock_sha256", pin), ("source_before", {"cargo_lock_sha256": pin})):
        altered = copy.deepcopy(normal); altered[key] = value
        check("invented_mac_" + key + "_refused", lambda altered=altered: m.verify_cargo_lock_evidence(
            runtime, altered, platform="mac", source_root=str(source)),
            "observer_mac_original_normal_lock_fields_must_not_be_invented")
    linux = {"source_before": {"cargo_lock_sha256": pin}, "source_after": {"cargo_lock_sha256": pin}}
    check("modeled_linux_retains_real_receipt_field_contract", lambda: m.verify_cargo_lock_evidence(
        runtime, linux, platform="linux", source_root="/modeled/linux/source"))
    changed = copy.deepcopy(linux); changed["source_after"]["cargo_lock_sha256"] = "a" * 64
    check("linux_original_before_after_mismatch_refused", lambda: m.verify_cargo_lock_evidence(
        runtime, changed, platform="linux", source_root="/modeled/linux/source"),
        "observer_runtime_same_normal_cargo_lock")
    result = {"schema": "heptabao.observer-source-lock-controls.v1",
        "status": "passed" if all(row["passed"] for row in rows) else "failed",
        "required": len(rows), "passed": sum(row["passed"] for row in rows), "checks": rows,
        "module_sha256": hashlib.sha256(mp.read_bytes()).hexdigest(),
        "qa_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "actual_original_normal_receipt": {"path": str(normal_path), "sha256": hashlib.sha256(normal_raw).hexdigest(),
            "status": normal["status"], "scope": "Real original field layout only; failed build is not admitted."},
        "actual_original_normal_controller": {"path": str(builder_path), "sha256": ORIGINAL_BUILDER},
        "source_bytes_and_runtime_lock_inputs_modeled": True,
        "actual_observer_executor_admissions": 0, "actual_candidate_admissions": 0,
        "compiler_or_product_processes_started": 0}
    for name, content in (("observer_build_evidence.tested.py", mp.read_bytes()), ("qa.tested.py", Path(__file__).read_bytes())):
        with (output / name).open("xb") as stream:
            stream.write(content); stream.flush(); os.fsync(stream.fileno())
    raw = (json.dumps(result, sort_keys=True, indent=2) + "\n").encode(); p = output / "result.public.json"
    with p.open("xb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    p.chmod(0o600)
    fd = os.open(output, os.O_RDONLY)
    try: os.fsync(fd)
    finally: os.close(fd)
    print(json.dumps({"status": result["status"], "required": len(rows), "passed": result["passed"],
                      "result": str(p), "sha256": hashlib.sha256(raw).hexdigest()}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
