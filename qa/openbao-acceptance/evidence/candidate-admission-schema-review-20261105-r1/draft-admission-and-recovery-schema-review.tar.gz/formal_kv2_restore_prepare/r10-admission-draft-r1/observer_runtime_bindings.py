#!/usr/bin/env python3
"""Read-only original-executor links for two actual observer jobs per ABI.

This module validates execution metadata, not the observer tests' semantics.
The enclosing frozen observer gate must independently validate the build,
source, manifests, process evidence, derived suites and joint result.
"""
from __future__ import annotations

import hashlib
import importlib.util
from pathlib import Path, PurePosixPath
import re
import sys

RUNTIME_SHA256 = "b9f2d80cbdc797b02b835cf913aeff3b13e9c2a2076cf548a3fd6655fed36e79"
INDEX_SCHEMA = "heptabao.readindex-observer-executor-bindings.v1"
SCHEMA = "heptabao.readindex-observer-runtime-admission.v1"
STAGES = (
    "mac_observer_build", "mac_observer16",
    "linux_observer_build", "linux_observer16",
)
INVOCATION_FIELDS = frozenset((
    "executable", "args", "cwd", "env", "timeout_seconds", "nice",
    "memory_max_bytes", "cpu_quota_percent", "execution_mode", "allow_job_network",
    "controller_sha256",
))
RESOURCE_CONTEXT_FIELDS = (
    "memory_max_bytes", "cpu_quota_percent", "execution_mode", "allow_job_network",
)


class Refusal(RuntimeError):
    pass


def need(value, label):
    if not value:
        raise Refusal(label)


def runtime_module():
    path = Path(__file__).resolve().with_name("runtime_prerequisite_bindings.py")
    need(hashlib.sha256(path.read_bytes()).hexdigest() == RUNTIME_SHA256,
         "observer_fixed_runtime_module_changed")
    spec = importlib.util.spec_from_file_location("observer_original_runtime", path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def fixed_execution_policy(stage):
    """Parent-approved observer policy, not copied from a producer's result."""
    need(stage in STAGES, "observer_policy_stage")
    linux = stage.startswith("linux_")
    return {
        "executable": "/usr/bin/python3" if linux else "/opt/homebrew/bin/python3",
        "timeout_seconds": 1200 if stage.endswith("_build") else 900,
        "nice": 10,
        "memory_max_bytes": 12 * 1024 ** 3 if linux else None,
        "cpu_quota_percent": None,
        "execution_mode": "operator",
        "allow_job_network": True,
    }


def validate_resource_context(worker, expected):
    """Exact original worker fields; absent and null are different states."""
    need(isinstance(worker, dict) and isinstance(expected, dict)
         and all(key in worker and key in expected for key in RESOURCE_CONTEXT_FIELDS),
         "observer_original_resource_context_missing")
    for key in RESOURCE_CONTEXT_FIELDS:
        need(type(worker[key]) is type(expected[key]) and worker[key] == expected[key],
             "observer_original_resource_context_changed_" + key)
    return {key: worker[key] for key in RESOURCE_CONTEXT_FIELDS}


def validate_linux_unit_identity(worker, start):
    """Bind the observed bare API/worker name, then add exactly one suffix."""
    need(isinstance(worker, dict) and isinstance(start, dict)
         and isinstance(start.get("job"), dict) and isinstance(start.get("launch"), dict),
         "observer_original_linux_unit_documents")
    job, launch = start["job"], start["launch"]
    job_id = worker.get("job_id")
    need(isinstance(job_id, str) and re.fullmatch(r"[0-9a-f]+-[0-9a-f]+-[0-9a-f]+", job_id) is not None,
         "observer_original_linux_unit_job_id")
    bare = "hepta-runtime-job-" + job_id
    need(worker.get("unit") == job.get("unit") == launch.get("unit") == bare
         and job.get("id") == job_id and launch.get("backend") == "systemd",
         "observer_original_linux_unit_exact_bare_identity")
    return {"bare_unit": bare, "service_unit": bare + ".service", "job_id": job_id}


def validate_actual_execution_resource(value, *, worker, original_start):
    """Recompute the joint runner's bounded before-test kernel observation."""
    need(isinstance(value, dict), "observer_actual_resource_document")
    schema = "heptabao.observer-actual-execution-resource.v1"
    if worker.get("platform") == "macos":
        need(value == {"schema": schema, "system": "Darwin", "linux_cgroup_applicable": False,
            "scope": "Linux cgroup not applicable on Darwin; native worker policy checked independently"},
            "observer_actual_darwin_resource_scope")
        return value
    need(worker.get("platform") == "linux" and set(value) == {
        "schema", "system", "linux_cgroup_applicable", "process_id", "proc_cgroup_path",
        "proc_cgroup_text", "proc_cgroup_sha256", "unit_path", "memory_max_path",
        "memory_max_text", "memory_max_sha256", "memory_max_bytes", "scope"}
         and value["schema"] == schema and value["system"] == "Linux"
         and value["linux_cgroup_applicable"] is True, "observer_actual_linux_resource_fields")
    identity = validate_linux_unit_identity(worker, original_start)
    need(type(value["process_id"]) is int and value["process_id"] > 0
         and value["proc_cgroup_path"] == "/proc/self/cgroup", "observer_actual_runner_resource_origin")
    text = value["proc_cgroup_text"]
    need(isinstance(text, str) and text.startswith("0::/") and text.endswith("\n")
         and text.count("\n") == 1 and "\0" not in text and "\r" not in text
         and len(text.encode()) <= 4096, "observer_actual_unified_cgroup_text")
    relative = text[4:-1]
    parts = relative.split("/")
    need(relative and all(part not in ("", ".", "..") for part in parts)
         and parts[-1] == identity["service_unit"], "observer_actual_cgroup_matches_original_unit")
    path = PurePosixPath("/sys/fs/cgroup") / relative
    need(str(path) == value["unit_path"] and str(path / "memory.max") == value["memory_max_path"]
         and value["proc_cgroup_sha256"] == hashlib.sha256(text.encode()).hexdigest(),
         "observer_actual_cgroup_path_and_original_bytes")
    maximum = 12 * 1024 ** 3
    memory = str(maximum) + "\n"
    need(type(value["memory_max_bytes"]) is int and value["memory_max_bytes"] == maximum
         and value["memory_max_text"] == memory
         and value["memory_max_sha256"] == hashlib.sha256(memory.encode("ascii")).hexdigest()
         and value["scope"] == "read-only actual executor cgroup and hard MemoryMax before any inventory or exact test",
         "observer_actual_cgroup_exact_memory_limit")
    # process_id is the runner. It is deliberately not equated to the worker's
    # supervisor identity; the original unit is the supported cross-record link.
    return {**value, "original_unit_binding": identity}


def validate_inventory(index, *, row_fields, linux_host, prerequisite_jobs):
    """Pure inventory check; its return is not an execution admission."""
    need(isinstance(index, dict) and set(index) == {"schema", "jobs"}
         and index["schema"] == INDEX_SCHEMA, "observer_runtime_index_schema")
    need(linux_host in ("rog", "pocket4"), "observer_actual_linux_builder")
    rows = index["jobs"]
    need(isinstance(rows, list) and len(rows) == len(STAGES)
         and all(isinstance(row, dict) and set(row) == set(row_fields) for row in rows)
         and {row["stage"] for row in rows} == set(STAGES),
         "observer_exact_four_actual_jobs")
    previous = list(prerequisite_jobs)
    need(all(isinstance(pair, (list, tuple)) and len(pair) == 2
             and all(isinstance(x, str) for x in pair) for pair in previous)
         and len({tuple(pair) for pair in previous}) == len(previous),
         "observer_prerequisite_job_inventory")
    pairs = {(row["host"], row["job_id"]) for row in rows}
    need(len(pairs) == len(STAGES) and not pairs.intersection(map(tuple, previous)),
         "observer_reused_actual_or_prerequisite_job")
    for row in rows:
        need(row["host"] == (linux_host if row["stage"].startswith("linux_") else "mac"),
             "observer_actual_configured_host")
        need(isinstance(row["job_id"], str)
             and re.fullmatch(r"[0-9a-f]+-[0-9a-f]+-[0-9a-f]+", row["job_id"]) is not None,
             "observer_actual_job_id_shape")
    return rows


def validate_joint_final_stdout(final, result):
    """Pure final-line predicate; actual exit 0 is separately mandatory."""
    need(isinstance(final, dict) and set(final) == {
        "status", "result", "result_sha256", "expected_unique_tests", "passed",
        "pool_deadline_satisfied_after_final_fsync", "final_fsync_completed_monotonic_ns",
        "original_pool_deadline_monotonic_ns"}
         and final["status"] == "passed" and type(final["expected_unique_tests"]) is int
         and type(final["passed"]) is int
         and final["expected_unique_tests"] == final["passed"] == 16,
         "observer_joint_stdout_contract")
    need(result.get("schema") == "heptabao.readindex-observer-joint-result.v1",
         "observer_joint_result_schema")
    pool = result["original_test_pool"]
    need(final["pool_deadline_satisfied_after_final_fsync"] is True
         and type(final["final_fsync_completed_monotonic_ns"]) is int
         and type(final["original_pool_deadline_monotonic_ns"]) is int
         and final["original_pool_deadline_monotonic_ns"] == pool["deadline_monotonic_ns"]
         and type(result["completed_monotonic_ns_before_result_fsync"]) is int
         and result["completed_monotonic_ns_before_result_fsync"]
             <= final["final_fsync_completed_monotonic_ns"] < pool["deadline_monotonic_ns"],
         "observer_joint_actual_post_fsync_deadline")


def validate_observer_executors(binding, *, expected_results, expected_invocations,
                                linux_host, prerequisite_jobs):
    """Bind four original jobs to frozen caller-derived invocations and results.

    expected_results[stage]: {path, sha256, runtime_path}.
    expected_invocations[stage]: exact INVOCATION_FIELDS. The enclosing gate
    derives these from its fixed builders/runner and candidate evidence; they
    are not accepted from an unverified caller-authored success summary.
    """
    runtime = runtime_module()
    need(isinstance(expected_results, dict) and isinstance(expected_invocations, dict)
         and set(expected_results) == set(expected_invocations) == set(STAGES),
         "observer_expected_four_stage_bindings")
    rows = validate_inventory(runtime.pinned(binding), row_fields=runtime.ROW_FIELDS,
                              linux_host=linux_host, prerequisite_jobs=prerequisite_jobs)
    verified = []
    for row in rows:
        name = row["stage"]
        expected, invocation = expected_results[name], expected_invocations[name]
        need(isinstance(expected, dict) and set(expected) == {"path", "sha256", "runtime_path"}
             and row["result"] == {"path": expected["path"], "sha256": expected["sha256"]},
             "observer_stage_result_binding")
        runtime.origin(expected["runtime_path"])
        runtime.digest(expected["sha256"])
        if row["host"] == "mac":
            need(expected["path"] == expected["runtime_path"], "observer_mac_result_origin")
        need(isinstance(invocation, dict) and set(invocation) == set(INVOCATION_FIELDS),
             "observer_frozen_invocation_fields")
        runtime.digest(invocation["controller_sha256"])
        policy = fixed_execution_policy(name)
        need(all(type(invocation[key]) is type(value) and invocation[key] == value
                 for key, value in policy.items()), "observer_invocation_must_use_fixed_execution_policy")
        result = runtime.pinned(row["result"])
        worker, started = runtime.worker_files(row)
        resource_context = validate_resource_context(worker, policy)
        api = runtime.api_originals(row, worker)
        need(api["available"] is True, "observer_original_api_start_required")
        original_start = runtime.pinned(row["api_start"])
        unit = validate_linux_unit_identity(worker, original_start) if row["host"] != "mac" else None
        terminal = runtime.terminal_record(row, worker, started)
        output = runtime.complete_output(row, terminal)
        lines = [line for line in output["stdout"].splitlines() if line.strip()]
        need(len(lines) == 1 and output["stderr"] == b"", "observer_unique_complete_stdout")
        final = runtime.decode(lines[0])
        is_build = name.endswith("_build")
        if is_build:
            need(set(final) == {"status", "result", "result_sha256", "runtime_tests_started"}
                 and final["status"] == "built" and final["runtime_tests_started"] is False,
                 "observer_build_stdout_contract")
            need(result.get("schema") == "heptabao.r6-readindex-runtime-libtest-build.v1",
                 "observer_build_result_schema")
        else:
            validate_joint_final_stdout(final, result)
            actual_resource = validate_actual_execution_resource(result["actual_execution_resource"],
                worker=worker, original_start=original_start)
        need(final["result"] == expected["runtime_path"]
             and final["result_sha256"] == expected["sha256"]
             and final["status"] == result["status"], "observer_actual_stdout_result_binding")
        need(all(worker[field] == invocation[field] for field in INVOCATION_FIELDS
                 if field != "controller_sha256"), "observer_original_worker_invocation")
        need(result["controller_sha256"] == invocation["controller_sha256"],
             "observer_actual_controller_binding")
        verified.append({
            "stage": name, "host": row["host"], "job_id": row["job_id"],
            "launch_nonce": worker["launch_nonce"], "request_digest": worker["request_digest"],
            "result": expected, "original_invocation": invocation, "original_api": api,
            "fixed_execution_policy": policy, "actual_resource_context": resource_context,
            "original_linux_unit_binding": unit,
            "actual_joint_execution_resource": None if is_build else actual_resource,
            "worker_request": row["worker_request"], "worker_started": row["worker_started"],
            "worker_capture": row["worker_capture"], "terminal_capture": row["terminal_capture"],
            "read_captures": row["read_captures"],
            "started_at_unix_ms": started["at_unix_ms"], "terminal_at_unix_ms": terminal["at_unix_ms"],
            "stdout_sha256": hashlib.sha256(output["stdout"]).hexdigest(),
            "stderr_sha256": hashlib.sha256(output["stderr"]).hexdigest(),
            "complete_stdout_bytes": len(output["stdout"]), "complete_stderr_bytes": len(output["stderr"]),
        })
    return {
        "schema": SCHEMA, "status": "admitted", "index": binding,
        "module_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "runtime_module_sha256": RUNTIME_SHA256, "linux_host": linux_host,
        "required_stages": list(STAGES), "required": 4, "passed": 4,
        "rows": sorted(verified, key=lambda value: value["stage"]),
        "scope": "Original executor linkage only; observer semantics require the enclosing gate.",
        "observer_semantics_qualified_by_this_module": False,
        "products_started": False,
    }
