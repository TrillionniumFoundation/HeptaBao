#!/usr/bin/env python3
"""Independent observer16 source/build/test admission — draft, qualification closed.

Manifest and Cargo helpers can be reviewed independently. The actual joint
producer contract and its original result graph must be integrated before
this entry point is frozen or can return an admission.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import re
import sys

DRAFT_ONLY = True
SCHEMA = "heptabao.readindex-observer-admission.v1"
INPUT_SCHEMA = "heptabao.readindex-observer-admission-inputs.v1"
BASE_GATE_SHA256 = "8a25a3bb32d7a78a2884b34b036d227dfb7e984a2b5078f86cea384bb57dae95"
RUNTIME_BINDING_SHA256 = "b72626f7686a1c6bd8ca63c5e88ac7d3f5d58409f3b58f76bdac17f4d086b144"
CARGO_EVIDENCE_SHA256 = "426249ea6a695e48d02906b5b91bc5507ef9d3299d4d830dc5c2ea6cfcd41fc4"
BUILD_EVIDENCE_SHA256 = "5a327c0528c7217a924923b34898edf1484b4a8296f51a813e30b4fe7cd572d2"
JOINT_EVIDENCE_SHA256 = "7f43853b704db1083fbcd6d0baea0f7c6163eed070d04177c2cdb3a79a0eeee4"
BUILDER_PINS = {
    "mac": "e3ebd812f86316a6a12813944c45abfe13a8031c64db4c3421ad89727fcd8083",
    "linux": "8e3a502621f3e8ca7f8bed074976b81c0824b64fc5d746d1b37d9d8f3c90903d",
}
LINUX_COMMANDS_HELPER_SHA256 = "b3e7cf80ab227f96e2fb4c1d822b0b6e6ee078c483cc8c642bd99c8b246ccfde"
JOINT_RUNNER_SHA256 = "fc0af1e464641f40223d4d80ec9297ffbe63e1af50bf1a3d5fe85440c7d2afd9"
HOSTS = {
    "mac": {"system": "Darwin", "host": "MacBook-Pro.local"},
    "rog": {"system": "Linux", "host": "qian-qi-ROG-Flow-Z13-GZ302EA-GZ302EA"},
    "pocket4": {"system": "Linux", "host": "alex-G1628-04"},
}
PLATFORM_FIELDS = frozenset(("runtime_build", "normal_cargo_stdout", "runtime_cargo_stdout",
                             "joint_result", "builder", "runner", "commands_helper"))
SERVER_NAMES = tuple("http::read_index_observation::tests::" + name for name in (
    "read_observation_headers_are_bounded_prewrite_metadata",
    "payload_match_requires_actual_wire_data_and_attempt",
    "payload_match_refuses_duplicate_wrapped_or_missing_wire_fields",
    "status_observer_uses_only_accepted_status_prefix",
    "disabled_handle_has_no_header_or_terminal_effect",
))
RUNTIME_NAMES = tuple("read_index_observation::tests::" + name for name in (
    "launch_id_accepts_only_bounded_lower_hex",
    "explicit_collector_scope_does_not_leak_to_spawned_tasks",
    "incomplete_cancelled_and_overflowed_collections_never_look_complete",
    "observation_success_requires_real_complete_fields_and_original_deadline",
    "completed_selection_never_binds_at_or_after_its_original_deadline",
    "payload_identity_refuses_other_http_scope_and_incomplete_selection",
    "closed_or_inconsistent_selection_never_binds_payload",
    "out_of_order_thread_guards_do_not_revive_retired_scope",
    "private_log_file_refuses_existing_linked_and_nonprivate_targets",
    "private_log_sink_persists_launch_identity_without_stderr",
    "private_log_sink_enforces_record_and_byte_limits",
))
SOURCE_FILES = (
    "crates/heptabao-server/src/http_read_index_observation.rs",
    "crates/heptabao-raft-runtime/src/read_index_observation.rs",
    "crates/heptabao-raft-runtime/src/lib.rs",
    "crates/heptabao-server/src/http.rs",
    "crates/heptabao-server/src/main.rs",
)
MANIFEST_FIELDS = frozenset((
    "schema", "source_commit", "source_tree", "expected_unique_tests", "cohorts", "source_files",
    "original_181", "test_pool_seconds", "per_test_seconds", "list_seconds_per_artifact", "pool_policy",
    "runtime_libtest_build_seconds", "test_retries", "missing_ignored_zero_tests_fail",
    "original_181_tests_added_removed_or_rebudgeted", "qualification_scope", "product_tests_run",
    "full_replacement_qualified",
))


class Refusal(RuntimeError):
    pass


def need(value, code):
    if not value:
        raise Refusal(code)


def module(filename, name, pin):
    path = Path(__file__).resolve().with_name(filename)
    need(path.resolve(strict=True) == path and hashlib.sha256(path.read_bytes()).hexdigest() == pin,
         "observer_fixed_module_changed")
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = value
    spec.loader.exec_module(value)
    return value


def base_module():
    return module("full34_cross_host_gate_r4.py", "observer_original181_gate", BASE_GATE_SHA256)


def validate_manifest(binding, *, base_inputs, base_admission):
    """Validate the actual shared manifest and source bytes, not test execution."""
    base = base_module()
    need(isinstance(binding, dict) and set(binding) == {"path", "sha256"}, "observer_manifest_binding")
    value = base.read_receipt(binding["path"], binding["sha256"])["document"]
    need(set(value) == set(MANIFEST_FIELDS)
         and value["schema"] == "heptabao.readindex-observer-manifest.v1"
         and value["source_commit"] == base_inputs["commit"] == base_admission["source_commit"]
         and value["source_tree"] == base_inputs["tree"] == base_admission["source_tree"],
         "observer_manifest_same_frozen_source")
    for key, expected in (("expected_unique_tests", 16), ("test_pool_seconds", 600),
                          ("per_test_seconds", 120), ("list_seconds_per_artifact", 60),
                          ("runtime_libtest_build_seconds", 900), ("test_retries", 0)):
        need(type(value[key]) is int and value[key] == expected, "observer_manifest_exact_denominator_and_caps")
    need(value["missing_ignored_zero_tests_fail"] is True
         and value["original_181_tests_added_removed_or_rebudgeted"] is False
         and value["product_tests_run"] is False and value["full_replacement_qualified"] is False
         and value["pool_policy"] == "one absolute monotonic pool for server5 then runtime11; no reset at suite boundary"
         and value["qualification_scope"] == "independent synthetic libtests; normal-service physical ReadIndex remains separate",
         "observer_manifest_scope")
    files = value["source_files"]
    need(isinstance(files, list) and len(files) == len(SOURCE_FILES)
         and all(isinstance(row, dict) and set(row) == {"path", "bytes", "sha256"} for row in files)
         and [row["path"] for row in files] == list(SOURCE_FILES), "observer_manifest_source_inventory")
    source = Path(base_inputs["source"])
    for row in files:
        need(type(row["bytes"]) is int and row["bytes"] > 0, "observer_manifest_source_byte_shape")
        _, actual = base.raw_file(source / row["path"], row["sha256"], retain=False)
        need(actual["bytes"] == row["bytes"], "observer_manifest_current_source_bytes")
    expected_cohorts = [
        {"suite": "server_observer", "crate": "heptabao-server", "expected_unique_tests": 5,
         "required_exact_names": list(SERVER_NAMES), "features": ["default", "native-v6-ha", "native-v6-storage"],
         "artifact_key": "libtest_artifact", "source_file": files[0]},
        {"suite": "runtime_observer", "crate": "heptabao-raft-runtime", "expected_unique_tests": 11,
         "required_exact_names": list(RUNTIME_NAMES), "features": ["default", "native-v6-raft-objects"],
         "artifact_key": "runtime_libtest_artifact", "source_file": files[1]},
    ]
    need(value["cohorts"] == expected_cohorts, "observer_manifest_exact_server5_runtime11")
    original = value["original_181"]
    need(isinstance(original, dict) and set(original) == {"server", "ha"}, "observer_original181_inventory")
    original_names = set()
    for suite, count in (("server", 172), ("ha", 9)):
        expected = {"filename": suite + "-regression-manifest.public.json",
                    "sha256": base_admission["manifests"][suite]["sha256"], "unique_tests": count}
        need(original[suite] == expected, "observer_same_original181_manifest_bytes")
        old_binding = base_admission["manifests"][suite]
        old = base.read_receipt(old_binding["local_path"], old_binding["sha256"])["document"]
        original_names.update(name for group in old["groups"] for name in group["required_exact_names"])
    need(len(original_names) == 181
         and not original_names.intersection(set(SERVER_NAMES) | set(RUNTIME_NAMES)),
         "observer_cohorts_independent_from_original181")
    return value


def original_base_contexts(base_inputs, base_admission):
    """Derive origins from the unchanged gate's validated build/executor graph."""
    base = base_module()
    need(base_admission["schema"] == base.SCHEMA and base_admission["status"] == "admitted"
         and base_admission["required_each_host"] == 181
         and base_admission["actual_linux_host"] == base_inputs["linux_host"]
         and base_admission["source_commit"] == base_inputs["commit"]
         and base_admission["source_tree"] == base_inputs["tree"], "observer_requires_actual_original181_gate")
    old_runtime = base_admission["runtime_prerequisites"]
    need(old_runtime["schema"] == "heptabao.runtime-prerequisite-admission.v2"
         and old_runtime["status"] == "admitted" and old_runtime["required"] == old_runtime["passed"] == 9,
         "observer_requires_original_nine_executor_origins")
    rows = old_runtime["rows"]
    need(len(rows) == 9 and len({row["stage"] for row in rows}) == 9
         and len({(row["host"], row["job_id"]) for row in rows}) == 9,
         "observer_original_job_inventory")
    by_stage = {row["stage"]: row for row in rows}
    contexts = {}
    for platform, stage in (("mac", "mac_build"), ("linux", "linux_libtest")):
        value = base_admission[platform]
        binding = value["build"]
        origin = by_stage[stage]["result"]
        need(origin["path"] == binding["local_path"] and origin["sha256"] == binding["sha256"],
             "observer_original_build_executor_result")
        normal = base.read_receipt(binding["local_path"], binding["sha256"])["document"]
        preparation = base.read_receipt(value["preparation"]["local_path"], value["preparation"]["sha256"])["document"]
        if platform == "mac":
            source = base.origin(base_inputs["source"])
            need(origin["path"] == origin["runtime_path"], "observer_mac_normal_original_path")
            release, release_binding = None, None
        else:
            source = base.origin(preparation["controller_path"]).parent.parent / "source"
            bound = base_admission["linux_release_chain"]["release_controller"]
            release_binding = by_stage["linux_release"]["result"]
            need(release_binding["path"] == bound["local_path"]
                 and release_binding["sha256"] == bound["sha256"], "observer_linux_release_original_executor")
            release = base.read_receipt(bound["local_path"], bound["sha256"])["document"]
        need(source.name == "source", "observer_candidate_source_directory")
        configured_host = "mac" if platform == "mac" else base_inputs["linux_host"]
        contexts[platform] = {"platform": platform, "source": str(source), "root": str(source.parent),
            "configured_host": configured_host, "expected_host": HOSTS[configured_host],
            "normal": normal, "normal_binding": origin, "release": release,
            "release_binding": release_binding, "preparation": preparation}
    return contexts, [(row["host"], row["job_id"]) for row in rows]


def exact_cli_values(argv, *, controller_origin, expected_values, python_flags=("-I", "-S", "-B")):
    """Verify every actual flag once while preserving the original flag order."""
    need(tuple(python_flags) in (("-I", "-S", "-B"), ("-B",)), "observer_fixed_python_flags")
    prefix = [*python_flags, controller_origin]
    need(isinstance(argv, list) and all(isinstance(x, str) for x in argv)
         and argv[:len(prefix)] == prefix
         and len(argv) == len(prefix) + 2 * len(expected_values), "observer_original_python_cli")
    found = {}
    for index in range(len(prefix), len(argv), 2):
        flag, value = argv[index:index + 2]
        need(flag.startswith("--") and flag[2:] in expected_values and flag[2:] not in found,
             "observer_duplicate_or_unknown_cli_flag")
        found[flag[2:]] = value
    need(found == expected_values, "observer_original_cli_candidate_context")
    return list(argv)


def fixed_controller(binding, *, platform, kind, root):
    base = base_module()
    need(isinstance(binding, dict) and set(binding) == {"path", "sha256", "runtime_path"},
         "observer_controller_binding_fields")
    if kind == "builder":
        filename = "build_runtime_observer_" + platform + ".py"
        expected_sha = BUILDER_PINS[platform]
    else:
        need(kind == "runner", "observer_controller_kind")
        filename, expected_sha = "run_observer16.py", JOINT_RUNNER_SHA256
    need(re.fullmatch(r"[0-9a-f]{64}", expected_sha) is not None,
         "observer_controller_pin_not_frozen")
    need(binding["runtime_path"] == str(PurePosixPath(root) / "control" / filename)
         and binding["sha256"] == expected_sha, "observer_fixed_controller_origin")
    if platform == "mac":
        need(binding["path"] == binding["runtime_path"], "observer_mac_original_controller")
    base.raw_file(binding["path"], expected_sha, retain=False)
    return binding


def derive_invocation(stage, *, context, controls, manifest_binding, runtime_binding,
                      joint_binding, actual_worker, executor_module):
    policy = executor_module.fixed_execution_policy(stage)
    root, normal = PurePosixPath(context["root"]), context["normal"]
    expected = {"source": context["source"], "commit": normal["source_commit"],
                "tree": normal["source_tree"], "normal-build-result": context["normal_binding"]["runtime_path"],
                "normal-build-result-sha256": context["normal_binding"]["sha256"]}
    if stage.endswith("_build"):
        controller = controls["builder"]
        expected.update({"output": str(root / "runtime-observer-libtest-build-r1"),
            "toolchain": normal["profile"]["PATH"].split(":")[0],
            "cargo-home": normal["profile"]["CARGO_HOME"], "target": normal["profile"]["CARGO_TARGET_DIR"]})
    else:
        controller = controls["runner"]
        expected.update({"output": str(root / "observer-regressions-r1"),
            "manifest": str(root / "control/observer-regression-manifest.public.json"),
            "manifest-sha256": manifest_binding["sha256"],
            "runtime-build-result": runtime_binding["runtime_path"],
            "runtime-build-result-sha256": runtime_binding["sha256"]})
        need(joint_binding["runtime_path"] == str(root / "observer-regressions-r1/result.public.json"),
             "observer_actual_joint_output_origin")
    python_flags = ("-B",) if stage == "linux_observer_build" else ("-I", "-S", "-B")
    argv = exact_cli_values(actual_worker["args"], controller_origin=controller["runtime_path"],
                            expected_values=expected, python_flags=python_flags)
    return {**policy, "args": argv, "cwd": str(root), "env": {},
            "controller_sha256": controller["sha256"]}


def validate_observer_inputs(binding, *, base_inputs, base_admission):
    """Read-only admission. The enclosing pinned outer supplies the base gate result."""
    need(DRAFT_ONLY is False, "observer_joint_producer_contract_not_frozen")
    base = base_module()
    need(isinstance(binding, dict) and set(binding) == {"path", "sha256"}, "observer_inputs_binding")
    inputs = base.read_receipt(binding["path"], binding["sha256"])["document"]
    need(isinstance(inputs, dict) and set(inputs) == {
        "schema", "source_commit", "source_tree", "linux_host", "manifest", "executors", "mac", "linux"}
         and inputs["schema"] == INPUT_SCHEMA and inputs["source_commit"] == base_inputs["commit"]
         and inputs["source_tree"] == base_inputs["tree"] and inputs["linux_host"] == base_inputs["linux_host"]
         and inputs["linux_host"] in ("rog", "pocket4"), "observer_inputs_same_frozen_candidate")
    manifest = validate_manifest(inputs["manifest"], base_inputs=base_inputs, base_admission=base_admission)
    contexts, previous_jobs = original_base_contexts(base_inputs, base_admission)
    executors = module("observer_runtime_bindings.py", "observer_fixed_executor_links", RUNTIME_BINDING_SHA256)
    runtime = executors.runtime_module()
    rows = executors.validate_inventory(runtime.pinned(inputs["executors"]), row_fields=runtime.ROW_FIELDS,
        linux_host=inputs["linux_host"], prerequisite_jobs=previous_jobs)
    by_stage = {row["stage"]: row for row in rows}
    builds = module("observer_build_evidence.py", "observer_fixed_build_evidence", BUILD_EVIDENCE_SHA256)
    joints = module("observer_joint_evidence.py", "observer_fixed_joint_evidence", JOINT_EVIDENCE_SHA256)
    expected_results, invocations, verified = {}, {}, {}
    for platform in ("mac", "linux"):
        declared = inputs[platform]
        need(isinstance(declared, dict) and set(declared) == set(PLATFORM_FIELDS),
             "observer_platform_evidence_inventory")
        context = contexts[platform]
        root = PurePosixPath(context["root"])
        controls = {kind: fixed_controller(declared[kind], platform=platform, kind=kind, root=str(root))
                    for kind in ("builder", "runner")}
        workers = {}
        units = {}
        for suffix in ("observer_build", "observer16"):
            stage = platform + "_" + suffix
            row = by_stage[stage]
            worker, _ = runtime.worker_files(row)
            need(runtime.api_originals(row, worker)["available"] is True,
                 "observer_new_job_original_start_required")
            workers[stage] = worker
            units[stage] = (executors.validate_linux_unit_identity(worker, runtime.pinned(row["api_start"]))
                            if platform == "linux" else None)
        if platform == "mac":
            need(declared["commands_helper"] is None, "observer_mac_has_no_linux_commands_helper")
        else:
            helper = declared["commands_helper"]
            builds.origin_binding(helper, expected_origin=root / "control/owned_build_commands.py",
                                  expected_sha=LINUX_COMMANDS_HELPER_SHA256)
            base.raw_file(helper["path"], helper["sha256"], retain=False)
            need(context["normal"]["commands_helper_sha256"] == helper["sha256"],
                 "observer_linux_same_actual_normal_commands_helper")
            controls["commands_helper"] = helper
        checked_build = builds.verify_runtime_build(declared["runtime_build"], platform=platform,
            source_root=context["source"], normal=context["normal"], normal_binding=context["normal_binding"],
            release=context["release"], release_binding=context["release_binding"],
            normal_cargo_binding=declared["normal_cargo_stdout"], runtime_cargo_binding=declared["runtime_cargo_stdout"],
            controller_sha256=controls["builder"]["sha256"], original_unit=units[platform + "_observer_build"])
        origin = str(root / "control/observer-regression-manifest.public.json")
        checked_joint = joints.verify_joint_result(declared["joint_result"], normal_build=context["normal"],
            runtime_build=checked_build["result"], normal_build_binding=context["normal_binding"],
            runtime_build_binding=declared["runtime_build"], manifest=manifest, manifest_binding=inputs["manifest"],
            manifest_origin=origin, expected_host=context["expected_host"], controller_sha256=controls["runner"]["sha256"])
        for suffix, result_key in (("observer_build", "runtime_build"), ("observer16", "joint_result")):
            stage = platform + "_" + suffix
            expected_results[stage] = declared[result_key]
            invocations[stage] = derive_invocation(stage, context=context, controls=controls,
                manifest_binding=inputs["manifest"], runtime_binding=declared["runtime_build"],
                joint_binding=declared["joint_result"], actual_worker=workers[stage], executor_module=executors)
        verified[platform] = {"passed": 16, "configured_host": context["configured_host"],
            "actual_host": context["expected_host"], "source_origin": context["source"],
            "normal_build": context["normal_binding"], "normal_server_sha256": context["normal"]["artifacts"]["heptabao-server"]["sha256"],
            "runtime_build": declared["runtime_build"], "runtime_compiler_event": checked_build["runtime_compiler_event"],
            "normal_runtime_dependency": checked_build["normal_runtime_dependency"],
            "runtime_process": checked_build["process"], "runtime_stderr": checked_build["stderr"],
            "cargo_lock_evidence": checked_build["cargo_lock_evidence"],
            "linux_runtime_resource_and_custody": checked_build["linux_resource_and_custody"],
            "joint": declared["joint_result"], "derived_suites": checked_joint["suite_bindings"],
            "original_pool": checked_joint["pool"], "original_process_count": 18, "controllers": controls,
            "complete_original_process_logs_reparsed": True}
    linked = executors.validate_observer_executors(inputs["executors"], expected_results=expected_results,
        expected_invocations=invocations, linux_host=inputs["linux_host"], prerequisite_jobs=previous_jobs)
    return {"schema": SCHEMA, "status": "admitted", "source_commit": inputs["source_commit"],
        "source_tree": inputs["source_tree"], "actual_linux_host": inputs["linux_host"],
        "required_each_host": 16, "manifest": inputs["manifest"], "inputs": binding,
        "mac": verified["mac"], "linux": verified["linux"], "runtime_admission": linked,
        "module_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "original_181_gate_sha256": BASE_GATE_SHA256, "executor_module_sha256": RUNTIME_BINDING_SHA256,
        "build_evidence_sha256": BUILD_EVIDENCE_SHA256, "joint_evidence_sha256": JOINT_EVIDENCE_SHA256,
        "raw_cargo_parser_sha256": CARGO_EVIDENCE_SHA256,
        "derived_suites_are_independent_executor_jobs": False,
        "remote_live_executables_rehashed_by_this_gate": False,
        "remote_artifact_scope": "Original successful build and joint executor receipts; physical launch must rehash each retained executable.",
        "product_readindex_qualified": False, "full_replacement_qualified": False,
        "products_started": False}
