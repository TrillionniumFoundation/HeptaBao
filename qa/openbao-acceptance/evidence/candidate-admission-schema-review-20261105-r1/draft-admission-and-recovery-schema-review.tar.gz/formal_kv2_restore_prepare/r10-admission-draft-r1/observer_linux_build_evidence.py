#!/usr/bin/env python3
"""Check the frozen Pocket Commands receipt, including its actual resource guards.

This consumes typed observations recorded by the original fixed controller and
helper. The caller must also bind the original API/worker/terminal/full output;
these dictionaries alone are not a host attestation or a successful execution.
"""
from pathlib import PurePosixPath
import math

HELPER_SHA256 = "b3e7cf80ab227f96e2fb4c1d822b0b6e6ee078c483cc8c642bd99c8b246ccfde"
MAXIMUM = 12 * 1024 ** 3
HEADROOM = 3 * 1024 ** 3 // 2
DISK_FLOOR = 8 * 1024 ** 3
RETAINED_CAP = 512 * 1024 ** 2
LOG_RESERVE = 128 * 1024 ** 2
EARLY_STOP = DISK_FLOOR + RETAINED_CAP + LOG_RESERVE


class Refusal(RuntimeError):
    pass


def need(value, label):
    if not value:
        raise Refusal(label)


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def numeric(value, minimum=0):
    return type(value) in (int, float) and math.isfinite(value) and value >= minimum


def memory_snapshot(value, unit_path):
    need(isinstance(value, dict) and set(value) == {
        "path", "memory_max", "memory_current_bytes", "memory_peak_bytes",
        "memory_swap_current_bytes", "memory_swap_max", "events"}
         and value["path"] == str(unit_path) and value["memory_max"] == str(MAXIMUM),
         "observer_linux_runtime_actual_cgroup_snapshot")
    need(all(integer(value[key]) for key in (
        "memory_current_bytes", "memory_peak_bytes", "memory_swap_current_bytes"))
         and isinstance(value["memory_swap_max"], str)
         and (value["memory_swap_max"] == "max" or value["memory_swap_max"].isdigit()),
         "observer_linux_runtime_cgroup_measurements")
    events = value["events"]
    need(isinstance(events, dict) and events and all(isinstance(k, str) and integer(v) for k, v in events.items())
         and all(events.get(key, 0) == 0 for key in ("oom", "oom_kill", "oom_group_kill")),
         "observer_linux_runtime_own_oom_event")


def budget_snapshot(value, *, disk_minimum, memory_minimum):
    need(isinstance(value, dict) and set(value) == {
        "persistent_free_bytes", "target_disk_free_bytes", "memory_available_bytes"}
         and integer(value["persistent_free_bytes"], disk_minimum)
         and integer(value["target_disk_free_bytes"], disk_minimum)
         and integer(value["memory_available_bytes"], memory_minimum),
         "observer_linux_runtime_actual_headroom")


def verify_linux_runtime(build, *, normal, source_root, original_unit):
    need(isinstance(original_unit, dict) and set(original_unit) == {"bare_unit", "service_unit", "job_id"}
         and original_unit["bare_unit"] == "hepta-runtime-job-" + original_unit["job_id"]
         and original_unit["service_unit"] == original_unit["bare_unit"] + ".service",
         "observer_linux_runtime_original_unit_required")
    need(build["commands_helper_sha256"] == normal["commands_helper_sha256"] == HELPER_SHA256
         and build["actual_host"] == normal["actual_host"] == "alex-G1628-04"
         and build["actual_system"] == normal["actual_system"] == "Linux"
         and build["source_before"] == normal["source_after"],
         "observer_linux_runtime_same_normal_helper_source_host")
    cgroup = build["executor_cgroup"]
    need(isinstance(cgroup, str) and cgroup.startswith("0::/") and "\n" not in cgroup
         and "\r" not in cgroup and "\0" not in cgroup, "observer_linux_runtime_original_cgroup")
    relative = cgroup[4:]
    parts = relative.split("/")
    need(relative and all(part not in ("", ".", "..") for part in parts)
         and parts[-1] == original_unit["service_unit"], "observer_linux_runtime_cgroup_matches_worker")
    unit_path = PurePosixPath("/sys/fs/cgroup") / relative
    normal_artifacts = [*normal["artifacts"].values(), normal["libtest_artifact"], normal["ha_libtest_artifact"]]
    need(len(normal_artifacts) == 4 and len({row["path"] for row in normal_artifacts}) == 4
         and all(integer(row["bytes"], 1) for row in normal_artifacts),
         "observer_linux_runtime_original_normal_retention_inventory")
    old_bytes = sum(row["bytes"] for row in normal_artifacts)
    need(old_bytes + build["runtime_libtest_artifact"]["bytes"] <= RETAINED_CAP,
         "observer_linux_runtime_combined_retention_cap")
    compile_disk_floor = DISK_FLOOR + max(0, RETAINED_CAP - old_bytes) + LOG_RESERVE
    admission = build["resource_admission"]
    need(isinstance(admission, dict) and set(admission) == {
        "phase", "configured_memory_max_bytes", "actual_unit", "ancestry", "initial",
        "host_memory_headroom_bytes", "persistent_hard_floor_bytes", "retained_cap_bytes",
        "log_reserve_bytes", "swap_counted_as_available", "poll_seconds", "maximum_poll_gap_seconds"}
         and admission["phase"] == "observer_runtime"
         and type(admission["configured_memory_max_bytes"]) is int and admission["configured_memory_max_bytes"] == MAXIMUM
         and admission["host_memory_headroom_bytes"] == HEADROOM
         and admission["persistent_hard_floor_bytes"] == DISK_FLOOR
         and admission["retained_cap_bytes"] == RETAINED_CAP and admission["log_reserve_bytes"] == LOG_RESERVE
         and admission["swap_counted_as_available"] is False
         and admission["poll_seconds"] == 0.20 and admission["maximum_poll_gap_seconds"] == 0.50,
         "observer_linux_runtime_fixed_resource_policy")
    memory_snapshot(admission["actual_unit"], unit_path)
    budget_snapshot(admission["initial"], disk_minimum=compile_disk_floor, memory_minimum=MAXIMUM + HEADROOM)
    expected_paths, cursor = [], unit_path
    while True:
        expected_paths.append(str(cursor))
        if cursor == PurePosixPath("/sys/fs/cgroup"):
            break
        cursor = cursor.parent
    ancestry = admission["ancestry"]
    need(isinstance(ancestry, list) and [row["path"] for row in ancestry] == expected_paths
         and all(isinstance(row, dict) and set(row) == {"path", "values"} and isinstance(row["values"], dict)
                 for row in ancestry), "observer_linux_runtime_actual_cgroup_ancestry")
    for row in ancestry:
        values = row["values"]
        need(set(values) <= {"memory.max", "memory.current", "memory.events", "memory.peak",
                            "memory.swap.max", "memory.swap.current", "cpu.max"}
             and all(isinstance(value, str) for value in values.values()),
             "observer_linux_runtime_ancestor_fields")
        maximum = values.get("memory.max", "max")
        need(maximum == "max" or maximum.isdigit() and int(maximum) >= MAXIMUM,
             "observer_linux_runtime_ancestor_limit_below_original_cap")
    need(ancestry[0]["values"].get("memory.max") == str(MAXIMUM),
         "observer_linux_runtime_actual_unit_ancestry_limit")
    call = build["runtime_libtest_build"]
    need(call["cwd"] == source_root and call["original_leader_retained_with_wnowait"] is True
         and call["live_group_before_first_reap"] == [] and call["signals"] == []
         and call["premature_exit_with_live_group"] is False and call["cancelled_by_signal"] is None
         and build["commands"] == [call]
         and build["cleanup"] == [{"label": call["label"], "exit_code": 0,
                                     "direct_child_reaped": True, "remaining": []}],
         "observer_linux_runtime_original_command_ownership")
    guard = call["budget_guard"]
    need(isinstance(guard, dict) and set(guard) == {
        "policy", "phase", "host_memory_headroom_bytes", "unit_memory_max_bytes", "cgroup_before", "cgroup_after",
        "max_observed_unit_current_bytes", "early_stop_free_bytes", "hard_headroom_bytes", "poll_interval_seconds",
        "maximum_admitted_poll_gap_seconds", "maximum_observed_poll_gap_seconds", "checks", "initial", "minimum", "violation"}
         and guard["policy"] == "Pocket real cgroup limit plus disk retention reservations and fixed host memory reserve"
         and guard["phase"] == "observer_runtime" and guard["host_memory_headroom_bytes"] == HEADROOM
         and guard["unit_memory_max_bytes"] == MAXIMUM and guard["early_stop_free_bytes"] == EARLY_STOP
         and guard["hard_headroom_bytes"] == DISK_FLOOR and guard["poll_interval_seconds"] == 0.20
         and guard["maximum_admitted_poll_gap_seconds"] == 0.50
         and numeric(guard["maximum_observed_poll_gap_seconds"]) and guard["maximum_observed_poll_gap_seconds"] <= 0.50
         and integer(guard["checks"], 2) and integer(guard["max_observed_unit_current_bytes"])
         and guard["violation"] is None, "observer_linux_runtime_complete_resource_guard")
    memory_snapshot(guard["cgroup_before"], unit_path)
    memory_snapshot(guard["cgroup_after"], unit_path)
    for key in ("initial", "minimum"):
        budget_snapshot(guard[key], disk_minimum=compile_disk_floor, memory_minimum=HEADROOM)
    need(all(guard["minimum"][key] <= guard["initial"][key] for key in guard["initial"]),
         "observer_linux_runtime_recorded_minimum")
    return {"original_unit": original_unit, "actual_unit_path": str(unit_path),
            "helper_sha256": HELPER_SHA256, "resource_admission": admission, "compile_budget_guard": guard,
            "normal_retained_bytes": old_bytes, "compile_disk_floor_bytes": compile_disk_floor,
            "same_original_owned_command_reaped": True}
