#!/usr/bin/env python3
"""Read original joint/suite/process/log evidence from one observer16 executor.

Successful executor metadata and the post-fsync stdout deadline are checked by
the separate original-runtime binder. A passed JSON file alone is insufficient.
"""
from __future__ import annotations
import hashlib
import importlib.util
import re
from pathlib import Path, PurePosixPath
import sys

BASE_SHA = "8a25a3bb32d7a78a2884b036d227dfb7e984a2b5078f86cea384bb57dae95"
SUITES = ("server_observer", "runtime_observer")
COUNTS = {"server_observer": 5, "runtime_observer": 11}


class Refusal(RuntimeError):
    pass


def need(value, label):
    if not value:
        raise Refusal(label)


def base_module():
    path = Path(__file__).resolve().with_name("full34_cross_host_gate_r4.py")
    need(hashlib.sha256(path.read_bytes()).hexdigest() == BASE_SHA, "joint_fixed_original_reader")
    spec = importlib.util.spec_from_file_location("joint_original_evidence_reader", path)
    module = importlib.util.module_from_spec(spec); sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def origin_binding(binding):
    need(isinstance(binding, dict) and set(binding) == {"path", "sha256", "runtime_path"},
         "joint_origin_binding_fields")
    base = base_module()
    base.origin(binding["runtime_path"]); base.digest(binding["sha256"])
    return binding


def mapped(binding, child):
    """Map only a declared file inside this original joint's own output root."""
    origin_binding(binding)
    need(isinstance(child, dict) and set(child) == {"path", "sha256"}, "joint_leaf_binding_fields")
    base = base_module()
    root = base.origin(binding["runtime_path"]).parent
    path = base.origin(child["path"])
    need(path.is_relative_to(root) and path != root, "joint_leaf_outside_original_output")
    local = Path(binding["path"]).parent / str(path.relative_to(root))
    return {"path": str(local), "sha256": base.digest(child["sha256"])}


def read_leaf(binding, child, *, document=True):
    local = mapped(binding, child)
    base = base_module()
    if document:
        return base.read_receipt(local["path"], local["sha256"])["document"]
    return base.raw_file(local["path"], local["sha256"])[0]


def inventory_names(raw):
    try:
        text = raw.decode("utf-8")
    except UnicodeError:
        raise Refusal("joint_inventory_original_utf8") from None
    names = []
    for line in text.splitlines():
        match = re.fullmatch(r"([A-Za-z0-9_:]+): test", line.strip())
        if match:
            names.append(match.group(1))
    summaries = re.findall(r"(?m)^(\d+) tests?, (\d+) benchmarks?\s*$", text)
    need(names and len(names) == len(set(names)) and len(summaries) == 1
         and int(summaries[0][0]) == len(names), "joint_actual_inventory_count")
    return names


def exact_test_stdout(raw, name):
    try:
        text = raw.decode("utf-8")
    except UnicodeError:
        raise Refusal("joint_exact_original_utf8") from None
    running = re.findall(r"(?m)^running (\d+) tests?\s*$", text)
    counts = re.findall(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
                        r"(\d+) ignored; (\d+) measured; (\d+) filtered out;", text)
    need(running == ["1"] and len(counts) == 1
         and counts[0][:5] == ("ok", "1", "0", "0", "0"), "joint_exact_one_actual_test")
    # The immutable argv binds the exact name. Also retain the libtest line as
    # an independent protection against associating another case's raw log.
    # --nocapture may place the test's own output between this prefix and the
    # trailing "ok", including newlines. The unique successful summary above
    # proves the result; the unique prefix proves this log names this case.
    need(re.findall(r"(?m)^test ([A-Za-z0-9_:]+) \.\.\.", text) == [name],
         "joint_exact_name_in_original_stdout")


def validate_pool(value):
    need(isinstance(value, dict) and set(value) == {
        "seconds", "per_test_seconds", "started_monotonic_ns", "deadline_monotonic_ns",
        "inventories_included", "inventory_seconds_per_artifact",
        "post_verification_and_final_fsync_included", "pool_reset_between_suites"},
        "joint_original_pool_fields")
    for key, expected in (("seconds", 600), ("per_test_seconds", 120), ("inventory_seconds_per_artifact", 60)):
        need(type(value[key]) is int and value[key] == expected, "joint_original_pool_caps")
    need(type(value["started_monotonic_ns"]) is int and value["started_monotonic_ns"] > 0
         and type(value["deadline_monotonic_ns"]) is int
         and value["deadline_monotonic_ns"] - value["started_monotonic_ns"] == 600_000_000_000
         and value["inventories_included"] is False
         and value["post_verification_and_final_fsync_included"] is True
         and value["pool_reset_between_suites"] is False, "joint_one_actual_absolute_pool")
    return value


def verify_process(binding, process, *, label, argv, pool, cap_seconds):
    need(isinstance(process, dict) and set(process) == {"path", "sha256", "record"},
         "joint_process_binding_fields")
    original_root = PurePosixPath(binding["runtime_path"]).parent
    need(process["path"] == str(original_root / (label + ".public.json")),
         "joint_original_process_receipt_path")
    leaf = {key: process[key] for key in ("path", "sha256")}
    record = read_leaf(binding, leaf)
    need(record == process["record"] and record["label"] == label and record["argv"] == argv,
         "joint_actual_process_record_and_argv")
    need(type(record["exit_code"]) is int and record["exit_code"] == 0
         and record["timed_out"] is False and record["cancelled"] is False
         and record["direct_child_reaped"] is True and record["remaining"] == []
         and record["completed_before_original_call_deadline"] is True,
         "joint_actual_process_success_and_cleanup")
    for key in ("started_monotonic_ns", "deadline_monotonic_ns", "completed_monotonic_ns", "owned_pgid"):
        need(type(record[key]) is int and record[key] > 0, "joint_original_process_clock_types")
    started, deadline, completed = (record[key] for key in (
        "started_monotonic_ns", "deadline_monotonic_ns", "completed_monotonic_ns"))
    maximum = started + cap_seconds * 1_000_000_000
    if pool is None:
        need(record["original_pool_deadline_monotonic_ns"] is None and deadline == maximum,
             "joint_inventory_original_call_cap")
    else:
        need(record["original_pool_deadline_monotonic_ns"] == pool["deadline_monotonic_ns"]
             and deadline == min(maximum, pool["deadline_monotonic_ns"])
             and started >= pool["started_monotonic_ns"], "joint_case_same_original_pool")
    need(started <= completed < deadline
         and record["elapsed_seconds"] == (completed - started) / 1_000_000_000
         and record["outer_cap_seconds"] == (deadline - started) / 1_000_000_000,
         "joint_actual_process_elapsed_and_cap")
    for stream in ("stdout", "stderr"):
        need(record[stream + "_path"] == str(original_root / (label + "." + stream)),
             "joint_original_process_log_path")
    stdout = read_leaf(binding, {"path": record["stdout_path"], "sha256": record["stdout_sha256"]}, document=False)
    read_leaf(binding, {"path": record["stderr_path"], "sha256": record["stderr_sha256"]}, document=False)
    return record, stdout


def verify_joint_result(binding, *, normal_build, runtime_build, normal_build_binding,
                        runtime_build_binding, manifest, manifest_binding, manifest_origin,
                        expected_host, controller_sha256):
    origin_binding(binding)
    base = base_module()
    result = base.read_receipt(binding["path"], binding["sha256"])["document"]
    root = PurePosixPath(binding["runtime_path"]).parent
    need(PurePosixPath(binding["runtime_path"]).name == "result.public.json"
         and result["schema"] == "heptabao.readindex-observer-joint-result.v1"
         and result["status"] == "passed" and result["joint_output_root"] == str(root)
         and result["controller_sha256"] == controller_sha256, "joint_actual_result_identity")
    need(result["source_commit"] == manifest["source_commit"]
         and result["source_tree"] == manifest["source_tree"]
         and result["actual_system"] == expected_host["system"]
         and result["actual_host"] == expected_host["host"], "joint_actual_source_and_physical_host")
    need(result["manifest_path"] == manifest_origin and result["manifest_sha256"] == manifest_binding["sha256"]
         and result["normal_build_result_path"] == normal_build_binding["runtime_path"]
         and result["normal_build_result_sha256"] == normal_build_binding["sha256"]
         and result["runtime_build_result_path"] == runtime_build_binding["runtime_path"]
         and result["runtime_build_result_sha256"] == runtime_build_binding["sha256"]
         and result["server_sha256"] == normal_build["artifacts"]["heptabao-server"]["sha256"]
         and result["normal_runtime_dependency"] == runtime_build["normal_runtime_dependency"],
         "joint_same_actual_normal_runtime_builds")
    for key in ("expected_unique_tests", "attempted_once", "passed"):
        need(type(result[key]) is int and result[key] == 16, "joint_complete_sixteen_denominator")
    need(result["cohort_counts"] == COUNTS and type(result["test_retries"]) is int and result["test_retries"] == 0,
         "joint_exact_disjoint_cohorts")
    for key in ("full_denominator_retained", "source_unchanged", "normal_artifacts_unchanged", "all_owned_groups_empty",
                "success_requires_executor_exit0_after_final_fsync_and_final_pool_check",
                "test_pool_deadline_not_expired_before_final_files"):
        need(result[key] is True, "joint_required_actual_" + key)
    for key in ("original_181_results_or_budgets_changed", "product_readindex_qualified", "full_replacement_qualified",
                "production_changed", "derived_suite_files_are_independent_executor_jobs"):
        need(result[key] is False, "joint_scope_" + key)
    need("failure" not in result and "failure_type" not in result, "joint_failure_not_hidden")
    pool = validate_pool(result["original_test_pool"])
    need(type(result["completed_monotonic_ns_before_result_fsync"]) is int
         and pool["started_monotonic_ns"] <= result["completed_monotonic_ns_before_result_fsync"] < pool["deadline_monotonic_ns"],
         "joint_pre_fsync_original_deadline")
    children = result["children"]
    need(isinstance(children, list) and len(children) == 2 and [row["suite"] for row in children] == list(SUITES),
         "joint_two_derived_suites")
    cohorts = {row["suite"]: row for row in manifest["cohorts"]}
    artifacts = {"server_observer": normal_build["libtest_artifact"],
                 "runtime_observer": runtime_build["runtime_libtest_artifact"]}
    all_cases, calls, suite_bindings = [], {}, []
    previous_case_completed = pool["started_monotonic_ns"]
    previous_inventory_completed = None
    for child in children:
        suite, count = child["suite"], COUNTS[child["suite"]]
        need(set(child) == {"suite", "path", "sha256", "expected_unique_tests", "passed"}
             and child["path"] == str(root / (suite + "-result.public.json"))
             and child["expected_unique_tests"] == child["passed"] == count,
             "joint_derived_suite_binding")
        leaf = {key: child[key] for key in ("path", "sha256")}
        actual = read_leaf(binding, leaf)
        suite_bindings.append(mapped(binding, leaf))
        need(actual["schema"] == "heptabao.readindex-observer-suite-result.v1"
             and actual["suite"] == suite and actual["status"] == "passed"
             and actual["source_commit"] == result["source_commit"] and actual["source_tree"] == result["source_tree"]
             and actual["joint_output_root"] == str(root) and actual["controller_sha256"] == controller_sha256
             and actual["manifest_path"] == manifest_origin and actual["manifest_sha256"] == manifest_binding["sha256"]
             and actual["normal_build_result_sha256"] == normal_build_binding["sha256"]
             and actual["runtime_build_result_sha256"] == runtime_build_binding["sha256"]
             and actual["binary"] == artifacts[suite] and actual["original_test_pool"] == pool,
             "joint_derived_suite_same_actual_context")
        for key in ("expected_unique_tests", "attempted_once", "passed"):
            need(type(actual[key]) is int and actual[key] == count, "joint_derived_suite_denominator")
        need(actual["full_denominator_retained"] is True and actual["independent_executor_job"] is False
             and actual["success_requires_joint_final_deadline_and_executor_exit0"] is True
             and actual["product_readindex_qualified"] is False and actual["full_replacement_qualified"] is False,
             "joint_derived_suite_not_an_independent_executor")
        inventory_binding = actual["inventory"]
        need(set(inventory_binding) == {"path", "sha256", "record"}
             and inventory_binding["path"] == str(root / (suite + "-inventory.public.json")),
             "joint_inventory_binding")
        inventory = read_leaf(binding, {key: inventory_binding[key] for key in ("path", "sha256")})
        need(inventory == inventory_binding["record"]
             and inventory["schema"] == "heptabao.readindex-observer-inventory.v1"
             and inventory["suite"] == suite and inventory["binary_sha256"] == artifacts[suite]["sha256"]
             and inventory["manifest_sha256"] == manifest_binding["sha256"]
             and inventory["required_exact_test_names"] == cohorts[suite]["required_exact_names"]
             and inventory["missing_required_names"] == [], "joint_actual_inventory_identity")
        label = suite + "-list"
        call, stdout = verify_process(binding, inventory["inventory_process"], label=label,
            argv=[artifacts[suite]["path"], "--list"], pool=None, cap_seconds=60)
        names = inventory_names(stdout)
        need(inventory["actual_compiled_test_names"] == names
             and set(cohorts[suite]["required_exact_names"]) <= set(names)
             and call["completed_monotonic_ns"] <= pool["started_monotonic_ns"],
             "joint_actual_inventory_contains_required_names_before_pool")
        if previous_inventory_completed is not None:
            need(call["started_monotonic_ns"] >= previous_inventory_completed, "joint_inventories_sequential")
        previous_inventory_completed = call["completed_monotonic_ns"]
        calls[label] = call
        cases = actual["cases"]
        need(isinstance(cases, list) and len(cases) == count
             and [row["name"] for row in cases] == cohorts[suite]["required_exact_names"],
             "joint_actual_exact_case_inventory")
        for row in cases:
            ordinal = len(all_cases) + 1
            need(set(row) == {"name", "suite", "ordinal", "attempted", "status", "process", "stdout", "stderr"}
                 and row["suite"] == suite and type(row["ordinal"]) is int and row["ordinal"] == ordinal
                 and row["attempted"] is True and row["status"] == "passed", "joint_exact_case_once")
            label = "test-" + str(ordinal).zfill(4)
            call, stdout = verify_process(binding, row["process"], label=label,
                argv=[artifacts[suite]["path"], row["name"], "--exact", "--nocapture", "--test-threads=1"],
                pool=pool, cap_seconds=120)
            need(call["started_monotonic_ns"] >= previous_case_completed,
                 "joint_all_cases_one_sequential_pool")
            previous_case_completed = call["completed_monotonic_ns"]
            for stream in ("stdout", "stderr"):
                need(row[stream] == {"path": call[stream + "_path"], "sha256": call[stream + "_sha256"]},
                     "joint_case_original_log_binding")
            exact_test_stdout(stdout, row["name"])
            calls[label] = call
            all_cases.append(row)
    need(result["cases"] == all_cases and len(all_cases) == 16
         and previous_case_completed <= result["completed_monotonic_ns_before_result_fsync"],
         "joint_exact_union_and_final_clock")
    labels = [suite + "-list" for suite in SUITES] + ["test-" + str(i).zfill(4) for i in range(1, 17)]
    cleanup = result["cleanup"]
    need(isinstance(cleanup, list) and len(cleanup) == 18
         and [row["label"] for row in cleanup] == list(reversed(labels)), "joint_complete_original_process_inventory")
    for row in cleanup:
        call = calls[row["label"]]
        need(row["pid"] == call["owned_pgid"] and type(row["exit_code"]) is int and row["exit_code"] == 0
             and row["direct_child_reaped"] is True and row["remaining"] == [], "joint_actual_all_process_cleanup")
    return {"result": result, "binding": binding, "suite_bindings": suite_bindings,
            "manifest": manifest_binding, "pool": pool, "passed": 16,
            "original_process_count": 18, "original_logs_reparsed": True,
            "successful_executor_and_post_fsync_stdout_still_required": True}
