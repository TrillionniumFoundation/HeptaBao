#!/usr/bin/env python3
"""Pure verification of pinned original Cargo JSON bytes for observer builds.

The enclosing gate supplies bytes read and hash-checked from actual build
evidence, plus independently derived origin paths and hashes. These functions
do not establish host identity or build execution by themselves.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import PurePosixPath
import re

FEATURES = ("default", "native-v6-raft-objects")
INDEX_BASIS = "one_based_physical_stdout_line_including_line_ending"
DEPENDENCY_FIELDS = frozenset((
    "cargo_stdout", "event_line_sha256", "event_index", "event_index_basis", "features",
    "profile", "package_id", "target_name", "target_src_path", "manifest_path",
))
MAX_CARGO_BYTES = 16 * 1024 * 1024


class Refusal(RuntimeError):
    pass


def need(value, code):
    if not value:
        raise Refusal(code)


def strict_pairs(pairs):
    result = {}
    for key, value in pairs:
        need(key not in result, "observer_cargo_duplicate_json_key")
        result[key] = value
    return result


def nonfinite(_value):
    raise Refusal("observer_cargo_nonfinite_json")


def origin(value):
    need(isinstance(value, str) and value.startswith("/") and "\0" not in value,
         "observer_cargo_origin_shape")
    path = PurePosixPath(value)
    need(str(path) == value and ".." not in path.parts, "observer_cargo_canonical_origin")
    return path


def digest(value):
    need(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
         "observer_cargo_digest_shape")
    return value


def parse_cargo_stream(raw):
    need(isinstance(raw, bytes) and 0 < len(raw) <= MAX_CARGO_BYTES,
         "observer_cargo_original_byte_bound")
    rows = []
    for index, line in enumerate(raw.splitlines(keepends=True), 1):
        need(line.endswith(b"\n") and bool(line.strip()), "observer_cargo_partial_or_blank_line")
        try:
            event = json.loads(line.decode("utf-8"), object_pairs_hook=strict_pairs,
                               parse_constant=nonfinite)
        except (UnicodeError, ValueError, RecursionError):
            raise Refusal("observer_cargo_invalid_json_line") from None
        need(isinstance(event, dict), "observer_cargo_event_not_object")
        rows.append((index, line, event))
    finishes = [row for row in rows if row[2].get("reason") == "build-finished"]
    need(len(finishes) == 1 and finishes[0] is rows[-1]
         and finishes[0][2].get("success") is True,
         "observer_cargo_unique_success_last_event")
    return rows


def verify_profile(profile, *, test):
    need(isinstance(profile, dict)
         and set(profile) == {"opt_level", "debuginfo", "debug_assertions", "overflow_checks", "test"}
         and profile["opt_level"] == "3" and type(profile["debuginfo"]) is int and profile["debuginfo"] == 0
         and profile["debug_assertions"] is True and profile["overflow_checks"] is True
         and profile["test"] is test, "observer_cargo_exact_normal_profile")


def select_runtime_event(raw, *, source_root, test):
    rows = parse_cargo_stream(raw)
    matches = [row for row in rows if row[2].get("reason") == "compiler-artifact"
               and row[2].get("target", {}).get("name") == "heptabao_raft_runtime"
               and row[2].get("profile", {}).get("test") is test]
    need(len(matches) == 1, "observer_cargo_unique_runtime_event")
    index, line, event = matches[0]
    verify_profile(event["profile"], test=test)
    need(isinstance(event.get("features"), list) and sorted(event["features"]) == list(FEATURES),
         "observer_cargo_actual_runtime_features")
    target = event["target"]
    root = origin(source_root)
    need(target["kind"] == ["lib"] and target["crate_types"] == ["lib"]
         and target["src_path"] == str(root / "crates/heptabao-raft-runtime/src/lib.rs")
         and event["manifest_path"] == str(root / "crates/heptabao-raft-runtime/Cargo.toml"),
         "observer_cargo_exact_runtime_source_paths")
    need(isinstance(event.get("package_id"), str) and bool(event["package_id"]),
         "observer_cargo_runtime_package_identity")
    if test:
        origin(event.get("executable"))
    else:
        need(event.get("executable") is None, "observer_normal_runtime_not_libtest")
    return index, line, event


def normal_runtime_dependency(raw, *, source_root, stdout_origin, stdout_sha256):
    origin(stdout_origin)
    need(hashlib.sha256(raw).hexdigest() == digest(stdout_sha256),
         "observer_normal_cargo_original_hash")
    index, line, event = select_runtime_event(raw, source_root=source_root, test=False)
    return {
        "cargo_stdout": {"path": stdout_origin, "sha256": stdout_sha256, "bytes": len(raw)},
        "event_line_sha256": hashlib.sha256(line).hexdigest(),
        "event_index": index, "event_index_basis": INDEX_BASIS,
        "features": event["features"], "profile": event["profile"],
        "package_id": event["package_id"], "target_name": event["target"]["name"],
        "target_src_path": event["target"]["src_path"], "manifest_path": event["manifest_path"],
    }


def verify_normal_dependency(declared, raw, *, source_root, stdout_origin, stdout_sha256):
    need(isinstance(declared, dict) and set(declared) == set(DEPENDENCY_FIELDS),
         "observer_normal_dependency_exact_fields")
    expected = normal_runtime_dependency(raw, source_root=source_root,
                                         stdout_origin=stdout_origin, stdout_sha256=stdout_sha256)
    need(declared == expected, "observer_normal_dependency_matches_original_event")
    return expected


def verify_runtime_libtest_event(raw, *, source_root, stdout_origin, stdout_sha256,
                                 normal_dependency, artifact):
    origin(stdout_origin)
    need(hashlib.sha256(raw).hexdigest() == digest(stdout_sha256),
         "observer_runtime_cargo_original_hash")
    index, line, event = select_runtime_event(raw, source_root=source_root, test=True)
    need(event["package_id"] == normal_dependency["package_id"]
         and event["manifest_path"] == normal_dependency["manifest_path"]
         and event["target"]["src_path"] == normal_dependency["target_src_path"]
         and event["features"] == normal_dependency["features"],
         "observer_runtime_same_normal_dependency")
    need(artifact["compiler_executable"] == event["executable"]
         and artifact["features"] == event["features"] and artifact["profile"] == event["profile"]
         and artifact["fresh"] == event.get("fresh"), "observer_runtime_retained_artifact_event")
    return {
        "cargo_stdout": {"path": stdout_origin, "sha256": stdout_sha256, "bytes": len(raw)},
        "event_line_sha256": hashlib.sha256(line).hexdigest(),
        "event_index": index, "event_index_basis": INDEX_BASIS,
        "package_id": event["package_id"], "target_src_path": event["target"]["src_path"],
        "manifest_path": event["manifest_path"], "features": event["features"],
        "profile": event["profile"], "compiler_executable": event["executable"],
        "artifact_sha256": digest(artifact["sha256"]),
    }
