#!/usr/bin/env python3
"""Small modeled inventory controls; never fabricates worker execution evidence."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
path = HERE / "observer_runtime_bindings.py"
spec = importlib.util.spec_from_file_location("observer_inventory_under_test", path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
runtime = module.runtime_module()


def modeled_index():
    rows = []
    for i, name in enumerate(module.STAGES, 1):
        row = {key: None for key in runtime.ROW_FIELDS}
        row.update(stage=name, host="linux_placeholder" if name.startswith("linux_") else "mac",
                   job_id=f"abcde-{i:04x}-1234")
        if row["host"] == "linux_placeholder":
            row["host"] = "pocket4"
        rows.append(row)
    return {"schema": module.INDEX_SCHEMA, "jobs": rows}


def main():
    output = Path(sys.argv[1])
    output.mkdir(mode=0o700)
    previous = [("mac", "1234-5678-0001"), ("pocket4", "1234-5678-0002")]
    rows = []
    def check(name, change=None, refusal=None, prior=None):
        value = modeled_index()
        if change is not None:
            change(value)
        observed = None
        try:
            result = module.validate_inventory(value, row_fields=runtime.ROW_FIELDS,
                                               linux_host="pocket4", prerequisite_jobs=previous if prior is None else prior)
            assert result == value["jobs"]
        except module.Refusal as error:
            observed = str(error)
        rows.append({"case": name, "passed": observed == refusal, "expected_refusal": refusal,
                     "actual_refusal": observed})
    check("four_actual_stage_names_inventory_only")
    check("original_job_reuse_refused", lambda x: x["jobs"][0].update(job_id=previous[0][1]),
          "observer_reused_actual_or_prerequisite_job")
    check("same_host_job_reuse_refused", lambda x: x["jobs"][1].update(job_id=x["jobs"][0]["job_id"]),
          "observer_reused_actual_or_prerequisite_job")
    check("different_linux_builder_host_refused", lambda x: x["jobs"][2].update(host="rog"),
          "observer_actual_configured_host")
    check("suite_derivative_as_executor_refused", lambda x: x["jobs"][1].update(stage="mac_observer_server"),
          "observer_exact_four_actual_jobs")
    check("missing_joint_executor_refused", lambda x: x["jobs"].pop(),
          "observer_exact_four_actual_jobs")
    check("duplicate_stage_name_refused", lambda x: x["jobs"][1].update(stage=x["jobs"][0]["stage"]),
          "observer_exact_four_actual_jobs")
    check("duplicated_original_prerequisite_refused", prior=previous + [previous[0]],
          refusal="observer_prerequisite_job_inventory")
    check("invented_job_identifier_shape_refused", lambda x: x["jobs"][0].update(job_id="not-an-original-id"),
          "observer_actual_job_id_shape")
    result = {
        "schema": "heptabao.observer-inventory-control-qa.v1",
        "status": "passed" if all(row["passed"] for row in rows) else "failed",
        "module_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "qa_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "required": len(rows), "passed": sum(row["passed"] for row in rows), "checks": rows,
        "scope": "Modeled inventory predicates only; no original worker/start/terminal/result is synthesized or validated.",
        "actual_positive_executor_binding_tested": False,
        "observer_qualification": False, "products_started": 0, "network_calls": 0,
    }
    raw = (json.dumps(result, sort_keys=True, indent=2) + "\n").encode()
    target = output / "result.public.json"
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    try:
        assert os.write(fd, raw) == len(raw)
        os.fsync(fd)
    finally:
        os.close(fd)
    print(json.dumps({"status": result["status"], "required": len(rows), "passed": result["passed"],
                      "result": str(target), "sha256": hashlib.sha256(raw).hexdigest()}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
