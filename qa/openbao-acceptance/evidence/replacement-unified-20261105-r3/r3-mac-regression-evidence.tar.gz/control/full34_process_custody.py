#!/usr/bin/env python3
"""Process custody for the unchanged full34 driver; no API or test predicate lives here."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import stat
import subprocess
import sys
import threading
import time

ORIGINAL_POPEN = subprocess.Popen
OWNED_SIGNALS = (signal.SIGHUP, signal.SIGINT, signal.SIGTERM)
SCHEMA = "heptabao.full34-process-custody.v1"
MAX_JSON = 128 * 1024

class CustodyError(RuntimeError):
    pass

class Cancelled(BaseException):
    pass

def require(value, reason):
    if not value:
        raise CustodyError(reason)

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":")) + "\n").encode()

def write_new(path, value):
    path = Path(path)
    raw = canonical(value)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as out:
        out.write(raw)
        out.flush()
        os.fsync(out.fileno())

def private_json(path):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
                and before.st_nlink == 1 and not before.st_mode & 0o077
                and before.st_size <= MAX_JSON, "private_receipt_required")
        raw = stream.read(MAX_JSON + 1)
        after = os.fstat(stream.fileno())
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns)
                and len(raw) == before.st_size, "private_receipt_changed")
    return json.loads(raw)

def require_waitid():
    require(all(hasattr(os, n) for n in ("waitid", "P_PID", "WEXITED", "WNOHANG", "WNOWAIT")),
            "WNOWAIT_required_before_dispatch")
    require(signal.getsignal(signal.SIGCHLD) == signal.SIG_DFL,
            "foreign_SIGCHLD_reaper_refused")

def exit_event(child):
    require(child.returncode is None, "original_child_already_reaped")
    event = os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
    if event is None:
        return None
    require(event.si_pid == child.pid and event.si_signo == signal.SIGCHLD,
            "original_exit_identity_changed")
    return {"pid": event.si_pid, "code": event.si_code, "status": event.si_status}

def ps_rows(seconds=2.0):
    """Projection only. This helper never signals any enumerated PID."""
    process = ORIGINAL_POPEN(
        ["/bin/ps", "-axo", "pid=,ppid=,pgid=,uid=,stat=,lstart="],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        env=dict(os.environ, LC_ALL="C"))
    try:
        stdout, stderr = process.communicate(timeout=seconds)
    except BaseException:
        if process.poll() is None:
            process.kill()
        process.communicate(timeout=2)
        raise
    require(process.returncode == 0 and not stderr and len(stdout) <= 4 * 1024 * 1024,
            "bounded_process_projection_failed")
    rows = []
    for line in stdout.decode("ascii").splitlines():
        fields = line.split(None, 5)
        require(len(fields) == 6, "process_projection_shape")
        row = {"pid": int(fields[0]), "ppid": int(fields[1]), "pgid": int(fields[2]),
               "uid": int(fields[3]), "state": fields[4], "start": fields[5]}
        # ps was itself an owned, already-waited projection child.
        if row["pid"] != process.pid:
            rows.append(row)
    return rows

def stable(row):
    return {name: row[name] for name in ("pid", "ppid", "pgid", "uid", "start")}

def capture_session(child):
    require_waitid()
    require(child.returncode is None, "session_reaped_before_capture")
    rows = [row for row in ps_rows() if row["pid"] == child.pid]
    require(len(rows) == 1 and rows[0]["ppid"] == os.getpid()
            and rows[0]["pgid"] == child.pid and rows[0]["uid"] == os.geteuid(),
            "original_direct_session_identity")
    event = exit_event(child)
    if event is None and not rows[0]["state"].startswith("Z"):
        try:
            require(os.getsid(child.pid) == child.pid and os.getpgid(child.pid) == child.pid,
                    "original_session_not_private")
        except ProcessLookupError:
            require(exit_event(child) is not None, "session_identity_lost")
    return stable(rows[0])

def verify_session(child, birth):
    require(child.returncode is None, "cannot_signal_reaped_session")
    event = exit_event(child)
    rows = [row for row in ps_rows() if row["pid"] == child.pid]
    require(len(rows) == 1 and stable(rows[0]) == birth
            and rows[0]["ppid"] == os.getpid(), "session_birth_changed_no_signal")
    return event

def finish_session(child, birth, until, *, force=False):
    """Keep the original session leader reserved until every other member is gone."""
    require(time.monotonic() < until, "session_cleanup_deadline")
    event = verify_session(child, birth)
    rows = [row for row in ps_rows() if row["pgid"] == child.pid]
    others = [row for row in rows if row["pid"] != child.pid]
    require(all(row["uid"] == os.geteuid() for row in rows), "session_uid_changed_no_signal")
    unexpected = bool(others) and event is not None
    signalled = False
    if force or unexpected:
        verify_session(child, birth)
        os.killpg(child.pid, signal.SIGKILL)
        signalled = True
    while True:
        require(time.monotonic() < until, "session_cleanup_deadline")
        event = verify_session(child, birth)
        others = [row for row in ps_rows() if row["pgid"] == child.pid and row["pid"] != child.pid]
        if event is not None and not others:
            break
        time.sleep(min(0.02, max(0, until - time.monotonic())))
    # First reap occurs only after all other live AND zombie group members are absent.
    code = ORIGINAL_POPEN.wait(child, timeout=max(0.001, until - time.monotonic()))
    return {"leader_pid": child.pid, "original_child_reaped": True,
            "exit_code": code, "group_empty_before_first_reap": True,
            "group_signal_while_original_leader_reserved": signalled,
            "unexpected_descendants": unexpected,
            "signals_after_reap": 0}

def signal_original_session(child, birth, number):
    if verify_session(child, birth) is None:
        # The same direct original child is still unreaped; no PID lookup grants authority.
        os.kill(child.pid, number)

def read_line(fd, maximum=MAX_JSON, deadline=None):
    data = bytearray()
    while b"\n" not in data:
        if deadline is not None:
            remaining = deadline - time.monotonic()
            require(remaining > 0 and select.select([fd], [], [], remaining)[0],
                    "custody_admission_deadline")
        chunk = os.read(fd, 4096)
        require(chunk, "custody_parent_closed_before_admission")
        data.extend(chunk)
        require(len(data) <= maximum, "custody_admission_bound")
    line, tail = bytes(data).split(b"\n", 1)
    require(not tail, "custody_admission_trailing_data")
    return json.loads(line)

def own_group_kill(reason, receipt_path, payload, target):
    """The guardian is the live leader of this group; no enumerated PID is signalled."""
    require(os.getpid() == os.getpgrp() == os.getsid(0), "guardian_lost_own_session")
    write_new(receipt_path.with_suffix(".abort.json"), {
        "schema": SCHEMA, "nonce": payload["nonce"], "guardian_pid": os.getpid(),
        "target_pid": target.pid if target else None, "reason": reason,
        "signal": "SIGKILL", "scope": "guardian_own_live_session",
        "original_guardian_pid_reserved": True})
    os.killpg(os.getpid(), signal.SIGKILL)
    os._exit(74)

def guardian(control_fd, ack_fd, receipt_path):
    """Own one original target and its inherited group; parent EOF is fatal."""
    require_waitid()
    signal.pthread_sigmask(signal.SIG_UNBLOCK, set(OWNED_SIGNALS))
    cancellation = {"number": None}
    def on_signal(number, _frame):
        cancellation["number"] = number
    for number in OWNED_SIGNALS:
        signal.signal(number, on_signal)
    require(os.getpid() == os.getpgrp() == os.getsid(0), "guardian_requires_own_session")
    payload = read_line(control_fd)
    require(set(payload) == {"nonce", "argv", "executable_sha256", "argv_sha256"},
            "guardian_payload_fields")
    arguments = payload["argv"]
    require(isinstance(arguments, list) and arguments and all(isinstance(a, str) for a in arguments),
            "guardian_argv")
    require(hashlib.sha256(canonical(arguments)).hexdigest() == payload["argv_sha256"]
            and Path(arguments[0]).is_absolute() and sha(arguments[0]) == payload["executable_sha256"],
            "guardian_target_pin")
    if select.select([control_fd], [], [], 0)[0]:
        require(os.read(control_fd, 1), "guardian_parent_lost_before_effect")
        raise CustodyError("guardian_unexpected_parent_bytes")
    target = None
    try:
        # Standard streams are inherited untouched. The metadata/body stdin is not read here.
        target = ORIGINAL_POPEN(arguments, close_fds=True, start_new_session=False)
        write_new(receipt_path.with_suffix(".started.json"), {
            "schema": SCHEMA, "nonce": payload["nonce"], "guardian_pid": os.getpid(),
            "guardian_pgid": os.getpgrp(), "target_pid": target.pid,
            "target_original_Popen": True, "target_argv_sha256": payload["argv_sha256"],
            "target_executable_sha256": payload["executable_sha256"],
            "owned_signals_unblocked": not bool(set(OWNED_SIGNALS) &
                signal.pthread_sigmask(signal.SIG_BLOCK, set()))})
        os.write(ack_fd, canonical({"target_pid": target.pid, "guardian_pid": os.getpid()}))
        os.close(ack_fd)
        ack_fd = -1
        while True:
            if cancellation["number"] is not None:
                own_group_kill("guardian_received_owned_signal", receipt_path, payload, target)
            if select.select([control_fd], [], [], 0.02)[0]:
                value = os.read(control_fd, 1)
                own_group_kill("parent_pipe_eof" if not value else "parent_pipe_invalid",
                               receipt_path, payload, target)
            event = exit_event(target)
            if event is not None:
                members = [row for row in ps_rows() if row["pgid"] == os.getpid()
                           and row["pid"] not in (os.getpid(), target.pid)]
                if members:
                    own_group_kill("target_exit_with_descendants", receipt_path, payload, target)
                code = target.wait(timeout=2)
                write_new(receipt_path.with_suffix(".terminal.json"), {
                    "schema": SCHEMA, "nonce": payload["nonce"], "guardian_pid": os.getpid(),
                    "target_pid": target.pid, "target_exit_code": code,
                    "target_original_wait_completed": True,
                    "inherited_group_empty_before_target_reap": True})
                return code if code >= 0 else 128 - code
    except BaseException:
        if target is not None:
            own_group_kill("guardian_exception", receipt_path, payload, target)
        raise
    finally:
        if ack_fd >= 0:
            os.close(ack_fd)
        os.close(control_fd)

class Registry:
    """Scope one unchanged Python driver's Popen custody; all effect code remains frozen."""
    def __init__(self, directory, nonce):
        self.directory = Path(directory)
        self.directory.mkdir(mode=0o700)
        self.nonce = nonce
        self.children = []
        self.protected = 0
        self.cancelled = None
        self.cancel_raised = False
        self.closing = False
        self.previous_handlers = {}
        self.integrity = True

    def on_signal(self, number, _frame):
        self.cancelled = number
        if not self.protected and not self.closing and not self.cancel_raised:
            self.cancel_raised = True
            raise Cancelled()

    def install(self):
        require_waitid()
        # No block is inherited by any effect child; registration defers Python exceptions instead.
        signal.pthread_sigmask(signal.SIG_UNBLOCK, set(OWNED_SIGNALS))
        for number in OWNED_SIGNALS:
            self.previous_handlers[number] = signal.getsignal(number)
            signal.signal(number, self.on_signal)
        registry = self

        class RegisteredPopen(ORIGINAL_POPEN):
            def __init__(self, arguments, **kwargs):
                registry.protected += 1
                self.custody_guardian = kwargs.get("start_new_session") is True
                self.custody_birth = None
                self.custody_lifeline = None
                self.custody_group_result = None
                self.custody_ordinal = len(registry.children) + 1
                self.custody_prefix = registry.directory / ("child-" + str(self.custody_ordinal).zfill(5))
                read_fd = ack_read = ack_write = None
                original_arguments = [os.fsdecode(os.fspath(a)) for a in arguments]
                argv_sha = hashlib.sha256(canonical(original_arguments)).hexdigest()
                try:
                    if self.custody_guardian:
                        require(not kwargs.get("shell", False) and not kwargs.get("pass_fds")
                                and "executable" not in kwargs, "unsupported_session_spawn_refused")
                        read_fd, self.custody_lifeline = os.pipe()
                        ack_read, ack_write = os.pipe()
                        kwargs["pass_fds"] = (read_fd, ack_write)
                        arguments = [sys.executable, "-I", "-S", "-B", str(Path(__file__).resolve()),
                                     "--session-guardian", str(read_fd), str(ack_write),
                                     str(self.custody_prefix)]
                    try:
                        super().__init__(arguments, **kwargs)
                    finally:
                        if getattr(self, "pid", None) is not None:
                            registry.children.append(self)
                    if self.custody_guardian:
                        os.close(read_fd); read_fd = None
                        os.close(ack_write); ack_write = None
                        self.custody_birth = capture_session(self)
                    write_new(self.custody_prefix.with_suffix(".birth.json"), {
                        "schema": SCHEMA, "nonce": registry.nonce, "pid": self.pid,
                        "parent_pid": os.getpid(), "guardian": self.custody_guardian,
                        "session_birth": self.custody_birth,
                        "original_caller_argv_sha256": argv_sha,
                        "original_Popen_registered_before_admission": True})
                    if registry.cancelled is not None:
                        registry.cancel_raised = True
                        raise Cancelled()
                    if self.custody_guardian:
                        os.write(self.custody_lifeline, canonical({
                            "nonce": registry.nonce, "argv": original_arguments,
                            "argv_sha256": argv_sha, "executable_sha256": sha(original_arguments[0])}))
                        acknowledgement = read_line(ack_read, deadline=time.monotonic() + 5)
                        require(acknowledgement.get("guardian_pid") == self.pid,
                                "guardian_admission_identity")
                finally:
                    for descriptor in (read_fd, ack_read, ack_write):
                        if descriptor is not None:
                            os.close(descriptor)
                    registry.protected -= 1

            def _guarded_reap(self, until):
                self.custody_group_result = finish_session(
                    self, self.custody_birth, until, force=False)
                if self.custody_group_result["unexpected_descendants"]:
                    registry.integrity = False
                if self.custody_lifeline is not None:
                    os.close(self.custody_lifeline)
                    self.custody_lifeline = None
                return self.returncode

            def _internal_poll(self, _deadstate=None):
                if not self.custody_guardian or self.custody_birth is None or self.returncode is not None:
                    return ORIGINAL_POPEN._internal_poll(self, _deadstate)
                if exit_event(self) is None:
                    return None
                return self._guarded_reap(time.monotonic() + 5)

            def wait(self, timeout=None):
                if not self.custody_guardian or self.custody_birth is None or self.returncode is not None:
                    return ORIGINAL_POPEN.wait(self, timeout=timeout)
                end = None if timeout is None else time.monotonic() + timeout
                while exit_event(self) is None:
                    if end is not None and time.monotonic() >= end:
                        raise subprocess.TimeoutExpired(self.args, timeout)
                    time.sleep(0.01 if end is None else min(0.01, max(0, end - time.monotonic())))
                return self._guarded_reap(min(time.monotonic() + 5, end) if end is not None
                                         else time.monotonic() + 5)

        self.adapter = RegisteredPopen
        subprocess.Popen = RegisteredPopen
        return self

    def finish(self):
        self.closing = True
        subprocess.Popen = ORIGINAL_POPEN
        rows = []
        for child in reversed(self.children):
            row = {"pid": child.pid, "guardian": child.custody_guardian,
                   "original_Popen": True, "source_requested_session": child.custody_guardian}
            try:
                if child.custody_guardian and child.custody_lifeline is not None:
                    os.close(child.custody_lifeline)
                    child.custody_lifeline = None
                if child.returncode is None:
                    if child.custody_guardian:
                        if child.custody_birth is None:
                            child.custody_birth = capture_session(child)
                        child.custody_group_result = finish_session(
                            child, child.custody_birth, time.monotonic() + 5, force=True)
                    else:
                        if ORIGINAL_POPEN.poll(child) is None:
                            child.kill()
                        ORIGINAL_POPEN.wait(child, timeout=5)
                row.update(exit_code=child.returncode, original_child_reaped=child.returncode is not None,
                           session=child.custody_group_result)
            except BaseException as error:
                self.integrity = False
                row["cleanup_error_type"] = type(error).__name__
            rows.append(row)
        for number, handler in self.previous_handlers.items():
            signal.signal(number, handler)
        receipt = {
            "schema": SCHEMA, "nonce": self.nonce,
            "registered_original_children": len(self.children), "children": list(reversed(rows)),
            "all_registered_original_children_reaped": all(r.get("original_child_reaped") for r in rows),
            "all_registered_session_groups_empty_before_reap": all(
                not r["guardian"] or (r.get("session") or {}).get("group_empty_before_first_reap") is True
                for r in rows),
            "integrity": self.integrity, "cancellation_signal": self.cancelled,
            "signal_mask_fixed": True, "source_or_request_predicates_modified": False,
            "signals_sent_using_enumerated_pid": False,
        }
        write_new(self.directory / "result.public.json", receipt)
        return receipt

def observe_registered_sessions(directory, nonce, until):
    """Read-only final observation, including sessions whose parent was cancelled."""
    directory = Path(directory)
    births = []
    for path in sorted(directory.glob("child-*.birth.json")):
        row = private_json(path)
        require(row.get("nonce") == nonce and row.get("schema") == SCHEMA,
                "foreign_custody_receipt_refused")
        if row.get("guardian"):
            births.append(row)
    while True:
        rows = ps_rows()
        remaining = [{"registered_session": b["pid"], "observed": stable(row),
                      "state": row["state"]}
                     for b in births for row in rows if row["pgid"] == b["pid"]]
        if not remaining or time.monotonic() >= until:
            return {"registered_sessions": len(births), "all_members_absent": not remaining,
                    "remaining": remaining, "observation_only_no_signals": True}
        time.sleep(0.02)

def parent_pipe_monitor(read_fd):
    """Loss of the outer original owner cancels this private driver group."""
    require(os.getpid() == os.getpgrp() == os.getsid(0), "driver_requires_private_session")
    while os.read(read_fd, 1):
        pass
    os.close(read_fd)
    os.kill(os.getpid(), signal.SIGTERM)
    # Cleanup keeps the original 45-second grace; this never grants test success.
    time.sleep(45)
    os.killpg(os.getpid(), signal.SIGKILL)

if __name__ == "__main__":
    if len(sys.argv) == 5 and sys.argv[1] == "--session-guardian":
        try:
            raise SystemExit(guardian(int(sys.argv[2]), int(sys.argv[3]), Path(sys.argv[4])))
        except CustodyError:
            raise SystemExit(73)
    raise SystemExit(64)
