#!/usr/bin/env python3
"""Derive a pinned HA history controller with actual raw-TLS HTTP204 evidence.
Only control files are written. No product process or physical fixture starts.
"""
from __future__ import annotations
import ast
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r3")
SOURCE = ROOT / "source"
OUTPUT = ROOT / "control/ha-official-history204-r1"
COMMIT = "6b16a9292d046bbc42aec65045fa105aaa1ac5de"
TREE = "0de9c516e94a47cb89e2e0f5ac2146e60913cfef"
LIVE = "native_v6_ha_official_history_live.py"
WIRE = "native_v6_ha_official_history_wire.py"
PINS = {
    LIVE: "758e5d6cc93900fd6c5de328446fce069f167fe1eb7c63fc1f2a8310231e04d5",
    WIRE: "15355994054c75d293a98f906b8762751b6edd59376a896267a9546ae8ceb080",
}
RAW_OBSERVER = r'''
def observe_raw_snapshot_204(tls_socket, deadline):
    """Observe the exact TLS stream through authenticated close_notify and peer EOF."""
    require(tls_socket.suppress_ragged_eofs is False)
    require(not (tls_socket.context.options & getattr(ssl, "OP_IGNORE_UNEXPECTED_EOF", 0)))
    header_limit = 64 * 1024
    pending = bytearray()
    header = None
    version = None
    content_length = None
    while True:
        remaining = deadline - time.monotonic()
        require(remaining > 0)
        tls_socket.settimeout(remaining)
        chunk = tls_socket.recv(4096)
        if not chunk:
            require(header is not None)
            return {
                "status": 204, "raw_tls_http204": True,
                "http_version": version, "header_bytes": len(header),
                "header_sha256": hashlib.sha256(header).hexdigest(),
                "body_bytes": 0, "body_sha256": hashlib.sha256(b"").hexdigest(),
                "peer_eof_observed": True, "tls_close_notify_observed": True, "content_length": content_length,
                "transfer_encoding_count": 0,
            }
        # Even a delayed TLS record after the terminator is a response-body byte.
        # Connection: close was sent; only actual EOF proves this bounded stream.
        require(header is None)
        pending.extend(chunk)
        split = pending.find(b"\r\n\r\n")
        if split < 0:
            require(len(pending) <= header_limit)
            continue
        require(split + 4 <= header_limit and len(pending) == split + 4)
        header = bytes(pending)
        lines = header[:-4].split(b"\r\n")
        status = re.fullmatch(rb"(HTTP/1\.[01]) 204(?: [\x20-\x7e]*)?", lines[0])
        require(status is not None)
        version = status.group(1).decode("ascii")
        lengths, encodings = [], []
        for line in lines[1:]:
            name, separator, value = line.partition(b":")
            require(separator and re.fullmatch(rb"[!#$%&'*+.^_\x60|~0-9A-Za-z-]+", name)
                    and all(byte == 9 or 32 <= byte <= 126 for byte in value))
            value = value.strip(b" \t")
            if name.lower() == b"content-length":
                lengths.append(value)
            if name.lower() == b"transfer-encoding":
                encodings.append(value)
        require(not encodings and len(lengths) <= 1)
        if lengths:
            require(re.fullmatch(rb"[0-9]{1,10}", lengths[0]) is not None
                    and int(lengths[0]) == 0)
            content_length = 0

'''
PROGRESS_PREDICATE = r'''
def restore_progress_valid(before, after, archive_generation, raft_before, raft_after):
    """Join independent admitted capacity observations to the real Raft frontier."""
    if (type(archive_generation) is not int or archive_generation < 0
            or type(raft_before) is not int or type(raft_after) is not int
            or not 0 <= raft_before < raft_after):
        return False
    if not all(type(row.get(key)) is int and row[key] >= 0
               for row in (before, after) for key in ("generation", "replay_epoch")):
        return False
    return (
        before.get("state_storage_format") == "heptabao-state-records-v6"
        and after.get("state_storage_format") == "heptabao-state-records-v6"
        and before["generation"] >= archive_generation
        and after["generation"] > before["generation"]
        and after["replay_epoch"] == before["replay_epoch"] + 1
    )

'''
OLD_PUBLICATION = r'''        status, publication = self.wire(leader, "POST", SNAPSHOT, archive_in=archive)
        self.check("official271_snapshot_restore_once", status == 200)
        data = publication.get("data", {})
        after_capacity = self.capacity(leader)
        raft_after = base.capture_committed_frontier(self.context, leader)
        self.check("official271_restore_publication_advanced",
            all(type(data.get(key)) is int for key in ("imported_generation", "previous_local_generation",
                                                       "published_local_generation", "replay_epoch"))
            and data["imported_generation"] == envelope["generation"]
            # Mandatory Auth clock publications may advance between the read
            # and restore admission. Compare monotonic frontiers, not equality
            # between two different admitted capacity generations.
            and data["previous_local_generation"] >= previous_generation
            and data["published_local_generation"] > data["previous_local_generation"]
            and data["replay_epoch"] == before_capacity["replay_epoch"] + 1
            and after_capacity["replay_epoch"] == data["replay_epoch"]
            and after_capacity["generation"] >= data["published_local_generation"]
            and raft_after > raft_before
            and data.get("cluster_coordinated") is True and not publication.get("auth")
            and not publication.get("wrap_info"),
            publication=data, before_capacity_generation=previous_generation,
            raft_frontier_before=raft_before, raft_frontier_after=raft_after)
'''
NEW_PUBLICATION = r'''        status, observation = self.wire(leader, "POST", SNAPSHOT, archive_in=archive)
        self.check("official271_snapshot_restore_once",
            status == 204 and observation.get("raw_tls_http204") is True
            and observation.get("body_bytes") == 0
            and observation.get("body_sha256") == digest(b"")
            and observation.get("peer_eof_observed") is True
            and observation.get("tls_close_notify_observed") is True
            and observation.get("content_length") in (None, 0)
            and observation.get("transfer_encoding_count") == 0,
            raw_tls_response=observation, original_http_seconds=15)
        after_capacity = self.capacity(leader)
        raft_after = base.capture_committed_frontier(self.context, leader)
        # HTTP204 intentionally has no JSON publication. Observe the committed
        # state independently, then prove rollback with all 19 API/raw versions.
        self.check("official271_restore_publication_advanced",
            restore_progress_valid(before_capacity, after_capacity, envelope["generation"],
                                   raft_before, raft_after),
            archive_generation=envelope["generation"],
            before_capacity_generation=previous_generation,
            after_capacity_generation=after_capacity.get("generation"),
            before_replay_epoch=before_capacity.get("replay_epoch"),
            after_replay_epoch=after_capacity.get("replay_epoch"),
            raft_frontier_before=raft_before, raft_frontier_after=raft_after)
'''

def require(value, label):
    if not value:
        raise RuntimeError(label)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    return subprocess.check_output(["git", "-C", str(SOURCE), *args], text=True).strip()

def identity():
    require(git("rev-parse", "HEAD") == COMMIT, "source_commit_changed")
    require(git("rev-parse", "HEAD^{tree}") == TREE, "source_tree_changed")
    require(not git("status", "--porcelain"), "source_not_clean")

def replace_once(text, old, new):
    require(text.count(old) == 1, "derived_context_not_exactly_once")
    return text.replace(old, new, 1)

def write_new(path, value):
    raw = value.encode() if isinstance(value, str) else value
    with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "wb") as out:
        out.write(raw)
        out.flush()
        os.fsync(out.fileno())

def named_node(tree, name):
    return next(node for node in tree.body
                if getattr(node, "name", None) == name)

def check_names(tree):
    return sorted(node.args[0].value for node in ast.walk(tree)
                  if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                  and node.func.attr == "check" and node.args
                  and isinstance(node.args[0], ast.Constant)
                  and isinstance(node.args[0].value, str))

def mutation_calls(tree):
    return sorted(ast.dump(node, include_attributes=False) for node in ast.walk(tree)
                  if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                  and node.func.attr == "wire" and len(node.args) >= 3
                  and isinstance(node.args[1], ast.Constant)
                  and node.args[1].value in ("POST", "DELETE"))

def main():
    os.umask(0o077)
    identity()
    original = {}
    for name, pin in PINS.items():
        path = SOURCE / "qa/openbao-acceptance" / name
        raw = path.read_bytes()
        require(digest(raw) == pin, "original_helper_pin_changed")
        original[name] = raw.decode()

    wire = replace_once(original[WIRE], "import sys\n", "import sys\nimport time\n")
    wire = replace_once(wire,
        "connection.sock = context.wrap_socket(tcp, server_hostname=str(ip))",
        "connection.sock = context.wrap_socket(tcp, server_hostname=str(ip), suppress_ragged_eofs=False)")
    wire = replace_once(wire, "def main():\n", RAW_OBSERVER + "\ndef main():\n    deadline = time.monotonic() + 15\n")
    wire = replace_once(wire, "        response = connection.getresponse()\n", r'''        if packet["archive_in"] is not None:
            metadata = observe_raw_snapshot_204(connection.sock, deadline)
            metadata["leaf_sha256"] = packet["leaf_sha256"]
            # No HTTPResponse.read() call can discard forbidden HTTP204 bytes.
            sys.stdout.buffer.write(json.dumps(metadata, sort_keys=True).encode() + b"\n")
            return
        response = connection.getresponse()
''')
    live = replace_once(original[LIVE], "import kv2_271_lossless_native_live as exact\n",
        "PINNED_SOURCE_ROOT = Path(" + repr(str(SOURCE)) + ")\n"
        "sys.path.insert(0, str(PINNED_SOURCE_ROOT / 'qa/openbao-acceptance'))\n\n"
        "import kv2_271_lossless_native_live as exact\n")
    live = replace_once(live, "ROOT = HERE.parents[1]\n", "ROOT = PINNED_SOURCE_ROOT\n")
    live = replace_once(live, "def admit_source(root, summary_sha256):\n",
                        PROGRESS_PREDICATE + "\ndef admit_source(root, summary_sha256):\n")
    live = replace_once(live, '            if "archive_sha256" in outcome:\n                response = outcome\n',
        r'''            if "archive_sha256" in outcome:
                response = outcome
            if archive_in is not None:
                need(method == "POST" and path == SNAPSHOT and not raw_response
                     and outcome.get("raw_tls_http204") is True
                     and outcome.get("status") == 204
                     and outcome.get("body_bytes") == 0
                     and outcome.get("body_sha256") == digest(b"")
                     and outcome.get("peer_eof_observed") is True
                     and outcome.get("tls_close_notify_observed") is True,
                     "restore_raw_tls_204_observation")
                response = outcome
''')
    live = replace_once(live, OLD_PUBLICATION, NEW_PUBLICATION)
    old_tree, new_tree = ast.parse(original[LIVE]), ast.parse(live)
    ast.parse(wire)
    old_class, new_class = named_node(old_tree, "OfficialHistoryRun"), named_node(new_tree, "OfficialHistoryRun")
    old_methods = {n.name: n for n in old_class.body if isinstance(n, ast.FunctionDef)}
    new_methods = {n.name: n for n in new_class.body if isinstance(n, ast.FunctionDef)}
    require(set(old_methods) == set(new_methods), "lifecycle_method_set_changed")
    unchanged = []
    for name in old_methods:
        if name in ("wire", "finish_application"):
            continue
        require(ast.dump(old_methods[name]) == ast.dump(new_methods[name]), "other_lifecycle_method_changed")
        unchanged.append(name)
    require(check_names(old_tree) == check_names(new_tree), "check_names_or_multiplicity_changed")
    require(mutation_calls(old_tree) == mutation_calls(new_tree), "mutation_operations_changed")
    extra_old = next(n for n in old_tree.body if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == "EXTRA_CHECKS" for t in n.targets))
    extra_new = next(n for n in new_tree.body if isinstance(n, ast.Assign)
                     and any(isinstance(t, ast.Name) and t.id == "EXTRA_CHECKS" for t in n.targets))
    require(ast.dump(extra_old) == ast.dump(extra_new), "extra_check_set_changed")
    extra = eval(compile(ast.Expression(extra_old.value), "<unchanged extra checks>", "eval"),
                 {"__builtins__": {"frozenset": frozenset}})
    require(len(extra) == 30, "extra_denominator_not_30")
    require('        super().finish_application(leader)\n' in live, "base_98_lifecycle_removed")
    require('timeout=max(0, started + 15 - time.monotonic())' in live
            and 'intent = begin_binary(self.recovery, node, "POST", IMPORT_ROUTE, self.bundle, self.stage, 5)' in live,
            "original_request_budgets_changed")
    require(not OUTPUT.exists(), "existing_derived_control_refused")
    OUTPUT.mkdir(mode=0o700)
    changes = {LIVE: live, WIRE: wire}
    for name, content in changes.items():
        write_new(OUTPUT / name, content)
    patch = "".join("".join(difflib.unified_diff(
        original[name].splitlines(True), changes[name].splitlines(True),
        fromfile="source/qa/openbao-acceptance/" + name,
        tofile="control/ha-official-history204-r1/" + name))
        for name in (LIVE, WIRE))
    write_new(OUTPUT / "protocol204.diff", patch)
    identity()
    receipt = {
        "schema": "heptabao.ha-official-history-204-control-preparation.v1",
        "status": "prepared_pending_isolated_qa", "source_commit": COMMIT,
        "source_tree": TREE, "source_unchanged": True,
        "source_helper_sha256": PINS,
        "derived_helper_sha256": {n: digest(t.encode()) for n, t in changes.items()},
        "patch_sha256": digest(patch.encode()),
        "preparer_sha256": digest(Path(__file__).read_bytes()),
        "base_direct_lan_denominator_retained": 98,
        "base_direct_lan_implementation_changed": False,
        "extra_official_history_denominator": len(extra),
        "extra_checks": sorted(extra),
        "all_check_calls_and_multiplicity_retained": True,
        "all_mutation_calls_retained_without_replay": True,
        "unchanged_lifecycle_methods": sorted(unchanged),
        "original_http_seconds": 15, "native_large_http_seconds": 5,
        "restore_wire_scope": "same pinned TLS connection through authenticated close_notify and peer EOF; no HTTP body decoder",
        "suppress_ragged_eofs": False, "tls_close_notify_required": True,
        "raw_observer_uses_original_absolute_deadline": True,
        "prior_28_qa_did_not_cover_missing_close_notify": True,
        "production_changed": False, "physical_ha_started": False,
        "product_processes_started": False, "compiled_source_changed": False,
        "created_ns": time.time_ns(),
    }
    write_new(OUTPUT / "preparation.public.json", json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"status": receipt["status"], "output": str(OUTPUT),
                      "derived_helper_sha256": receipt["derived_helper_sha256"],
                      "patch_sha256": receipt["patch_sha256"],
                      "source_unchanged": True}, sort_keys=True))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
