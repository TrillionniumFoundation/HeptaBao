#!/usr/bin/env python3
"""Run a frozen HeptaBao regression manifest once, using exact libtest names.

This controller never builds, retries a test, changes application budgets, or
reuses a run directory. Product qualification remains separate from this suite.
"""
import argparse
import hashlib
import json
import os
import re
import resource
import signal
import stat
import subprocess
import sys
import time
from pathlib import Path


class AdmissionError(Exception):
    pass


def require(value, message):
    if not value:
        raise AdmissionError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def regular(path):
    value = Path(path)
    info = value.lstat()
    require(stat.S_ISREG(info.st_mode) and not value.is_symlink(), "regular file required: " + str(value))
    return value


def durable_json(path, value, replace=False):
    path = Path(path)
    temporary = path.with_name(path.name + ".next") if replace else path
    with temporary.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    if replace:
        os.replace(temporary, path)
    fd = os.open(str(path.parent), os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def git(source, *args):
    return subprocess.check_output(
        ["/usr/bin/git", "-C", str(source), *args],
        text=True, timeout=30, stderr=subprocess.PIPE,
    ).strip()


def freeze(source):
    return {
        "commit": git(source, "rev-parse", "HEAD"),
        "tree": git(source, "rev-parse", "HEAD^{tree}"),
        "status": git(source, "status", "--porcelain"),
    }


def group_members(pgid):
    output = subprocess.check_output(
        ["/bin/ps", "-axo", "pid=,ppid=,pgid=,stat="],
        text=True, timeout=10, stderr=subprocess.PIPE,
    )
    members = []
    for line in output.splitlines():
        fields = line.split()
        if len(fields) >= 4 and int(fields[2]) == pgid:
            members.append({"pid": int(fields[0]), "ppid": int(fields[1]),
                            "pgid": int(fields[2]), "state": fields[3]})
    return members


def retire(child):
    # A live unreaped direct child keeps this owned process-group identity.
    # Once reaped, observe survivors; never signal a possibly recycled group.
    if child.poll() is None:
        try:
            os.killpg(child.pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            if child.poll() is None:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            child.wait(timeout=5)
    return group_members(child.pid)


def parse_inventory(text):
    names = []
    for line in text.splitlines():
        match = re.fullmatch(r"([A-Za-z0-9_:]+): test", line.strip())
        if match:
            names.append(match.group(1))
    require(names and len(names) == len(set(names)), "empty or duplicate real libtest inventory")
    summaries = re.findall(r"(?m)^(\d+) tests?, (\d+) benchmarks?\s*$", text)
    require(len(summaries) == 1, "libtest inventory summary absent or ambiguous")
    require(int(summaries[0][0]) == len(names), "libtest inventory summary disagrees with names")
    return names


def one_exact_test_passed(text, returncode, timed_out, cancelled):
    counts = re.findall(
        r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; "
        r"(\d+) ignored; (\d+) measured; (\d+) filtered out;", text,
    )
    running = re.findall(r"(?m)^running (\d+) tests?\s*$", text)
    return (
        returncode == 0 and not timed_out and not cancelled
        and running == ["1"] and len(counts) == 1
        and counts[0][0:5] == ("ok", "1", "0", "0", "0")
    )


def validate_manifest(manifest):
    require(manifest.get("schema") == "heptabao.unified-regression-manifest.v1", "unsupported manifest")
    suite = manifest.get("suite")
    require(suite in ("server", "ha"), "unknown binary suite")
    baseline_count = 60 if suite == "server" else 0
    groups = manifest.get("groups", [])
    require(groups, "no regression groups")
    unique = []
    memberships = {}
    baseline = []
    for group in groups:
        require(re.fullmatch(r"[a-z0-9_-]+", group["label"]), "unsafe group label")
        names = group["required_exact_names"]
        require(names and len(names) == len(set(names)), "empty or duplicate declared group")
        require(group["phase"] in ("original", "new"), "unknown group phase")
        require(group["max_seconds"] == 600, "group budget was changed")
        if group["phase"] == "new":
            require(group["per_test_seconds"] == 120, "new-test budget was changed")
        for name in names:
            require(re.fullmatch(r"[A-Za-z0-9_:]+", name), "unsafe exact test name")
            if name not in memberships:
                unique.append(name)
                memberships[name] = []
            memberships[name].append(group["label"])
        if group["phase"] == "original":
            baseline.extend(names)
    require(len(unique) == manifest["expected_unique_tests"], "manifest unique denominator mismatch")
    require(len(baseline) == baseline_count and len(set(baseline)) == baseline_count,
            "original regression denominator was changed")
    require(set(baseline) == set(manifest["original_60_exact_names"]), "original sixty identity mismatch")
    require(manifest["new_runtime_pool_seconds"] == 600, "new runtime pool was changed")
    require(manifest["list_seconds"] == 60, "inventory budget was changed")
    return groups, unique, memberships


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", required=True)
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--build-result", required=True)
    parser.add_argument("--build-result-sha256", required=True)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    os.umask(0o077)
    require(os.uname().sysname == "Darwin", "this runner records Darwin resource units")
    require(re.fullmatch(r"[0-9a-f]{40}", args.commit), "exact source commit required")
    require(re.fullmatch(r"[0-9a-f]{40}", args.tree), "exact source tree required")
    source = Path(args.source).resolve(strict=True)
    manifest_path = regular(Path(args.manifest)).resolve(strict=True)
    require(sha(manifest_path) == args.manifest_sha256, "manifest pin changed")
    manifest = json.loads(manifest_path.read_text())
    groups, names, memberships = validate_manifest(manifest)
    require(manifest["source_commit"] == args.commit and manifest["source_tree"] == args.tree,
            "manifest belongs to another frozen source combination")
    suite = manifest["suite"]
    baseline_count = 60 if suite == "server" else 0
    output = Path(args.output)
    require(output.is_absolute() and not output.exists(), "existing run refused; inspect its receipt instead")
    output.mkdir(mode=0o700)
    children = []
    cancellation = {"signal": None}

    def signal_received(number, _frame):
        cancellation["signal"] = number

    signal.signal(signal.SIGTERM, signal_received)
    signal.signal(signal.SIGINT, signal_received)
    rows = {name: {"name": name, "status": "not_run", "requested_by_groups": memberships[name]}
            for name in names}
    result = {
        "schema": "heptabao.unified-exact-regression-result.v1",
        "status": "running",
        "source_commit": args.commit, "source_tree": args.tree,
        "manifest_path": str(manifest_path), "manifest_sha256": args.manifest_sha256,
        "build_result_path": args.build_result, "build_result_sha256": args.build_result_sha256,
        "controller_sha256": sha(__file__),
        "started_ns": time.time_ns(),
        "suite": suite, "expected_unique_tests": len(names),
        "original_test_denominator": baseline_count, "original_60_applicable": suite == "server",
        "production_changed": False, "full_replacement_qualified": False,
        "single_request_budgets_changed": False, "test_retries": 0,
        "execution_scope": "normal compiled libtest; synthetic owned fixtures",
        "cleanup_scope": "owned process groups; detached descendants are not claimed",
        "pending_external_gates": manifest.get("pending_external_gates", []),
        "new_runtime_pool_seconds": 600,
    }
    durable_json(output / "intent.public.json", result)

    def owned(label, argv, cap):
        require(cap > 0, "process budget already exhausted")
        began = time.monotonic()
        before_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        timed_out = False
        was_cancelled = False
        child = None
        stdout_path = output / (label + ".stdout")
        stderr_path = output / (label + ".stderr")
        with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
            child = subprocess.Popen(
                argv, cwd=source, stdin=subprocess.DEVNULL, stdout=stdout,
                stderr=stderr, start_new_session=True,
            )
            children.append((label, child))
            try:
                while child.poll() is None:
                    remaining = began + cap - time.monotonic()
                    if cancellation["signal"] is not None:
                        was_cancelled = True
                        break
                    if remaining <= 0:
                        timed_out = True
                        break
                    try:
                        child.wait(timeout=min(0.5, remaining))
                    except subprocess.TimeoutExpired:
                        pass
            finally:
                survivors = retire(child)
                stdout.flush()
                stderr.flush()
                os.fsync(stdout.fileno())
                os.fsync(stderr.fileno())
        after_usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        record = {
            "label": label, "argv": argv, "exit_code": child.returncode,
            "timed_out": timed_out, "cancelled": was_cancelled,
            "elapsed_seconds": time.monotonic() - began, "outer_cap_seconds": cap,
            "owned_pgid": child.pid, "direct_child_reaped": child.returncode is not None,
            "remaining": survivors,
            "children_user_cpu_seconds": after_usage.ru_utime - before_usage.ru_utime,
            "children_system_cpu_seconds": after_usage.ru_stime - before_usage.ru_stime,
            "cumulative_children_peak_rss_bytes": after_usage.ru_maxrss,
            "rss_scope": "Darwin RUSAGE_CHILDREN high-water mark since controller start",
            "stdout_sha256": sha(stdout_path), "stderr_sha256": sha(stderr_path),
        }
        durable_json(output / (label + ".public.json"), record)
        return record

    terminal_reason = "not_run_preflight"
    binary = None
    binary_digest = None
    baseline_identity = {"commit": args.commit, "tree": args.tree, "status": ""}
    executed = set()
    group_receipts = []
    try:
        require(freeze(source) == baseline_identity, "source is not the frozen clean candidate")
        for item in manifest["source_files"]:
            path = Path(item["path"])
            require(not path.is_absolute() and ".." not in path.parts, "unsafe manifest source path")
            require(sha(regular(source / path)) == item["sha256"], "predeclared source file changed: " + str(path))
        build_path = regular(Path(args.build_result)).resolve(strict=True)
        require(sha(build_path) == args.build_result_sha256, "build receipt changed")
        build = json.loads(build_path.read_text())
        require(build.get("status") == "built", "build has no successful terminal receipt")
        require(build.get("source_commit") == args.commit and build.get("source_tree") == args.tree,
                "build receipt uses another source combination")
        require(build.get("source_unchanged") is True, "build did not retain frozen source")
        build_call = build["libtest_build" if suite == "server" else "ha_libtest_build"]
        require(build_call.get("exit_code") == 0 and not build_call.get("timed_out")
                and build_call.get("direct_child_reaped") is True and not build_call.get("remaining"),
                "libtest build is not reconciled")
        artifact = build["libtest_artifact" if suite == "server" else "ha_libtest_artifact"]
        require(artifact["profile"] == {
            "opt_level": "3", "debuginfo": 0, "debug_assertions": True,
            "overflow_checks": True, "test": True,
        }, "normal release libtest profile changed")
        expected_features = (["default", "native-v6-ha", "native-v6-storage"] if suite == "server"
                             else ["default", "native-v6-peer-ingress"])
        require(sorted(artifact["features"]) == expected_features,
                "unexpected test-only feature combination")
        binary = regular(Path(artifact["path"])).resolve(strict=True)
        require(binary.parent == build_path.parent, "retained libtest is outside its build receipt directory")
        expected_binary = ("retained-heptabao-server-libtest" if suite == "server"
                           else "retained-heptabao-ha-service-libtest")
        require(binary.name == expected_binary, "wrong retained libtest")
        binary_digest = artifact["sha256"]
        require(sha(binary) == binary_digest, "retained libtest digest mismatch")
        result["binary"] = artifact
        listed = owned("all-tests-list", [str(binary), "--list"], 60)
        result["inventory_process"] = listed
        require(listed["exit_code"] == 0 and not listed["timed_out"] and not listed["cancelled"]
                and listed["direct_child_reaped"] and not listed["remaining"],
                "libtest inventory did not terminate cleanly")
        actual_names = parse_inventory((output / "all-tests-list.stdout").read_text(errors="replace"))
        actual_set = set(actual_names)
        missing = [name for name in names if name not in actual_set]
        inventory = {
            "schema": "heptabao.actual-libtest-inventory.v1",
            "binary_sha256": binary_digest, "manifest_sha256": args.manifest_sha256,
            "actual_compiled_test_names": actual_names,
            "required_exact_test_names": names, "missing_required_names": missing,
            "required_unique_count": len(names), "compiled_count": len(actual_names),
            "original_60_present": all(name in actual_set for name in manifest["original_60_exact_names"]),
        }
        durable_json(output / "actual-test-inventory.public.json", inventory)
        for name in missing:
            rows[name]["status"] = "not_run_missing_from_libtest"
        new_pool_deadline = None
        terminal_reason = "not_run_after_runtime_failure"
        for group in groups:
            if cancellation["signal"] is not None:
                terminal_reason = "not_run_cancelled"
                break
            require(freeze(source) == baseline_identity, "source changed before next regression group")
            require(sha(binary) == binary_digest, "binary changed before next regression group")
            began = time.monotonic()
            group_deadline = began + group["max_seconds"]
            executed_here = []
            for name in group["required_exact_names"]:
                if name in executed or rows[name]["status"] != "not_run":
                    continue
                if cancellation["signal"] is not None:
                    terminal_reason = "not_run_cancelled"
                    break
                remaining = group_deadline - time.monotonic()
                if group["phase"] == "new":
                    if new_pool_deadline is None:
                        new_pool_deadline = time.monotonic() + manifest["new_runtime_pool_seconds"]
                    remaining = min(remaining, new_pool_deadline - time.monotonic(),
                                    group["per_test_seconds"])
                if remaining <= 0:
                    rows[name]["status"] = ("not_run_new_pool_budget" if group["phase"] == "new"
                                           else "not_run_original_group_budget")
                    continue
                ordinal = len(executed) + 1
                label = "test-" + str(ordinal).zfill(4)
                # Register at-most-once before starting any selected test.
                executed.add(name)
                rows[name].update({"status": "execution_outcome_unknown",
                                   "execution_group": group["label"],
                                   "process_receipt": label + ".public.json"})
                durable_json(output / (label + ".intent.public.json"), {
                    "name": name, "group": group["label"],
                    "binary_sha256": binary_digest, "cap_seconds": remaining,
                })
                process = owned(label, [str(binary), name, "--exact", "--nocapture", "--test-threads=1"],
                                remaining)
                text = (output / (label + ".stdout")).read_text(errors="replace")
                passed = one_exact_test_passed(
                    text, process["exit_code"], process["timed_out"], process["cancelled"],
                ) and process["direct_child_reaped"] and not process["remaining"]
                status = ("passed" if passed else "timed_out" if process["timed_out"]
                          else "cancelled" if process["cancelled"] else "failed")
                rows[name].update({"status": status, "execution_group": group["label"],
                                   "process_receipt": label + ".public.json",
                                   "elapsed_seconds": process["elapsed_seconds"],
                                   "exact_one_test_proved": passed})
                executed_here.append(name)
                durable_json(output / "progress.public.json", {
                    "schema": result["schema"], "source_commit": args.commit,
                    "expected_unique_tests": len(names), "attempted_once": len(executed),
                    "passed": sum(row["status"] == "passed" for row in rows.values()),
                    "completed_latest": name, "latest_status": status,
                }, replace=(output / "progress.public.json").exists())
                require(not process["remaining"], "owned process group cleanup is incomplete")
            group_receipts.append({
                "label": group["label"], "phase": group["phase"],
                "required_count": len(group["required_exact_names"]),
                "required_exact_names": group["required_exact_names"],
                "executed_here": executed_here,
                "elapsed_seconds": time.monotonic() - began,
                "cap_seconds": group["max_seconds"],
            })
            if cancellation["signal"] is not None:
                break
        require(freeze(source) == baseline_identity, "source changed during regression execution")
        require(sha(binary) == binary_digest, "retained binary changed during regression execution")
        require(sha(build_path) == args.build_result_sha256, "build receipt changed during regression execution")
        require(sha(manifest_path) == args.manifest_sha256, "manifest changed during regression execution")
        result["source_unchanged"] = True
        result["binary_unchanged"] = True
        result["admission_and_identity_checks_passed"] = True
        terminal_reason = "not_run_cancelled" if cancellation["signal"] else "not_run_unexpected"
    except BaseException as exc:
        result["failure_type"] = type(exc).__name__
        result["failure"] = str(exc)
        if cancellation["signal"]:
            terminal_reason = "not_run_cancelled"
    finally:
        # The persistent outer worker can still observe this controller's exit.
        cleanup = []
        for label, child in reversed(children):
            try:
                survivors = retire(child)
            except BaseException as exc:
                survivors = [{"observation_failed": type(exc).__name__}]
            cleanup.append({"label": label, "pid": child.pid, "exit_code": child.returncode,
                            "direct_child_reaped": child.returncode is not None,
                            "remaining": survivors})
        for row in rows.values():
            if row["status"] == "not_run":
                row["status"] = terminal_reason
        reached = {group["label"]: group for group in group_receipts}
        group_receipts = [
            reached.get(group["label"], {
                "label": group["label"], "phase": group["phase"],
                "required_count": len(group["required_exact_names"]),
                "required_exact_names": group["required_exact_names"],
                "executed_here": [], "elapsed_seconds": 0,
                "cap_seconds": group["max_seconds"], "group_not_started": True,
            }) for group in groups
        ]
        for group in group_receipts:
            coverage = [rows[name] for name in group["required_exact_names"]]
            group["passed_count"] = sum(row["status"] == "passed" for row in coverage)
            group["status"] = ("passed" if group["passed_count"] == group["required_count"] else "failed")
            group["shared_results_are_not_reexecuted"] = True
        counts = {}
        for row in rows.values():
            counts[row["status"]] = counts.get(row["status"], 0) + 1
        baseline_rows = [rows[name] for name in manifest["original_60_exact_names"]]
        cleanup_ok = all(row["direct_child_reaped"] and not row["remaining"] for row in cleanup)
        result.update({
            "tests": [rows[name] for name in names], "group_results": group_receipts,
            "counts": counts, "attempted_once": len(executed),
            "passed": counts.get("passed", 0),
            "original_60_passed": sum(row["status"] == "passed" for row in baseline_rows),
            "full_denominator_retained": len(rows) == manifest["expected_unique_tests"],
            "cleanup": cleanup, "all_owned_groups_empty": cleanup_ok,
            "cancellation_signal": cancellation["signal"], "terminal_ns": time.time_ns(),
        })
        passed = (counts.get("passed", 0) == len(names) and cleanup_ok
                  and result.get("admission_and_identity_checks_passed") is True
                  and not cancellation["signal"])
        result["status"] = "passed" if passed else "failed"
        durable_json(output / "result.public.json", result)
        print(json.dumps({
            "status": result["status"], "passed": result["passed"], "denominator": len(names),
            "original_60_passed": result["original_60_passed"],
            "result": str(output / "result.public.json"),
            "result_sha256": sha(output / "result.public.json"),
        }), flush=True)
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except AdmissionError as error:
        print(json.dumps({"status": "admission_refused_before_run", "reason": str(error)}), flush=True)
        raise SystemExit(2)
