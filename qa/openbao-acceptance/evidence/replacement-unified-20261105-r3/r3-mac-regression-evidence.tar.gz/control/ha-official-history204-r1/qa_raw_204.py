#!/usr/bin/env python3
"""Isolated loopback TLS negative QA for the control-only HTTP204 observer.
No HeptaBao/OpenBao process, private LAN, fixture credential or HA action is used.
"""
from __future__ import annotations
import ast
import hashlib
import http.client
import importlib.util
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import types

HERE = Path(__file__).resolve().parent
SOURCE = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r3/source")
COMMIT = "6b16a9292d046bbc42aec65045fa105aaa1ac5de"
TREE = "0de9c516e94a47cb89e2e0f5ac2146e60913cfef"
WIRE = HERE / "native_v6_ha_official_history_wire.py"
LIVE = HERE / "native_v6_ha_official_history_live.py"
RESULT = HERE / "qa.public.json"

def require(value, label):
    if not value:
        raise RuntimeError(label)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def frozen():
    def git(*args):
        return subprocess.check_output(["git", "-C", str(SOURCE), *args], text=True).strip()
    return (git("rev-parse", "HEAD") == COMMIT and git("rev-parse", "HEAD^{tree}") == TREE
            and not git("status", "--porcelain"))

def tls_case(name, chunks, expected, server_context, client_context, leaf_sha256,
             observer, *, hold_seconds=0.0, budget=1.0, legacy=False, ragged_eof=False):
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.bind(("127.0.0.1", 0))
    listener.listen(1)
    listener.settimeout(3)
    address = listener.getsockname()
    server_state = {"accepted": False, "request_complete": False}
    stop = threading.Event()

    def serve():
        try:
            tcp, _ = listener.accept()
            server_state["accepted"] = True
            tcp.settimeout(2)
            with server_context.wrap_socket(tcp, server_side=True, suppress_ragged_eofs=False) as peer:
                raw = bytearray()
                while b"\r\n\r\n" not in raw:
                    piece = peer.recv(4096)
                    require(piece and len(raw) + len(piece) <= 8192, "qa_request_bound")
                    raw.extend(piece)
                server_state["request_complete"] = True
                for delay, chunk in chunks:
                    if delay:
                        stop.wait(delay)
                    peer.sendall(chunk)
                if hold_seconds:
                    stop.wait(hold_seconds)
                if ragged_eof:
                    server_state["deliberate_ragged_eof"] = True
                    os.close(peer.detach())
                else:
                    server_state["tls_close_notify_started"] = True
                    # unwrap sends close_notify before waiting for the peer's reply.
                    # The strict client observation independently proves receipt.
                    peer.unwrap().close()
        except BaseException as exc:
            server_state["server_exception_type"] = type(exc).__name__
        finally:
            listener.close()

    thread = threading.Thread(target=serve, name="ha204-qa-" + name, daemon=True)
    thread.start()
    observed = False
    phase = "connect"
    observation = None
    error_type = None
    client = None
    connection = None
    began = time.monotonic()
    try:
        tcp = socket.create_connection(address, timeout=2)
        client = client_context.wrap_socket(tcp, server_hostname="127.0.0.1", suppress_ragged_eofs=False)
        require(hashlib.sha256(client.getpeercert(binary_form=True)).hexdigest() == leaf_sha256,
                "qa_same_connection_leaf_pin")
        if legacy:
            connection = http.client.HTTPConnection(*address, timeout=2)
            connection.sock = client
            connection.request("POST", "/v1/sys/storage/raft/snapshot", body=b"",
                               headers={"Connection": "close"})
            phase = "observer"
            response = connection.getresponse()
            body = response.read()
            observation = {"status": response.status, "body_bytes": len(body)}
            observed = response.status == 204 and body == b""
        else:
            client.sendall(b"POST /v1/sys/storage/raft/snapshot HTTP/1.1\r\n"
                           b"Host: 127.0.0.1\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
            phase = "observer"
            observation = observer(client, time.monotonic() + budget)
            observed = (
                observation["status"] == 204 and observation["raw_tls_http204"] is True
                and observation["peer_eof_observed"] is True
                and observation["tls_close_notify_observed"] is True
                and observation["body_bytes"] == 0
                and observation["body_sha256"] == hashlib.sha256(b"").hexdigest()
            )
    except BaseException as exc:
        error_type = type(exc).__name__
    finally:
        if connection is not None:
            connection.close()
        if client is not None:
            client.close()
        # Do not cancel the delayed-tail peer before its originally scheduled send.
        thread.join(timeout=4)
        if thread.is_alive():
            stop.set()
            listener.close()
            thread.join(timeout=2)
    infrastructure_ok = (phase == "observer" and server_state["accepted"]
                         and server_state["request_complete"] and not thread.is_alive())
    passed = infrastructure_ok and observed is expected
    if ragged_eof:
        passed = passed and not observed and error_type == "SSLEOFError" \
            and server_state.get("deliberate_ragged_eof") is True
    elif expected and not legacy:
        passed = passed and server_state.get("tls_close_notify_started") is True
    return {
        "name": name, "passed": passed, "expected_accepted": expected,
        "observer_accepted": observed, "observer_exception_type": error_type,
        "connection_ca_san_and_leaf_verified": phase == "observer",
        "peer_thread_joined": not thread.is_alive(),
        "suppress_ragged_eofs": False, "deliberate_ragged_eof": ragged_eof,
        "elapsed_seconds": time.monotonic() - began,
        "response_stream_sha256": hashlib.sha256(b"".join(chunk for _, chunk in chunks)).hexdigest(),
        "response_bytes_scheduled": sum(len(chunk) for _, chunk in chunks),
        "observation": observation,
        "isolated_deadline_seconds": budget if not legacy else None,
        "server": server_state,
    }

def main():
    os.umask(0o077)
    require(not RESULT.exists(), "existing_qa_result_refused")
    require(frozen(), "source_not_frozen")
    prep = json.loads((HERE / "preparation.public.json").read_text())
    for name, value in prep["derived_helper_sha256"].items():
        require(sha(HERE / name) == value, "derived_helper_pin_changed")
    wire = types.ModuleType("isolated_raw204_wire")
    wire.__file__ = str(WIRE)
    exec(compile(WIRE.read_text(), str(WIRE), "exec"), wire.__dict__)
    live_tree = ast.parse(LIVE.read_text())
    progress_node = next(n for n in live_tree.body
                         if isinstance(n, ast.FunctionDef) and n.name == "restore_progress_valid")
    namespace = {}
    exec(compile(ast.Module(body=[progress_node], type_ignores=[]), str(LIVE), "exec"), namespace)
    progress_valid = namespace["restore_progress_valid"]
    rows = []
    header = b"HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n"
    clzero = b"HTTP/1.1 204 No Content\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
    legacy_hidden_tail = header + b"unexpected-body"
    cases = [
        ("204_absent_length_eof", [(0, header)], True, 0, 1),
        ("204_zero_length_eof", [(0, clzero)], True, 0, 1),
        ("204_fragmented_header_eof", [(0, clzero[:8]), (0.01, clzero[8:34]),
                                       (0.01, clzero[34:])], True, 0, 1),
        ("reject_same_flight_body", [(0, legacy_hidden_tail)], False, 0, 1),
        ("reject_delayed_tls_tail", [(0, header), (0.03, b"x")], False, 0, 1),
        ("reject_nonzero_content_length", [(0, b"HTTP/1.1 204 No Content\r\nContent-Length: 1\r\n\r\n")], False, 0, 1),
        ("reject_transfer_encoding", [(0, b"HTTP/1.1 204 No Content\r\nTransfer-Encoding: chunked\r\n\r\n0\r\n\r\n")], False, 0, 1),
        ("reject_duplicate_content_length", [(0, b"HTTP/1.1 204 No Content\r\nContent-Length: 0\r\nContent-Length: 0\r\n\r\n")], False, 0, 1),
        ("reject_http200", [(0, b"HTTP/1.1 200 OK\r\nContent-Length: 0\r\n\r\n")], False, 0, 1),
        ("reject_truncated_header", [(0, b"HTTP/1.1 204 No Content\r\n")], False, 0, 1),
        ("reject_oversized_header", [(0, b"HTTP/1.1 204 No Content\r\nX-QA: " + b"a" * 66000 + b"\r\n\r\n")], False, 0, 1),
        ("reject_no_eof_before_original_deadline", [(0, header)], False, 0.3, 0.1),
        ("reject_malformed_header", [(0, b"HTTP/1.1 204 No Content\r\nmalformed\r\n\r\n")], False, 0, 1),
        ("reject_empty_response", [], False, 0, 1),
    ]
    with tempfile.TemporaryDirectory(prefix="ha204-loopback-", dir=HERE) as temporary:
        temp = Path(temporary)
        config = temp / "openssl.cnf"
        config.write_text("[req]\nprompt=no\ndistinguished_name=dn\nx509_extensions=v3\n"
                          "[dn]\nCN=heptabao-isolated-loopback-qa\n[v3]\n"
                          "basicConstraints=critical,CA:TRUE\n"
                          "keyUsage=critical,digitalSignature,keyEncipherment,keyCertSign\n"
                          "extendedKeyUsage=serverAuth\nsubjectAltName=IP:127.0.0.1\n")
        key, cert = temp / "key.pem", temp / "cert.pem"
        generated = subprocess.run(["/usr/bin/openssl", "req", "-x509", "-newkey", "rsa:2048",
            "-nodes", "-days", "1", "-keyout", str(key), "-out", str(cert),
            "-config", str(config)], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=20)
        require(generated.returncode == 0, "isolated_certificate_generation_failed")
        server_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        server_context.minimum_version = ssl.TLSVersion.TLSv1_2
        server_context.load_cert_chain(str(cert), str(key))
        client_context = ssl.create_default_context(cafile=str(cert))
        client_context.minimum_version = ssl.TLSVersion.TLSv1_2
        leaf_sha256 = hashlib.sha256(ssl.PEM_cert_to_DER_cert(cert.read_text())).hexdigest()
        for name, chunks, expected, hold, budget in cases:
            rows.append(tls_case(name, chunks, expected, server_context, client_context,
                leaf_sha256, wire.observe_raw_snapshot_204, hold_seconds=hold, budget=budget))
        legacy = tls_case("legacy_http_client_discards_identical_forbidden_body",
            [(0, legacy_hidden_tail)], True, server_context, client_context,
            leaf_sha256, wire.observe_raw_snapshot_204, legacy=True)
        rows.append(legacy)
        rows.append(tls_case("reject_missing_tls_close_notify", [(0, header)], False,
            server_context, client_context, leaf_sha256, wire.observe_raw_snapshot_204,
            ragged_eof=True))
    before = {"generation": 20, "replay_epoch": 2, "state_storage_format": "heptabao-state-records-v6"}
    after = {"generation": 23, "replay_epoch": 3, "state_storage_format": "heptabao-state-records-v6"}
    predicates = [
        ("independent_progress_accepts_all_three_frontiers", before, after, 15, 100, 103, True),
        ("generation_must_strictly_advance", before, dict(after, generation=20), 15, 100, 103, False),
        ("epoch_must_advance", before, dict(after, replay_epoch=2), 15, 100, 103, False),
        ("epoch_must_advance_exactly_once", before, dict(after, replay_epoch=4), 15, 100, 103, False),
        ("raft_must_strictly_advance", before, after, 15, 100, 100, False),
        ("raft_must_not_regress", before, after, 15, 100, 99, False),
        ("archive_generation_must_precede_local", before, after, 21, 100, 103, False),
        ("boolean_generation_is_not_integer_frontier", before, dict(after, generation=True), 15, 100, 103, False),
        ("negative_epoch_refused", dict(before, replay_epoch=-1), dict(after, replay_epoch=0), 15, 100, 103, False),
        ("formal_v6_format_required", before, dict(after, state_storage_format="legacy"), 15, 100, 103, False),
        ("missing_generation_refused", before, {"replay_epoch": 3}, 15, 100, 103, False),
    ]
    for name, first, last, generation, front, next_front, expected in predicates:
        observed = progress_valid(first, last, generation, front, next_front)
        rows.append({"name": name, "passed": observed is expected,
                     "expected_accepted": expected, "observed_accepted": observed})
    # Import only definitions to independently count the inherited check sets.
    # The fixture main() and constructors are deliberately never called.
    spec = importlib.util.spec_from_file_location("isolated_history204_definitions", LIVE)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    counts = {"base": len(module.direct.DIRECT_CHECKS), "extra": len(module.EXTRA_CHECKS),
              "combined": len(module.OfficialHistoryRun.required_checks)}
    rows.append({"name": "actual_inherited_and_extra_denominators_preserved",
                 "passed": counts == {"base": 98, "extra": 30, "combined": 128}, "counts": counts})
    unchanged = frozen() and all(sha(HERE / n) == v for n, v in prep["derived_helper_sha256"].items())
    rows.append({"name": "source_and_control_identity_unchanged", "passed": unchanged})
    previous_qa = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r1/control/ha-official-history204-r1/qa.public.json")
    require(sha(previous_qa) == "802b165524cf239752c41575372c5f8145a940d707a03bef26cfa78df89cb8e6",
            "original_28_qa_identity_changed")
    original_names = [row["name"] for row in json.loads(previous_qa.read_bytes())["checks"]]
    actual_names = [row["name"] for row in rows]
    require(len(original_names) == 28 and len(actual_names) == len(set(actual_names)) == 29
            and [name for name in actual_names if name != "reject_missing_tls_close_notify"] == original_names,
            "original28_or_single_additional_negative_changed")
    result = {
        "schema": "heptabao.ha-official-history204-isolated-qa.v1",
        "status": "passed" if all(row["passed"] for row in rows) else "failed",
        "source_commit": COMMIT, "source_tree": TREE, "source_unchanged": unchanged,
        "expected_checks": len(rows), "passed": sum(row["passed"] for row in rows),
        "checks": rows, "actual_loopback_tls_cases": len(cases) + 2,
        "original_28_exact_names_preserved": True,
        "original_28_names": original_names,
        "only_additional_case": "reject_missing_tls_close_notify",
        "strict_tls_close_notify_required": True, "suppress_ragged_eofs": False,
        "previous_28_did_not_cover_missing_close_notify": True,
        "previous_qa_path": str(previous_qa), "previous_qa_sha256": sha(previous_qa),
        "derived_helper_sha256": prep["derived_helper_sha256"],
        "preparation_sha256": sha(HERE / "preparation.public.json"),
        "qa_controller_sha256": sha(__file__),
        "raw204_response_uses_http_client_body_decoder": False,
        "legacy_comparison_uses_http_client": True,
        "original_product_http_seconds_unchanged": 15,
        "native_large_http_seconds_unchanged": 5,
        "isolated_qa_deadlines_do_not_change_product_budgets": True,
        "all_network_endpoints": "127.0.0.1 ephemeral owned listeners",
        "product_processes_started": False, "physical_ha_started": False,
        "production_changed": False, "real_credential_accessed": False,
        "ha_qualified": False, "finished_ns": time.time_ns(),
    }
    with RESULT.open("x") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
        output.flush()
        os.fsync(output.fileno())
    print(json.dumps({"status": result["status"], "passed": result["passed"],
        "expected": result["expected_checks"], "result": str(RESULT), "sha256": sha(RESULT),
        "failed": [r["name"] for r in rows if not r["passed"]]}, sort_keys=True))
    return 0 if result["status"] == "passed" else 1

if __name__ == "__main__":
    raise SystemExit(main())
