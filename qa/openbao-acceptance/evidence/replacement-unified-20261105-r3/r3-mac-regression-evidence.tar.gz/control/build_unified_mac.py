#!/usr/bin/env python3
"""Build frozen merged HeptaBao source and retain real Cargo artifacts."""
import argparse, hashlib, json, os, resource, shutil, signal, subprocess, time
from pathlib import Path
os.umask(0o077)
p=argparse.ArgumentParser()
for n in ("source","output","commit","tree","toolchain","cargo-home","target"):
    p.add_argument("--"+n,required=True)
a=p.parse_args()
source=Path(a.source).resolve(strict=True)
output=Path(a.output)
assert not output.exists() and output.is_absolute()
assert os.uname().sysname=="Darwin" and os.uname().machine=="arm64"
output.mkdir(mode=0o700)
children=[]
profile={
 "PATH":a.toolchain+":/opt/homebrew/bin:/usr/bin:/bin",
 "CARGO_HOME":a.cargo_home,"CARGO_TARGET_DIR":a.target,"CARGO_BUILD_JOBS":"2",
 "CARGO_PROFILE_RELEASE_OPT_LEVEL":"3","CARGO_PROFILE_RELEASE_CODEGEN_UNITS":"16",
 "CARGO_PROFILE_RELEASE_LTO":"false","CARGO_PROFILE_RELEASE_DEBUG":"0",
 "CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS":"true","CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS":"true",
 "CARGO_PROFILE_RELEASE_PANIC":"unwind","RUSTFLAGS":"","CARGO_TERM_COLOR":"never"}
env=dict(os.environ);env.update(profile);env.pop("CARGO_ENCODED_RUSTFLAGS",None)
def sha(path):
    with Path(path).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def write(name,data):
    with (output/name).open("x") as f:
        json.dump(data,f,indent=2,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
    fd=os.open(output,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
def git(*args):
    return subprocess.check_output(["/usr/bin/git","-C",str(source),*args],text=True,timeout=30).strip()
def freeze():
    return {"commit":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"status":git("status","--porcelain")}
def members(pgid):
    raw=subprocess.check_output(["/bin/ps","-axo","pid=,ppid=,pgid=,stat="],text=True,timeout=10)
    return [line.strip() for line in raw.splitlines() if len(line.split())>=4 and int(line.split()[2])==pgid]
def stop(child):
    if child.poll() is None:
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait(timeout=5)
    return members(child.pid)
class Cancelled(BaseException):pass
def on_signal(sig,frame):raise Cancelled(sig)
signal.signal(signal.SIGTERM,on_signal);signal.signal(signal.SIGINT,on_signal)
def owned(label,args,seconds):
    start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    timed=False
    with (output/(label+".stdout")).open("xb") as stdout,(output/(label+".stderr")).open("xb") as stderr:
        blocked=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGTERM,signal.SIGINT})
        try:
            child=subprocess.Popen(args,cwd=source,env=env,stdin=subprocess.DEVNULL,
                  stdout=stdout,stderr=stderr,start_new_session=True)
            children.append((label,child))
        finally:signal.pthread_sigmask(signal.SIG_SETMASK,blocked)
        try:code=child.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            timed=True;stop(child);code=child.returncode
        finally:
            if child.poll() is None:stop(child)
            stdout.flush();stderr.flush();os.fsync(stdout.fileno());os.fsync(stderr.fileno())
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    remaining=members(child.pid)
    rec={"label":label,"argv":args,"exit_code":code,"timed_out":timed,
      "elapsed_seconds":time.monotonic()-start,"outer_cap_seconds":seconds,
      "direct_child_reaped":child.returncode is not None,"owned_pgid":child.pid,"remaining":remaining,
      "children_user_cpu_seconds":after.ru_utime-before.ru_utime,
      "children_system_cpu_seconds":after.ru_stime-before.ru_stime,
      "cumulative_children_peak_rss_bytes":after.ru_maxrss,
      "rss_scope":"Darwin RUSAGE_CHILDREN high-water mark since this controller began",
      "stdout_sha256":sha(output/(label+".stdout")),"stderr_sha256":sha(output/(label+".stderr"))}
    write(label+".public.json",rec)
    assert not remaining,"owned build process group not empty"
    return rec
def cargo_events(label):
    rows=[]
    for line in (output/(label+".stdout")).read_text().splitlines():
        try:rows.append(json.loads(line))
        except json.JSONDecodeError:pass
    assert any(e.get("reason")=="build-finished" and e.get("success") is True for e in rows),"missing real build-finished"
    return rows
def retain(event,path,test,features=None):
    expected = ["default","native-v6-ha","native-v6-storage"] if features is None else features
    assert sorted(event["features"])==sorted(expected)
    assert event["profile"]=={"opt_level":"3","debuginfo":0,"debug_assertions":True,"overflow_checks":True,"test":test}
    original=Path(event["executable"]);assert original.is_file() and not original.is_symlink()
    assert original.resolve().is_relative_to(Path(a.target).resolve())
    digest=sha(original)
    with original.open("rb") as src,path.open("xb") as dst:
        shutil.copyfileobj(src,dst,1024*1024);dst.flush();os.fsync(dst.fileno())
    path.chmod(0o500);assert sha(path)==digest and sha(original)==digest
    return {"path":str(path),"sha256":digest,"bytes":path.stat().st_size,
      "compiler_executable":str(original),"features":event["features"],"profile":event["profile"],"fresh":event.get("fresh")}
result={"schema":"heptabao.unified-release-libtest-build.v1","status":"failed",
 "source_commit":a.commit,"source_tree":a.tree,"profile":profile,"started_ns":time.time_ns(),
 "controller_sha256":sha(__file__),"production_changed":False,"runtime_tests_started":False,
 "full_replacement_qualified":False,"stage_caps_seconds":{"release":1800,"libtest":1800,"native_ha_libtest":900}}
write("intent.public.json",result)
try:
    before=freeze();assert before=={"commit":a.commit,"tree":a.tree,"status":""}
    rustc=subprocess.check_output([str(Path(a.toolchain)/"rustc"),"-vV"],text=True,timeout=30)
    assert "release: 1.98.0" in rustc and "host: aarch64-apple-darwin" in rustc
    cargo=str(Path(a.toolchain)/"cargo")
    build=owned("normal-release-build",[cargo,"build","--release","--locked","--offline","-p","heptabao-server",
       "--bin","heptabao-server","--bin","heptabao-seed","--message-format=json-render-diagnostics"],1800)
    result["release_build"]=build
    assert build["exit_code"]==0 and not build["timed_out"],"normal release compilation failed"
    events=cargo_events("normal-release-build");artifacts={};(output/"artifacts").mkdir(mode=0o700)
    for name in ("heptabao-server","heptabao-seed"):
        matches=[e for e in events if e.get("reason")=="compiler-artifact" and e.get("target",{}).get("name")==name and e.get("executable")]
        assert len(matches)==1
        artifacts[name]=retain(matches[0],output/"artifacts"/name,False)
    assert freeze()==before
    receipt={"schema":"heptabao.native-default-build-result.v1","normal_default_candidate":True,
       "formal_qualification":False,"source_commit":a.commit,"source_tree":a.tree,"source_freeze_verified":True,
       "native_abi":"aarch64-apple-darwin","build_exit_code":0,"build_finished_success":True,"timed_out":False,
       "owned_group_survivors_after_wait":False,"elapsed_seconds":build["elapsed_seconds"],"command":build["argv"],
       "rustc_vv":rustc,"build_driver_path":__file__,"build_driver_sha256":sha(__file__),
       "cargo_events_sha256":build["stdout_sha256"],"cargo_stderr_sha256":build["stderr_sha256"],
       "requested_release_profile":{k:v for k,v in profile.items() if k.startswith("CARGO_PROFILE_RELEASE_")},
       "artifacts":artifacts}
    write("normal-release-result.public.json",receipt)
    native={"schema":"heptabao.native-build.v1","source_commit":a.commit,"source_tree":a.tree,
       "source_freeze_verified":True,"native_abi":"aarch64-apple-darwin","build_exit_code":0,
       "binary_sha256":artifacts["heptabao-server"]["sha256"],"features":artifacts["heptabao-server"]["features"],
       "provenance":{"result_path":str(output/"normal-release-result.public.json"),
        "result_sha256":sha(output/"normal-release-result.public.json"),"cargo_events_sha256":build["stdout_sha256"]}}
    write("native-build.public.json",native);result["artifacts"]=artifacts
    print(json.dumps({"phase":"release_built","commit":a.commit,"server_sha256":artifacts["heptabao-server"]["sha256"]}),flush=True)
    testbuild=owned("normal-libtest-build",[cargo,"test","--release","--locked","--offline","-p","heptabao-server",
      "--lib","--no-run","--message-format=json-render-diagnostics"],1800)
    result["libtest_build"]=testbuild
    assert testbuild["exit_code"]==0 and not testbuild["timed_out"],"normal libtest compilation failed"
    events=cargo_events("normal-libtest-build")
    matches=[e for e in events if e.get("reason")=="compiler-artifact" and e.get("profile",{}).get("test")
       and e.get("target",{}).get("name")=="heptabao_server" and e.get("executable")]
    assert len(matches)==1
    result["libtest_artifact"]=retain(matches[0],output/"retained-heptabao-server-libtest",True)
    assert freeze()==before and all(sha(v["path"])==v["sha256"] for v in artifacts.values())
    habuild=owned("native-ha-libtest-build",[cargo,"test","--release","--locked","--offline","-p","heptabao-ha-service",
      "--features","native-v6-peer-ingress","--lib","--no-run","--message-format=json-render-diagnostics"],900)
    result["ha_libtest_build"]=habuild
    assert habuild["exit_code"]==0 and not habuild["timed_out"],"native HA libtest compilation failed"
    events=cargo_events("native-ha-libtest-build")
    matches=[e for e in events if e.get("reason")=="compiler-artifact" and e.get("profile",{}).get("test")
       and e.get("target",{}).get("name")=="heptabao_ha_service" and e.get("executable")]
    assert len(matches)==1
    result["ha_libtest_artifact"]=retain(matches[0],output/"retained-heptabao-ha-service-libtest",True,
        ["default","native-v6-peer-ingress"])
    assert freeze()==before and all(sha(v["path"])==v["sha256"] for v in artifacts.values())
    result["source_unchanged"]=True;result["artifacts_unchanged"]=True;result["status"]="built"
except BaseException as exc:
    result["failure_type"]=type(exc).__name__;result["failure"]=str(exc)
finally:
    signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
    cleanup=[]
    for label,child in reversed(children):
        try:remaining=stop(child)
        except BaseException:remaining=["cleanup_observation_failed"]
        cleanup.append({"label":label,"pid":child.pid,"exit_code":child.returncode,
           "direct_child_reaped":child.returncode is not None,"remaining":remaining})
    if any(x["remaining"] or not x["direct_child_reaped"] for x in cleanup):result["status"]="failed"
    result["cleanup"]=cleanup;result["terminal_ns"]=time.time_ns()
    write("result.public.json",result)
    print(json.dumps({"status":result["status"],"result":str(output/"result.public.json"),
      "result_sha256":sha(output/"result.public.json"),"runtime_tests_started":False}),flush=True)
raise SystemExit(0 if result["status"]=="built" else 1)
