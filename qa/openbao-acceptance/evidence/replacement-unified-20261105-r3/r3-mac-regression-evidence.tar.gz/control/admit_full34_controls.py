#!/usr/bin/env python3
"""Bind the reviewed full34 process controls to the exact frozen R3 Python driver.
This control-only preparation starts no product and grants no full34 pass.
"""
import ast
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time

ROOT = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r3")
SOURCE = ROOT / "source"
CONTROL = ROOT / "control"
REVIEW = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r2/control")
COMMIT = "6b16a9292d046bbc42aec65045fa105aaa1ac5de"
TREE = "0de9c516e94a47cb89e2e0f5ac2146e60913cfef"
SOURCE_PINS = {
    "qa/openbao-acceptance/kv2_271_lossless_native_live.py": "15cc68f3bd2442e4e4d3047f4fb30eecf826d8c4f54258732f97090005f542d4",
    "qa/openbao-acceptance/official_openbao_launcher.py": "5c11b432e1180fb40394fab382da774cf4171bf51431aab7e5823068cfba01d6",
    "qa/openbao-acceptance/owned_process.py": "0ee96c9f43b50ebd57ee8f0ef95f2431c441ec02c1799992588dbf50768745d0",
    "qa/openbao-acceptance/online_evidence.py": "3e15bc20dc4d1a75b4bd860252d887981020f1f9781be33d43a1c4ee26900ea9",
    "qa/single-node/smoke.py": "ced4e40a825d3d98a285598d40b58c61083cfc397d0859a783958d855a161971",
    "tools/migration/openbao271_kv2_native_large_migrate.py": "8043bce5e2443ca10f09d88dc854fc1a850ae4ac8b904763fbfc1ae3fa2de52a",
    "tools/migration/kv2_native_large_http_once.py": "ea7b2e7c63e07ec0ae6035511a13f372d96081992022d3a9b2f4f3f39a13d455",
    "tools/migration/openbao270_kv2_migrate.py": "7d49451fc876040ad1887de5170b6255a0a569d79894141e34c201d6d369f607",
    "tools/migration/kv2_lossless_raw.py": "633470fd47ca5d402fb2e175ecf57aaf43d9fa6c27b8ba4885d9fc43d4a989d2",
}
CONTROL_PINS = {
    "run_full34_mac_guarded.py": "888335a3bed213f2614d2665a4c5fc370a2cd4a5117a3c551e093056b3e6dba2",
    "full34_process_custody.py": "c32a4f3091a1ff7b105ac54099fbdeaf68c6e9aeb41aa5ff829b507857ee31cb",
}
QA_PINS = {
    "full34-custody-qa-r1/result.public.json": "2ea20e0e93282499dfbd72ac2e4a4bce4d307925e34856ef20f3d26d8e03effa",
    "full34-loader-inert-qa-r1/result.public.json": "a81bd3f87fb7a3259e1ef1bc85dfd82d3ec6d2b74c6c142dc86e7f50b7006d9a",
}
AUDIT_SHA = "8fb67882dae8f37030a21ed33b343da336dcfc77ee4df8cc5e80570a2d33bf5f"
PYTHON_SHA = "cebfcc4ac431ff7a2179bc6eff7e5c6bdae48b564eeab2d504bef6173a2cfc13"

def require(value, label):
    if not value:
        raise RuntimeError(label)

def regular(path):
    path = Path(path)
    require(stat.S_ISREG(path.lstat().st_mode), "nonregular_control_input")
    return path

def sha(path):
    return hashlib.sha256(regular(path).read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(
        ["/usr/bin/git", "-C", str(SOURCE), *args], text=True, timeout=30,
    ).strip()

def frozen():
    require(git("rev-parse", "HEAD") == COMMIT and git("rev-parse", "HEAD^{tree}") == TREE
            and not git("status", "--porcelain", "--untracked-files=all"),
            "candidate_source_not_frozen")

def main():
    os.umask(0o077)
    require(sys.version_info[:3] == (3, 14, 3) and __debug__, "reviewed_interpreter_required")
    interpreter = Path(sys.executable).resolve(strict=True)
    require(sha(interpreter) == PYTHON_SHA, "reviewed_interpreter_changed")
    frozen()
    freeze_receipt = regular(CONTROL / "r3-source-freeze-remote.public.json")
    freeze_digest = sha(freeze_receipt)
    require(freeze_digest == "85c3f13d2880526cfa1178cec3e3fd31d422c49684627fd5ffaa2b1f22be79fc",
            "independently_admitted_source_receipt_changed")
    audit_path = REVIEW / "full34-independent-coverage-audit.public.json"
    require(sha(audit_path) == AUDIT_SHA, "independent_review_changed")
    audit = json.loads(audit_path.read_bytes())
    require(audit["fresh_full34_executed"] is False and audit["production_changed"] is False,
            "static_audit_scope_changed")
    for relative, digest in SOURCE_PINS.items():
        require(sha(SOURCE / relative) == digest, "reviewed_driver_dependency_changed:" + relative)
        ast.parse((SOURCE / relative).read_text())
    checks = next(
        ast.literal_eval(node.value) for node in ast.parse((SOURCE / next(iter(SOURCE_PINS))).read_text()).body
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "CHECKS" for t in node.targets)
    )
    require(len(checks) == len(set(checks)) == 31
            and list(checks) == [row["name"] for row in audit["required_checks"]], "original31_changed")
    qa_records = []
    for relative, digest in QA_PINS.items():
        path = REVIEW / relative
        require(sha(path) == digest, "retained_inert_qa_changed")
        value = json.loads(path.read_bytes())
        require(value["status"] == "passed" and value["passed"] == 5 and len(value["cases"]) == 5
                and all(row["passed"] is True for row in value["cases"])
                and value["product_processes_started"] is False and value["network_used"] is False,
                "retained_inert_qa_scope_or_result_changed")
        qa_records.append({"path": str(path), "sha256": digest, "passed": 5,
                           "reused_only_for_identical_control_and_python_dependency_bytes": True})
    copied = []
    for name, digest in CONTROL_PINS.items():
        original, target = REVIEW / name, CONTROL / name
        require(sha(original) == digest, "reviewed_process_control_changed")
        raw = original.read_bytes()
        ast.parse(raw)
        if target.exists():
            require(sha(target) == digest and target.read_bytes() == raw,
                    "existing_r3_control_differs")
        else:
            with target.open("xb") as stream:
                stream.write(raw); stream.flush(); os.fsync(stream.fileno())
        copied.append({"path": str(target), "sha256": digest, "source_path": str(original),
                       "byte_identical_to_reviewed_control": True})
    frozen()
    require(sha(freeze_receipt) == freeze_digest, "source_freeze_receipt_changed")
    for relative, digest in SOURCE_PINS.items():
        require(sha(SOURCE / relative) == digest, "driver_dependency_changed_during_admission")
    result = {
        "schema": "heptabao.full34-control-candidate-admission.v1",
        "status": "admitted_pending_candidate_regressions",
        "source_commit": COMMIT, "source_tree": TREE, "source_unchanged": True,
        "source_freeze_path": str(freeze_receipt), "source_freeze_sha256": freeze_digest,
        "python_dependencies_compared_byte_for_byte": SOURCE_PINS, "controls": copied,
        "independent_audit_path": str(audit_path), "independent_audit_sha256": AUDIT_SHA,
        "inert_qa": qa_records, "inert_qa_rerun": False,
        "original31_exact_names": list(checks), "original_request_budgets_changed": False,
        "production_changed": False, "product_processes_started": False,
        "full34_executed": False, "full34_qualified": False,
        "required_candidate_regression_total": 181, "required_original176": 176,
        "required_original60": 60, "preparer_sha256": sha(__file__),
        "interpreter": str(interpreter), "interpreter_sha256": PYTHON_SHA,
        "created_ns": time.time_ns(),
    }
    out = CONTROL / "full34-control-admission.public.json"
    with out.open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True); stream.write("\n")
        stream.flush(); os.fsync(stream.fileno())
    print(json.dumps({"status": result["status"], "path": str(out), "sha256": sha(out),
                      "source_unchanged": True, "driver_dependencies": len(SOURCE_PINS),
                      "controls": copied, "full34_executed": False}, sort_keys=True))

if __name__ == "__main__":
    main()
