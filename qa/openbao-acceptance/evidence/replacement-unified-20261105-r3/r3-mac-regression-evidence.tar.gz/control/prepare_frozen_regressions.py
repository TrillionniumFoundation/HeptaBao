#!/usr/bin/env python3
"""Freeze exact regression names; this preparer never starts any libtest."""
import argparse
import ast
import hashlib
import importlib.util
import json
import os
import re
import subprocess
from pathlib import Path

ROOT = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r3")
SOURCE = ROOT / "source"
CONTROL = ROOT / "control"
BASELINE = Path("/Volumes/T5/hepta-vnext-recovery-20261013/continuation-20261105-cold-h2-normal-r1")
COMMIT = None
TREE = None
OLD_COMMIT = "df026fe323dd7cf0f0ec57d7d2d9c5a79897053c"
ADDITIONAL_PATH = None
ADDITIONAL_SPEC = None
ADDITIONAL_SHA256 = None


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def git(*args):
    return subprocess.check_output(
        ["/usr/bin/git", "-C", str(SOURCE), *args], text=True, timeout=30,
    ).strip()


def names_in(relative, prefix):
    text = (SOURCE / relative).read_text()
    names = re.findall(r"#\[test\]\s*fn\s+(\w+)", text)
    # A source file may now contain another explicitly declared sibling test module.
    # Keep the original module's names intact; exact compiled inventory is authoritative.
    sibling_names = {
        name.rsplit("::", 1)[1]
        for row in ADDITIONAL_SPEC["groups"]
        if relative in row["source_files"] and row["declared_module"] != prefix
        for name in row["required_exact_names"]
    }
    names = [name for name in names if name not in sibling_names]

    assert names and len(names) == len(set(names)), (relative, names)
    return [prefix + "::" + name for name in names]


def group(label, names, phase="new", source_files=None, scope=None):
    row = {"label": label, "phase": phase, "required_exact_names": names,
           "max_seconds": 600, "selection": "exact names, never a runtime substring filter"}
    if phase == "new":
        row["per_test_seconds"] = 120
    if source_files:
        row["source_files"] = source_files
    if scope:
        row["declared_module"] = scope
    return row


def file_records(paths):
    return [{"path": path, "sha256": sha(SOURCE / path), "bytes": (SOURCE / path).stat().st_size}
            for path in sorted(set(paths))]


def manifest(suite, groups, baseline_names, sources, references, pending):
    names = list(dict.fromkeys(name for item in groups for name in item["required_exact_names"]))
    return {
        "schema": "heptabao.unified-regression-manifest.v1",
        "suite": suite, "crate": "heptabao-server" if suite == "server" else "heptabao-ha-service",
        "source_commit": COMMIT, "source_tree": TREE,
        "expected_unique_tests": len(names),
        "original_60_exact_names": baseline_names,
        "original_regression_reference": references,
        "groups": groups, "source_files": file_records(sources),
        "new_runtime_pool_seconds": 600, "list_seconds": 60,
        "new_pool_policy": "All new groups share one 600-second pool; each selected test has at most 120 seconds.",
        "original_group_policy": "Each of the eight original groups retains its separate 600-second cap.",
        "duplicate_policy": "One exact execution per name and binary; group coverage may reference that same receipt.",
        "missing_or_zero_tests_policy": "Missing required names and zero/ignored tests fail qualification without shrinking the denominator.",
        "failure_policy": "Record every declared test, including unknown, failed, cancelled and not-run outcomes; never retry automatically.",
        "single_request_budgets_changed": False,
        "retries": 0, "product_tests_run": False, "full_replacement_qualified": False,
        "pending_external_gates": pending,
    }


R1_CONTROL = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r1/control")
R1_PINS = {
    "server-regression-manifest.public.json": "3ca16f73e62845fc1f31933cc8235a1ee83aef568808fa9e7e7fceb08bde99bc",
    "ha-regression-manifest.public.json": "a7fc36e1ad14d8472cc14d3561a411a0e440822beb44011c41a718373a7dcaed",
    "run_unified_regressions.py": "b5b936d1c75c2b7ef880aa0f60ca446bab479b30ddf0ccda9e0d095087e806f1",
    "aggregate_unified_regressions.py": "3f05af52c9f06cff95d98327272b223061d8de147ec66add65a326e4ba0e6fd9",
}

def unchanged_plan(value):
    keys = ("suite", "crate", "expected_unique_tests", "original_60_exact_names",
            "new_runtime_pool_seconds", "list_seconds", "retries")
    group_keys = ("label", "phase", "required_exact_names", "max_seconds",
                  "per_test_seconds", "selection", "declared_module")
    return {**{key: value[key] for key in keys},
            "groups": [{key: row[key] for key in group_keys if key in row}
                       for row in value["groups"]]}

def admit_upstream_controls():
    CONTROL.mkdir(mode=0o700, exist_ok=True)
    for name, expected in R1_PINS.items():
        assert sha(R1_CONTROL / name) == expected, ("upstream_control_changed", name)
    runner = CONTROL / "run_unified_regressions.py"
    raw = (R1_CONTROL / "run_unified_regressions.py").read_bytes()
    if runner.exists():
        assert runner.read_bytes() == raw, "existing_runner_not_exact_upstream"
    else:
        with runner.open("xb") as stream:
            stream.write(raw); stream.flush(); os.fsync(stream.fileno())
    return {suite: json.loads((R1_CONTROL / (suite + "-regression-manifest.public.json")).read_text())
            for suite in ("server", "ha")}

def additional_test_source_paths(value):
    # Hash the actual files of the original sixty as well, including redirect/ingress.
    required = {name.rsplit("::", 1)[1]
                for group in value["groups"] for name in group["required_exact_names"]}
    base = SOURCE / ("crates/" + value["crate"] + "/src")
    found = set()
    matched = set()
    for path in base.rglob("*.rs"):
        declarations = set(re.findall(r"#\[test\]\s*fn\s+(\w+)", path.read_text()))
        relevant = declarations & required
        if relevant:
            found.add(str(path.relative_to(SOURCE)))
            matched.update(relevant)
    assert required <= matched, ("source_test_declaration_missing", sorted(required - matched))
    return sorted(found)

def finish_rebinding(server, ha, upstream):
    assert ADDITIONAL_PATH is not None and ADDITIONAL_PATH.is_absolute()
    assert sha(ADDITIONAL_PATH) == ADDITIONAL_SHA256, "additional manifest changed"
    extras = ADDITIONAL_SPEC
    assert set(extras) == {"schema", "source_commit", "source_tree", "groups"}
    assert extras["schema"] == "heptabao.explicit-extra-regressions.v1"
    assert (extras["source_commit"], extras["source_tree"]) == (COMMIT, TREE)
    assert extras["groups"], "new candidate must predeclare its additional negative tests"
    new_by_suite = {"server": [], "ha": []}
    seen_new = {"server": set(), "ha": set()}
    for row in extras["groups"]:
        assert set(row) == {"suite", "label", "declared_module", "required_exact_names", "source_files"}
        suite = row["suite"]
        assert suite in new_by_suite and re.fullmatch(r"[a-z0-9_-]+", row["label"])
        prefix, names, paths = row["declared_module"], row["required_exact_names"], row["source_files"]
        assert names and len(names) == len(set(names)) and paths
        assert all(name.startswith(prefix + "::") and re.fullmatch(r"[A-Za-z0-9_:]+", name) for name in names)
        assert not (set(names) & seen_new[suite]), "duplicate additional exact test"
        seen_new[suite].update(names)
        crate = "heptabao-server" if suite == "server" else "heptabao-ha-service"
        assert all(path.startswith("crates/" + crate + "/src/") and ".." not in Path(path).parts for path in paths)
        declared_leaves = {name.rsplit("::", 1)[1] for name in names}
        actual_leaves = set()
        for path in paths:
            actual_leaves.update(re.findall(r"#\[test\]\s*fn\s+(\w+)", (SOURCE / path).read_text()))
        assert declared_leaves <= actual_leaves, "additional test is absent from frozen source"
        new_by_suite[suite].append(group(row["label"], names, source_files=paths, scope=prefix))
    transitions = {}
    for suite, value in (("server", server), ("ha", ha)):
        previous = upstream[suite]
        baseline_names = list(dict.fromkeys(name for row in previous["groups"] for name in row["required_exact_names"]))
        assert len(baseline_names) == (167 if suite == "server" else 9)
        assert not set(baseline_names) & seen_new[suite], "additional test substitutes a baseline case"
        generated = {name for row in value["groups"] for name in row["required_exact_names"]}
        assert set(baseline_names) <= generated
        assert generated <= set(baseline_names) | seen_new[suite], "undeclared new test in affected source"
        assert [row["label"] for row in value["groups"]] == [row["label"] for row in previous["groups"]]
        for current_group, previous_group in zip(value["groups"], previous["groups"]):
            assert set(previous_group["required_exact_names"]) <= set(current_group["required_exact_names"])
            current_group["required_exact_names"] = list(previous_group["required_exact_names"])
        value["expected_unique_tests"] = len(baseline_names)
        assert unchanged_plan(value) == unchanged_plan(previous), ("original exact plan changed", suite)
        labels = {row["label"] for row in value["groups"]}
        assert all(row["label"] not in labels for row in new_by_suite[suite])
        value["groups"].extend(new_by_suite[suite])
        value["baseline_exact_names"] = baseline_names
        value["additional_exact_test_names"] = [
            name for row in new_by_suite[suite] for name in row["required_exact_names"]]
        value["additional_manifest_sha256"] = sha(ADDITIONAL_PATH)
        value["expected_unique_tests"] = len(baseline_names) + len(seen_new[suite])
        original_paths = {row["path"] for row in previous["source_files"]}
        current_paths = {row["path"] for row in value["source_files"]}
        assert original_paths <= current_paths, ("original source inventory shrank", suite)
        paths = current_paths | set(additional_test_source_paths(value))
        paths.update(path for row in new_by_suite[suite] for path in row["source_files"])
        value["source_files"] = file_records(paths)
        previous_files = {row["path"]: row for row in previous["source_files"]}
        transitions[suite] = [
            {"path": row["path"], "previous_sha256": previous_files.get(row["path"], {}).get("sha256"),
             "current_sha256": row["sha256"], "current_bytes": row["bytes"],
             "read_from_current_frozen_source": True}
            for row in value["source_files"]
        ]
    aggregate_template = CONTROL / "aggregate_frozen_regressions.template.py"
    aggregate = aggregate_template.read_text()
    ast.parse(aggregate)
    aggregate_path = CONTROL / "aggregate_unified_regressions.py"
    if aggregate_path.exists():
        assert aggregate_path.read_text() == aggregate, "existing aggregate differs"
    else:
        with aggregate_path.open("x") as stream:
            stream.write(aggregate); stream.flush(); os.fsync(stream.fileno())
    return transitions

def main():
    os.umask(0o077)
    assert git("rev-parse", "HEAD") == COMMIT
    assert git("rev-parse", "HEAD^{tree}") == TREE
    assert not git("status", "--porcelain", "--untracked-files=all")
    upstream = admit_upstream_controls()
    old_groups_path = BASELINE / "control/normal-test-groups.public.json"
    old_result_path = BASELINE / "normal-release-tests-r1/result.public.json"
    old_groups = json.loads(old_groups_path.read_text())
    old_result = json.loads(old_result_path.read_text())
    assert old_result["source_commit"] == OLD_COMMIT
    assert sum(len(item["tests"]) for item in old_groups) == 44
    original = []
    groups = []
    for item in old_groups:
        assert item["runtime_seconds"] == 600
        original.extend(item["tests"])
        groups.append(group("original-" + item["label"], item["tests"], phase="original"))
    for key, label, count in [
        ("ingress_observer_regression", "original-ingress7", 7),
        ("cold_h2_regression", "original-cold-h2-9", 9),
    ]:
        names = old_result[key]["actual_test_names"]
        assert len(names) == count and old_result[key]["test_count"] == count
        original.extend(names)
        groups.append(group(label, names, phase="original"))
    assert len(original) == len(set(original)) == 60
    references = [
        {"path": str(old_groups_path), "sha256": sha(old_groups_path), "original_names": 44},
        {"path": str(old_result_path), "sha256": sha(old_result_path), "additional_actual_names": 16,
         "source_commit": OLD_COMMIT},
    ]
    root = "crates/heptabao-server/src/"
    cold = "service::native_v6_ha_pipeline_tests::historical_restore_tests::cold_dr_tests"
    specs = [
        ("prefetch", "engines/kv2_native_lossless_prefetch_tests.rs",
         "engines::kv::native_records::paged::lossless_export::prefetch::tests"),
        ("kv1-signed", "service_native_kv1_signed_lease_tests.rs",
         "service::native_storage::tests::kv1_registry_tests::signed_lease_tests"),
        ("pki-ha", "service_native_pki_ha_tests.rs",
         "service::native_v6_ha_pipeline_tests::native_pki_tests"),
        ("pki", "service_native_pki_tests.rs", "service::native_auth::pki_tests"),
        ("ssh", "service_native_ssh_tests.rs", "service::native_auth::ssh_tests"),
        ("storage", "service_native_storage_tests.rs", "service::native_storage::tests"),
        ("transit", "service_native_transit_tests.rs", "service::native_auth::transit_tests"),
        ("cold-restore", "service_native_v6_ha_cold_restore_tests.rs", cold),
        ("ssh-archive", "service_native_ssh_archive_tests.rs", "service::native_auth::ssh_tests::archive"),
        ("ssh-ha", "service_native_ssh_ha_tests.rs",
         "service::native_v6_ha_pipeline_tests::native_pki_tests::ssh_tests"),
        ("snapshot-clock", "ha_snapshot_clock.rs", "ha::snapshot_clock::tests"),
        ("snapshot-standby", "service_native_v6_ha_standby_http_tests.rs", cold + "::standby_http_tests"),
        ("snapshot-acl", "service_native_v6_ha_snapshot_acl_tests.rs", cold + "::standby_http_tests::acl_denial_tests"),
        ("cold-clock-floor", "service_native_v6_ha_cold_restore_clock_floor_tests.rs", cold + "::clock_floor_tests"),
        ("snapshot-transfer", "service_snapshot_transfer_tests.rs", "service::snapshot_transfer::tests"),
        ("snapshot-https", "http_snapshot_accept_tests.rs", "http::snapshot_accept_tests"),
        ("snapshot-framing", "http_snapshot.rs", "http::snapshot::tests"),
        ("ha-deadline", "ha_request_deadline_tests.rs", "ha::request_deadline_tests"),
    ]
    source_files = []
    source_count = {}
    for label, relative, prefix in specs:
        path = root + relative
        names = names_in(path, prefix)
        groups.append(group("new-" + label, names, source_files=[path], scope=prefix))
        source_files.append(path)
        source_count[path] = len(names)
    # The formal API file is a driver; its actual tests live in standby and ACL modules.
    support = [
        "service_native_v6_ha_formal_api_pipeline_tests.rs",
        "http_formal_api_fixture.rs", "ha_snapshot_test_support.rs",
    ]
    source_files.extend(root + relative for relative in support)
    all_names = {name for item in groups for name in item["required_exact_names"]}
    required_negative = [
        "service::native_storage::tests::configured_native_activation_rejects_unsupported_live_engine_without_retiring_v5",
        "service::native_storage::tests::configured_native_activation_rejects_unsupported_acme_without_retiring_v5",
        cold + "::cold_dr_unsupported_engine_archive_refused_without_destination_or_source_loss",
        cold + "::cold_dr_unsupported_acme_archive_refused_without_destination_or_source_loss",
    ]
    assert set(required_negative) <= all_names
    server = manifest("server", groups, original, source_files, references, [
        {"gate": "native-ha-clock-transport-and-quorum", "manifest": "ha-regression-manifest.public.json",
         "separate_binary": "retained-heptabao-ha-service-libtest"},
        {"gate": "formal-34MiB-KV2-migration-and-cold-recovery", "status": "requires_separate_current_binary_receipt"},
        {"gate": "physical-Mac-ROG-Pocket4-HA", "status": "not_claimed_by_in_process_tests"},
        {"gate": "AuthBus-real-client-cutover-and-cleanup", "status": "not_claimed_by_this_suite"},
    ])
    server["independent_negative_owner_cases"] = required_negative
    server["source_test_counts"] = source_count
    server["test_support_files_without_own_tests"] = [root + relative for relative in support]
    ha_root = "crates/heptabao-ha-service/src/"
    ha_specs = [
        ("native-ha-clock-transport", "snapshot_clock_transport_tests.rs",
         "v6_closure_quorum::tests::snapshot_clock_transport_tests"),
        ("native-ha-closure-quorum", "v6_closure_quorum_tests.rs", "v6_closure_quorum::tests"),
    ]
    ha_groups = []
    ha_sources = []
    for label, relative, prefix in ha_specs:
        path = ha_root + relative
        ha_groups.append(group(label, names_in(path, prefix), source_files=[path], scope=prefix))
        ha_sources.append(path)
    ha = manifest("ha", ha_groups, [], ha_sources, [], [
        {"gate": "server-original60-and-merged-source-regressions", "manifest": "server-regression-manifest.public.json"},
        {"gate": "physical-HA-and-production-cutover", "status": "not_claimed_by_transport_unit_tests"},
    ])
    assert ha["expected_unique_tests"] == 9
    hash_transitions = finish_rebinding(server, ha, upstream)
    runner_path = CONTROL / "run_unified_regressions.py"
    ast.parse(runner_path.read_text())
    spec = importlib.util.spec_from_file_location("unified_regression_runner", runner_path)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    for value in (server, ha):
        runner.validate_manifest(value)
    # Inert controller checks: no process launch and no product behavior claimed.
    good = "running 1 test\ntest example::proof ... ok\n\ntest result: ok. 1 passed; 0 failed; 0 ignored; 0 measured; 10 filtered out;\n"
    zero = "running 0 tests\n\ntest result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 11 filtered out;\n"
    ignored = "running 1 test\n\ntest result: ok. 0 passed; 0 failed; 1 ignored; 0 measured; 10 filtered out;\n"
    assert runner.one_exact_test_passed(good, 0, False, False)
    assert not runner.one_exact_test_passed(zero, 0, False, False)
    assert not runner.one_exact_test_passed(ignored, 0, False, False)
    assert not runner.one_exact_test_passed(good, 1, False, False)
    assert not runner.one_exact_test_passed(good, 0, True, False)
    assert not runner.one_exact_test_passed(good, 0, False, True)
    assert runner.parse_inventory("example::proof: test\n\n1 test, 0 benchmarks\n") == ["example::proof"]
    server_path = CONTROL / "server-regression-manifest.public.json"
    ha_path = CONTROL / "ha-regression-manifest.public.json"
    write(server_path, server)
    write(ha_path, ha)
    receipt = {
        "schema": "heptabao.unified-regression-preparation.v1",
        "source_commit": COMMIT, "source_tree": TREE, "source_unchanged": True,
        "controller_path": str(runner_path), "controller_sha256": sha(runner_path),
        "preparer_sha256": sha(__file__),
        "upstream_control_pins": R1_PINS,
        "original_167_plus_9_plan_exactly_retained": True,
        "baseline_manifests": {suite: {
            "path": str(R1_CONTROL / (suite + "-regression-manifest.public.json")),
            "sha256": R1_PINS[suite + "-regression-manifest.public.json"]}
            for suite in ("server", "ha")},
        "additional_manifest": {"path": str(ADDITIONAL_PATH), "sha256": sha(ADDITIONAL_PATH)},
        "expected_unique_tests": server["expected_unique_tests"] + ha["expected_unique_tests"],
        "additional_test_count": len(server["additional_exact_test_names"]) + len(ha["additional_exact_test_names"]),
        "all_current_source_hashes_recomputed": True,
        "source_hash_transitions": hash_transitions,
        "aggregate_controller_sha256": sha(CONTROL / "aggregate_unified_regressions.py"),
        "server_manifest": {"path": str(server_path), "sha256": sha(server_path),
                            "unique_tests": server["expected_unique_tests"], "original_tests": 60},
        "ha_manifest": {"path": str(ha_path), "sha256": sha(ha_path), "unique_tests": ha["expected_unique_tests"]},
        "syntax_and_inert_parser_checks": "passed",
        "product_tests_run": False, "cargo_started": False, "source_modified": False,
        "awaiting_successful_build_and_explicit_start": True,
    }
    assert git("rev-parse", "HEAD") == COMMIT and git("rev-parse", "HEAD^{tree}") == TREE
    assert not git("status", "--porcelain", "--untracked-files=all")
    assert sha(ADDITIONAL_PATH) == ADDITIONAL_SHA256, "additional manifest changed during preparation"
    write(CONTROL / "regression-preparation.public.json", receipt)
    print(json.dumps(receipt, sort_keys=True), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--commit", required=True)
    parser.add_argument("--tree", required=True)
    parser.add_argument("--additional-tests", required=True, type=Path)
    args = parser.parse_args()
    if not __debug__:
        raise RuntimeError("optimized_python_refused")
    assert args.root.is_absolute() and args.root.resolve(strict=True) == args.root
    assert re.fullmatch(r"[0-9a-f]{40}", args.commit) and re.fullmatch(r"[0-9a-f]{40}", args.tree)
    ROOT, COMMIT, TREE = args.root, args.commit, args.tree
    ADDITIONAL_PATH = args.additional_tests.resolve(strict=True)
    ADDITIONAL_SHA256 = sha(ADDITIONAL_PATH)
    ADDITIONAL_SPEC = json.loads(ADDITIONAL_PATH.read_text())
    SOURCE, CONTROL = ROOT / "source", ROOT / "control"
    main()
