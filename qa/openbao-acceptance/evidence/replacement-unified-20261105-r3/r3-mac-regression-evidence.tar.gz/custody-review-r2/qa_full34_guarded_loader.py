#!/usr/bin/env python3
"""Exercise the guarded full34 loader using inert children and actual owned_process helpers."""
import hashlib, importlib.util, json, os, select, signal, subprocess, sys, time
from pathlib import Path
HERE = Path(__file__).resolve().parent
MODULE = HERE / "full34_process_custody.py"
WRAPPER = HERE / "run_full34_mac_guarded.py"
spec = importlib.util.spec_from_file_location("full34_loader_qa_custody", MODULE)
custody = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = custody
spec.loader.exec_module(custody)
DRIVER = r'''import json, os, select, signal, subprocess, sys, time
from pathlib import Path
sys.path.insert(0, "/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r1/source/qa/openbao-acceptance")
import owned_process
mode, root = sys.argv[1], Path(sys.argv[2])
servers, worker = [], None
code = 1
try:
    program = "import signal,sys,time;signal.signal(signal.SIGTERM,lambda *_:sys.exit(0));print('ready',flush=True);time.sleep(60)"
    for label in ("source", "target"):
        process = owned_process.popen([sys.executable, "-I", "-S", "-B", "-c", program],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            label="inert_full34_" + label, action="TERM" if label == "source" else "KILL", stop_timeout=5)
        servers.append((label, process))
        if not select.select([process.stdout], [], [], 2)[0] or process.stdout.readline() != b"ready\n":
            raise RuntimeError("inert_server_not_ready")
    owned_process.run([sys.executable, "-I", "-S", "-B", "-c", "print('utility')"],
                      check=True, stdout=subprocess.DEVNULL, label="inert_utility")
    if mode == "natural":
        worker_program = "import subprocess,sys;p=subprocess.Popen([sys.executable,'-c','print(1)']);p.wait()"
    else:
        worker_program = "import subprocess,sys,time;subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)']);time.sleep(60)"
    worker = subprocess.Popen([sys.executable, "-I", "-S", "-B", "-c", worker_program],
        stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    (root / "ready.public.json").write_text(json.dumps({"mode": mode, "driver_pid": os.getpid()}))
    completed = False
    try:
        try:
            out, err = worker.communicate(b"", timeout=0.15 if mode == "inner_timeout" else 10)
            completed = True
            code = 0 if worker.returncode == 0 and not err else 1
        except subprocess.TimeoutExpired:
            if worker.returncode is None:
                os.killpg(worker.pid, signal.SIGKILL)
            worker.communicate(timeout=5)
            code = 1
    finally:
        if not completed and worker.returncode is None:
            os.killpg(worker.pid, signal.SIGKILL)
        if worker.returncode is None:
            worker.communicate(timeout=5)
except BaseException:
    code = 1
finally:
    for label, process in reversed(servers):
        owned_process.stop(process, action="TERM" if label == "source" else "KILL",
            timeout=5, expected_codes=(0,) if label == "source" else (-9,))
raise SystemExit(code)
'''

def case(root, driver, mode):
    directory = root / mode
    directory.mkdir(mode=0o700)
    nonce = os.urandom(16).hex()
    read_fd, write_fd = os.pipe()
    child = custody.ORIGINAL_POPEN(
        [sys.executable, "-I", "-S", "-B", str(WRAPPER), "--_child", str(driver),
         str(directory / "process-custody"), nonce, str(read_fd), custody.sha(MODULE),
         mode, str(directory)],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=True, pass_fds=(read_fd,))
    os.close(read_fd)
    birth = custody.capture_session(child)
    began = time.monotonic()
    try:
        if mode == "no_admission":
            os.close(write_fd); write_fd = None
        else:
            os.write(write_fd, b"1")
        if mode in ("term", "parent_eof"):
            until = began + 12
            while not (directory / "ready.public.json").exists():
                custody.require(custody.exit_event(child) is None and time.monotonic() < until,
                                "inert_loader_ready")
                time.sleep(0.01)
            if mode == "term":
                custody.signal_original_session(child, birth, signal.SIGTERM)
            else:
                os.close(write_fd); write_fd = None
        until = began + 20
        while custody.exit_event(child) is None:
            custody.require(time.monotonic() < until, "inert_loader_exit")
            time.sleep(0.01)
        finish = custody.finish_session(child, birth, time.monotonic() + 5)
        out, err = child.communicate(timeout=2)
        if write_fd is not None:
            os.close(write_fd); write_fd = None
        ownership = custody.private_json(directory / "process-custody/result.public.json")
        exit_receipt = custody.private_json(directory / "process-custody/driver-exit.public.json")
        nested = custody.observe_registered_sessions(directory / "process-custody", nonce, time.monotonic() + 5)
        ok = (finish["group_empty_before_first_reap"] and ownership["integrity"]
              and ownership["all_registered_original_children_reaped"]
              and ownership["all_registered_session_groups_empty_before_reap"]
              and nested["all_members_absent"] and exit_receipt["nonce"] == nonce)
        if mode == "natural":
            ok = ok and child.returncode == 0 and ownership["registered_original_children"] == 4
        else:
            ok = ok and child.returncode != 0
        if mode == "no_admission":
            ok = ok and ownership["registered_original_children"] == 0 \
                and not (directory / "ready.public.json").exists()
        return {"mode": mode, "passed": bool(ok), "exit_code": child.returncode,
                "registered_children": ownership["registered_original_children"],
                "cancellation_signal": ownership["cancellation_signal"],
                "main_session": finish, "nested_sessions": nested,
                "stdout_bytes": len(out), "stderr": err.decode(errors="replace")[-2000:],
                "elapsed_seconds": time.monotonic() - began}
    except BaseException as error:
        if write_fd is not None:
            os.close(write_fd); write_fd = None
        if child.returncode is None:
            try:
                custody.finish_session(child, birth, time.monotonic() + 5, force=True)
            except BaseException:
                pass
        return {"mode": mode, "passed": False, "error_type": type(error).__name__,
                "exit_code": child.returncode}
    finally:
        if write_fd is not None:
            os.close(write_fd)

def main():
    os.umask(0o077)
    root = HERE / "full34-loader-inert-qa-r1"
    custody.require(not root.exists(), "existing_qa_refused")
    root.mkdir(mode=0o700)
    driver = root / "inert_driver.py"
    with driver.open("x") as out:
        out.write(DRIVER)
    rows = [case(root, driver, mode) for mode in ("natural", "term", "inner_timeout", "parent_eof", "no_admission")]
    result = {"schema": "heptabao.full34-loader-inert-qa.v1",
              "status": "passed" if all(r["passed"] for r in rows) else "failed",
              "passed": sum(r["passed"] for r in rows), "expected": len(rows), "cases": rows,
              "wrapper_sha256": custody.sha(WRAPPER), "custody_sha256": custody.sha(MODULE),
              "qa_sha256": custody.sha(__file__), "frozen_source_modified": False,
              "original_driver_executed": False, "product_processes_started": False,
              "network_used": False, "request_budgets_changed": False,
              "uses_actual_frozen_owned_process_helper": True}
    custody.write_new(root / "result.public.json", result)
    print(json.dumps({"status": result["status"], "passed": result["passed"], "expected": len(rows),
                      "result": str(root / "result.public.json"), "sha256": custody.sha(root / "result.public.json"),
                      "failed": [r for r in rows if not r["passed"]]}, sort_keys=True))
    return 0 if result["status"] == "passed" else 1
if __name__ == "__main__":
    raise SystemExit(main())
