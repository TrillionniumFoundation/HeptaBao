#!/usr/bin/env python3
"""Owned inert Python processes only: full34 custody fault QA, no product/network."""
from __future__ import annotations
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
MODULE = HERE / "full34_process_custody.py"
spec = importlib.util.spec_from_file_location("full34_custody_qa_module", MODULE)
custody = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = custody
spec.loader.exec_module(custody)

def fake_driver(mode, root, nonce):
    os.umask(0o077)
    registry = custody.Registry(root / "registry", nonce).install()
    process = None
    result = {"mode": mode, "expected_failure": mode != "natural", "error_type": None}
    try:
        if mode == "natural":
            program = ("import subprocess,sys,signal,json;"
                       "p=subprocess.Popen([sys.executable,'-c','print(123)']);p.wait();"
                       "print(json.dumps({'blocked':[s.name for s in signal.pthread_sigmask(signal.SIG_BLOCK,set())]}))")
        elif mode == "orphan":
            program = ("import subprocess,sys;"
                       "subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)']);"
                       "print('parent-exits-with-live-descendant',flush=True)")
        else:
            program = ("import subprocess,sys,time;"
                       "subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)']);"
                       "print('ready',flush=True);time.sleep(60)")
        process = subprocess.Popen([sys.executable, "-I", "-S", "-B", "-c", program],
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                   start_new_session=True)
        custody.write_new(root / "ready.public.json", {"pid": os.getpid(), "guardian_pid": process.pid})
        began = time.monotonic()
        completed = False
        try:
            try:
                stdout, stderr = process.communicate(b"", timeout=0.15 if mode == "inner_timeout" else 10)
                completed = True
            except subprocess.TimeoutExpired:
                result["inner_original_deadline_fired"] = True
                if process.returncode is None:
                    os.killpg(process.pid, signal.SIGKILL)
                stdout, stderr = process.communicate(timeout=5)
            result.update(exit_code=process.returncode, stdout=stdout.decode(errors="replace"),
                          stderr=stderr.decode(errors="replace"), elapsed_seconds=time.monotonic() - began)
        finally:
            # These are the unchanged frozen driver's migration cancellation conditions.
            if not completed and process.returncode is None:
                os.killpg(process.pid, signal.SIGKILL)
            if process.returncode is None:
                process.communicate(timeout=5)
            result["original_wait_completed"] = process.returncode is not None
    except BaseException as error:
        result["error_type"] = type(error).__name__
    finally:
        receipt = registry.finish()
        result["registry_receipt"] = receipt
        custody.write_new(root / "driver.public.json", result)
    if mode == "natural":
        return 0 if result.get("exit_code") == 0 and receipt["integrity"] else 1
    return 1

def execute_case(root, mode, intervention):
    case = root / mode
    case.mkdir(mode=0o700)
    nonce = os.urandom(16).hex()
    original = custody.ORIGINAL_POPEN(
        [sys.executable, "-I", "-S", "-B", str(Path(__file__).resolve()),
         "--driver", mode, str(case), nonce],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=True)
    birth = custody.capture_session(original)
    began = time.monotonic()
    reason = None
    forced = intervention == "KILL"
    try:
        end = began + 20
        while not (case / "ready.public.json").exists() and custody.exit_event(original) is None:
            custody.require(time.monotonic() < end, "qa_driver_ready_deadline")
            time.sleep(0.01)
        if intervention == "TERM":
            custody.signal_original_session(original, birth, signal.SIGTERM)
        if forced:
            finish = custody.finish_session(original, birth, time.monotonic() + 5, force=True)
        else:
            while custody.exit_event(original) is None:
                custody.require(time.monotonic() < end, "qa_driver_exit_deadline")
                time.sleep(0.01)
            finish = custody.finish_session(original, birth, time.monotonic() + 5)
        stdout, stderr = original.communicate(timeout=2)
        final = custody.observe_registered_sessions(case / "registry", nonce, time.monotonic() + 6)
        child = custody.private_json(case / "driver.public.json") if (case / "driver.public.json").exists() else None
        state = child.get("registry_receipt") if child else None
        custody_ok = (finish["original_child_reaped"] and finish["group_empty_before_first_reap"]
                      and final["all_members_absent"])
        if forced:
            passed = custody_ok and original.returncode == -signal.SIGKILL and child is None
        else:
            passed = custody_ok and state is not None and state["all_registered_original_children_reaped"] \
                and state["all_registered_session_groups_empty_before_reap"]
            if mode == "natural":
                passed = passed and original.returncode == 0 and child["exit_code"] == 0 \
                    and '"blocked": []' in child["stdout"] and state["integrity"]
            elif mode == "inner_timeout":
                passed = passed and child.get("inner_original_deadline_fired") is True \
                    and child["original_wait_completed"] and child["exit_code"] == -9
            elif mode == "orphan":
                aborts = list((case / "registry").glob("*.abort.json"))
                passed = passed and child.get("exit_code") == -9 and any(
                    custody.private_json(p).get("reason") == "target_exit_with_descendants" for p in aborts)
            else:
                passed = passed and state["cancellation_signal"] == signal.SIGTERM \
                    and child["error_type"] == "Cancelled"
        return {"mode": mode, "intervention": intervention, "passed": bool(passed),
                "driver_exit_code": original.returncode, "driver_ownership": finish,
                "all_registered_sessions": final,
                "driver_receipt": str(case / "driver.public.json") if child else None,
                "elapsed_seconds": time.monotonic() - began,
                "stdout_bytes": len(stdout), "stderr": stderr.decode(errors="replace")[-2000:]}
    except BaseException as error:
        reason = type(error).__name__
        if original.returncode is None:
            try:
                custody.finish_session(original, birth, time.monotonic() + 5, force=True)
            except BaseException as cleanup_error:
                reason += "/cleanup:" + type(cleanup_error).__name__
        return {"mode": mode, "intervention": intervention, "passed": False, "failure": reason,
                "driver_exit_code": original.returncode}

def main():
    os.umask(0o077)
    output = Path(sys.argv[1]) if len(sys.argv) == 2 else HERE / "full34-custody-qa-r1"
    custody.require(output.is_absolute() and not output.exists(), "new_qa_root_required")
    output.mkdir(mode=0o700)
    cases = [
        execute_case(output, "natural", None),
        execute_case(output, "term", "TERM"),
        execute_case(output, "inner_timeout", None),
        execute_case(output, "orphan", None),
        execute_case(output, "forced_parent", "KILL"),
    ]
    result = {
        "schema": "heptabao.full34-custody-inert-qa.v1",
        "status": "passed" if all(c["passed"] for c in cases) else "failed",
        "expected_cases": len(cases), "passed": sum(c["passed"] for c in cases), "cases": cases,
        "product_processes_started": False, "network_used": False, "source_modified": False,
        "production_request_budgets_changed": False,
        "inert_timeout_seconds": 0.15, "timeout_scope": "inert fault fixture only",
        "module_sha256": custody.sha(MODULE), "qa_sha256": custody.sha(__file__),
        "interpreter": sys.executable, "interpreter_version": sys.version,
        "signals_to_enumerated_pid": False,
    }
    custody.write_new(output / "result.public.json", result)
    print(json.dumps({"status": result["status"], "passed": result["passed"], "expected": len(cases),
                      "result": str(output / "result.public.json"),
                      "sha256": custody.sha(output / "result.public.json"),
                      "failed": [r for r in cases if not r["passed"]]}, sort_keys=True))
    return 0 if result["status"] == "passed" else 1

if __name__ == "__main__":
    if len(sys.argv) == 5 and sys.argv[1] == "--driver":
        raise SystemExit(fake_driver(sys.argv[2], Path(sys.argv[3]), sys.argv[4]))
    raise SystemExit(main())
