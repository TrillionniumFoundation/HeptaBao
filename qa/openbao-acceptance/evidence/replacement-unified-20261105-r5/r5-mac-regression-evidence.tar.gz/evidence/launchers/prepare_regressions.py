import ast, hashlib, json, os, stat, subprocess, sys
from pathlib import Path
os.umask(0o077)
R3=Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r3")
R5=Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5")
C=R5/"control"
COMMIT="1f188df0f2affebb92702222e9fe5dfb4712194c"
TREE="74bcb2b2af2fc9d349f007cd847fc2f16c08c01a"
def sha(b): return hashlib.sha256(b).hexdigest()
def read(path):
    s=path.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and path.resolve(strict=True)==path
    return path.read_bytes()
def publish(path, raw):
    if path.exists():
        assert read(path)==raw, ("existing_different_control",str(path))
    else:
        with path.open("xb") as f: f.write(raw); f.flush(); os.fsync(f.fileno())
    return sha(raw)
def git(*args):
    return subprocess.check_output(["/usr/bin/git","-C",str(R5/"source"),*args],text=True,timeout=30).strip()
assert git("rev-parse","HEAD")==COMMIT and git("rev-parse","HEAD^{tree}")==TREE
assert git("status","--porcelain","--untracked-files=all")==""
freeze=C/"r5-source-freeze-remote.public.json"
assert sha(read(freeze))=="57b91c763fac2f9300a2d3ff30fd739b6fa84089889befd8083f74a91d6bcf5a"
pins={
"prepare_frozen_regressions.py":"d8ee97e7e79d05dd4b365e49d7ae565eeee601ac08295f7d95d1cc3d90ec5ea2",
"run_unified_regressions.py":"b5b936d1c75c2b7ef880aa0f60ca446bab479b30ddf0ccda9e0d095087e806f1",
"aggregate_frozen_regressions.template.py":"a7f66f9b8ea516bccaa2121864734118b9ebde120ac9b0f534d53ea8704096cc",
}
for name,digest in pins.items():
    raw=read(R3/"control"/name); assert sha(raw)==digest
    ast.parse(raw); publish(C/name,raw)
raw=read(R3/"control"/"additional-regressions.public.json")
assert sha(raw)=="8ae7d96eba62ff5faa922aec1616612f557795058685accc2297d0a7b780be76"
extra=json.loads(raw)
assert extra["source_commit"]=="6b16a9292d046bbc42aec65045fa105aaa1ac5de"
assert extra["source_tree"]=="0de9c516e94a47cb89e2e0f5ac2146e60913cfef"
assert sum(len(g["required_exact_names"]) for g in extra["groups"])==5
extra["source_commit"],extra["source_tree"]=COMMIT,TREE
extra_raw=(json.dumps(extra,indent=2,sort_keys=True)+"\n").encode()
publish(C/"additional-regressions.public.json",extra_raw)
note={
"schema":"heptabao.regression-semantic-change-scope.v1",
"source_commit":COMMIT,"source_tree":TREE,
"parent_source_commit":"6b16a9292d046bbc42aec65045fa105aaa1ac5de",
"parent_source_tree":"0de9c516e94a47cb89e2e0f5ac2146e60913cfef",
"expected_unique_tests":181,"expected_server_tests":172,"expected_ha_tests":9,
"original_176_exact_names_retained":True,"original_60_exact_names_retained":True,
"original_plan_budgets_retained":True,"original_assertion_text_completely_unchanged":False,
"changed_test_exact_name":"service::native_v6_ha_pipeline_tests::historical_restore_tests::cold_dr_tests::standby_http_tests::acl_denial_tests::formal_native_nonroot_snapshot_acl_and_historical_restore_use_original_update_actor",
"changed_test_oracle":"The former equality of the entire NativeV6PublishedRoot was invalid across legitimate clock-only publication. R5 uses the reviewed strict Auth/root byte oracle with clock-only differences; source bytes and support hashes are recomputed from this exact frozen candidate.",
"additional_support_change":"A read-only epoch-view derives equality while retaining the retained_roots field.",
"prior_failed_candidate_results_preserved":{
"mac_r3_aggregate_sha256":"d0b4ac8ff03392517e102df4b2a2c9167f2b377474809da64d91d92b1db78975",
"linux_r3_aggregate_sha256":"64e2b5cc57005ceb8a6c24cd8ca1033b4fc3c3e7a28236804123a39882cd00f5",
"mac_passed":180,"linux_passed":180,"denominator":181},
"prior_candidate_qualification_borrowed":False,
"product_tests_run_by_bootstrap":False,"production_changed":False,
"source_freeze_sha256":sha(read(freeze)),
"base_control_sha256":pins,
"additional_manifest_sha256":sha(extra_raw)}
publish(C/"regression-semantic-change-scope.public.json",(json.dumps(note,indent=2,sort_keys=True)+"\n").encode())
print(json.dumps({"stage":"r5_controls_rebound","source_commit":COMMIT,"source_tree":TREE,
"additional_manifest_sha256":sha(extra_raw),"changed_oracle_explicitly_declared":True}),flush=True)
os.execv(sys.executable,[sys.executable,"-I","-S","-B",str(C/"prepare_frozen_regressions.py"),"--root",str(R5),"--commit",COMMIT,"--tree",TREE,"--additional-tests",str(C/"additional-regressions.public.json")])
