from pathlib import Path
import hashlib, json, os, stat, subprocess, sys
def need(value,label):
    if not value: raise RuntimeError(label)
def digest(path):
    path=Path(path); need(stat.S_ISREG(path.lstat().st_mode),'nonregular_artifact')
    with path.open('rb') as stream: return hashlib.file_digest(stream,'sha256').hexdigest()
root=Path('/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5')
receipt=root/'build-r1/result.public.json'
expected='8e6fae0298c1b643b70d18e383e8ec64113f8b6b1d55e046daf30a1200c53528'
need(digest(receipt)==expected,'normal_build_receipt_changed')
build=json.loads(receipt.read_bytes())
need(build['schema']=='heptabao.unified-release-libtest-build.v1'
     and build['status']=='built' and build['source_unchanged'] is True
     and build['artifacts_unchanged'] is True,'normal_build_not_admitted')
need((build['source_commit'],build['source_tree'])==
     ('1f188df0f2affebb92702222e9fe5dfb4712194c','74bcb2b2af2fc9d349f007cd847fc2f16c08c01a'),'candidate_changed')
def git(*args): return subprocess.check_output(['/usr/bin/git','-C',str(root/'source'),*args],text=True,timeout=30).strip()
need(git('rev-parse','HEAD')==build['source_commit'] and git('rev-parse','HEAD^{tree}')==build['source_tree']
     and not git('status','--porcelain','--untracked-files=all'),'source_not_frozen')
artifacts=[*build['artifacts'].values(),build['libtest_artifact'],build['ha_libtest_artifact']]
for artifact in artifacts: need(digest(artifact['path'])==artifact['sha256'],'retained_artifact_changed')
need(digest(receipt)==expected,'normal_build_receipt_changed_during_admission')
need(digest(root/'control/run_unified_regressions.py')=='b5b936d1c75c2b7ef880aa0f60ca446bab479b30ddf0ccda9e0d095087e806f1','runner_changed')
need(digest(root/'control/regression-preparation.public.json')=='7780c7ae0dcbaf571d2ff9748a1268f0b4d1cd5ff22011ec9de9000faede9f99','preparation_changed')
need(digest(root/'control/regression-semantic-change-scope.public.json')=='4120d973733695ef0de18dc0f08c1b614a732cdbe7f15f8974db565baed4d46b','semantic_scope_changed')
print(json.dumps({'normal_build_gate':'admitted','build_sha256':expected,
                  'frozen_source_verified':True,'retained_artifacts_verified':len(artifacts),
                  'runtime_tests_started_before_gate':False}),flush=True)
args=json.loads(r'''["-I","-S","-B","/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5/control/run_unified_regressions.py","--source","/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5/source","--manifest","/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5/control/ha-regression-manifest.public.json","--manifest-sha256","06d3a44e334537b166150f841cf7d41cd3fa35a316ddaeb065fb29d673cb4b6d","--build-result","/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5/build-r1/result.public.json","--build-result-sha256","8e6fae0298c1b643b70d18e383e8ec64113f8b6b1d55e046daf30a1200c53528","--commit","1f188df0f2affebb92702222e9fe5dfb4712194c","--tree","74bcb2b2af2fc9d349f007cd847fc2f16c08c01a","--output","/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5/regression-ha-r1"]''')
os.execv(sys.executable,[sys.executable,*args])
