#!/usr/bin/env python3
"""Package immutable public R5 Mac evidence and explicitly preserved R3 failure chains; never run products."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

ROOT = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5")
SOURCE = ROOT / "source"
PUBLIC = ROOT / "public-evidence-r1"
R1 = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r1")
R2 = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r2")
COMMIT = "1f188df0f2affebb92702222e9fe5dfb4712194c"
TREE = "74bcb2b2af2fc9d349f007cd847fc2f16c08c01a"
PRIOR_MANIFEST_SHA = "a0f11db21600647f5c97a2ce43e58cffb08c416c9b9e290f3d4e608f4212d5d8"
R3 = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r3")
R3_PUBLIC = R3 / "public-evidence-r1"
GATE_ROOT = R3 / "control/full34-cross-host-gate-draft-r1"
R3_MANIFEST_SHA = "b8d6a160659165fcf81a06415c54b9eeaf165d115cd79c675a2ee7f6d782dabe"
R3_ARCHIVE_SHA = "9ba5b8407a2878f37843a948b29e1b0031deb9f67b3619dbe9e44746070b46f8"
R3_PACKAGER_SHA = "4bca620492b045539fe67f267a41e2130d98abbe6d46bf9fe6c9389050b38366"
PINS = {
    "build-r1/result.public.json": "8e6fae0298c1b643b70d18e383e8ec64113f8b6b1d55e046daf30a1200c53528",
    "build-r1/native-build.public.json": "75a9ed489126f09cedae59d97bb2351ed8c090c5ef41f3a1460b10567a2fb348",
    "build-r1/normal-release-result.public.json": "956d55feec61e4df51fa9d067ecb6e0712feb195de4b8aaa1e75e21a0aaf70ce",
    "regression-server-r1/result.public.json": "38fe026443a05e9fd501bd79918868fff7208fa96e40a04e23b7913396908681",
    "regression-ha-r1/result.public.json": "9b06ff1bc814e196138a34929da12ad0d6e8ba470883106b7f5e39b14c0f8b47",
    "regression-r1/result.public.json": "6917e6d2426f53f88c9a7f2e51cba18cdba002ec7d33f5a5be954c8aa4e5510c",
    "control/r5-source-freeze-remote.public.json": "57b91c763fac2f9300a2d3ff30fd739b6fa84089889befd8083f74a91d6bcf5a",
    "control/server-regression-manifest.public.json": "0f41bc4c6137a778a922baf99eff3772c5cae2cb5d3bf30417afd84b5dc9cf99",
    "control/ha-regression-manifest.public.json": "06d3a44e334537b166150f841cf7d41cd3fa35a316ddaeb065fb29d673cb4b6d",
    "control/regression-preparation.public.json": "7780c7ae0dcbaf571d2ff9748a1268f0b4d1cd5ff22011ec9de9000faede9f99",
    "control/regression-semantic-change-scope.public.json": "4120d973733695ef0de18dc0f08c1b614a732cdbe7f15f8974db565baed4d46b",
    "control/additional-regressions.public.json": "f786fc4e9038dbb63f54b3d4362ce13cf636be8e3cfd38a0001ae789725b2391",
    "control/run_unified_regressions.py": "b5b936d1c75c2b7ef880aa0f60ca446bab479b30ddf0ccda9e0d095087e806f1",
    "control/aggregate_unified_regressions.py": "a7f66f9b8ea516bccaa2121864734118b9ebde120ac9b0f534d53ea8704096cc",
    "control/build_unified_mac.py": "47afd2c97d8ba1e25b2f74b7014f510f21e36bc85e217d8cb067a394a023018e"
}
PRIOR_R3_PINS = {
    "build-r1/result.public.json": "a17913754a19a0434651b585d93bc08bdb07a1c0351904467c9248ed88f2aafb",
    "regression-server-r1/result.public.json": "2731396d5207a6c4252e92d826558594ee4e546df2d65ac962ddae908907b0fb",
    "regression-ha-r1/result.public.json": "49a8b5070e0bef8f3d212fc0cb8cc2cc86efc611da30b5d0856fa16c37a2d0c6",
    "regression-r1/result.public.json": "d0b4ac8ff03392517e102df4b2a2c9167f2b377474809da64d91d92b1db78975",
    "control/r3-source-freeze-remote.public.json": "85c3f13d2880526cfa1178cec3e3fd31d422c49684627fd5ffaa2b1f22be79fc",
    "control/server-regression-manifest.public.json": "ee44d8dc29f0762b532d13af3ecf2417638855e9464ca0bb052ae3f2dd35ba9e",
    "control/ha-regression-manifest.public.json": "132ae0404e4d40ac9adc159533176b0e54d4ab1b32928aabf8b9b977c2e15287",
    "control/regression-preparation.public.json": "0592a1684da73695f7bf3f00c311f087b5e3ff7db6d622819160942e776a603d",
    "control/additional-regressions.public.json": "8ae7d96eba62ff5faa922aec1616612f557795058685accc2297d0a7b780be76",
    "control/run_unified_regressions.py": "b5b936d1c75c2b7ef880aa0f60ca446bab479b30ddf0ccda9e0d095087e806f1",
    "control/aggregate_unified_regressions.py": "a7f66f9b8ea516bccaa2121864734118b9ebde120ac9b0f534d53ea8704096cc",
    "control/ha-official-history204-r1/preparation.public.json": "78ece336ec508c80010ecf48ebb180b95dd20147f970c1b52c1149a47e0d34d8",
    "control/ha-official-history204-r1/qa.public.json": "828682cc74d3e9856857be9bc4b32151adf82ac45af23e731f4d8fffe49c5137",
    "control/ha-official-history204-r1/native_v6_ha_official_history_live.py": "41519e00988b7ecf8a2a4683596e1fab5253803339d3d0f0b8f2e8970f83ab1e",
    "control/ha-official-history204-r1/native_v6_ha_official_history_wire.py": "71a81748c07f22a2584993239b28e2e02babe97e5de8fc1f6911d7353fa3bc22",
    "control/ha-official-history204-r1/qa_raw_204.py": "f07382f0c4cd3bd2a31882fb508ed26adbe448e28dae8f3c5c1ea877d816355b",
    "control/full34-control-admission.public.json": "37c165f3f1f355cb85b856e5fb5bd90740e12860627f0177428161333e2f1b1b",
    "control/full34-tls-eof-scope.public.json": "42f103309f2599bad38491ee626664df9b0bd6d629b1e960a7a64d75052f39e4",
    "control/run_full34_mac_guarded.py": "888335a3bed213f2614d2665a4c5fc370a2cd4a5117a3c551e093056b3e6dba2",
    "control/full34_process_custody.py": "c32a4f3091a1ff7b105ac54099fbdeaf68c6e9aeb41aa5ff829b507857ee31cb",
}
SCAN_SPECS = [
    ("pem_private_key", rb"-----BEGIN (?:[A-Z0-9]+ )?PRIVATE KEY-----"),
    ("vault_bearer_token", rb"(?<![A-Za-z0-9_])(?:hvs|hvb|hvr|s)\.[A-Za-z0-9_-]{16,}"),
    ("json_credential_value", rb'(?i)"(?:root_token|client_token|secret_id|private_key|unseal_key|recovery_key)"\s*:\s*"[^"\r\n]{1,}"'),
    ("auth_header_value", rb'(?im)(?:X-(?:Vault|Bao)-Token|Authorization)\s*["\x27]?\s*[:=]\s*["\x27]?(?:Bearer[ \t]+)?[A-Za-z0-9._~+/=-]{16,}'),
]
PATTERNS = [(name, re.compile(pattern)) for name, pattern in SCAN_SPECS]
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024

def require(value, label):
    if not value:
        raise RuntimeError(label)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()

def stamp(info):
    return tuple(getattr(info, key) for key in (
        "st_dev", "st_ino", "st_mode", "st_uid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns"))

def read_regular(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, "symlink_parent_or_relative_input")
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
            and before.st_uid == os.geteuid() and before.st_size <= MAX_FILE_BYTES,
            "nonregular_linked_foreign_or_oversized_input")
    with path.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        require(stamp(opened) == stamp(before), "input_identity_changed_on_open")
        raw = stream.read(MAX_FILE_BYTES + 1)
        after = os.fstat(stream.fileno())
    require(stamp(before) == stamp(after) and len(raw) == before.st_size
            and stamp(path.lstat()) == stamp(before), "input_changed_during_read")
    raw.decode("utf-8")
    require(b"\0" not in raw, "nontext_public_input")
    return raw, stamp(before)

def read_json(path, expected=None):
    raw, _ = read_regular(path)
    if expected:
        require(digest(raw) == expected, "pinned_public_input_changed:" + str(path))
    return json.loads(raw)

def write_new(path, raw):
    raw = canonical(raw) if not isinstance(raw, bytes) else raw
    with Path(path).open("xb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())

def git(*args):
    return subprocess.check_output(
        ["/usr/bin/git", "-C", str(SOURCE), *args], text=True, timeout=20).strip()

def source_frozen():
    require(git("rev-parse", "HEAD") == COMMIT and git("rev-parse", "HEAD^{tree}") == TREE
            and not git("status", "--porcelain", "--untracked-files=all"), "r5_source_not_frozen")

def scan(raw):
    return [{"category": name, "offset": match.start()}
            for name, pattern in PATTERNS for match in pattern.finditer(raw)]

def pack(payloads):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode="wb", filename="", mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name in sorted(payloads):
                raw = payloads[name]
                entry = tarfile.TarInfo(name)
                entry.size = len(raw); entry.mode = 0o644
                entry.uid = entry.gid = 0
                entry.uname = entry.gname = ""
                entry.mtime = 0
                entry.type = tarfile.REGTYPE
                archive.addfile(entry, io.BytesIO(raw))
    return target.getvalue()

def main():
    os.umask(0o077)
    source_frozen()
    original_manifest_path = R1 / "control/r1-regression-evidence-manifest.public.json"
    original = read_json(original_manifest_path, PRIOR_MANIFEST_SHA)
    require(original["file_count"] == len(original["entries"]) == 724
            and original["pattern_positive_witnesses_passed"] == 4
            and original["sensitive_pattern_hits"] == [], "original_public_manifest_changed")
    require(all(PurePosixPath(row["path"]).parts[0] in (
        "regression-server-r1", "regression-ha-r1", "regression-r1", "build-r1", "control")
        for row in original["entries"]), "prior_selection_scope_changed")
    require(not any(key in original for key in ("patterns", "regexes", "scanner_source")),
            "prior_patterns_available_review_required")
    for relative, expected in PINS.items():
        read_json(ROOT / relative, expected) if relative.endswith(".json") else require(
            digest(read_regular(ROOT / relative)[0]) == expected, "pinned_controller_changed")

    aggregate = read_json(ROOT / "regression-r1/result.public.json")
    require((aggregate["status"], aggregate["passed"], aggregate["expected_unique_tests"]) == ("passed", 181, 181)
            and aggregate["original_176_passed"] == 176 and aggregate["original_176_retained"] is True
            and aggregate["original_60_passed"] == 60 and aggregate["full_denominator_retained"] is True
            and aggregate["source_unchanged"] is True and aggregate["all_owned_groups_empty"] is True
            and len(aggregate["tests"]) == 181, "candidate_outcome_changed")
    build = read_json(ROOT / "build-r1/result.public.json")
    require(build["status"] == "built" and build["source_commit"] == COMMIT
            and build["source_tree"] == TREE, "normal_build_binding_changed")
    prep = read_json(ROOT / "control/regression-preparation.public.json")
    require(prep["expected_unique_tests"] == 181 and prep["additional_test_count"] == 5
            and prep["original_167_plus_9_plan_exactly_retained"] is True, "regression_plan_changed")
    qa = read_json(R3 / "control/ha-official-history204-r1/qa.public.json", PRIOR_R3_PINS["control/ha-official-history204-r1/qa.public.json"])
    require(qa["status"] == "passed" and qa["passed"] == qa["expected_checks"] == 29
            and qa["original_28_exact_names_preserved"] is True
            and qa["only_additional_case"] == "reject_missing_tls_close_notify",
            "strict_tls_qa_changed")
    require(next(row for row in qa["checks"] if row["name"] == "reject_missing_tls_close_notify")
            ["observer_exception_type"] == "SSLEOFError", "strict_tls_negative_not_actual")
    terminals = read_json(PUBLIC / "executor-terminals.public.json")
    require(len(terminals["observations"]) == 7, "executor_terminal_denominator_changed")

    native = read_json(ROOT / "build-r1/native-build.public.json")
    normal = read_json(ROOT / "build-r1/normal-release-result.public.json")
    require(native["schema"] == "heptabao.native-build.v1"
            and normal["schema"] == "heptabao.native-default-build-result.v1"
            and native["source_commit"] == normal["source_commit"] == COMMIT
            and native["source_tree"] == normal["source_tree"] == TREE
            and native["source_freeze_verified"] is True and normal["source_freeze_verified"] is True
            and native["native_abi"] == normal["native_abi"] == "aarch64-apple-darwin"
            and native["build_exit_code"] == normal["build_exit_code"] == 0
            and normal["build_finished_success"] is True and normal["normal_default_candidate"] is True,
            "normal_native_build_provenance_changed")
    require(native["binary_sha256"] == normal["artifacts"]["heptabao-server"]["sha256"]
            == build["artifacts"]["heptabao-server"]["sha256"]
            and native["features"] == normal["artifacts"]["heptabao-server"]["features"]
            == ["default", "native-v6-ha", "native-v6-storage"]
            and normal["artifacts"] == build["artifacts"]
            and native["provenance"]["result_sha256"] == PINS["build-r1/normal-release-result.public.json"]
            and native["provenance"]["result_path"] == str(ROOT / "build-r1/normal-release-result.public.json")
            and native["provenance"]["cargo_events_sha256"] == normal["cargo_events_sha256"]
            == build["release_build"]["stdout_sha256"], "normal_native_artifact_sha_chain")
    semantic = read_json(ROOT / "control/regression-semantic-change-scope.public.json")
    require(semantic["original_assertion_text_completely_unchanged"] is False
            and semantic["original_176_exact_names_retained"] is True
            and semantic["original_60_exact_names_retained"] is True
            and semantic["original_plan_budgets_retained"] is True
            and semantic["prior_candidate_qualification_borrowed"] is False,
            "r5_oracle_change_must_be_explicit")
    prior_r3_manifest = read_json(R3_PUBLIC / "r3-regression-evidence-manifest.public.json", R3_MANIFEST_SHA)
    prior_r3_receipt = read_json(R3_PUBLIC / "r3-regression-evidence-receipt.public.json")
    require(prior_r3_manifest["file_count"] == len(prior_r3_manifest["entries"]) == 798
            and prior_r3_manifest["candidate_acceptance_status"] == "failed"
            and prior_r3_manifest["candidate_passed"] == 180
            and prior_r3_receipt["manifest_sha256"] == R3_MANIFEST_SHA
            and prior_r3_receipt["archive_sha256"] == R3_ARCHIVE_SHA
            and prior_r3_receipt["packager_sha256"] == R3_PACKAGER_SHA,
            "prior_r3_failure_bundle_reference_changed")
    require(digest(read_regular(R3_PUBLIC / "pack_r3_public_evidence.py")[0]) == R3_PACKAGER_SHA,
            "prior_r3_scanner_source_changed")
    prior_policy = read_json(R3_PUBLIC / "evidence-policy.public.json")
    require(prior_policy["patterns"] == [{"name": n, "bytes_regex": p.decode("ascii")}
                                        for n, p in SCAN_SPECS], "r3_sensitive_patterns_not_exactly_reused")
    prior_mac = read_json(R3 / "regression-r1/result.public.json",
                         PRIOR_R3_PINS["regression-r1/result.public.json"])
    prior_linux = read_json(GATE_ROOT / "revision-r3/linux-public/aggregate.public.json",
                            "64e2b5cc57005ceb8a6c24cd8ca1033b4fc3c3e7a28236804123a39882cd00f5")
    for prior in (prior_mac, prior_linux):
        require(prior["status"] == "failed" and prior["passed"] == 180
                and prior["expected_unique_tests"] == 181 and prior["original_176_passed"] == 175
                and prior["original_60_passed"] == 60
                and prior["source_commit"] == "6b16a9292d046bbc42aec65045fa105aaa1ac5de"
                and prior["source_tree"] == "0de9c516e94a47cb89e2e0f5ac2146e60913cfef",
                "prior_failed_candidate_must_remain_failed")
        failed = [r for r in prior["tests"] if r["status"] != "passed"]
        require(len(failed) == 1 and failed[0]["name"] == semantic["changed_test_exact_name"]
                and failed[0]["process_receipt"] == "test-0128.public.json", "prior_failure_identity_changed")
    prior_terminals = read_json(R3_PUBLIC / "executor-terminals.public.json")
    require(len(prior_terminals["observations"]) == 10, "prior_terminal_denominator_changed")
    gate_cases = [("", 3, 27, "failed",
                   "894d64fe3eaa3055c5c96aa4f844db48e684bf7395faccd56a8403db1412a3c5"),
                  ("revision-r2", 29, 29, "passed",
                   "9ac12c9cec41b756e250b1fb88ea42c424c6a3886db5363029a7954ef6d82db0"),
                  ("revision-r3", 32, 32, "passed",
                   "f3fcdc874d3767f11f3fbc44787de28234e7ae4ff8ca32f14c6d707bea1c22ef")]
    for suffix, passed, total, status, pin in gate_cases:
        q = read_json(GATE_ROOT / suffix / "qa.public.json", pin)
        require(q["status"] == status and q["passed"] == passed and q["required_count"] == total
                and q["product_processes_started"] is False
                and q["positive_full_181_candidate_admission_observed"] is False,
                "cross_host_control_qa_scope_changed")

    witnesses = [
        ("pem_private_key", b"-----" + b"BEGIN RSA PRIVATE KEY" + b"-----"),
        ("vault_bearer_token", b"hvs" + b"." + b"w" * 36),
        ("json_credential_value", b'{"' + b'client_' + b'token": "' + b"w" * 24 + b'"}'),
        ("auth_header_value", b"X-Vault-" + b"Token: " + b"w" * 24),
    ]
    positive = []
    for name, payload in witnesses:
        hits = scan(payload)
        require(any(hit["category"] == name for hit in hits), "scanner_positive_control_failed")
        positive.append({"category": name, "actual_expected_pattern_hit": True,
                         "synthetic_witness_bytes_not_published": True})

    policy = {
        "schema": "heptabao.public-evidence-selection-and-scan-policy.v1",
        "source_commit": COMMIT, "source_tree": TREE,
        "prior_manifest_sha256": PRIOR_MANIFEST_SHA, "prior_entry_count": 724,
        "r3_policy_patterns_exactly_reused": True, "r3_packager_source_sha256": R3_PACKAGER_SHA,
        "r3_public_manifest_sha256": R3_MANIFEST_SHA, "r3_public_archive_sha256": R3_ARCHIVE_SHA,
        "prior_exact_scanner_patterns_available": False,
        "packager_byte_identical_to_prior_temporary_script": False,
        "selection": "Explicit public filenames and receipt-derived test ordinals; no recursive directory inclusion.",
        "regular_file_only": True, "symlinks_and_hardlinks_refused": True,
        "excluded": ["private-run", "credentials", "secret material", "snapshots", "backups",
                     "binary executables", "Git bundles", "runtime data stores", "archive payloads"],
        "patterns": [{"name": name, "bytes_regex": expression.decode("ascii")}
                     for name, expression in SCAN_SPECS],
        "positive_controls": positive, "positive_control_count": len(positive),
        "scan_claim": "No hits for these declared patterns in the explicitly selected public bytes; private paths are never selected.",
        "tar_format": "USTAR", "tar_regular_members_only": True,
        "tar_uid": 0, "tar_gid": 0, "tar_mode": "0644", "tar_mtime": 0,
        "gzip_mtime": 0, "gzip_filename": "", "gzip_compresslevel": 9,
        "maximum_file_bytes": MAX_FILE_BYTES, "maximum_selected_bytes": MAX_TOTAL_BYTES,
    }
    write_new(PUBLIC / "evidence-policy.public.json", policy)

    members = {}
    identities = {}
    selections = []
    def add(path, archive_name, category):
        archive_path = PurePosixPath(archive_name)
        lower_parts = [part.lower() for part in archive_path.parts]
        require(not archive_path.is_absolute() and all(part not in ("", ".", "..")
                for part in archive_path.parts) and len(archive_name.encode()) <= 255,
                "unsafe_member_name")
        require(not any("private" in part or part in ("credentials", "secrets", "snapshots", "backups")
                        for part in lower_parts), "private_member_name_refused")
        require(not archive_name.lower().endswith((
            ".pem", ".key", ".p12", ".pfx", ".crt", ".der", ".zip", ".tar", ".gz", ".tgz", ".bundle")),
            "credential_or_payload_extension_refused")
        require(archive_name not in members, "duplicate_public_member")
        raw, identity = read_regular(path)
        members[archive_name] = raw
        identities[archive_name] = (Path(path), identity)
        selections.append({"path": archive_name, "source": str(path), "category": category})
        require(sum(map(len, members.values())) <= MAX_TOTAL_BYTES, "public_byte_bound")
        return raw

    test_counts = {}
    for suite, expected, status, passed in (
            ("server", 172, "passed", 172), ("ha", 9, "passed", 9)):
        prefix = "regression-" + suite + "-r1"
        directory = ROOT / prefix
        result = read_json(directory / "result.public.json")
        require(result["status"] == status and result["passed"] == passed
                and result["expected_unique_tests"] == expected and result["attempted_once"] == expected
                and len(result["tests"]) == expected and result["source_unchanged"] is True,
                "suite_result_changed")
        inventory = read_json(directory / "actual-test-inventory.public.json")
        require(inventory["missing_required_names"] == [] and inventory["required_unique_count"] == expected,
                "compiled_inventory_gap")
        manifest = read_json(ROOT / ("control/" + suite + "-regression-manifest.public.json"))
        names = list(dict.fromkeys(name for group in manifest["groups"] for name in group["required_exact_names"]))
        require(len(names) == expected and set(names) == {row["name"] for row in result["tests"]},
                "suite_name_set_changed")
        labels = set()
        for row in result["tests"]:
            receipt_name = row["process_receipt"]
            require(re.fullmatch(r"test-[0-9]{4}\.public\.json", receipt_name), "test_receipt_not_public")
            label = receipt_name[:-len(".public.json")]
            require(label not in labels, "test_process_receipt_reused")
            labels.add(label)
            intent = read_json(directory / (label + ".intent.public.json"))
            process = read_json(directory / receipt_name)
            require(intent["name"] == row["name"] and process["argv"][1:] ==
                    [row["name"], "--exact", "--nocapture", "--test-threads=1"],
                    "actual_exact_test_changed")
            for suffix in (".intent.public.json", ".public.json", ".stdout", ".stderr"):
                raw = add(directory / (label + suffix), prefix + "/" + label + suffix, "actual_exact_test")
                if suffix in (".stdout", ".stderr"):
                    require(digest(raw) == process[suffix[1:] + "_sha256"], "original_test_log_changed")
        require(len(labels) == expected, "test_log_denominator_changed")
        test_counts[suite] = len(labels)
        for name in ("actual-test-inventory.public.json", "all-tests-list.public.json",
                     "all-tests-list.stdout", "all-tests-list.stderr",
                     "intent.public.json", "progress.public.json", "result.public.json"):
            add(directory / name, prefix + "/" + name, "suite_public_receipt")
    for name in ("intent.public.json", "result.public.json"):
        add(ROOT / "regression-r1" / name, "regression-r1/" + name, "aggregate_public_receipt")
    for name in ("intent.public.json", "native-build.public.json",
                 "normal-release-result.public.json", "result.public.json"):
        add(ROOT / "build-r1" / name, "build-r1/" + name, "normal_build_public_receipt")
    for stage in ("normal-release-build", "normal-libtest-build", "native-ha-libtest-build"):
        process = read_json(ROOT / "build-r1" / (stage + ".public.json"))
        require(process["exit_code"] == 0 and process["direct_child_reaped"] is True
                and process["remaining"] == [] and not process["timed_out"], "normal_build_stage_changed")
        for suffix in (".public.json", ".stdout", ".stderr"):
            raw = add(ROOT / "build-r1" / (stage + suffix), "build-r1/" + stage + suffix,
                      "normal_build_original_log_or_receipt")
            if suffix in (".stdout", ".stderr"):
                require(digest(raw) == process[suffix[1:] + "_sha256"], "original_build_log_changed")

    control_names = [
        "build_unified_mac.py", "run_unified_regressions.py", "aggregate_unified_regressions.py",
        "aggregate_frozen_regressions.template.py", "prepare_frozen_regressions.py",
        "server-regression-manifest.public.json", "ha-regression-manifest.public.json",
        "regression-preparation.public.json", "additional-regressions.public.json",
        "r5-source-freeze-remote.public.json", "regression-semantic-change-scope.public.json",
    ]
    for name in control_names:
        add(ROOT / "control" / name, "control/" + name, "explicit_public_controller_or_binding")
    ha_prefix = "control/ha-official-history204-r1"
    for name in ("native_v6_ha_official_history_live.py", "native_v6_ha_official_history_wire.py",
                 "preparation.public.json", "qa_raw_204.py", "qa.public.json", "protocol204.diff"):
        add(R3 / ha_prefix / name, "prior-r3-controls/" + ha_prefix + "/" + name,
            "prior_r3_strict_tls_control_qa_only_not_r5_transport")
    for name in ("server-regression-manifest.public.json", "ha-regression-manifest.public.json",
                 "r1-regression-evidence-manifest.public.json"):
        add(R1 / "control" / name, "baseline-r1/" + name, "prior_manifest_reference_only")
    for relative in (
        "full34-independent-coverage-audit.public.json", "full34-guarded-wrapper.diff",
        "qa_full34_process_custody.py", "qa_full34_guarded_loader.py",
        "full34-custody-qa-r1/result.public.json", "full34-loader-inert-qa-r1/result.public.json"):
        add(R2 / "control" / relative, "custody-review-r2/" + relative,
            "unchanged_control_inert_qa_reference_only")
    for relative in (
        "build-r1/result.public.json", "regression-server-r1/result.public.json",
        "regression-ha-r1/result.public.json", "regression-r1/intent.public.json",
        "regression-r1/result.public.json", "control/r3-source-freeze-remote.public.json",
        "control/server-regression-manifest.public.json", "control/ha-regression-manifest.public.json",
        "control/regression-preparation.public.json", "control/additional-regressions.public.json",
        "control/full34-control-admission.public.json", "control/full34-tls-eof-scope.public.json",
        "control/run_full34_mac_guarded.py", "control/full34_process_custody.py"):
        raw = add(R3 / relative, "prior-r3-mac/" + relative, "prior_r3_failed_candidate_original")
        if relative in PRIOR_R3_PINS:
            require(digest(raw) == PRIOR_R3_PINS[relative], "prior_r3_pinned_byte_changed")
    for name in ("r3-regression-evidence-manifest.public.json",
                 "r3-regression-evidence-receipt.public.json",
                 "evidence-policy.public.json", "pack_r3_public_evidence.py"):
        add(R3_PUBLIC / name, "prior-r3-mac/evidence/" + name, "prior_failed_bundle_reference_no_nested_archive")
    prior_mac_process = read_json(R3 / "regression-server-r1/test-0128.public.json")
    prior_linux_process = read_json(PUBLIC / "prior-r3-linux/test-0128.public.json")
    for label, directory, process in (
        ("mac", R3 / "regression-server-r1", prior_mac_process),
        ("linux", PUBLIC / "prior-r3-linux", prior_linux_process)):
        require(process["exit_code"] == 101 and process["timed_out"] is False
                and process["direct_child_reaped"] is True and process["remaining"] == [],
                "prior_failure_process_outcome_changed")
        for suffix in (".intent.public.json", ".public.json", ".stdout", ".stderr"):
            raw = add(directory / ("test-0128" + suffix),
                      "prior-r3-" + label + "/failure/test-0128" + suffix,
                      "prior_r3_original_failure_log_preserved")
            if suffix in (".stdout", ".stderr"):
                require(digest(raw) == process[suffix[1:] + "_sha256"], "prior_failure_log_sha_mismatch")
    add(PUBLIC / "prior-r3-linux/regression-executor-bindings.public.json",
        "prior-r3-linux/regression-executor-bindings.public.json", "prior_r3_linux_executor_bindings")
    add(PUBLIC / "prior-r3-linux/copy-manifest.public.json",
        "prior-r3-linux/copy-manifest.public.json", "prior_r3_linux_byte_copy_provenance")
    copy_manifest = read_json(GATE_ROOT / "revision-r3/evidence-copy-manifest.public.json")
    require(len(copy_manifest["files"]) == 8, "prior_linux_chain_denominator")
    for name, binding in copy_manifest["files"].items():
        raw = add(GATE_ROOT / "revision-r3/linux-public" / (name + ".public.json"),
                  "prior-r3-linux/receipts/" + name + ".public.json", "prior_r3_linux_original_receipt")
        require(digest(raw) == binding["sha256"], "prior_linux_receipt_digest_changed")
    for suffix, passed, total, status, pin in gate_cases:
        prefix = "cross-host-gate/" + (suffix or "revision-r1")
        directory = GATE_ROOT / suffix
        names = ["full34_cross_host_gate.py", "run_full34_mac_cross_host.py",
                 "full34_process_custody.py", "qa_cross_host_admission.py",
                 "prepare_controls.py", "wrapper.diff", "preparation.public.json",
                 "qa.public.json", "evidence-copy-manifest.public.json", "README.txt"]
        if suffix == "revision-r3":
            names.append("gate-v2-to-v3.diff")
        for name in names:
            add(directory / name, prefix + "/" + name, "cross_host_admission_control_qa_only")
    for observation in prior_terminals["observations"]:
        raw = add(R3_PUBLIC / observation["raw_response_path"],
                  "prior-r3-mac/evidence/" + observation["raw_response_path"],
                  "prior_r3_unmodified_executor_terminal")
        require(digest(raw) == observation["raw_response_sha256"],
                "prior_original_executor_terminal_changed")
    add(R3_PUBLIC / "executor-terminals.public.json", "prior-r3-mac/evidence/executor-terminals.public.json",
        "prior_r3_executor_terminal_index")
    launcher_index = read_json(PUBLIC / "launch-request-bindings.public.json")
    require(len(launcher_index["entries"]) == 3, "launcher_inventory")
    for row in launcher_index["entries"]:
        raw = add(PUBLIC / row["path"], "evidence/" + row["path"], "exact_original_executed_python_argument")
        require(digest(raw) == row["sha256"], "launcher_original_bytes_changed")
    add(PUBLIC / "launch-request-bindings.public.json", "evidence/launch-request-bindings.public.json",
        "exact_launch_argument_binding_index")
    for observation in terminals["observations"]:
        raw_path = PUBLIC / observation["raw_response_path"]
        raw = add(raw_path, "evidence/" + observation["raw_response_path"], "unmodified_executor_terminal")
        require(digest(raw) == observation["raw_response_sha256"]
                and json.loads(raw) == observation["value"][0], "executor_terminal_bytes_changed")
        state = observation["value"][0]
        require(state["output_complete"] is True and state["output_durable"] is True
                and state["state"] in ("failed", "succeeded"), "executor_not_terminal")
    add(PUBLIC / "executor-terminals.public.json", "evidence/executor-terminals.public.json",
        "executor_terminal_index")
    add(PUBLIC / "evidence-policy.public.json", "evidence/evidence-policy.public.json", "publication_policy")
    add(Path(__file__).absolute(), "evidence/pack_r5_public_evidence.py", "publication_controller")

    source_frozen()
    hits = []
    for name, raw in sorted(members.items()):
        hits.extend({"path": name, **hit} for hit in scan(raw))
    if hits:
        write_new(PUBLIC / "sensitive-scan-rejection.public.json",
                  {"status": "publication_refused", "hits": hits,
                   "matched_bytes_not_published": True, "candidate_acceptance_status": "regressions_passed_only"})
        raise RuntimeError("sensitive_pattern_hit_publication_refused")
    entries = [{"path": name, "bytes": len(raw), "sha256": digest(raw)}
               for name, raw in sorted(members.items())]
    manifest = {
        "schema": "heptabao.synthetic-regression-evidence-bundle.v2",
        "source_commit": COMMIT, "source_tree": TREE,
        "entries": entries, "file_count": len(entries),
        "scope": "R5 Mac complete181 exact regression evidence, normal-build/source-freeze/semantic-change records, preserved R3 Mac and Linux failure chains, and separately labelled control QA; no production credentials, backups, snapshots or client-store contents",
        "candidate_acceptance_status": "regressions_passed_only", "candidate_passed": 181, "candidate_denominator": 181,
        "original_176_passed": 176, "original_176_retained": True, "original_60_passed": 60,
        "test_log_denominators": test_counts, "failure_logs_preserved_without_redaction": True,
        "r5_assertion_text_completely_unchanged": False,
        "r5_oracle_semantic_change_receipt_sha256": PINS["control/regression-semantic-change-scope.public.json"],
        "r5_original_names_and_budgets_retained": True, "prior_candidate_qualification_borrowed": False,
        "r3_failed_chain_preserved": {"source_commit": "6b16a9292d046bbc42aec65045fa105aaa1ac5de",
            "mac_passed": 180, "linux_passed": 180, "denominator_each": 181,
            "mac_aggregate_sha256": PRIOR_R3_PINS["regression-r1/result.public.json"],
            "linux_aggregate_sha256": "64e2b5cc57005ceb8a6c24cd8ca1033b4fc3c3e7a28236804123a39882cd00f5",
            "original_test_0128_logs_both_hosts_included": True,
            "public_manifest_sha256": R3_MANIFEST_SHA, "public_archive_sha256": R3_ARCHIVE_SHA},
        "cross_host_admission_control_qa": {"original_failed": "3/27", "revision_r2": "29/29",
            "revision_r3": "32/32", "scope": "pure admission only; no full181 passing candidate substituted"},
        "linux_r5_regression_qualification_in_this_archive": False, "two_host_gate_not_claimed": True,
        "full_denominator_retained": True, "source_unchanged": True,
        "normal_build_result_sha256": PINS["build-r1/result.public.json"],
        "aggregate_result_sha256": PINS["regression-r1/result.public.json"],
        "prior_manifest_sha256": PRIOR_MANIFEST_SHA, "prior_manifest_entry_count": 724,
        "prior_exact_scanner_patterns_available": False,
        "packager_byte_identical_to_prior_temporary_script": False,
        "sensitive_pattern_hits": [], "pattern_positive_witnesses_passed": len(positive),
        "declared_sensitive_pattern_count": len(PATTERNS),
        "policy_sha256": digest(members["evidence/evidence-policy.public.json"]),
        "executor_terminal_count": 7, "executor_failed_states_preserved": [
            row["name"] for row in terminals["observations"] if row["value"][0]["state"] == "failed"],
        "prior_r3_strict_tls_control_qa": {"passed": 29, "expected": 29, "original28_retained": True,
                                 "scope": "loopback inert control QA; no physical HA product run"},
        "full34_original31_enforces_tls_close_notify": False,
        "formal_full34_executed_for_r5": False, "physical_ha_executed_for_r5": False,
        "build_cancellation_fault_qualification_claimed": False,
        "source_stage_executor_is_not_final_source_freeze": True,
        "prior_r3_executor_failed_states_preserved": [row["name"] for row in prior_terminals["observations"]
                                                    if row["value"][0]["state"] == "failed"],
        "authbus_qualified": False, "production_changed": False, "old_services_deleted": False,
        "full_replacement_qualified": False,
        "deterministic_format": {"tar": "USTAR", "uid": 0, "gid": 0, "mode": "0644",
                                 "mtime": 0, "gzip_mtime": 0, "gzip_filename": "", "gzip_level": 9},
        "selection": sorted(selections, key=lambda row: row["path"]),
    }
    manifest_raw = canonical(manifest)
    require(not scan(manifest_raw), "sensitive_pattern_in_public_manifest")
    payloads = {**members, "MANIFEST.public.json": manifest_raw}
    packed = pack(payloads)
    require(pack(payloads) == packed, "deterministic_pack_replay_differs")
    require(packed[:2] == b"\x1f\x8b" and packed[4:8] == b"\0\0\0\0"
            and not packed[3] & 8, "gzip_header_not_deterministic")
    tar_raw = gzip.decompress(packed)
    require(tar_raw[257:263] == b"ustar\0", "archive_not_ustar")
    with tarfile.open(fileobj=io.BytesIO(packed), mode="r:gz") as archive:
        observed = archive.getmembers()
        require(len(observed) == len(payloads) and {row.name for row in observed} == set(payloads),
                "archive_member_set_changed")
        for row in observed:
            require(row.isfile() and row.type == tarfile.REGTYPE and row.uid == row.gid == 0
                    and row.mode == 0o644 and row.mtime == 0 and not row.pax_headers
                    and row.uname == row.gname == "", "archive_metadata_changed")
            raw = archive.extractfile(row).read()
            require(raw == payloads[row.name] and digest(raw) == digest(payloads[row.name]),
                    "archive_member_bytes_changed")
            require(not scan(raw), "sensitive_pattern_after_compression")
    for name, (path, identity) in identities.items():
        raw, now = read_regular(path)
        require(now == identity and raw == members[name], "source_evidence_changed_during_pack")
    source_frozen()
    manifest_path = PUBLIC / "r5-regression-evidence-manifest.public.json"
    archive_path = PUBLIC / "r5-regression-evidence.tar.gz"
    write_new(manifest_path, manifest_raw)
    write_new(archive_path, packed)
    receipt = {
        "schema": "heptabao.public-evidence-package-receipt.v1",
        "status": "public_evidence_packaged", "candidate_acceptance_status": "regressions_passed_only",
        "source_commit": COMMIT, "source_tree": TREE,
        "manifest_path": str(manifest_path), "manifest_sha256": digest(manifest_raw),
        "manifest_bytes": len(manifest_raw), "archive_path": str(archive_path),
        "archive_sha256": digest(packed), "archive_bytes": len(packed),
        "entry_count": len(entries), "tar_member_count_including_manifest": len(payloads),
        "selected_uncompressed_bytes": sum(len(raw) for raw in members.values()),
        "deterministic_rebuild_identical": True, "every_tar_member_readback_verified": True,
        "every_source_evidence_byte_unchanged_after_pack": True,
        "sensitive_pattern_hits": [], "positive_controls_passed": len(positive),
        "candidate_passed": 181, "candidate_denominator": 181, "original176_passed": 176,
        "original60_passed": 60, "full_replacement_qualified": False,
        "product_processes_started_by_packager": False, "published_to_repository": False,
        "packager_sha256": digest(members["evidence/pack_r5_public_evidence.py"]),
    }
    write_new(PUBLIC / "r5-regression-evidence-receipt.public.json", receipt)
    print(json.dumps(receipt, sort_keys=True))

if __name__ == "__main__":
    main()
