#!/usr/bin/env python3
"""Read-only cross-host evidence admission; this module never starts a process."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
from types import SimpleNamespace

SCHEMA = "heptabao.full34-cross-host-regression-admission.v1"
COUNTS = {"server": 172, "ha": 9}
BASELINE_COUNTS = {"server": 167, "ha": 9}
BASELINE_PINS = {
    "server": "3ca16f73e62845fc1f31933cc8235a1ee83aef568808fa9e7e7fceb08bde99bc",
    "ha": "a7fc36e1ad14d8472cc14d3561a411a0e440822beb44011c41a718373a7dcaed",
}
AGGREGATE_PIN = "a7f66f9b8ea516bccaa2121864734118b9ebde120ac9b0f534d53ea8704096cc"
RUNNER_PINS = {
    "mac": "b5b936d1c75c2b7ef880aa0f60ca446bab479b30ddf0ccda9e0d095087e806f1",
    "linux": "5d352d362c01d42c7f6795efdf18b8b876c6af9899ebfb1eb5a4572420c1ec25",
}
FEATURES = ["default", "native-v6-ha", "native-v6-storage"]
HA_FEATURES = ["default", "native-v6-peer-ingress"]
PROFILE = {"opt_level": "3", "debuginfo": 0, "debug_assertions": True,
           "overflow_checks": True, "test": False}
RELEASE_ENV = {
    "CARGO_PROFILE_RELEASE_OPT_LEVEL": "3",
    "CARGO_PROFILE_RELEASE_CODEGEN_UNITS": "16",
    "CARGO_PROFILE_RELEASE_DEBUG": "0",
    "CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS": "true",
    "CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS": "true",
    "CARGO_PROFILE_RELEASE_LTO": "false",
    "CARGO_PROFILE_RELEASE_PANIC": "unwind",
}
PREFIX = "http::snapshot::reconciliation_projection_tests::"
EXTRAS = [PREFIX + name for name in (
    "native_pending_restore_projection_keeps_standard_envelope_and_exact_markers",
    "native_pending_restore_projection_rejects_forged_plain_json",
    "native_pending_restore_projection_keeps_non200_and_wrapped_paths",
    "native_pending_restore_projection_rejects_changed_markers_or_reference",
    "native_pending_restore_writer_refuses_unprojected_custody",
)]
LINUX_ARGUMENTS = (
    "linux-aggregate", "linux-preparation", "linux-libtest-build",
    "linux-release-controller", "linux-native-build", "linux-normal-release",
    "linux-server-result", "linux-ha-result",
)
MAX_RECEIPT_BYTES = 16 * 1024 * 1024


class AdmissionError(RuntimeError):
    pass


def require(ok, code):
    if not ok:
        raise AdmissionError(code)


def digest(value):
    require(isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None,
            "invalid_sha256")
    return value


def strict_object(pairs):
    out = {}
    for key, value in pairs:
        require(key not in out, "duplicate_json_key")
        out[key] = value
    return out


def invalid_constant(_value):
    raise AdmissionError("non_finite_json_number")


def identity(s):
    return (s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size,
            s.st_mtime_ns, s.st_ctime_ns, s.st_uid)


def raw_file(path, expected, *, retain=True):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path,
            "noncanonical_local_evidence_path")
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
            and before.st_uid == os.geteuid(), "non_owned_regular_evidence")
    if retain:
        require(before.st_size <= MAX_RECEIPT_BYTES, "oversize_public_receipt")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    h, chunks = hashlib.sha256(), []
    try:
        require(identity(os.fstat(fd)) == identity(before), "evidence_open_race")
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
            if retain:
                chunks.append(chunk)
        require(identity(os.fstat(fd)) == identity(before), "evidence_changed_during_read")
    finally:
        os.close(fd)
    require(identity(path.lstat()) == identity(before), "evidence_path_changed")
    require(h.hexdigest() == digest(expected), "evidence_digest_mismatch")
    return b"".join(chunks), {"local_path": str(path), "sha256": expected,
                            "bytes": before.st_size}


def read_receipt(path, expected):
    raw, binding = raw_file(path, expected)
    document = json.loads(raw.decode("utf-8"), object_pairs_hook=strict_object,
                          parse_constant=invalid_constant)
    require(isinstance(document, dict), "receipt_not_object")
    return {"document": document, "binding": binding}


def origin(value, root=None):
    require(isinstance(value, str), "invalid_origin_path")
    path = PurePosixPath(value)
    require(path.is_absolute() and ".." not in path.parts and str(path) == value,
            "noncanonical_origin_path")
    if root is not None:
        require(path.is_relative_to(root), "origin_outside_candidate_root")
    return path


def same_source(value, commit, tree, label):
    require((value.get("source_commit"), value.get("source_tree")) == (commit, tree),
            label + "_source_mismatch")


def clean_pair(value, commit, tree, label):
    before, after = value["source_before"], value["source_after"]
    require(before == after and before.get("status") == ""
            and (before.get("commit"), before.get("tree")) == (commit, tree),
            label + "_source_not_clean_and_unchanged")
    digest(before["cargo_lock_sha256"])


def release_profile(value, label):
    require(all(value.get(k) == v for k, v in RELEASE_ENV.items()),
            label + "_non_normal_release_profile")
    require(value.get("RUSTFLAGS", "") == "", label + "_extra_rustflags")


def artifact(record, test=False, ha=False):
    require(record.get("profile") == {**PROFILE, "test": test}, "artifact_profile")
    require(sorted(record.get("features", [])) == (HA_FEATURES if ha else FEATURES),
            "artifact_features")
    require(type(record.get("bytes")) is int and record["bytes"] > 0, "artifact_size")
    digest(record["sha256"])
    origin(record["path"])
    return record


def command_ok(row, label):
    require(row.get("exit_code") == 0 and type(row.get("exit_code")) is int
            and row.get("timed_out") is False and row.get("direct_child_reaped") is True
            and row.get("remaining") == [], label + "_command_not_complete")
    require(row.get("cancelled") in (None, False)
            and row.get("cancelled_by_signal") is None, label + "_command_cancelled")


def manifest_names(value):
    require(value.get("schema") == "heptabao.unified-regression-manifest.v1",
            "manifest_schema")
    suite = value["suite"]
    require(suite in COUNTS, "manifest_suite")
    groups, names, original, memberships = value["groups"], [], [], {}
    require(bool(groups), "empty_manifest")
    labels = []
    for group in groups:
        label = group["label"]
        require(re.fullmatch(r"[a-z0-9_-]+", label) is not None, "manifest_group_label")
        labels.append(label)
        exact = group["required_exact_names"]
        require(exact and len(exact) == len(set(exact)), "manifest_empty_duplicate_group")
        require(group["phase"] in ("original", "new") and group["max_seconds"] == 600,
                "manifest_group_budget")
        if group["phase"] == "new":
            require(group["per_test_seconds"] == 120, "manifest_test_budget")
        else:
            original.extend(exact)
        for name in exact:
            require(re.fullmatch(r"[A-Za-z0-9_:]+", name) is not None, "manifest_exact_name")
            if name not in memberships:
                names.append(name)
                memberships[name] = []
            memberships[name].append(label)
    require(len(labels) == len(set(labels)), "duplicate_manifest_labels")
    require(len(names) == value["expected_unique_tests"], "manifest_count")
    require(len(original) == len(set(original)) == (60 if suite == "server" else 0)
            and original == value["original_60_exact_names"], "original_60_manifest_identity")
    require(value["new_runtime_pool_seconds"] == 600 and value["list_seconds"] == 60
            and value["retries"] == 0 and value["single_request_budgets_changed"] is False,
            "manifest_global_budgets")
    return names, memberships


def plan_group(group):
    return {key: group[key] for key in (
        "label", "phase", "required_exact_names", "max_seconds",
        "per_test_seconds", "selection", "declared_module") if key in group}


def load_manifests(preparation, source, commit, tree):
    manifests, bindings = {}, {}
    for suite in ("server", "ha"):
        current = preparation[suite + "_manifest"]
        record = read_receipt(current["path"], current["sha256"])
        value = record["document"]
        same_source(value, commit, tree, suite + "_manifest")
        require(value["suite"] == suite and value["crate"] ==
                ("heptabao-server" if suite == "server" else "heptabao-ha-service"),
                "manifest_crate")
        names, memberships = manifest_names(value)
        require(len(names) == current["unique_tests"] == COUNTS[suite], "suite_denominator")
        old = preparation["baseline_manifests"][suite]
        require(old["sha256"] == BASELINE_PINS[suite], "original_176_baseline_pin")
        baseline = read_receipt(old["path"], BASELINE_PINS[suite])["document"]
        baseline_names, _ = manifest_names(baseline)
        require(len(baseline_names) == BASELINE_COUNTS[suite]
                and value["baseline_exact_names"] == baseline_names,
                "original_176_exact_identity")
        require([plan_group(g) for g in value["groups"][:len(baseline["groups"])]]
                == [plan_group(g) for g in baseline["groups"]], "original_176_plan_changed")
        require(value["original_60_exact_names"] == baseline["original_60_exact_names"],
                "original_60_names_changed")
        extras = EXTRAS if suite == "server" else []
        require(value["additional_exact_test_names"] == extras
                and names == list(dict.fromkeys(baseline_names + extras)),
                "additional_five_identity_or_order")
        files = value["source_files"]
        require(files and len({r["path"] for r in files}) == len(files), "source_file_inventory")
        for row in files:
            rel = PurePosixPath(row["path"])
            require(not rel.is_absolute() and ".." not in rel.parts, "unsafe_source_file")
            _, actual = raw_file(source / str(rel), row["sha256"], retain=False)
            require(actual["bytes"] == row["bytes"], "source_file_size")
        manifests[suite] = {"document": value, "names": names,
                            "memberships": memberships, "baseline_names": baseline_names}
        bindings[suite] = record["binding"]
    return manifests, bindings


def validate_preparations(mac, linux, manifests, commit, tree):
    for label, prep in (("mac", mac), ("linux", linux)):
        require(prep["schema"] == "heptabao.unified-regression-preparation.v1",
                label + "_preparation_schema")
        same_source(prep, commit, tree, label + "_preparation")
        require(prep["expected_unique_tests"] == 181
                and prep["controller_sha256"] == RUNNER_PINS[label]
                and prep["aggregate_controller_sha256"] == AGGREGATE_PIN,
                label + "_preparation_plan_or_controller")
        for suite in COUNTS:
            row = prep[suite + "_manifest"]
            require(row["unique_tests"] == COUNTS[suite]
                    and row["sha256"] == mac[suite + "_manifest"]["sha256"],
                    "cross_host_manifest_bytes_differ")
            require(prep["baseline_manifests"][suite]["sha256"] == BASELINE_PINS[suite],
                    label + "_baseline_manifest_changed")
    require(mac["source_unchanged"] is True
            and mac["original_167_plus_9_plan_exactly_retained"] is True
            and mac["all_current_source_hashes_recomputed"] is True, "mac_preparation_freeze")
    require(linux["status"] == "prepared" and linux["source_clean"] is True
            and linux["platform"] == "Linux" and linux["native_abi"] == "x86_64-unknown-linux-gnu"
            and linux["original_176_names_retained"] is True
            and linux["original_60_names_and_budgets_retained"] is True,
            "linux_preparation_freeze")
    for suite in COUNTS:
        files = manifests[suite]["document"]["source_files"]
        require(linux["source_files_verified"][suite] ==
                [{"path": r["path"], "sha256": r["sha256"]} for r in files],
                "linux_source_file_inventory_differs")
        transitions = mac["source_hash_transitions"][suite]
        require([{"path": r["path"], "sha256": r["current_sha256"],
                  "bytes": r["current_bytes"]} for r in transitions] == files
                and all(r["read_from_current_frozen_source"] is True for r in transitions),
                "mac_source_hashes_not_recomputed")


def validate_mac_build(record, commit, tree):
    build = record["document"]
    require(build["schema"] == "heptabao.unified-release-libtest-build.v1"
            and build["status"] == "built" and build["source_unchanged"] is True
            and build["artifacts_unchanged"] is True, "mac_build_not_frozen")
    same_source(build, commit, tree, "mac_build")
    release_profile(build["profile"], "mac")
    for key in ("release_build", "libtest_build", "ha_libtest_build"):
        command_ok(build[key], "mac_" + key)
    for record in (artifact(build["artifacts"]["heptabao-server"]),
                   artifact(build["libtest_artifact"], test=True),
                   artifact(build["ha_libtest_artifact"], test=True, ha=True)):
        raw_file(record["path"], record["sha256"], retain=False)
    return build


def validate_linux_build_chain(records, preparation, commit, tree):
    docs = {key: value["document"] for key, value in records.items()}
    build, release = docs["libtest_build"], docs["release_controller"]
    native, normal = docs["native_build"], docs["normal_release"]
    root = origin(preparation["controller_path"]).parent.parent
    require(origin(preparation["controller_path"]) == root / "control/run_unified_regressions.py",
            "linux_controller_origin")
    release_origin = origin(build["normal_release_result_path"], root)
    attempt = release_origin.parent
    require(attempt.parent == root
            and re.fullmatch(r"normal-release-r[1-9][0-9]*", attempt.name) is not None
            and release_origin == attempt / "result.public.json",
            "linux_normal_release_attempt_origin")
    for key, value in docs.items():
        same_source(value, commit, tree, "linux_" + key)
    require(build["schema"] == "heptabao.unified-linux-libtest-build.v1"
            and build["status"] == "built" and build["source_unchanged"] is True
            and build["release_artifacts_unchanged"] is True, "linux_libtest_build")
    require(build["controller_sha256"] == preparation["libtest_build_controller_sha256"],
            "linux_libtest_controller_binding")
    clean_pair(build, commit, tree, "linux_libtest")
    release_profile(build["profile"], "linux_libtest")
    require(build["shared_libtest_build_cap_seconds"] == 1800, "linux_libtest_budget")
    for key in ("libtest_build", "ha_libtest_build"):
        command_ok(build[key], "linux_" + key)
    require(release["schema"] == "heptabao.unified-linux-release-controller.v1"
            and release["status"] == "passed" and release["normal_default_features"] is True
            and release["fixture_features"] == []
            and release["prior_candidate_qualification_borrowed"] is False, "linux_release_controller")
    clean_pair(release, commit, tree, "linux_release")
    release_profile(release["profile"], "linux_release")
    command_ok(release["build"], "linux_normal_release")
    require(build["source_before"]["cargo_lock_sha256"] ==
            release["source_before"]["cargo_lock_sha256"], "linux_cargo_lock_changed")
    require(native["schema"] == "heptabao.native-build.v1"
            and native["build_exit_code"] == 0 and native["source_freeze_verified"] is True
            and native["native_abi"] == "x86_64-unknown-linux-gnu"
            and sorted(native["features"]) == FEATURES, "linux_native_receipt")
    require(normal["schema"] == "heptabao.native-default-build-result.v1"
            and normal["build_exit_code"] == 0 and normal["build_finished_success"] is True
            and normal["source_freeze_verified"] is True and normal["normal_default_candidate"] is True
            and normal["native_abi"] == "x86_64-unknown-linux-gnu"
            and normal["timed_out"] is False
            and normal["owned_group_survivors_after_wait"] is False, "linux_normal_result")
    require(normal["requested_release_profile"] == RELEASE_ENV, "linux_normal_profile")
    require("host: x86_64-unknown-linux-gnu\n" in normal["rustc_vv"], "linux_rust_abi")
    server = artifact(normal["artifacts"]["heptabao-server"])
    require(origin(server["path"], root) == attempt / "artifacts/heptabao-server",
            "linux_normal_artifact_origin")
    require(server == release["release_artifacts"]["heptabao-server"]
            == build["artifacts"]["heptabao-server"]
            and server["sha256"] == native["binary_sha256"], "linux_server_artifact_chain")
    artifact(build["libtest_artifact"], test=True)
    artifact(build["ha_libtest_artifact"], test=True, ha=True)
    require(origin(build["normal_release_result_path"], root) ==
            attempt / "result.public.json"
            and build["release_result_sha256"] == records["release_controller"]["binding"]["sha256"],
            "linux_release_controller_digest_chain")
    require(release["native_build_receipt_sha256"] == records["native_build"]["binding"]["sha256"],
            "linux_native_digest_chain")
    require(origin(native["provenance"]["result_path"], root) ==
            attempt / "normal-release-result.public.json"
            and native["provenance"]["result_sha256"] ==
            records["normal_release"]["binding"]["sha256"], "linux_native_provenance_chain")
    require(native["provenance"]["cargo_events_sha256"] == normal["cargo_events_sha256"]
            == release["build"]["stdout_sha256"], "linux_cargo_events_chain")
    require(normal["build_driver_sha256"] == release["controller_sha256"]
            and normal["commands_helper_sha256"] == release["commands_helper_sha256"]
            == build["commands_helper_sha256"], "linux_controller_helper_chain")
    require(normal["command"] == release["build"]["argv"]
            and normal["command"][1:] == [
                "build", "--release", "--locked", "--offline", "-p", "heptabao-server",
                "--bin", "heptabao-server", "--bin", "heptabao-seed",
                "--message-format=json-render-diagnostics"], "linux_normal_build_command")
    require(build["release_executor_receipt_sha256"] ==
            preparation["release_executor_receipt_sha256"], "linux_release_executor_link")
    digest(preparation["release_executor_receipt_sha256"])
    for suite in COUNTS:
        require(build["manifest_sha256"][suite + "-regression-manifest.public.json"] ==
                preparation[suite + "_manifest"]["sha256"], "linux_build_manifest_binding")
    return build, root


def validate_suite(label, suite, record, child_binding, aggregate, preparation, build,
                   build_digest, manifests, origin_root):
    child = record["document"]
    manifest = manifests[suite]
    names, memberships = manifest["names"], manifest["memberships"]
    require(record["binding"]["sha256"] == child_binding["sha256"], label + "_child_digest")
    origin(child_binding["path"], origin_root)
    same_source(child, aggregate["source_commit"], aggregate["source_tree"], label + "_" + suite)
    require(child["schema"] == "heptabao.unified-exact-regression-result.v1"
            and child["suite"] == suite and child["status"] == "passed",
            label + "_" + suite + "_not_passed")
    require(child["build_result_path"] == aggregate["build_result_path"]
            and child["build_result_sha256"] == build_digest
            and child["controller_sha256"] == RUNNER_PINS[label], label + "_child_build_binding")
    mb = preparation[suite + "_manifest"]
    require(child["manifest_path"] == child_binding["manifest_path"] == mb["path"]
            and child["manifest_sha256"] == child_binding["manifest_sha256"] == mb["sha256"],
            label + "_child_manifest_binding")
    artifact_key = "libtest_artifact" if suite == "server" else "ha_libtest_artifact"
    require(child["binary"] == build[artifact_key]
            and child_binding["libtest_sha256"] == build[artifact_key]["sha256"],
            label + "_child_test_binary")
    require(child["expected_unique_tests"] == child["attempted_once"] == child["passed"]
            == child_binding["expected_tests"] == child_binding["passed"] == COUNTS[suite],
            label + "_child_denominator")
    require(child_binding["status"] == "passed" and child_binding["same_normal_build_receipt"] is True,
            label + "_child_terminal_binding")
    for flag in ("source_unchanged", "binary_unchanged", "full_denominator_retained",
                 "all_owned_groups_empty", "admission_and_identity_checks_passed"):
        require(child[flag] is True, label + "_child_" + flag)
    require(child_binding["all_owned_groups_empty"] is True
            and child["cancellation_signal"] is None and child["test_retries"] == 0
            and child["single_request_budgets_changed"] is False
            and child["new_runtime_pool_seconds"] == 600, label + "_child_runtime_contract")
    rows = child["tests"]
    require([r["name"] for r in rows] == names, label + "_child_exact_inventory")
    require([r["process_receipt"] for r in rows] ==
            ["test-" + str(i).zfill(4) + ".public.json" for i in range(1, len(rows) + 1)],
            label + "_child_exact_once_process_inventory")
    for row in rows:
        require(row["status"] == "passed" and row["exact_one_test_proved"] is True,
                label + "_child_not_exact_one_test")
        require(row["requested_by_groups"] == memberships[row["name"]]
                and row["execution_group"] in memberships[row["name"]],
                label + "_child_group_membership")
    require(len(child["cleanup"]) == len(names) + 1
            and all(r["direct_child_reaped"] is True and r["remaining"] == []
                    and r["exit_code"] == 0 for r in child["cleanup"]), label + "_child_cleanup")
    command_ok(child["inventory_process"], label + "_inventory")
    expected_groups = manifest["document"]["groups"]
    require(len(child["group_results"]) == len(expected_groups), label + "_group_denominator")
    executed = []
    for actual, group in zip(child["group_results"], expected_groups):
        require(actual["label"] == group["label"] and actual["phase"] == group["phase"]
                and actual["required_exact_names"] == group["required_exact_names"]
                and actual["cap_seconds"] == group["max_seconds"] == 600, label + "_group_budget")
        executed.extend(actual["executed_here"])
    require(len(executed) == len(names) and set(executed) == set(names), label + "_group_exact_once")
    original_count = 60 if suite == "server" else 0
    require(child["original_test_denominator"] == original_count
            and child["original_60_passed"] == original_count, label + "_original_60_count")
    return [{"crate": manifest["document"]["crate"], **row} for row in rows]


def validate_aggregate(label, record, prep_record, build_record, children, manifests, root):
    value, prep, build = record["document"], prep_record["document"], build_record["document"]
    require(value["schema"] == "heptabao.unified-regression-aggregate.v1"
            and value["controller_sha256"] == AGGREGATE_PIN, label + "_aggregate_controller")
    require(value["status"] == "passed", label + "_aggregate_not_passed")
    same_source(value, prep["source_commit"], prep["source_tree"], label + "_aggregate")
    require(value["expected_unique_tests"] == value["passed"] == 181
            and value["expected_server_tests"] == 172 and value["expected_ha_tests"] == 9
            and value["original_176_passed"] == 176 and value["original_176_retained"] is True
            and value["original_60_passed"] == 60, label + "_aggregate_denominator")
    for flag in ("source_unchanged", "full_denominator_retained", "all_owned_groups_empty"):
        require(value[flag] is True, label + "_aggregate_" + flag)
    require(value["source_at_aggregation"] == {
        "commit": prep["source_commit"], "tree": prep["source_tree"], "status": ""},
        label + "_source_at_aggregation")
    require(value["preparation_sha256"] == prep_record["binding"]["sha256"]
            and value["build_result_sha256"] == build_record["binding"]["sha256"],
            label + "_aggregate_receipt_chain")
    require(origin(value["preparation_path"], root) == root / "control/regression-preparation.public.json",
            label + "_preparation_origin")
    expected_build_origin = (Path(build_record["binding"]["local_path"]) if label == "mac"
                             else root / "libtest-build-r1/build-result.public.json")
    require(value["build_result_path"] == str(expected_build_origin), label + "_build_origin")
    normal = build["artifacts"]["heptabao-server"]
    require(value["server_binary_path"] == normal["path"] and value["server_sha256"] == normal["sha256"]
            and value["server_libtest_sha256"] == build["libtest_artifact"]["sha256"]
            and value["ha_libtest_sha256"] == build["ha_libtest_artifact"]["sha256"],
            label + "_aggregate_artifact_binding")
    require([row["suite"] for row in value["children"]] == ["server", "ha"],
            label + "_aggregate_child_inventory")
    all_rows = []
    for binding in value["children"]:
        suite = binding["suite"]
        all_rows.extend(validate_suite(label, suite, children[suite], binding, value, prep, build,
                                       build_record["binding"]["sha256"], manifests, root))
    require(value["tests"] == all_rows and len(all_rows) == 181,
            label + "_aggregate_rows_not_exact_child_union")
    baseline_names = set(manifests["server"]["baseline_names"] + manifests["ha"]["baseline_names"])
    originals = set(manifests["server"]["document"]["original_60_exact_names"])
    require(sum(r["name"] in baseline_names for r in all_rows) == 176
            and sum(r["name"] in originals for r in all_rows) == 60,
            label + "_aggregate_baseline_rows")
    return {"aggregate": record["binding"], "preparation": prep_record["binding"],
            "build": build_record["binding"], "server_sha256": normal["sha256"],
            "server_origin_path": normal["path"], "passed": 181, "original_176_passed": 176,
            "original_60_passed": 60,
            "children": {suite: children[suite]["binding"] for suite in ("server", "ha")}}


def admit(args):
    commit, tree = args.commit, args.tree
    require(re.fullmatch(r"[0-9a-f]{40}", commit) and re.fullmatch(r"[0-9a-f]{40}", tree),
            "exact_source_identity_required")
    source = Path(args.source).resolve(strict=True)
    mac_aggregate = read_receipt(args.regression_result, args.regression_sha256)
    mac_preparation = read_receipt(args.regression_preparation, args.regression_preparation_sha256)
    mac_build = read_receipt(args.build_result, mac_aggregate["document"]["build_result_sha256"])
    linux = {}
    for name in LINUX_ARGUMENTS:
        key = name.replace("-", "_")
        linux[key.removeprefix("linux_")] = read_receipt(getattr(args, key), getattr(args, key + "_sha256"))
    manifests, manifest_bindings = load_manifests(mac_preparation["document"], source, commit, tree)
    validate_preparations(mac_preparation["document"], linux["preparation"]["document"],
                          manifests, commit, tree)
    validate_mac_build(mac_build, commit, tree)
    linux_build_records = {key: linux[key] for key in (
        "libtest_build", "release_controller", "native_build", "normal_release")}
    _, linux_root = validate_linux_build_chain(linux_build_records, linux["preparation"]["document"],
                                               commit, tree)
    mac_children = {binding["suite"]: read_receipt(binding["path"], binding["sha256"])
                    for binding in mac_aggregate["document"]["children"]}
    mac = validate_aggregate("mac", mac_aggregate, mac_preparation, mac_build,
                             mac_children, manifests, PurePosixPath(str(source.parent)))
    linux_result = validate_aggregate("linux", linux["aggregate"], linux["preparation"],
                                      linux["libtest_build"],
                                      {suite: linux[suite + "_result"] for suite in COUNTS},
                                      manifests, linux_root)
    return {
        "schema": SCHEMA, "status": "admitted", "source_commit": commit, "source_tree": tree,
        "required_each_host": 181, "required_original_176_each_host": 176,
        "required_original_60_each_host": 60, "manifest_bytes_identical": True,
        "manifests": manifest_bindings, "mac": mac, "linux": linux_result,
        "linux_release_chain": {key: rec["binding"] for key, rec in linux_build_records.items()},
        "linux_normal_release_result_origin_path": linux["libtest_build"]["document"]["normal_release_result_path"],
        "source_hashes_recomputed_from_local_frozen_source": True,
        "linux_source_files_equal_local_manifest": True,
        "remote_live_files_rehashed_by_this_gate": False,
        "remote_artifact_hash_scope": "Pinned successful Linux build and regression receipts; physical-host admission must independently rehash retained executables.",
        "executor_terminals_requeried_by_this_gate": False,
        "raw_test_logs_reparsed_by_this_gate": False,
        "regression_scope": "Exact rows and immutable child receipts produced by pinned runners; synthetic owned fixtures only.",
        "product_processes_started_by_gate": False, "production_changed": False,
        "full34_executed_by_gate": False, "full_replacement_qualified": False,
    }


INPUT_SCHEMA = "heptabao.full34-cross-host-admission-inputs.v1"
INPUT_FIELDS = (
    "schema", "source", "commit", "tree", "regression_result", "regression_sha256",
    "regression_preparation", "regression_preparation_sha256", "build_result",
) + tuple(field for name in LINUX_ARGUMENTS
          for field in (name.replace("-", "_"), name.replace("-", "_") + "_sha256"))


def validate_inputs(inputs):
    """Public HA/full34 entry: exact schema dict -> receipt; no process/network writes."""
    require(isinstance(inputs, dict) and set(inputs) == set(INPUT_FIELDS),
            "cross_host_input_fields")
    require(inputs["schema"] == INPUT_SCHEMA and all(isinstance(v, str) for v in inputs.values()),
            "cross_host_input_schema_or_types")
    return admit(SimpleNamespace(**{key: value for key, value in inputs.items() if key != "schema"}))
