#!/usr/bin/env python3
"""Control-only QA using immutable failed R3 evidence; never executes a product."""
import ast
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys

D = Path(__file__).resolve().parent
R3 = D.parents[1]
SOURCE = R3 / "source"
COMMIT = "6b16a9292d046bbc42aec65045fa105aaa1ac5de"
TREE = "0de9c516e94a47cb89e2e0f5ac2146e60913cfef"
os.umask(0o077)
if not __debug__ or sys.version_info < (3, 11):
    raise RuntimeError("unoptimized_modern_python_required")
spec = importlib.util.spec_from_file_location("full34_cross_host_gate", D / "full34_cross_host_gate.py")
gate = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = gate
spec.loader.exec_module(gate)
copy_manifest = json.loads((D / "evidence-copy-manifest.public.json").read_bytes())
bindings = copy_manifest["files"]
records = {name: gate.read_receipt(str(D / "linux-public" / (name + ".public.json")),
                                  row["sha256"]) for name, row in bindings.items()}
mac_agg = gate.read_receipt(str(R3 / "regression-r1/result.public.json"),
                           "d0b4ac8ff03392517e102df4b2a2c9167f2b377474809da64d91d92b1db78975")
mac_prep = gate.read_receipt(str(R3 / "control/regression-preparation.public.json"),
                            "0592a1684da73695f7bf3f00c311f087b5e3ff7db6d622819160942e776a603d")
mac_build = gate.read_receipt(str(R3 / "build-r1/result.public.json"),
                             "a17913754a19a0434651b585d93bc08bdb07a1c0351904467c9248ed88f2aafb")
mac_children = {r["suite"]: gate.read_receipt(r["path"], r["sha256"])
                for r in mac_agg["document"]["children"]}
linux_builds = {k: records[k] for k in (
    "libtest_build", "release_controller", "native_build", "normal_release")}
REQUIRED_CASES = ["actual_frozen_manifest_source_hashes_and_original_176_plan","actual_mac_linux_identical_manifest_bytes_and_source_inventory","actual_normal_mac_build_retained_binary_hashes","actual_normal_linux_build_receipt_chain","actual_mac_ha9_exact_success_rows_and_cleanup","actual_linux_ha9_exact_success_rows_and_cleanup","actual_mac_180_of_181_rejected","actual_linux_180_of_181_rejected","full_gate_rejects_real_failed_candidate_before_any_product","reject_linux_manifest_not_same_bytes","reject_linux_declared_denominator_shrink","reject_unreviewed_linux_runner","reject_other_source_linux_native_receipt","reject_linux_native_binary_not_normal_artifact","reject_linux_native_provenance_digest_mismatch","reject_linux_non_normal_profile","reject_linux_fixture_feature_receipt","reject_linux_libtest_release_digest_mismatch","reject_child_missing_required_test","reject_child_zero_or_ignored_test_claim","reject_child_unreconciled_group","reject_child_replayed_or_unattempted_count","reject_wrong_explicit_file_sha256","reject_duplicate_json_key","wrapper_original_execution_custody_and_budget_bytes_preserved","custody_module_exact_frozen_bytes","gate_has_no_process_network_or_signal_operations"]
cases = []


def expect(name, callback, error=None):
    try:
        callback()
    except gate.AdmissionError as exc:
        ok = error is not None and str(exc) == error
        cases.append({"name": name, "passed": ok, "expected_error": error,
                      "observed_error": str(exc)})
        if not ok:
            raise
    else:
        ok = error is None
        cases.append({"name": name, "passed": ok, "expected_error": error,
                      "observed_error": None})
        if not ok:
            raise AssertionError(name + " did not reject")


def mutation(value, path, replacement):
    item = copy.deepcopy(value)
    focus = item
    for key in path[:-1]:
        focus = focus[key]
    focus[path[-1]] = replacement
    return item


def main():
    manifests, _ = gate.load_manifests(mac_prep["document"], SOURCE, COMMIT, TREE)
    expect("actual_frozen_manifest_source_hashes_and_original_176_plan",
           lambda: gate.load_manifests(mac_prep["document"], SOURCE, COMMIT, TREE))
    expect("actual_mac_linux_identical_manifest_bytes_and_source_inventory",
           lambda: gate.validate_preparations(mac_prep["document"],
               records["preparation"]["document"], manifests, COMMIT, TREE))
    expect("actual_normal_mac_build_retained_binary_hashes",
           lambda: gate.validate_mac_build(mac_build, COMMIT, TREE))
    expect("actual_normal_linux_build_receipt_chain",
           lambda: gate.validate_linux_build_chain(linux_builds,
               records["preparation"]["document"], COMMIT, TREE))
    _, linux_root = gate.validate_linux_build_chain(linux_builds,
                          records["preparation"]["document"], COMMIT, TREE)
    mac_root = gate.PurePosixPath(str(R3))

    def suite(label, record):
        aggregate = mac_agg if label == "mac" else records["aggregate"]
        prep = mac_prep if label == "mac" else records["preparation"]
        build = mac_build if label == "mac" else records["libtest_build"]
        root = mac_root if label == "mac" else linux_root
        binding = aggregate["document"]["children"][1]
        return gate.validate_suite(label, "ha", record, binding, aggregate["document"],
                    prep["document"], build["document"], build["binding"]["sha256"], manifests, root)

    expect("actual_mac_ha9_exact_success_rows_and_cleanup",
           lambda: suite("mac", mac_children["ha"]))
    expect("actual_linux_ha9_exact_success_rows_and_cleanup",
           lambda: suite("linux", records["ha_result"]))
    expect("actual_mac_180_of_181_rejected",
           lambda: gate.validate_aggregate("mac", mac_agg, mac_prep, mac_build,
                   mac_children, manifests, mac_root), "mac_aggregate_not_passed")
    expect("actual_linux_180_of_181_rejected",
           lambda: gate.validate_aggregate("linux", records["aggregate"], records["preparation"],
                   records["libtest_build"], {s: records[s + "_result"] for s in gate.COUNTS},
                   manifests, linux_root), "linux_aggregate_not_passed")

    class Args:
        source = str(SOURCE)
        commit, tree = COMMIT, TREE
        regression_result = str(R3 / "regression-r1/result.public.json")
        regression_sha256 = mac_agg["binding"]["sha256"]
        regression_preparation = str(R3 / "control/regression-preparation.public.json")
        regression_preparation_sha256 = mac_prep["binding"]["sha256"]
        build_result = str(R3 / "build-r1/result.public.json")
    args = Args()
    for key, record in records.items():
        setattr(args, "linux_" + key, record["binding"]["local_path"])
        setattr(args, "linux_" + key + "_sha256", record["binding"]["sha256"])
    expect("full_gate_rejects_real_failed_candidate_before_any_product",
           lambda: gate.admit(args), "mac_aggregate_not_passed")

    wrong_prep = mutation(records["preparation"]["document"],
                          ["server_manifest", "sha256"], "0" * 64)
    expect("reject_linux_manifest_not_same_bytes",
           lambda: gate.validate_preparations(mac_prep["document"], wrong_prep,
                  manifests, COMMIT, TREE), "cross_host_manifest_bytes_differ")
    wrong_prep = mutation(records["preparation"]["document"],
                          ["expected_unique_tests"], 180)
    expect("reject_linux_declared_denominator_shrink",
           lambda: gate.validate_preparations(mac_prep["document"], wrong_prep,
                  manifests, COMMIT, TREE), "linux_preparation_plan_or_controller")
    wrong_prep = mutation(records["preparation"]["document"],
                          ["controller_sha256"], "0" * 64)
    expect("reject_unreviewed_linux_runner",
           lambda: gate.validate_preparations(mac_prep["document"], wrong_prep,
                  manifests, COMMIT, TREE), "linux_preparation_plan_or_controller")

    build_mutations = [
        ("reject_other_source_linux_native_receipt", ["native_build", "document", "source_commit"],
         "0" * 40, "linux_native_build_source_mismatch"),
        ("reject_linux_native_binary_not_normal_artifact", ["native_build", "document", "binary_sha256"],
         "0" * 64, "linux_server_artifact_chain"),
        ("reject_linux_native_provenance_digest_mismatch",
         ["native_build", "document", "provenance", "result_sha256"],
         "0" * 64, "linux_native_provenance_chain"),
        ("reject_linux_non_normal_profile",
         ["normal_release", "document", "requested_release_profile", "CARGO_PROFILE_RELEASE_OPT_LEVEL"],
         "0", "linux_normal_profile"),
        ("reject_linux_fixture_feature_receipt",
         ["release_controller", "document", "fixture_features"], ["fixture-runtime"],
         "linux_release_controller"),
        ("reject_linux_libtest_release_digest_mismatch",
         ["libtest_build", "document", "release_result_sha256"], "0" * 64,
         "linux_release_controller_digest_chain"),
    ]
    for name, path, replacement, error in build_mutations:
        changed = mutation(linux_builds, path, replacement)
        expect(name, lambda changed=changed: gate.validate_linux_build_chain(changed,
                   records["preparation"]["document"], COMMIT, TREE), error)

    child_mutations = [
        ("reject_child_missing_required_test", ["document", "tests"],
         records["ha_result"]["document"]["tests"][:-1], "linux_child_exact_inventory"),
        ("reject_child_zero_or_ignored_test_claim", ["document", "tests", 0, "exact_one_test_proved"],
         False, "linux_child_not_exact_one_test"),
        ("reject_child_unreconciled_group", ["document", "cleanup", 0, "remaining"],
         [{"synthetic_negative": True}], "linux_child_cleanup"),
        ("reject_child_replayed_or_unattempted_count", ["document", "attempted_once"],
         8, "linux_child_denominator"),
    ]
    for name, path, replacement, error in child_mutations:
        changed = mutation(records["ha_result"], path, replacement)
        expect(name, lambda changed=changed: suite("linux", changed), error)

    expect("reject_wrong_explicit_file_sha256",
           lambda: gate.read_receipt(records["native_build"]["binding"]["local_path"], "0" * 64),
           "evidence_digest_mismatch")
    expect("reject_duplicate_json_key", lambda: json.loads('{"x":1,"x":2}',
           object_pairs_hook=gate.strict_object), "duplicate_json_key")
    base = (R3 / "control/run_full34_mac_guarded.py").read_text()
    derived = (D / "run_full34_mac_cross_host.py").read_text()
    provenance = json.loads((D / "preparation.public.json").read_text())
    restored = derived
    for change in reversed(provenance["exact_source_edits"]):
        assert restored.count(change["after"]) == 1
        restored = restored.replace(change["after"], change["before"], 1)
    assert restored == base
    expect("wrapper_original_execution_custody_and_budget_bytes_preserved", lambda: None)
    assert hashlib.sha256((D / "full34_process_custody.py").read_bytes()).hexdigest() == \
        "c32a4f3091a1ff7b105ac54099fbdeaf68c6e9aeb41aa5ff829b507857ee31cb"
    expect("custody_module_exact_frozen_bytes", lambda: None)
    tree = ast.parse((D / "full34_cross_host_gate.py").read_text())
    forbidden = {"subprocess", "socket", "ssl", "multiprocessing", "threading"}
    assert not any(isinstance(node, ast.Import) and any(
        alias.name.split(".")[0] in forbidden for alias in node.names) for node in ast.walk(tree))
    assert not any(isinstance(node, ast.ImportFrom) and (node.module or "").split(".")[0] in forbidden
                   for node in ast.walk(tree))
    assert not any(isinstance(node, ast.Attribute) and node.attr in
                   ("system", "popen", "fork", "spawn", "execv", "execve", "posix_spawn",
                    "kill", "killpg") for node in ast.walk(tree))
    expect("gate_has_no_process_network_or_signal_operations", lambda: None)


result = {"schema": "heptabao.full34-cross-host-gate-control-qa.v1",
          "status": "failed", "scope": "Read-only controls and semantic negative mutations in memory",
          "source_commit": COMMIT, "source_tree": TREE, "cases": cases,
          "real_candidate_qualified": False, "full34_executed": False,
          "product_processes_started": False, "source_modified": False,
          "original_results_modified": False, "production_changed": False,
          "positive_full_181_candidate_admission_observed": False}
try:
    main()
    assert [case["name"] for case in cases] == REQUIRED_CASES
    result["status"] = "passed"
except BaseException as exc:
    result["error_type"] = type(exc).__name__
    result["error"] = str(exc)
finally:
    result["passed"] = sum(c["passed"] for c in cases)
    result["case_count"] = len(cases)
    result["required_count"] = len(REQUIRED_CASES)
    result["required_cases"] = REQUIRED_CASES
    result["not_run_cases"] = [name for name in REQUIRED_CASES if name not in {c["name"] for c in cases}]
    result["gate_sha256"] = hashlib.sha256((D / "full34_cross_host_gate.py").read_bytes()).hexdigest()
    result["wrapper_sha256"] = hashlib.sha256((D / "run_full34_mac_cross_host.py").read_bytes()).hexdigest()
    result["linux_actual_aggregate_sha256"] = records["aggregate"]["binding"]["sha256"]
    result["mac_actual_aggregate_sha256"] = mac_agg["binding"]["sha256"]
    path = D / "qa.public.json"
    with path.open("x") as f:
        json.dump(result, f, indent=2, sort_keys=True); f.write("\n"); f.flush(); os.fsync(f.fileno())
    print(json.dumps({"status": result["status"], "passed": result["passed"],
                      "case_count": result["case_count"], "required_count": result["required_count"], "error": result.get("error"),
                      "qa_path": str(path), "qa_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                      "candidate_admitted": False, "product_processes_started": False}), flush=True)
raise SystemExit(0 if result["status"] == "passed" else 1)
