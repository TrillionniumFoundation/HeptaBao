Cross-host full34 admission control draft

This directory is independent of the sealed R3 control files and public archive.
No source, original result, product process, or full34 run is modified or started by preparation or QA.

run_full34_mac_cross_host.py is derived from the exact guarded wrapper 888335a3... using only two textual insertions: mandatory Linux path/SHA options and a pure admission call before the original driver path. wrapper.diff and preparation.public.json retain the exact reversible edits. All original child/session/cleanup code, 31-check driver, and HTTP 5/15s, migration 360s, and full34 1800s budgets retain their original bytes.

The new required option pairs are:
--linux-aggregate / --linux-aggregate-sha256
--linux-preparation / --linux-preparation-sha256
--linux-libtest-build / --linux-libtest-build-sha256
--linux-release-controller / --linux-release-controller-sha256
--linux-native-build / --linux-native-build-sha256
--linux-normal-release / --linux-normal-release-sha256
--linux-server-result / --linux-server-result-sha256
--linux-ha-result / --linux-ha-result-sha256

All eight paths identify local public copies. Embedded Linux origin paths must link consistently to the same candidate root; they are never resolved on the Mac. The final two copies verify the child SHA references and actual exact test rows in the aggregate. The same child checks are applied to the local Mac receipts.

The gate requires 181/181 on each host, including the original176 and original60 identities, the same source/tree, byte-identical 172+9 manifests, unchanged group/test budgets, independently hashed local source files, normal release profiles/features, and Linux build/native provenance linking to its tested normal binary SHA. It rejects failed, shrunk, substituted, ignored, zero-test, unattempted, or unreconciled receipt rows. It does not contact hosts, query durable executor terminals, rehash current remote executables, or reparse each raw stdout. Those independent evidence and physical-host checks remain mandatory in the parent workflow.

All public Linux copies here are the actual FAILED R3 candidate (180/181), as is the local Mac aggregate. QA exercises real build-chain validation, real HA9 rows, real candidate rejection, and in-memory negative mutations. A QA pass is not a successful full181 candidate admission. No failed candidate data is edited into a passing candidate fixture.

The interface accepts a later exact candidate only after its own frozen source, recomputed manifests, actual normal builds, and both complete actual181 aggregates pass. R5's 0128 oracle changed semantics while preserving its name and budget; its separate semantic-change-scope receipt must remain with R5 evidence. Old R3 assertion text is not claimed unchanged across candidates.

The original full34 driver proves only its declared synthetic normal native_v6_file migration/recovery checks. It does not prove production credential migration, physical HA, AuthBus, client/backup/sync cutover, or TLS close_notify.

Revision-r2 preserves the first control QA failure (3/27). It fixes the actual Linux release_artifacts key heptabao-server and exports validate_inputs(dict) for HA reuse. The exact required dict keys and schema are in preparation.public.json/public_api; unknown/missing fields are rejected. Two new admission-only cases exercise this entry. No product acceptance result is changed.
