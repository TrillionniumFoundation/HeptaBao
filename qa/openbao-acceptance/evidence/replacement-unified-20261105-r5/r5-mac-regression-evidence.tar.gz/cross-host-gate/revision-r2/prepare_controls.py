import ast, base64, difflib, hashlib, json, os, stat, subprocess, sys
from pathlib import Path
os.umask(0o077)
P=json.load(sys.stdin)
R3=Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r3")
D=R3/"control/full34-cross-host-gate-draft-r1/revision-r2"
SOURCE=R3/"source"
def sha(raw): return hashlib.sha256(raw).hexdigest()
def read(path):
    s=path.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_nlink==1 and path.resolve(strict=True)==path
    return path.read_bytes()
def write(path,raw):
    with path.open("xb") as f: f.write(raw); f.flush(); os.fsync(f.fileno())
def js(path,obj): write(path,(json.dumps(obj,indent=2,sort_keys=True)+"\n").encode())
def git(*args):
    return subprocess.check_output(["/usr/bin/git","-C",str(SOURCE),*args],text=True,timeout=30).strip()
assert git("rev-parse","HEAD")=="6b16a9292d046bbc42aec65045fa105aaa1ac5de"
assert git("rev-parse","HEAD^{tree}")=="0de9c516e94a47cb89e2e0f5ac2146e60913cfef"
assert git("status","--porcelain","--untracked-files=all")==""
base_path=R3/"control/run_full34_mac_guarded.py"
base_raw=read(base_path)
assert sha(base_raw)=="888335a3bed213f2614d2665a4c5fc370a2cd4a5117a3c551e093056b3e6dba2"
custody=read(R3/"control/full34_process_custody.py")
assert sha(custody)=="c32a4f3091a1ff7b105ac54099fbdeaf68c6e9aeb41aa5ff829b507857ee31cb"
driver=read(SOURCE/"qa/openbao-acceptance/kv2_271_lossless_native_live.py")
assert sha(driver)=="15cc68f3bd2442e4e4d3047f4fb30eecf826d8c4f54258732f97090005f542d4"
parsed=ast.parse(driver)
checks=next(ast.literal_eval(n.value) for n in parsed.body
            if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="CHECKS" for t in n.targets))
assert len(checks)==len(set(checks))==31
gate_raw=P["gate_source"].encode()
qa_raw=P["qa_source"].encode()
ast.parse(gate_raw); ast.parse(qa_raw)
gate_sha=sha(gate_raw)
keys=("linux-aggregate","linux-preparation","linux-libtest-build",
      "linux-release-controller","linux-native-build","linux-normal-release",
      "linux-server-result","linux-ha-result")
old='            "regression-preparation", "regression-preparation-sha256"):'
new='            "regression-preparation", "regression-preparation-sha256",\n'
for key in keys:
    new += '            "'+key+'", "'+key+'-sha256",\n'
new=new[:-2]+'):'
base=base_raw.decode()
assert base.count(old)==1
derived=base.replace(old,new,1)
anchor='    assert regressions["build_result_sha256"] == sha(built_path)\n'
block=anchor+'''    gate_path = Path(__file__).with_name("full34_cross_host_gate.py")
    assert sha(gate_path) == "GATE_SHA"
    gate_spec = importlib.util.spec_from_file_location("full34_cross_host_gate", gate_path)
    gate_module = importlib.util.module_from_spec(gate_spec)
    sys.modules[gate_spec.name] = gate_module
    gate_spec.loader.exec_module(gate_module)
    try:
        cross_host_admission = gate_module.admit(a)
    except gate_module.AdmissionError as gate_error:
        result["cross_host_admission_failure"] = str(gate_error)
        raise
    write("cross-host-admission.public.json", cross_host_admission)
    result.update(
        cross_host_admission_sha256=sha(output / "cross-host-admission.public.json"),
        cross_host_gate_module_sha256=sha(gate_path),
        required_hosts=["mac", "linux"],
        required_regressions_each_host=181,
        required_original_176_each_host=176,
        required_original_60_each_host=60,
        linux_server_sha256=cross_host_admission["linux"]["server_sha256"],
        linux_aggregate_sha256=cross_host_admission["linux"]["aggregate"]["sha256"],
    )
'''.replace("GATE_SHA",gate_sha)
assert derived.count(anchor)==1
derived=derived.replace(anchor,block,1)
ast.parse(derived)
assert derived.replace(block,anchor,1).replace(new,old,1)==base
raws={}
copy_rows={}
for name,row in P["linux_files"].items():
    assert name in {key.removeprefix("linux-").replace("-","_") for key in keys}
    if "text" in row:
        raw=row["text"].encode()
    else:
        offset=0; chunks=[]
        for part in row["chunks"]:
            assert part["offset"]==offset and part["version"]==row["chunks"][0]["version"]
            chunk=base64.b64decode(part["data_base64"],validate=True)
            assert sha(chunk)==part["chunk_sha256"]
            assert offset+len(chunk)==part["next_offset"]
            chunks.append(chunk);offset=part["next_offset"]
        assert row["chunks"][-1]["eof"] is True and offset==row["chunks"][0]["size"]
        raw=b"".join(chunks)
    assert sha(raw)==row["sha256"],("copy_digest_mismatch",name)
    json.loads(raw)
    raws[name]=raw
    copy_rows[name]={key:value for key,value in row.items() if key not in ("text","chunks")}
    copy_rows[name]["bytes"]=len(raw)
    if "chunks" in row:
        copy_rows[name]["source_version"]=row["chunks"][0]["version"]
        copy_rows[name]["verified_chunk_sha256"]=[x["chunk_sha256"] for x in row["chunks"]]
assert len(raws)==8
D.mkdir(mode=0o700)
(D/"linux-public").mkdir(mode=0o700)
for name,raw in raws.items(): write(D/"linux-public"/(name+".public.json"),raw)
write(D/"full34_cross_host_gate.py",gate_raw)
write(D/"qa_cross_host_admission.py",qa_raw)
write(D/"full34_process_custody.py",custody)
write(D/"run_full34_mac_cross_host.py",derived.encode())
write(D/"prepare_controls.py",P["preparer_source"].encode())
write(D/"wrapper.diff","".join(difflib.unified_diff(base.splitlines(keepends=True),derived.splitlines(keepends=True),
      fromfile=str(base_path),tofile=str(D/"run_full34_mac_cross_host.py"))).encode())
js(D/"evidence-copy-manifest.public.json",{
"schema":"heptabao.public-evidence-byte-copy.v1","source_configured_host":"rog",
"files":copy_rows,"all_copies_exact_original_bytes":True,
"source_files_modified":False,"private_material_read":False,
"scope":"R3 failed candidate public build and regression evidence; no successful candidate substituted"})
js(D/"preparation.public.json",{
"schema":"heptabao.full34-cross-host-control-preparation.v1",
"status":"prepared_for_control_only_qa",
"source_commit":"6b16a9292d046bbc42aec65045fa105aaa1ac5de",
"source_tree":"0de9c516e94a47cb89e2e0f5ac2146e60913cfef",
"candidate_independent_interface":True,
"future_candidate_requires_fresh_source_bound_manifests_and_both_real_passed_aggregates":True,
"wrapper_path":str(D/"run_full34_mac_cross_host.py"),"wrapper_sha256":sha(derived.encode()),
"base_wrapper_path":str(base_path),"base_wrapper_sha256":sha(base_raw),
"gate_module_sha256":gate_sha,"custody_module_sha256":sha(custody),
"driver_sha256":sha(driver),"driver_required_checks":checks,"driver_required_count":31,
"custody_bytes_unchanged":True,"original_wrapper_execution_and_budgets_bytes_unchanged":True,
"exact_source_edits":[{"before":old,"after":new},{"before":anchor,"after":block}],
"required_linux_path_sha_pairs":list(keys),
"expected_each_host":181,"original_176_each_host":176,"original_60_each_host":60,
"qa_controller_sha256":sha(qa_raw),
"public_api":{"function":"validate_inputs","input_schema":"heptabao.full34-cross-host-admission-inputs.v1","input_fields":["schema","source","commit","tree","regression_result","regression_sha256","regression_preparation","regression_preparation_sha256","build_result"]+[field for key in keys for field in (key.replace("-","_"),key.replace("-","_")+"_sha256")]},
"predecessor_control_qa":{"path":str(D.parent/"qa.public.json"),"sha256":"894d64fe3eaa3055c5c96aa4f844db48e684bf7395faccd56a8403db1412a3c5","status":"failed","passed":3,"required_count":27,"reason":"actual Linux release_artifacts key is heptabao-server; initial draft incorrectly indexed server"},
"revision_changes":["Use independently observed release_artifacts[heptabao-server] key.","Add a strict pure validate_inputs dict entry for the HA outer controller and two admission-only negative cases."],
"scope_limitations":[
"Input receipts are public immutable local copies; Linux origin paths are bound as strings, not misinterpreted as local files.",
"Gate verifies bytes, exact child rows, source and artifact receipt chains; it does not re-query remote executors or rehash live remote executables.",
"Operator must retain authoritative executor terminals and physical-host admission must independently rehash the retained server.",
"Both real R3 aggregates failed 180/181; no real full181 positive admission has been observed by this draft.",
"Original31 driver remains synthetic normal native_v6_file coverage and does not prove production credentials, physical HA, clients or TLS close_notify."],
"product_processes_started":False,"full34_executed":False,"production_changed":False})
write(D/"README.txt",P["readme"].encode())
assert read(base_path)==base_raw and read(R3/"control/full34_process_custody.py")==custody
assert read(SOURCE/"qa/openbao-acceptance/kv2_271_lossless_native_live.py")==driver
assert git("status","--porcelain","--untracked-files=all")==""
print(json.dumps({"stage":"cross_host_draft_written","directory":str(D),
"wrapper_sha256":sha(derived.encode()),"gate_sha256":gate_sha,
"copied_public_linux_receipts":8,"product_processes_started":False}),flush=True)
os.execv(sys.executable,[sys.executable,"-I","-S","-B",str(D/"qa_cross_host_admission.py")])
