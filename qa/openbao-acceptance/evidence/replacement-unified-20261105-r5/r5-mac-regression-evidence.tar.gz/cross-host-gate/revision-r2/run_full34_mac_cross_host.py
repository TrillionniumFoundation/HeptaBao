#!/usr/bin/env python3
"""Pin normal native build + completed regressions before one formal-backend full34 run."""
import argparse, ast, hashlib, importlib.util, json, os, resource, runpy, shutil, signal, subprocess, sys, threading, time
from pathlib import Path

os.umask(0o077)
if not __debug__ or sys.version_info < (3, 11):
    raise RuntimeError("full34 requires unoptimized Python with hashlib.file_digest")
custody_path = Path(__file__).with_name("full34_process_custody.py")
spec = importlib.util.spec_from_file_location("full34_process_custody", custody_path)
custody = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = custody
spec.loader.exec_module(custody)
CANCEL_REQUEST = {"number": None}
def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()
def interrupt(number, frame):
    CANCEL_REQUEST["number"] = number

if len(sys.argv) > 1 and sys.argv[1] == "--_child":
    driver = Path(sys.argv[2]).resolve(strict=True)
    directory, nonce, parent_fd = Path(sys.argv[3]), sys.argv[4], int(sys.argv[5])
    assert sha(custody_path) == sys.argv[6]
    sys.argv = [str(driver), *sys.argv[7:]]
    registry = custody.Registry(directory, nonce).install()
    code = 1
    try:
        custody.require(os.read(parent_fd, 1) == b"1", "outer_owner_not_admitted")
        threading.Thread(target=custody.parent_pipe_monitor, args=(parent_fd,), daemon=True).start()
        try:
            runpy.run_path(str(driver), run_name="__main__")
            code = 0
        except SystemExit as result:
            code = result.code if isinstance(result.code, int) else 1
    except BaseException:
        code = 1
    finally:
        receipt = registry.finish()
        if not (receipt["integrity"] and receipt["all_registered_original_children_reaped"]
                and receipt["all_registered_session_groups_empty_before_reap"]):
            code = 1
        custody.write_new(directory / "driver-exit.public.json",
            {"schema": custody.SCHEMA, "nonce": nonce, "exit_code": code,
             "driver_sha256": sha(driver), "custody_module_sha256": sha(custody_path)})
    raise SystemExit(code)

p = argparse.ArgumentParser()
for key in ("source", "output", "build-result", "regression-result", "regression-sha256",
            "commit", "tree", "oracle-binary", "oracle-archive",
            "regression-preparation", "regression-preparation-sha256",
            "linux-aggregate", "linux-aggregate-sha256",
            "linux-preparation", "linux-preparation-sha256",
            "linux-libtest-build", "linux-libtest-build-sha256",
            "linux-release-controller", "linux-release-controller-sha256",
            "linux-native-build", "linux-native-build-sha256",
            "linux-normal-release", "linux-normal-release-sha256",
            "linux-server-result", "linux-server-result-sha256",
            "linux-ha-result", "linux-ha-result-sha256"):
    p.add_argument("--" + key, required=True)
a = p.parse_args()
source = Path(a.source).resolve(strict=True)
output = Path(a.output)
assert output.is_absolute() and output.parent.resolve(strict=True) == output.parent
assert not output.exists() and not output.is_relative_to(source)
output.mkdir(mode=0o700)
work = output / "private-run"
child = None
child_birth = None
parent_write = None
parent_read = None
custody_root = output / "process-custody"
nonce = os.urandom(16).hex()
custody_sha256 = sha(custody_path)
result = {
    "schema": "heptabao.unified-formal-file-kv2-full34.v1",
    "status": "failed", "source_commit": a.commit, "source_tree": a.tree,
    "scope": "normal native_v6_file backend with fresh synthetic OpenBao 2.7.1 source",
    "synthetic_only": True, "production_credentials_tested": False,
    "production_changed": False, "traffic_cutover": False, "replacement_qualified": False,
    "full34_qualified": False, "automatic_retry": False, "submission_count": 0,
    "stage_budgets_seconds": {"http": 15, "migration": 360, "controller": 1800},
    "started_ns": time.time_ns(), "controller_sha256": sha(__file__),
    "custody_module_sha256": custody_sha256, "custody_nonce": nonce,
}
def write(name, value):
    dest = output / name
    with dest.open("x") as f:
        json.dump(value, f, indent=2, sort_keys=True, ensure_ascii=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    fd = os.open(output, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
def git(*args):
    return subprocess.check_output(["git", "-C", str(source), *args], text=True, timeout=30).strip()
def freeze():
    return {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain", "--untracked-files=all")}
def group_members(pgid):
    rows = subprocess.check_output(["ps", "-axo", "pid=,ppid=,pgid=,stat="], text=True, timeout=10)
    return [line.strip() for line in rows.splitlines()
            if len(line.split()) >= 4 and int(line.split()[2]) == pgid]
def terminate_owned():
    global parent_write, child_birth
    if child is not None and child.returncode is None:
        if child_birth is None:
            child_birth = custody.capture_session(child)
        if custody.exit_event(child) is None:
            custody.signal_original_session(child, child_birth, signal.SIGTERM)
            grace = time.monotonic() + 45
            while custody.exit_event(child) is None and time.monotonic() < grace:
                time.sleep(min(0.05, max(0, grace - time.monotonic())))
        result["main_session_cleanup"] = custody.finish_session(
            child, child_birth, time.monotonic() + 10,
            force=custody.exit_event(child) is None)
    if parent_write is not None:
        os.close(parent_write)
        parent_write = None
    nested = custody.observe_registered_sessions(custody_root, nonce, time.monotonic() + 10)
    result["registered_nested_sessions"] = nested
    return nested["remaining"]
write("intent.public.json", result)
for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
    signal.signal(number, interrupt)
try:
    before = freeze()
    assert before == {"commit": a.commit, "tree": a.tree, "status": ""}
    built_path = Path(a.build_result).resolve(strict=True)
    built = json.loads(built_path.read_bytes())
    assert built["status"] == "built" and built["source_unchanged"] is True
    assert (built["source_commit"], built["source_tree"]) == (a.commit, a.tree)
    binary = Path(built["artifacts"]["heptabao-server"]["path"]).resolve(strict=True)
    binary_sha = built["artifacts"]["heptabao-server"]["sha256"]
    assert sha(binary) == binary_sha
    assert built["artifacts"]["heptabao-server"]["profile"] == {
        "opt_level": "3", "debuginfo": 0, "debug_assertions": True,
        "overflow_checks": True, "test": False}
    assert sorted(built["artifacts"]["heptabao-server"]["features"]) == ["default", "native-v6-ha", "native-v6-storage"]
    regression_path = Path(a.regression_result).resolve(strict=True)
    assert sha(regression_path) == a.regression_sha256
    regressions = json.loads(regression_path.read_bytes())
    assert regressions["status"] == "passed"
    assert (regressions["source_commit"], regressions["source_tree"]) == (a.commit, a.tree)
    assert regressions["source_unchanged"] is True
    preparation_path = Path(a.regression_preparation).resolve(strict=True)
    assert sha(preparation_path) == a.regression_preparation_sha256
    preparation = json.loads(preparation_path.read_bytes())
    assert (preparation["source_commit"], preparation["source_tree"]) == (a.commit, a.tree)
    expected_regressions = sum(preparation[suite + "_manifest"]["unique_tests"] for suite in ("server", "ha"))
    assert expected_regressions >= 176
    assert regressions["expected_unique_tests"] == expected_regressions and regressions["passed"] == expected_regressions
    assert regressions["original_176_passed"] == 176 and regressions["original_176_retained"] is True
    assert regressions["preparation_path"] == str(preparation_path)
    assert regressions["preparation_sha256"] == a.regression_preparation_sha256
    result.update(required_regression_count=expected_regressions,
                  regression_preparation_sha256=a.regression_preparation_sha256)
    assert regressions["original_60_passed"] == 60 and regressions["full_denominator_retained"] is True
    assert regressions["server_sha256"] == binary_sha
    assert regressions["build_result_sha256"] == sha(built_path)
    gate_path = Path(__file__).with_name("full34_cross_host_gate.py")
    assert sha(gate_path) == "85b34d43bed9d5b859951228459d9a09011c2c0ab1e1fb756080339aa793a581"
    gate_spec = importlib.util.spec_from_file_location("full34_cross_host_gate", gate_path)
    gate_module = importlib.util.module_from_spec(gate_spec)
    sys.modules[gate_spec.name] = gate_module
    gate_spec.loader.exec_module(gate_module)
    try:
        cross_host_admission = gate_module.admit(a)
    except gate_module.AdmissionError as gate_error:
        result["cross_host_admission_failure"] = str(gate_error)
        raise
    write("cross-host-admission.public.json", cross_host_admission)
    result.update(
        cross_host_admission_sha256=sha(output / "cross-host-admission.public.json"),
        cross_host_gate_module_sha256=sha(gate_path),
        required_hosts=["mac", "linux"],
        required_regressions_each_host=181,
        required_original_176_each_host=176,
        required_original_60_each_host=60,
        linux_server_sha256=cross_host_admission["linux"]["server_sha256"],
        linux_aggregate_sha256=cross_host_admission["linux"]["aggregate"]["sha256"],
    )
    driver = source / "qa/openbao-acceptance/kv2_271_lossless_native_live.py"
    tree = ast.parse(driver.read_text())
    required = next(ast.literal_eval(n.value) for n in tree.body
                    if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "CHECKS" for t in n.targets))
    assert len(required) == 31 and len(set(required)) == 31
    oracle = Path(a.oracle_binary).resolve(strict=True)
    archive = Path(a.oracle_archive).resolve(strict=True)
    assert sha(archive) == "15625b5f69aee5bb4578b4e76e856a2141647342b0f8e5969a8875b44e0fbf91"
    assert sha(oracle) == "50c3588e64271171cc2147bddeace8ec2b6742f94fd3fe53baa60f6d938cda0c"
    env = dict(os.environ)
    for key in list(env):
        if key.startswith("HB_ORACLE_") or key in ("PYTHONHOME", "PYTHONPATH"):
            env.pop(key, None)
    env.update(HB_ORACLE_BINARY=str(oracle), HB_ORACLE_ARCHIVE=str(archive),
               PATH="/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin", PYTHONDONTWRITEBYTECODE="1")
    argv = [sys.executable, "-I", "-S", "-B", str(Path(__file__).resolve()), "--_child", str(driver),
            str(custody_root), nonce, "PARENT_FD", custody_sha256,
            "--binary", str(binary), "--private-work-root", str(work),
            "--migration-lane", "native-large", "--profile", "full34"]
    result.update(binary_sha256=binary_sha, binary_bytes=binary.stat().st_size,
                  build_result_path=str(built_path), build_result_sha256=sha(built_path),
                  regression_result_path=str(regression_path), regression_result_sha256=a.regression_sha256,
                  driver_sha256=sha(driver), required_checks=list(required), required_count=len(required),
                  oracle_binary_sha256=sha(oracle), oracle_archive_sha256=sha(archive), argv=argv)
    write("admission.public.json", result)
    start = time.monotonic()
    usage_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    with (output / "stdout.log").open("xb") as stdout, (output / "stderr.log").open("xb") as stderr:
        assert CANCEL_REQUEST["number"] is None
        custody.require_waitid()
        parent_read, parent_write = os.pipe()
        argv[argv.index("PARENT_FD")] = str(parent_read)
        try:
            child = subprocess.Popen(argv, cwd=source, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, start_new_session=True,
                                     pass_fds=(parent_read,))
        finally:
            os.close(parent_read)
            parent_read = None
        result.update(submission_count=1, pid=child.pid, owned_pgid=child.pid)
        child_birth = custody.capture_session(child)
        write("driver-birth.public.json", {"birth": child_birth, "nonce": nonce,
                                           "original_Popen_registered": True})
        if CANCEL_REQUEST["number"] is None:
            os.write(parent_write, b"1")
        deadline = start + 1800
        while (custody.exit_event(child) is None and time.monotonic() < deadline
               and CANCEL_REQUEST["number"] is None):
            time.sleep(min(0.05, max(0, deadline - time.monotonic())))
        timed_out = time.monotonic() >= deadline
        result["cancellation_signal"] = CANCEL_REQUEST["number"]
        terminate_owned()
        code = child.returncode
        stdout.flush()
        stderr.flush()
        os.fsync(stdout.fileno())
        os.fsync(stderr.fileno())
    usage_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    result.update(exit_code=code, timed_out=timed_out, elapsed_seconds=time.monotonic()-start,
                  children_user_cpu_seconds=usage_after.ru_utime-usage_before.ru_utime,
                  children_system_cpu_seconds=usage_after.ru_stime-usage_before.ru_stime,
                  cumulative_children_peak_rss_bytes=usage_after.ru_maxrss,
                  resource_scope="whole migration fixture, not a matched per-engine benchmark")
    summary_path = work / "summary.json"
    summary = json.loads(summary_path.read_bytes())
    result.update(summary_sha256=sha(summary_path), fixture_status=summary.get("status"),
                  fixture_failure=summary.get("failure"), missing_checks=summary.get("missing_checks"),
                  full34_qualified=summary.get("full34_qualified"),
                  source_unchanged=freeze()==before, binary_unchanged=sha(binary)==binary_sha)
    write("summary.public.json", summary)
    checks = summary["checks"]
    passed = [r["case"] for r in checks if r.get("passed") is True]
    result["passed_count"] = len(passed)
    assert code == 0 and not timed_out and CANCEL_REQUEST["number"] is None
    custody_receipt = custody.private_json(custody_root / "result.public.json")
    assert custody_receipt["nonce"] == nonce and custody_receipt["integrity"] is True
    assert custody_receipt["all_registered_original_children_reaped"] is True
    assert custody_receipt["all_registered_session_groups_empty_before_reap"] is True
    assert result["main_session_cleanup"]["group_empty_before_first_reap"] is True
    assert result["registered_nested_sessions"]["all_members_absent"] is True
    assert sha(custody_path) == custody_sha256
    result.update(custody_receipt_sha256=sha(custody_root / "result.public.json"),
                  all_owned_processes_reconciled=True)
    assert len(checks) == len(required) and len(set(r["case"] for r in checks)) == len(required)
    assert set(passed) == set(required) and not summary["missing_checks"]
    assert summary["status"] == "passed" and summary["full34_qualified"] is True
    assert summary["candidate_startup"]["storage_profile"] == "native_v6_file"
    assert summary["candidate_startup"]["fixture_options"] is False
    assert summary["live_payload_bytes"] == 35651584
    assert summary["production_authority"] is False and summary["replacement_authority"] is False
    assert result["source_unchanged"] and result["binary_unchanged"]
    result["status"] = "passed"
except BaseException as error:
    result["failure_type"] = type(error).__name__
    # Do not turn an exception or private response into public diagnostics.
finally:
    for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(number, signal.SIG_IGN)
    try:
        survivors = terminate_owned()
    except BaseException:
        survivors = ["cleanup_observation_failed"]
    result["owned_group_survivors"] = survivors
    result["owned_child_reaped"] = child is None or child.returncode is not None
    if survivors or not result["owned_child_reaped"] or CANCEL_REQUEST["number"] is not None:
        result["status"] = "failed"
    for name in ("stdout.log", "stderr.log"):
        if (output / name).is_file():
            result[name.replace(".", "_") + "_sha256"] = sha(output / name)
    result["terminal_ns"] = time.time_ns()
    write("result.public.json", result)
    print(json.dumps({"status": result["status"], "passed": result.get("passed_count", 0),
                      "required": result.get("required_count", 31), "failure": result.get("fixture_failure"),
                      "result": str(output / "result.public.json"),
                      "result_sha256": sha(output / "result.public.json"),
                      "full34_qualified": result["full34_qualified"], "production_changed": False}), flush=True)
raise SystemExit(0 if result["status"] == "passed" else 1)
