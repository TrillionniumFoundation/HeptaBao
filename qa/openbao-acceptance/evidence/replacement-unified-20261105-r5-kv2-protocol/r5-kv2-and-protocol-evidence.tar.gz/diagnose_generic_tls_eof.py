#!/usr/bin/env python3
"""One read-only health request on a fresh, uninitialized normal R5 server.

This diagnostic preserves a failed strict transport observation as evidence.
It cannot qualify the original unknown mount operation, matched27, or HA.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import select
import signal
import socket
import ssl
import subprocess
import sys
import threading
import time

R5 = Path('/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r5')
SOURCE = R5 / 'source'
BINARY = R5 / 'build-r1/artifacts/heptabao-server'
BINARY_SHA = '8b42f0a6bc2de0647e558c065f517b52736c208b619902943663fe4a768f44d0'
BUILD_SHA = '8e6fae0298c1b643b70d18e383e8ec64113f8b6b1d55e046daf30a1200c53528'
COMMIT = '1f188df0f2affebb92702222e9fe5dfb4712194c'
TREE = '74bcb2b2af2fc9d349f007cd847fc2f16c08c01a'
COMPARATOR = Path('/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r1/control/matched-kv2-supervision-review-r1/revision-r2/matched_kv2_compare_r2.py')
COMPARATOR_SHA = '14bf2dd12c7e839a270ce7610addc4c8237ca13dc2236d711d3c6f56e5eb5c1a'
SMOKE_SHA = 'ced4e40a825d3d98a285598d40b58c61083cfc397d0859a783958d855a161971'
OUTPUT = R5 / 'tls-generic-eof-diagnostic-r1'
REQUEST_PATH = '/v1/sys/health?uninitcode=204'
HTTP_SECONDS = 15
DIAGNOSTIC_SECONDS = 120
MAX_BYTES = 65536


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def need(value, label):
    if not value:
        raise RuntimeError(label)


def load_comparator():
    need(sha(COMPARATOR) == COMPARATOR_SHA, 'original_comparator_pin')
    spec = importlib.util.spec_from_file_location('diagnostic_original_comparator', COMPARATOR)
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def write_bytes(path, data):
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())


def error_projection(error):
    return {'type': type(error).__name__, 'module': type(error).__module__,
            'errno': getattr(error, 'errno', None), 'library': getattr(error, 'library', None),
            'reason': getattr(error, 'reason', None), 'message': str(error)}


def verify_inputs(cmp):
    need(sys.executable == '/opt/homebrew/bin/python3', 'fixed_interpreter_entry')
    need(cmp.runtime_identity()['executable_sha256'] ==
         'cebfcc4ac431ff7a2179bc6eff7e5c6bdae48b564eeab2d504bef6173a2cfc13', 'fixed_python')
    need(cmp.frozen(SOURCE) == {'commit': COMMIT, 'tree': TREE, 'status': ''}, 'frozen_R5')
    need(sha(R5 / 'build-r1/result.public.json') == BUILD_SHA and sha(BINARY) == BINARY_SHA,
         'retained_normal_build_and_binary')
    built = json.loads((R5 / 'build-r1/result.public.json').read_bytes())
    need(built['status'] == 'built' and sorted(built['artifacts']['heptabao-server']['features']) ==
         ['default', 'native-v6-ha', 'native-v6-storage'], 'normal_features')
    need(sha(SOURCE / 'qa/single-node/smoke.py') == SMOKE_SHA, 'TLS_constructor_pin')


def observe_once(cmp, instance):
    request = ('GET ' + REQUEST_PATH + ' HTTP/1.1\r\nHost: 127.0.0.1:' + str(instance.port)
               + '\r\nAccept: application/json\r\nConnection: close\r\n\r\n').encode('ascii')
    expected_leaf = hashlib.sha256(ssl.PEM_cert_to_DER_cert(
        (instance.root / 'tls.crt').read_text())).hexdigest()
    context = ssl.create_default_context(cafile=str(instance.root / 'ca.crt'))
    context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
    context.set_ciphers('ECDHE-RSA-AES128-GCM-SHA256')
    context.set_alpn_protocols(['http/1.1'])
    context.options &= ~getattr(ssl, 'OP_IGNORE_UNEXPECTED_EOF', 0)
    started = cmp.clock_ns()
    deadline = started + HTTP_SECONDS * 1_000_000_000
    result = {'method': 'GET', 'path': REQUEST_PATH, 'request_count': 1, 'automatic_retry': False,
              'request_sha256': hashlib.sha256(request).hexdigest(), 'request_bytes': len(request),
              'credential_headers': [], 'clock_domain': cmp.CLOCK_DOMAIN,
              'started_ns': started, 'original_deadline_ns': deadline, 'budget_seconds': HTTP_SECONDS,
              'authenticated_tls_eof': False, 'transport_accepted': False, 'stages': []}
    raw = tls = None
    data = bytearray()
    def stage(name):
        cmp.remaining(deadline)
        result['stages'].append({'name': name, 'clock_ns': cmp.clock_ns()})
    try:
        raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw.settimeout(cmp.remaining(deadline))
        raw.connect(('127.0.0.1', instance.port))
        stage('tcp_connected')
        tls = context.wrap_socket(raw, server_hostname='127.0.0.1', do_handshake_on_connect=False,
                                  suppress_ragged_eofs=False)
        raw = None
        tls.settimeout(cmp.remaining(deadline))
        tls.do_handshake()
        stage('tls_verified')
        actual_leaf = hashlib.sha256(tls.getpeercert(binary_form=True)).hexdigest()
        result['tls'] = {'version': tls.version(), 'cipher': tls.cipher()[0],
                         'alpn': tls.selected_alpn_protocol(), 'verified_ca_and_san': True,
                         'expected_leaf_sha256': expected_leaf, 'actual_leaf_sha256': actual_leaf,
                         'suppress_ragged_eofs': tls.suppress_ragged_eofs,
                         'ignore_unexpected_eof': bool(context.options & getattr(ssl, 'OP_IGNORE_UNEXPECTED_EOF', 0))}
        need(actual_leaf == expected_leaf and tls.version() == 'TLSv1.2'
             and tls.cipher()[0] == 'ECDHE-RSA-AES128-GCM-SHA256'
             and tls.selected_alpn_protocol() in (None, 'http/1.1'), 'exact_TLS_identity_and_protocol')
        tls.settimeout(cmp.remaining(deadline))
        tls.sendall(request)
        stage('request_sent')
        while True:
            tls.settimeout(cmp.remaining(deadline))
            block = tls.recv(8192)
            cmp.remaining(deadline)
            if not block:
                result['authenticated_tls_eof'] = True
                stage('close_notify_observed')
                break
            data.extend(block)
            need(len(data) <= MAX_BYTES, 'bounded_readonly_response')
            result['stages'].append({'name': 'response_chunk', 'clock_ns': cmp.clock_ns(), 'bytes': len(block)})
        cmp.remaining(deadline)
    except BaseException as error:
        result['error'] = error_projection(error)
    finally:
        result['finished_ns'] = cmp.clock_ns()
        result['finished_before_original_deadline'] = result['finished_ns'] < deadline
        if tls is not None:
            tls.close()
        if raw is not None:
            raw.close()
    wire = bytes(data)
    write_bytes(OUTPUT / 'response.raw-http', wire)
    result.update(response_bytes=len(wire), response_sha256=hashlib.sha256(wire).hexdigest(),
                  raw_response_path=str(OUTPUT / 'response.raw-http'))
    header, separator, body = wire.partition(b'\r\n\r\n')
    result['raw_header_ascii'] = header.decode('ascii', errors='backslashreplace')
    result['body_bytes'] = len(body) if separator else None
    result['body_sha256'] = hashlib.sha256(body).hexdigest() if separator else None
    status = None
    try:
        parts = header.split(b'\r\n')[0].split(b' ')
        if parts[0] == b'HTTP/1.1':
            status = int(parts[1])
    except (ValueError, IndexError):
        pass
    names = [line.partition(b':')[0].lower() for line in header.split(b'\r\n')[1:]]
    result['status'] = status
    result['http_204_framing_complete'] = bool(separator and status == 204 and not body
        and b'content-length' not in names and b'transfer-encoding' not in names)
    result['transport_accepted'] = bool(result['http_204_framing_complete']
        and result['authenticated_tls_eof'] and result['finished_before_original_deadline']
        and 'error' not in result)
    result['finding'] = ('strict_204_authenticated_EOF' if result['transport_accepted'] else
        'complete_204_then_ragged_TLS_EOF' if result['http_204_framing_complete']
        and result.get('error', {}).get('type') == 'SSLEOFError' else 'other_or_inconclusive')
    return result


def child_main(cmp, nonce, parent_fd):
    verify_inputs(cmp)
    custody = cmp.load_custody()
    os.set_inheritable(parent_fd, False)
    registry = custody.Registry(OUTPUT / 'process-custody', nonce).install()
    parent_lost = threading.Event()
    report = {'schema': 'heptabao.generic-h1-tls-eof-diagnostic.v1', 'status': 'failed',
              'scope': 'one new uninitialized health response only', 'request_count': 0,
              'original_mount_outcome': 'unknown_not_retried', 'synthetic_only': True,
              'production_changed': False, 'ha_qualified': False, 'replacement_qualified': False,
              'source_commit': COMMIT, 'source_tree': TREE, 'binary_sha256': BINARY_SHA,
              'controller_sha256': sha(__file__), 'comparator_sha256': COMPARATOR_SHA,
              'custody_module_sha256': cmp.CUSTODY_SHA256, 'runtime_pin': cmp.runtime_identity()}
    target = log = None
    def monitor_parent():
        while os.read(parent_fd, 1):
            pass
        parent_lost.set()
        custody.parent_pipe_monitor(parent_fd)
    try:
        end = cmp.clock_ns() + 5_000_000_000
        need(select.select([parent_fd], [], [], cmp.remaining(end))[0]
             and os.read(parent_fd, 1) == b'1', 'original_outer_admission')
        threading.Thread(target=monitor_parent, daemon=True).start()
        sys.path.insert(0, str(SOURCE / 'qa/openbao-acceptance'))
        sys.path.insert(0, str(SOURCE / 'qa/single-node'))
        import smoke
        instance = smoke.Instance(BINARY, OUTPUT / 'private-server')
        config_path = instance.root / 'server.json'
        config = json.loads(config_path.read_bytes())
        need('storage' not in config and not Path(config['data_dir']).exists(), 'fresh_uninitialized_storage')
        config['storage'] = {'native_v6_file': {'path': config['data_dir']}}
        config_path.write_text(json.dumps(config))
        argv = [str(BINARY), '--config', str(config_path)]
        report.update(argv=argv, config=config, config_sha256=sha(config_path),
                      generated_ca_sha256=sha(instance.root / 'ca.crt'), smoke_sha256=sha(smoke.__file__))
        cmp.private_json(OUTPUT / 'server-launch.public.json', {k: report[k] for k in
            ('argv', 'config', 'config_sha256', 'binary_sha256', 'generated_ca_sha256')})
        log = (instance.root / 'server.log').open('xb')
        target = subprocess.Popen(argv, cwd=instance.root, env=cmp.clean_environment(),
                                  stdin=subprocess.DEVNULL, stdout=log, stderr=log)
        report['target'] = cmp.bind_target(target, expected_argv=argv,
                         expected_executable=BINARY, expected_sha256=BINARY_SHA)
        # Readiness is TCP only. No HTTP is sent before the one recorded GET.
        listener_end = cmp.clock_ns() + 15_000_000_000
        while True:
            need(target.poll() is None, 'normal_server_exited_before_request')
            probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                probe.settimeout(min(0.1, cmp.remaining(listener_end)))
                probe.connect(('127.0.0.1', instance.port))
                break
            except (ConnectionRefusedError, socket.timeout):
                cmp.remaining(listener_end)
                time.sleep(min(0.02, cmp.remaining(listener_end)))
            finally:
                probe.close()
        report['request_count'] = 1
        report['observation'] = observe_once(cmp, instance)
        report['status'] = 'observed'
    except BaseException as error:
        report['failure'] = error_projection(error)
    finally:
        for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(number, signal.SIG_IGN)
        if target is not None:
            was_live = target.poll() is None
            if was_live:
                target.kill()
            target.wait(timeout=5)
            report['target_stop'] = {'pid': target.pid, 'original_Popen_held': True,
                'was_live': was_live, 'action': 'SIGKILL' if was_live else 'already_exited',
                'same_original_waited': True, 'exit_code': target.returncode}
        if log is not None:
            log.close()
        receipt = registry.finish()
        report['parent_pipe_lost'] = parent_lost.is_set()
        report['custody_complete'] = bool(receipt['integrity'] and receipt['cancellation_signal'] is None
            and receipt['all_registered_original_children_reaped']
            and receipt['all_registered_session_groups_empty_before_reap'] and not parent_lost.is_set())
        if not report['custody_complete']:
            report['status'] = 'failed'
        cmp.private_json(OUTPUT / 'observation.public.json', report)
    return 0 if report['status'] == 'observed' else 1


def main():
    cmp = load_comparator()
    if len(sys.argv) == 4 and sys.argv[1] == '--_child':
        return child_main(cmp, sys.argv[2], int(sys.argv[3]))
    need(len(sys.argv) == 1, 'no_caller_overrides')
    verify_inputs(cmp)
    need(not OUTPUT.exists(), 'new_diagnostic_root_required')
    os.umask(0o077)
    OUTPUT.mkdir(mode=0o700)
    result = {'schema': 'heptabao.generic-h1-tls-eof-diagnostic-controller.v1', 'status': 'failed',
              'controller_sha256': sha(__file__), 'production_changed': False,
              'replacement_qualified': False, 'ha_qualified': False, 'automatic_retry': False}
    nonce = os.urandom(16).hex()
    owner = cmp.WorkerOwner(OUTPUT, OUTPUT / 'process-custody', nonce, result)
    for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(number, owner.request_cancel)
    try:
        with (OUTPUT / 'worker.stdout').open('xb') as out, (OUTPUT / 'worker.stderr').open('xb') as err:
            owner.start([sys.executable, '-I', '-S', '-B', str(Path(__file__).resolve()),
                '--_child', nonce, 'PARENT_FD'], cwd=OUTPUT, env=cmp.clean_environment(), stdout=out, stderr=err)
            timed_out = owner.wait_original(owner.started_ns + DIAGNOSTIC_SECONDS * 1_000_000_000)
            remaining = owner.stop()
            need(not timed_out and not remaining and owner.child.returncode == 0,
                 'diagnostic_worker_or_custody_failed')
        report = json.loads((OUTPUT / 'observation.public.json').read_bytes())
        need(report['custody_complete'] and report['request_count'] == 1 and report['status'] == 'observed',
             'one_observation_and_custody_required')
        need(owner.cancelled['number'] is None and result['main_session_cleanup']['group_empty_before_first_reap']
             and result['main_session_cleanup']['signals_after_reap'] == 0
             and not result['main_session_cleanup']['unexpected_descendants'], 'original_session_complete')
        result.update(status='observed', finding=report['observation']['finding'],
                      transport_accepted=report['observation']['transport_accepted'],
                      observation_sha256=sha(OUTPUT / 'observation.public.json'))
    except BaseException as error:
        result['failure'] = error_projection(error)
    finally:
        for number in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(number, signal.SIG_IGN)
        result['owned_group_survivors'] = owner.stop()
        result['same_original_worker_reaped'] = owner.child is None or owner.child.returncode is not None
        result['source_unchanged'] = cmp.frozen(SOURCE) == {'commit': COMMIT, 'tree': TREE, 'status': ''}
        result['binary_unchanged'] = sha(BINARY) == BINARY_SHA
        if result['owned_group_survivors'] or not result['same_original_worker_reaped'] or not result['source_unchanged'] or not result['binary_unchanged']:
            result['status'] = 'failed'
        result['custody_receipt_sha256'] = sha(OUTPUT / 'process-custody/result.public.json')
        cmp.private_json(OUTPUT / 'result.public.json', result)
    print(json.dumps({'status': result['status'], 'result': str(OUTPUT / 'result.public.json'),
                      'result_sha256': sha(OUTPUT / 'result.public.json'), 'finding': result.get('finding'),
                      'transport_accepted': result.get('transport_accepted')}))
    return 0 if result['status'] == 'observed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
