#!/usr/bin/env python3
"""Aggregate the two independently retained regression results without running tests."""
import argparse
import importlib.util
import json
import os
import time
from pathlib import Path

ROOT = Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r1")
COMMIT = "9208e0765f566f3bd7908e6567d2e39008156b9b"
TREE = "3a353adca3300eb46dbe8622c36eaa1f6d3fa7ce"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--build-result", required=True)
    parser.add_argument("--build-result-sha256", required=True)
    parser.add_argument("--server-result", default=str(ROOT / "regression-server-r1/result.public.json"))
    parser.add_argument("--ha-result", default=str(ROOT / "regression-ha-r1/result.public.json"))
    parser.add_argument("--output", default=str(ROOT / "regression-r1"))
    args = parser.parse_args()
    os.umask(0o077)
    control = ROOT / "control"
    runner_path = control / "run_unified_regressions.py"
    spec = importlib.util.spec_from_file_location("regression_runner", runner_path)
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    output = Path(args.output)
    runner.require(output.is_absolute() and not output.exists(), "existing aggregate is immutable")
    output.mkdir(mode=0o700)
    result = {
        "schema": "heptabao.unified-regression-aggregate.v1",
        "status": "failed", "started_ns": time.time_ns(),
        "source_commit": COMMIT, "source_tree": TREE,
        "expected_unique_tests": 176, "expected_server_tests": 167, "expected_ha_tests": 9,
        "passed": 0, "original_60_passed": 0, "full_denominator_retained": False,
        "source_unchanged": False, "production_changed": False,
        "full_replacement_qualified": False,
        "controller_sha256": runner.sha(__file__),
        "build_result_path": args.build_result,
        "build_result_sha256": args.build_result_sha256,
    }
    runner.durable_json(output / "intent.public.json", result)
    try:
        preparation_path = runner.regular(control / "regression-preparation.public.json")
        preparation = json.loads(preparation_path.read_text())
        runner.require(preparation["source_commit"] == COMMIT and preparation["source_tree"] == TREE,
                       "preparation uses another source")
        runner.require(runner.sha(runner_path) == preparation["controller_sha256"],
                       "regression runner changed after preparation")
        build_path = runner.regular(Path(args.build_result))
        runner.require(runner.sha(build_path) == args.build_result_sha256, "build receipt digest changed")
        build = json.loads(build_path.read_text())
        runner.require(build["status"] == "built" and build["source_unchanged"] is True,
                       "normal build is not successful and frozen")
        runner.require(build["source_commit"] == COMMIT and build["source_tree"] == TREE,
                       "build and regression source combination differ")
        server_artifact = build["artifacts"]["heptabao-server"]
        runner.require(server_artifact["profile"] == {
            "opt_level": "3", "debuginfo": 0, "debug_assertions": True,
            "overflow_checks": True, "test": False,
        }, "production server is not the normal release artifact")
        runner.require(sorted(server_artifact["features"]) == ["default", "native-v6-ha", "native-v6-storage"],
                       "production server feature combination changed")
        runner.require(runner.sha(runner.regular(server_artifact["path"])) == server_artifact["sha256"],
                       "normal server artifact changed")
        result["server_sha256"] = server_artifact["sha256"]
        result["server_binary_path"] = server_artifact["path"]
        result["preparation_path"] = str(preparation_path)
        result["preparation_sha256"] = runner.sha(preparation_path)
        children = []
        all_rows = []
        all_denominators_retained = True
        all_children_passed = True
        all_children_frozen = True
        expected_counts = {"server": 167, "ha": 9}
        for suite, child_path in (("server", Path(args.server_result)), ("ha", Path(args.ha_result))):
            manifest_binding = preparation[suite + "_manifest"]
            manifest_path = runner.regular(manifest_binding["path"])
            manifest_digest = runner.sha(manifest_path)
            runner.require(manifest_digest == manifest_binding["sha256"], "prepared manifest changed")
            manifest = json.loads(manifest_path.read_text())
            _groups, names, _memberships = runner.validate_manifest(manifest)
            runner.require(len(names) == expected_counts[suite], "suite denominator changed")
            runner.require(manifest["source_commit"] == COMMIT and manifest["source_tree"] == TREE,
                           "manifest source changed")
            child_path = runner.regular(child_path)
            child_digest = runner.sha(child_path)
            child = json.loads(child_path.read_text())
            runner.require(child["suite"] == suite, "wrong child suite")
            runner.require(child["source_commit"] == COMMIT and child["source_tree"] == TREE,
                           "child source combination changed")
            runner.require(child["build_result_sha256"] == args.build_result_sha256,
                           "child and normal server do not share the exact build receipt")
            runner.require(child["manifest_sha256"] == manifest_digest, "child manifest differs")
            runner.require(child["controller_sha256"] == preparation["controller_sha256"],
                           "child runner differs from reviewed preparation")
            artifact_key = "libtest_artifact" if suite == "server" else "ha_libtest_artifact"
            artifact = build[artifact_key]
            runner.require(child.get("binary", {}).get("sha256") == artifact["sha256"],
                           "child test artifact is not from the normal build")
            runner.require(runner.sha(runner.regular(artifact["path"])) == artifact["sha256"],
                           "retained test artifact changed")
            rows = child["tests"]
            actual_names = [row["name"] for row in rows]
            runner.require(len(actual_names) == len(set(actual_names)) and set(actual_names) == set(names),
                           "child omitted, duplicated, or substituted declared tests")
            passed = sum(row["status"] == "passed" for row in rows)
            runner.require(child["passed"] == passed and child["expected_unique_tests"] == len(names),
                           "child totals do not describe its real rows")
            all_denominators_retained &= child.get("full_denominator_retained") is True
            all_children_frozen &= child.get("source_unchanged") is True and child.get("binary_unchanged") is True
            child_passed = (
                child.get("status") == "passed" and passed == len(names)
                and child.get("attempted_once") == len(names)
                and child.get("all_owned_groups_empty") is True
                and child.get("admission_and_identity_checks_passed") is True
            )
            all_children_passed &= child_passed
            if suite == "server":
                original = set(manifest["original_60_exact_names"])
                original_passed = sum(row["name"] in original and row["status"] == "passed" for row in rows)
                runner.require(child["original_test_denominator"] == 60 and len(original) == 60,
                               "original sixty denominator changed")
                runner.require(child["original_60_passed"] == original_passed, "original sixty result differs")
                result["original_60_passed"] = original_passed
            children.append({
                "suite": suite, "path": str(child_path), "sha256": child_digest,
                "manifest_path": str(manifest_path), "manifest_sha256": manifest_digest,
                "libtest_sha256": artifact["sha256"],
                "expected_tests": len(names), "passed": passed,
                "status": child["status"], "same_normal_build_receipt": True,
                "all_owned_groups_empty": child.get("all_owned_groups_empty") is True,
            })
            all_rows.extend({"crate": manifest["crate"], **row} for row in rows)
        runner.require(len(all_rows) == 176, "aggregate denominator changed")
        source_now = runner.freeze(ROOT / "source")
        source_frozen = source_now == {"commit": COMMIT, "tree": TREE, "status": ""}
        result.update({
            "children": children, "tests": all_rows,
            "passed": sum(row["status"] == "passed" for row in all_rows),
            "full_denominator_retained": all_denominators_retained,
            "source_unchanged": source_frozen and all_children_frozen,
            "source_at_aggregation": source_now,
            "server_libtest_sha256": build["libtest_artifact"]["sha256"],
            "ha_libtest_sha256": build["ha_libtest_artifact"]["sha256"],
            "all_owned_groups_empty": all(child["all_owned_groups_empty"] for child in children),
            "aggregate_starts_no_product_processes": True,
        })
        runner.require(runner.sha(build_path) == args.build_result_sha256, "build receipt changed while aggregating")
        result["status"] = "passed" if (
            all_children_passed and result["passed"] == 176
            and result["original_60_passed"] == 60 and result["full_denominator_retained"]
            and result["source_unchanged"] and result["all_owned_groups_empty"]
        ) else "failed"
    except BaseException as exc:
        result["status"] = "failed"
        result["failure_type"] = type(exc).__name__
        result["failure"] = str(exc)
    finally:
        result["terminal_ns"] = time.time_ns()
        runner.durable_json(output / "result.public.json", result)
        print(json.dumps({
            "status": result["status"], "passed": result["passed"], "denominator": 176,
            "original_60_passed": result["original_60_passed"],
            "result": str(output / "result.public.json"),
            "result_sha256": runner.sha(output / "result.public.json"),
        }), flush=True)
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
