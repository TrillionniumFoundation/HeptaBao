#!/usr/bin/env python3
"""Package a failed diagnostic without changing its result or source."""
import base64, gzip, hashlib, io, json, os, re, stat, subprocess, sys, tarfile
from pathlib import Path
os.umask(0o077)
ROOT=Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r4-diagnostic")
SOURCE=ROOT/"source"
OUT=ROOT/"public-evidence-r1"
def digest(b): return hashlib.sha256(b).hexdigest()
def canonical(x): return (json.dumps(x,sort_keys=True,indent=2,ensure_ascii=False)+"\n").encode()
def write(path,data):
    with path.open("xb") as f:
        f.write(data);f.flush();os.fsync(f.fileno())
def git(*args):return subprocess.check_output(["/usr/bin/git","-C",str(SOURCE),*args],timeout=30)
def read(path):
    assert path.is_file() and not path.is_symlink()
    assert path.resolve(strict=True)==path
    assert stat.S_ISREG(path.stat().st_mode)
    return path.read_bytes()
assert not OUT.exists()
assert git("rev-parse","HEAD").strip()==b"d784a7cb75643bde9d9224d90427dbcddda60a4b"
assert git("rev-parse","HEAD^{tree}").strip()==b"c5a4df63dd04c0fa0b39e07f73014796affce752"
assert not git("status","--porcelain","--untracked-files=all").strip()
payload=json.loads(sys.stdin.buffer.read())
assert payload["diagnostic_terminal"]["job_id"]=="1a1aaa2d835-fc05-4571"
assert payload["diagnostic_terminal"]["state"]=="failed"
assert payload["diagnostic_terminal"]["exit_code"]==1
for v in (payload["source_terminal"],payload["diagnostic_terminal"]):
    assert v["output_complete"] and v["output_durable"] and v["terminal_publication_confirmed"]
    assert not v["timed_out"] and not v["automatic_retry"]
    assert not any(v["log_truncated"].values())
relative=[
"control/build_and_diagnose_publications.py",
"control/source-freeze.public.json",
"control/source.diff",
"diagnostic-publications-r1/intent.public.json",
"diagnostic-publications-r1/inventory.public.json",
"diagnostic-publications-r1/inventory.stdout",
"diagnostic-publications-r1/inventory.stderr",
"diagnostic-publications-r1/normal-libtest-build.public.json",
"diagnostic-publications-r1/normal-libtest-build.stdout",
"diagnostic-publications-r1/normal-libtest-build.stderr",
"diagnostic-publications-r1/result.public.json",
"diagnostic-publications-r1/test-0000.public.json",
"diagnostic-publications-r1/test-0000.stdout",
"diagnostic-publications-r1/test-0000.stderr",
]
entries={name:read(ROOT/name) for name in relative}
expected={
"control/build_and_diagnose_publications.py":"949376a1dca146f04327b584066d7e6d54a90017b42b93138870a2ddd45b0a11",
"control/source-freeze.public.json":"31803ef6ab6796c9f225795dc77b28fd00ea10a9a10897726430368153d6924a",
"control/source.diff":"7985a1457a79c429bbd2fe2e6c7bc66c5fd19823297480ec8b3f33b98bf381e2",
"diagnostic-publications-r1/result.public.json":"ad71d706b1f7afec4d93e0a75fbabbecb1cca80401247e04f99ade8e93aa54eb",
"diagnostic-publications-r1/test-0000.stderr":"de5fa55d0a8866e49082e6738bb6c8178ecc8a12807e1b1a2e7a10bc9fab382c",
}
for name,value in expected.items():assert digest(entries[name])==value,(name,digest(entries[name]))
result=json.loads(entries["diagnostic-publications-r1/result.public.json"])
assert result["status"]=="failed" and result["passed"]==0 and result["expected_unique_tests"]==1
assert result["diagnostic_only"] and not result["production_changed"] and not result["full_replacement_qualified"]
assert result["source_unchanged"] and result["artifact_unchanged"] and result["all_owned_groups_empty"]
source_file="crates/heptabao-server/src/service_native_v6_ha_snapshot_acl_tests.rs"
current=read(SOURCE/source_file)
assert digest(current)=="989ce8b1b27e054a610a4fd9f246ba7fc6e3cbcade9473c1963bc1f9dd025414"
before=git("show","6b16a9292d046bbc42aec65045fa105aaa1ac5de:"+source_file)
pos=0
for line in current.splitlines(keepends=True):
    if pos<len(before.splitlines(keepends=True)) and line==before.splitlines(keepends=True)[pos]:pos+=1
assert pos==len(before.splitlines(keepends=True))
removed=[line for line in entries["control/source.diff"].splitlines() if line.startswith(b"-") and not line.startswith(b"---")]
assert not removed
raw=git("cat-file","commit","HEAD")
assert hashlib.sha1(b"commit "+str(len(raw)).encode()+b"\0"+raw).hexdigest()=="d784a7cb75643bde9d9224d90427dbcddda60a4b"
entries["source/diagnostic-commit.raw"]=raw
entries["source/"+source_file]=current
entries["independent-runtime-terminals.public.json"]=canonical(payload)
entries["control/package_r4_public_diagnostic.py"]=read(Path(__file__).resolve())
patterns=[
re.compile(rb"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
re.compile(rb"(?<![A-Za-z0-9])(?:hvs|hvb|hvr|s)\.[A-Za-z0-9_-]{16,}"),
re.compile(rb'"(?:client_token|secret_id|role_id|unseal_key)"\s*:\s*"[A-Za-z0-9_+/=.-]{20,}"'),
re.compile(rb"eyJ[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}"),
]
positives=[
b"-----BEGIN "+b"PRIVATE KEY-----",
b"hvs."+b"x"*24,
b'"client_token": "'+b"x"*24+b'"',
b"eyJ"+b"x"*16+b"."+b"y"*16+b"."+b"z"*16,
]
assert all(p.search(v) for p,v in zip(patterns,positives))
findings=[{"path":name,"rule":i} for name,data in entries.items() for i,p in enumerate(patterns) if p.search(data)]
assert not findings, findings
manifest={
"schema":"heptabao.r4-publication-diagnostic-evidence-manifest.v1",
"source_commit":"d784a7cb75643bde9d9224d90427dbcddda60a4b",
"source_tree":"c5a4df63dd04c0fa0b39e07f73014796affce752",
"source_parent":"6b16a9292d046bbc42aec65045fa105aaa1ac5de",
"status":"failed","passed":0,"required":1,"diagnostic_only":True,
"all_original_source_lines_retained_in_order":True,"original_failed_equality_retained":True,
"all_original_evidence_hashes_match":True,
"production_changed":False,"full_replacement_qualified":False,
"scanner":{"rules":4,"positive_controls":4,"findings":0,"scope":"allowlisted public diagnostic files only"},
"entries":[{"path":name,"bytes":len(data),"sha256":digest(data)} for name,data in sorted(entries.items())],
}
m=canonical(manifest)
def package():
    rawtar=io.BytesIO()
    with tarfile.open(fileobj=rawtar,mode="w",format=tarfile.USTAR_FORMAT) as tar:
        for name,data in sorted({**entries,"MANIFEST.public.json":m}.items()):
            info=tarfile.TarInfo(name);info.size=len(data);info.uid=info.gid=0;info.uname=info.gname="";info.mtime=0;info.mode=0o644
            tar.addfile(info,io.BytesIO(data))
    out=io.BytesIO()
    with gzip.GzipFile(filename="",mode="wb",fileobj=out,mtime=0,compresslevel=9) as g:g.write(rawtar.getvalue())
    return out.getvalue()
archive=package()
assert archive==package()
with tarfile.open(fileobj=io.BytesIO(archive),mode="r:gz") as tar:
    members=tar.getmembers()
    assert len(members)==len(entries)+1
    assert {x.name for x in members}==set(entries)|{"MANIFEST.public.json"}
    for info in members:
        assert info.isfile()
        data=tar.extractfile(info).read()
        assert data==(m if info.name=="MANIFEST.public.json" else entries[info.name])
for name in relative:assert read(ROOT/name)==entries[name]
assert read(SOURCE/source_file)==current
assert not git("status","--porcelain","--untracked-files=all").strip()
OUT.mkdir(mode=0o700)
write(OUT/"r4-publication-diagnostic-evidence.tar.gz",archive)
write(OUT/"MANIFEST.public.json",m)
receipt={
"schema":"heptabao.r4-publication-diagnostic-package.v1",
"status":"packaged","diagnostic_status":"failed","passed":0,"required":1,
"archive_path":str(OUT/"r4-publication-diagnostic-evidence.tar.gz"),
"archive_bytes":len(archive),"archive_sha256":digest(archive),
"manifest_sha256":digest(m),"evidence_entries":len(entries),"archive_members":len(entries)+1,
"all_member_readback_matched":True,"deterministic_repeat_matched":True,
"source_and_original_evidence_unchanged":True,
"package_controller_sha256":digest(read(Path(__file__).resolve())),
"production_changed":False,"full_replacement_qualified":False,
}
write(OUT/"package.public.json",canonical(receipt))
fd=os.open(OUT,os.O_RDONLY)
try:os.fsync(fd)
finally:os.close(fd)
print(json.dumps(receipt,sort_keys=True),flush=True)
