#!/usr/bin/env python3
"""Build frozen merged HeptaBao source and retain real Cargo artifacts."""
import argparse, hashlib, json, os, resource, shutil, signal, subprocess, time
from pathlib import Path
os.umask(0o077)
p=argparse.ArgumentParser()
for n in ("source","output","commit","tree","toolchain","cargo-home","target"):
    p.add_argument("--"+n,required=True)
a=p.parse_args()
source=Path(a.source).resolve(strict=True)
output=Path(a.output)
assert not output.exists() and output.is_absolute()
assert os.uname().sysname=="Darwin" and os.uname().machine=="arm64"
output.mkdir(mode=0o700)
children=[]
profile={
 "PATH":a.toolchain+":/opt/homebrew/bin:/usr/bin:/bin",
 "CARGO_HOME":a.cargo_home,"CARGO_TARGET_DIR":a.target,"CARGO_BUILD_JOBS":"2",
 "CARGO_PROFILE_RELEASE_OPT_LEVEL":"3","CARGO_PROFILE_RELEASE_CODEGEN_UNITS":"16",
 "CARGO_PROFILE_RELEASE_LTO":"false","CARGO_PROFILE_RELEASE_DEBUG":"0",
 "CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS":"true","CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS":"true",
 "CARGO_PROFILE_RELEASE_PANIC":"unwind","RUSTFLAGS":"","CARGO_TERM_COLOR":"never"}
env=dict(os.environ);env.update(profile);env.pop("CARGO_ENCODED_RUSTFLAGS",None)
def sha(path):
    with Path(path).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
def write(name,data):
    with (output/name).open("x") as f:
        json.dump(data,f,indent=2,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
    fd=os.open(output,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
def git(*args):
    return subprocess.check_output(["/usr/bin/git","-C",str(source),*args],text=True,timeout=30).strip()
def freeze():
    return {"commit":git("rev-parse","HEAD"),"tree":git("rev-parse","HEAD^{tree}"),"status":git("status","--porcelain")}
def members(pgid):
    raw=subprocess.check_output(["/bin/ps","-axo","pid=,ppid=,pgid=,stat="],text=True,timeout=10)
    return [line.strip() for line in raw.splitlines() if len(line.split())>=4 and int(line.split()[2])==pgid]
def stop(child):
    if child.poll() is None:
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait(timeout=5)
    return members(child.pid)
class Cancelled(BaseException):pass
def on_signal(sig,frame):raise Cancelled(sig)
signal.signal(signal.SIGTERM,on_signal);signal.signal(signal.SIGINT,on_signal)
def owned(label,args,seconds):
    start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
    timed=False
    with (output/(label+".stdout")).open("xb") as stdout,(output/(label+".stderr")).open("xb") as stderr:
        blocked=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGTERM,signal.SIGINT})
        try:
            child=subprocess.Popen(args,cwd=source,env=env,stdin=subprocess.DEVNULL,
                  stdout=stdout,stderr=stderr,start_new_session=True)
            children.append((label,child))
        finally:signal.pthread_sigmask(signal.SIG_SETMASK,blocked)
        try:code=child.wait(timeout=seconds)
        except subprocess.TimeoutExpired:
            timed=True;stop(child);code=child.returncode
        finally:
            if child.poll() is None:stop(child)
            stdout.flush();stderr.flush();os.fsync(stdout.fileno());os.fsync(stderr.fileno())
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    remaining=members(child.pid)
    rec={"label":label,"argv":args,"exit_code":code,"timed_out":timed,
      "elapsed_seconds":time.monotonic()-start,"outer_cap_seconds":seconds,
      "direct_child_reaped":child.returncode is not None,"owned_pgid":child.pid,"remaining":remaining,
      "children_user_cpu_seconds":after.ru_utime-before.ru_utime,
      "children_system_cpu_seconds":after.ru_stime-before.ru_stime,
      "cumulative_children_peak_rss_bytes":after.ru_maxrss,
      "rss_scope":"Darwin RUSAGE_CHILDREN high-water mark since this controller began",
      "stdout_sha256":sha(output/(label+".stdout")),"stderr_sha256":sha(output/(label+".stderr"))}
    write(label+".public.json",rec)
    assert not remaining,"owned build process group not empty"
    return rec
def cargo_events(label):
    rows=[]
    for line in (output/(label+".stdout")).read_text().splitlines():
        try:rows.append(json.loads(line))
        except json.JSONDecodeError:pass
    assert any(e.get("reason")=="build-finished" and e.get("success") is True for e in rows),"missing real build-finished"
    return rows
def retain(event,path,test,features=None):
    expected = ["default","native-v6-ha","native-v6-storage"] if features is None else features
    assert sorted(event["features"])==sorted(expected)
    assert event["profile"]=={"opt_level":"3","debuginfo":0,"debug_assertions":True,"overflow_checks":True,"test":test}
    original=Path(event["executable"]);assert original.is_file() and not original.is_symlink()
    assert original.resolve().is_relative_to(Path(a.target).resolve())
    digest=sha(original)
    with original.open("rb") as src,path.open("xb") as dst:
        shutil.copyfileobj(src,dst,1024*1024);dst.flush();os.fsync(dst.fileno())
    path.chmod(0o500);assert sha(path)==digest and sha(original)==digest
    return {"path":str(path),"sha256":digest,"bytes":path.stat().st_size,
      "compiler_executable":str(original),"features":event["features"],"profile":event["profile"],"fresh":event.get("fresh")}
import re
r1=Path("/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r3")
prior_path=r1/"regression-server-r1/test-0128.public.json"
assert sha(prior_path)=="9d4e88f43015655ed849573182e19a813045591a3c2653c888009b94bd4cafdd"
prior=json.loads(prior_path.read_text())
assert prior["exit_code"] == 101 and prior["outer_cap_seconds"] == 120 and not prior["timed_out"]
selected=[prior["argv"][1]]
assert len(selected)==len(set(selected))==1
result={"schema":"heptabao.formal-pending-restore-clock-diagnostic.v1","status":"failed","source_commit":a.commit,"source_tree":a.tree,
 "started_ns":time.time_ns(),"controller_sha256":sha(__file__),"profile":profile,
 "expected_unique_tests":1,"original_application_deadlines_unchanged":True,
 "source_result_sha256":sha(prior_path),"diagnostic_only":True,"production_changed":False,"full_replacement_qualified":False,
 "tests":[{"name":n,"status":"not_run"} for n in selected]}
write("intent.public.json",result)
try:
    before=freeze();assert before=={"commit":a.commit,"tree":a.tree,"status":""}
    rustc=subprocess.check_output([str(Path(a.toolchain)/"rustc"),"-vV"],text=True,timeout=30)
    assert "release: 1.98.0" in rustc and "host: aarch64-apple-darwin" in rustc
    result["rustc_vv"]=rustc
    build=owned("normal-libtest-build",[str(Path(a.toolchain)/"cargo"),"test","--release","--locked","--offline",
      "-p","heptabao-server","--lib","--no-run","--message-format=json-render-diagnostics"],1800)
    result["libtest_build"]=build
    assert build["exit_code"]==0 and not build["timed_out"],"normal libtest compilation failed"
    events=cargo_events("normal-libtest-build")
    matches=[e for e in events if e.get("reason")=="compiler-artifact" and e.get("profile",{}).get("test")
      and e.get("target",{}).get("name")=="heptabao_server" and e.get("executable")]
    assert len(matches)==1
    result["libtest_artifact"]=retain(matches[0],output/"retained-heptabao-server-libtest",True)
    binary=result["libtest_artifact"]["path"]
    inv=owned("inventory",[binary,"--list"],60);assert inv["exit_code"]==0 and not inv["timed_out"]
    raw=(output/"inventory.stdout").read_text()
    names=re.findall(r"(?m)^([A-Za-z0-9_:]+): test$",raw)
    summary=re.findall(r"(?m)^(\d+) tests?, (\d+) benchmarks?\s*$",raw)
    assert len(names)==len(set(names)) and len(summary)==1 and int(summary[0][0])==len(names)
    assert set(selected).issubset(names)
    print(json.dumps({"phase":"diagnostic_libtest_built","binary_sha256":result["libtest_artifact"]["sha256"],"selected":1}),flush=True)
    for i,row in enumerate(result["tests"]):
        rec=owned("test-%04d"%i,[binary,row["name"],"--exact","--nocapture","--test-threads=1"],120)
        raw=(output/("test-%04d.stdout"%i)).read_text()
        counts=re.findall(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;",raw)
        running=re.findall(r"(?m)^running (\d+) tests?\s*$",raw)
        passed=rec["exit_code"]==0 and not rec["timed_out"] and running==["1"] and len(counts)==1 and counts[0][:5]==("ok","1","0","0","0")
        row.update(rec);row["status"]="passed" if passed else "failed"
        print(json.dumps({"phase":"diagnostic_test","index":i,"name":row["name"],"status":row["status"],"elapsed_seconds":rec["elapsed_seconds"]}),flush=True)
    assert freeze()==before
    assert sha(binary)==result["libtest_artifact"]["sha256"]
    result["source_unchanged"]=True;result["artifact_unchanged"]=True
    result["passed"]=sum(r["status"]=="passed" for r in result["tests"])
    if result["passed"]==1:result["status"]="passed"
except BaseException as exc:
    result["failure_type"]=type(exc).__name__;result["failure"]=str(exc)
finally:
    signal.signal(signal.SIGTERM,signal.SIG_IGN);signal.signal(signal.SIGINT,signal.SIG_IGN)
    cleanup=[]
    for label,child in reversed(children):
        try:remaining=stop(child)
        except BaseException:remaining=["cleanup_observation_failed"]
        cleanup.append({"label":label,"pid":child.pid,"exit_code":child.returncode,"direct_child_reaped":child.returncode is not None,"remaining":remaining})
    result["all_owned_groups_empty"]=all(not r["remaining"] and r["direct_child_reaped"] for r in cleanup)
    if not result["all_owned_groups_empty"]:result["status"]="failed"
    result["cleanup"]=cleanup;result["terminal_ns"]=time.time_ns()
    write("result.public.json",result)
    print(json.dumps({"status":result["status"],"passed":result.get("passed",0),"expected_unique_tests":1,"result_sha256":sha(output/"result.public.json"),"diagnostic_only":True}),flush=True)
raise SystemExit(0 if result["status"]=="passed" else 1)
