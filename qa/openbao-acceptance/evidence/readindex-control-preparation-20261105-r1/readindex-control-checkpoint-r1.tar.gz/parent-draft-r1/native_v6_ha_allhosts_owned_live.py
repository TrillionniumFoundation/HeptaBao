#!/usr/bin/env python3
"""All-three-host continuous custody for the unchanged native/official-history 128 cases."""
import hashlib,importlib.util,json,os,re,shlex,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
DRAFT_ONLY=True
if DRAFT_ONLY:raise RuntimeError("new_native128_owner_adapter_not_frozen")
SOURCE_ROOT=Path('/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r9/source')
SOURCE_COMMIT='fa37c0fc6f28317d5f432bbbc2bbae062c4be064'
SOURCE_TREE='b1911f24c0b5c2c2ca67590b4e52c7d47dbf43af'
OWNER_DIR=Path('/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r9/control/ha-allhosts-owner-r2')
HISTORY=Path('/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r9/control/ha-official-history-readindex-r1/native_v6_ha_official_history_live.py')
HISTORY_SHA256='00676bf477e4c4f3780013a9d74b694d0b0ee84d06f02b3e6c4a01f729f465e2'
HISTORY_PREPARATION_SHA256='UNFROZEN_R9_HISTORY_PREPARATION'
HISTORY_WIRE_SHA256="71a81748c07f22a2584993239b28e2e02babe97e5de8fc1f6911d7353fa3bc22"
HELPER_SHA256='b3bc7a066ffbb5b76e4583b8b85ab3a594e176b43b13c14e8eac6404ecb6b663'
RECONCILE_SHA256='b22e58b500caf2c6c55f6e37119ccfea07f4ffed8fe82f3170741d1fb4aae700'
PREPARATION_SHA256='UNFROZEN_R9_OWNER_PREPARATION'
TOY21_SHA256='UNFROZEN_R9_ACTUAL_OWNER21'
OWNER_CASES=(
 "all_three_actual_host_preflights",
 "every_submitted_launch_accounted_once",
 "every_live_stop_within_original_five_seconds",
 "every_remote_canonical_cleanup_verified",
 "every_original_ssh_birth_absent",
 "native_all_three_and_v5_seed_covered")
ALIASES={"hepta-mac-local","rog-ts","hepta-pocket4"}

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def need(v,label):
 if not v:raise RuntimeError(label)
def load(name,path,digest):
 path=Path(path)
 need(path.is_absolute() and path.resolve(strict=True)==path and path.is_file() and not path.is_symlink(),"control path changed")
 need(sha(path)==digest,"control bytes changed")
 spec=importlib.util.spec_from_file_location(name,path)
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
 return module
def exact_new_or_same(path,raw):
 path=Path(path)
 if path.exists():
  need(path.is_file() and not path.is_symlink() and path.read_bytes()==raw,"immutable owner record differs")
 else:owner.new_file(path,raw)

owner=load("allhosts_native_foreground",OWNER_DIR/"native_ha_foreground_watchdog.py",HELPER_SHA256)
reconcile=load("allhosts_native_reconcile",OWNER_DIR/"reconcile_owner.py",RECONCILE_SHA256)
need(sha(OWNER_DIR/"preparation.public.json")==PREPARATION_SHA256,"owner preflight pins changed")
need(sha(OWNER_DIR/"toy-aggregate-r1/result.public.json")==TOY21_SHA256,"owner toy21 pins changed")
PREPARATION=json.loads((OWNER_DIR/"preparation.public.json").read_text())
toy21=json.loads((OWNER_DIR/"toy-aggregate-r1/result.public.json").read_text())
need(toy21["status"]=="passed" and toy21["passed"]==toy21["expected"]==21
 and toy21["same_helper_all_21"] and toy21["helper_sha256"]==HELPER_SHA256
 and toy21["native_product_custody_qualified"] is False,"owner custody scope differs")
need(sha(HISTORY.parent/"preparation.public.json")==HISTORY_PREPARATION_SHA256,"R5 history source preparation changed")
need(sha(HISTORY.parent/"native_v6_ha_official_history_wire.py")==HISTORY_WIRE_SHA256,"strict raw204 wire changed")
history=load("allhosts_strict_official_history",HISTORY,HISTORY_SHA256)
need(Path(history.PINNED_SOURCE_ROOT).resolve()==SOURCE_ROOT,"history binds another source")
need(len(history.direct.DIRECT_CHECKS)==98 and len(history.EXTRA_CHECKS)==30
 and len(history.OfficialHistoryRun.required_checks)==128,"original history denominator changed")
base=history.base

PREFLIGHT=r'''
import hashlib,json,os,pathlib,platform,runpy,signal,sys
p=json.loads(sys.stdin.buffer.read(32769));payload=p["payload"];helper=pathlib.Path(payload["root"])/"native_ha_foreground_watchdog.py"
assert helper.is_file() and not helper.is_symlink() and helper.stat().st_nlink==1
assert hashlib.sha256(helper.read_bytes()).hexdigest()==payload["helper_sha256"]
m=runpy.run_path(str(helper));m["validate_payload"](payload);m["require_waitid"]()
launcher=pathlib.Path(sys.executable).resolve(strict=True);runtime=m["kernel_executable"](os.getpid())
assert str(launcher)==payload["python_path"] and str(runtime)==payload["python_runtime_path"]
assert hashlib.sha256(launcher.read_bytes()).hexdigest()==payload["python_sha256"]
assert hashlib.sha256(runtime.read_bytes()).hexdigest()==payload["python_runtime_sha256"]
assert os.geteuid()==p["uid"] and platform.machine()==p["machine"]
print(json.dumps({"host":platform.node(),"system":platform.system(),"machine":platform.machine(),"uid":os.geteuid(),"python_path":str(launcher),"python_sha256":payload["python_sha256"],"python_runtime_path":str(runtime),"python_runtime_sha256":payload["python_runtime_sha256"],"helper_sha256":payload["helper_sha256"],"waitid_and_wnowait":True,"sigchld_default":signal.getsignal(signal.SIGCHLD)==signal.SIG_DFL,"product_started":False,"observed_ns":__import__("time").time_ns()},sort_keys=True))
'''

class OfficialHistoryRun(history.OfficialHistoryRun):
 """Keep every launch, including standalone-V5 seed, under its real SSH object."""
 required_checks=history.OfficialHistoryRun.required_checks
 def __init__(self,*args):
  super().__init__(*args)
  need(self.args.source_commit==SOURCE_COMMIT and self.args.source_tree==SOURCE_TREE,"adapter source freeze differs")
  need({n.alias for n in self.nodes}==ALIASES and len(self.nodes)==3,"adapter requires exact three admitted aliases")
  self.foreground_helper=OWNER_DIR/"native_ha_foreground_watchdog.py"
  self._owner_rows={};self._owner_all_sessions={};self._owner_preflights={};self._owner_admitted=False
  for path in (Path(__file__).resolve(),self.foreground_helper,OWNER_DIR/"reconcile_owner.py",
               OWNER_DIR/"preparation.public.json",OWNER_DIR/"toy-aggregate-r1/result.public.json",
               HISTORY,HISTORY.parent/"preparation.public.json",HISTORY.parent/"native_v6_ha_official_history_wire.py"):
   self.source_files[str(path)]=sha(path)
  self.report.update({"owner_launches":[],"owner_launch_count":0,"owner_checks":[],
   "owner_required_check_count":6,"owner_passed_check_count":0,"owner_gate_qualified":False,
   "owner_preflight_observations":[],"owner_required_aliases":sorted(ALIASES),"owner_binary_bindings":[],
   "owner_helper_sha256":HELPER_SHA256,"owner_reconcile_sha256":RECONCILE_SHA256,
   "owner_preparation_sha256":PREPARATION_SHA256,"owner_toy21_sha256":TOY21_SHA256,
   "owner_qualified_scope":"each actual native/V5 launch must independently have original-five-second live receipt and cleanup-only canonical reconciliation",
   "foreground_scope":"all actual Mac/ROG/Pocket nodes; native and standalone-V5 seed; no bare-PID fallback",
   "process_identity_scope":"original real SSH Popen birth plus remote original product Popen retained with WNOWAIT through group cleanup",
   "owner_uncovered":list(PREPARATION["uncovered"])})
 def _host(self,node):
  spec=PREPARATION["hosts"][node.alias]
  actual=self.hosts[node.alias]
  need(actual["host"]==spec["host"] and actual["system"]==spec["system"],"actual host differs from pinned owner preflight")
  return spec
 def _payload_for_preflight(self,node):
  spec=self._host(node)
  return {"schema":owner.SCHEMA,"root":node.root,"run_id":self.run_id,"launch_id":"0"*32,
   "binary_sha256":self.expected[str(node.node_id)],"helper_sha256":HELPER_SHA256,
   "source_commit":SOURCE_COMMIT,"source_tree":SOURCE_TREE,
   "expected_system":spec["system"],"expected_host":spec["host"],
   "python_path":spec["python_path"],"python_sha256":spec["python_sha256"],
   "python_runtime_path":spec["python_runtime_path"],"python_runtime_sha256":spec["python_runtime_sha256"],
   "native_ha":True,"child_kind":"native","toy_sha256":None,"read_index_observation":"on"}
 def verify_foreground_helper(self,node):
  spec=self._host(node);payload=self._payload_for_preflight(node)
  command=shlex.join([spec["python_path"],"-I","-S","-B","-c",PREFLIGHT])
  argv=["/usr/bin/ssh","-o","ControlMaster=no","-o","ControlPath=none","-o","StrictHostKeyChecking=yes",
   "-o","BatchMode=yes","-o","ConnectTimeout=10","-o","ConnectionAttempts=1",node.alias,command]
  call=subprocess.run(argv,input=json.dumps({"payload":payload,"uid":spec["uid"],"machine":spec["machine"]}).encode(),
   stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=15)
  need(call.returncode==0 and len(call.stdout)<=16384,"fresh pinned owner preflight failed")
  observed=json.loads(call.stdout)
  need(observed["host"]==spec["host"] and observed["system"]==spec["system"]
   and observed["helper_sha256"]==HELPER_SHA256 and observed["waitid_and_wnowait"]
   and observed["sigchld_default"],"actual owner capabilities changed")
  self._owner_preflights[node.alias]=observed
  self.report["owner_preflight_observations"].append(dict(observed,alias=node.alias,node_id=node.node_id))
  return observed
 def prepare(self):
  # Parent preparation writes only fresh owned fixtures and probes endpoints.
  # DirectLanRun uploads this overridden helper and calls this verifier for Mac.
  super().prepare()
  for node in self.nodes:
   if self._host(node)["system"]!="Darwin":
    base.upload(node,self.foreground_helper,node.root+"/native_ha_foreground_watchdog.py",0o600)
   self.verify_foreground_helper(node)
  need(set(self._owner_preflights)==ALIASES,"not all actual interpreter/OS capabilities admitted")
  source_alias,source_path=base.parse_binary_source(self.args.binary_source)
  default=(source_alias,source_path,self.args.expected_binary_sha256)
  for node in self.nodes:
   source=self.sources.get(node.alias,default);expected=self.expected[str(node.node_id)]
   need(source[2]==expected,"per-node candidate source digest differs")
   receipt_alias,receipt_path,receipt_digest=self.receipts[node.alias]
   local_receipt=self.work/f"native-build-{node.node_id}.json"
   local_binary=Path(self.local_binaries[node.alias])
   need(sha(local_receipt)==receipt_digest and sha(local_binary)==expected,"prepared artifact/receipt changed")
   self.report["owner_binary_bindings"].append({"node_id":node.node_id,"alias":node.alias,
    "remote_binary_path":node.root+"/heptabao-server","binary_sha256":expected,
    "candidate_source_alias":source[0],"candidate_source_path":source[1],
    "local_candidate_path":str(local_binary),"native_abi":self.abis[node.alias],
    "native_build_receipt_source_alias":receipt_alias,"native_build_receipt_source_path":receipt_path,
    "native_build_receipt_sha256":receipt_digest,"local_native_build_receipt_path":str(local_receipt),
    "scope":"original parser validates exact source/tree/features/ABI/server hash; outer admission must additionally match Mac/Linux qualified receipts"})
  self.foreground_nodes=list(self.nodes);self._owner_admitted=True
  self.event("allhosts_continuous_owner_preflight_admitted",actual_hosts=3,original_start_seconds=60,original_stop_seconds=5)
 def _sync_row(self,session):
  row=self._owner_rows[session.launch_id]
  row["session_receipt"]=json.loads(json.dumps(session.receipt))
  row["submission_count"]=session.receipt["submission_count"]
  need(session.payload==row["payload"],"launch payload changed after registration")
  row["actual_child_executable"]=json.loads(json.dumps(session.ready.get("actual_child_executable"))) if session.ready else None
  row["actual_product_birth"]=json.loads(json.dumps(session.ready.get("child_identity"))) if session.ready else None
  row["local_ssh_identity"]=json.loads(json.dumps(session.owner)) if session.owner is not None else None
  for key,name in (("launch_intent","launch-intent.json"),("local_ssh_identity","ssh-identity.json")):
   path=session.phase/name;row[key+"_path"]=str(path)
   row[key+"_sha256"]=sha(path) if path.is_file() and not path.is_symlink() else None
  self.report["owner_launch_count"]=len(self.report["owner_launches"])
  return row
 def owned_process_action(self,node,action,*,native=True):
  need(action in ("start","stop"),"unknown owned product process action")
  if action=="start":
   need(self._owner_admitted,"all-host capabilities must be admitted before any product start")
   need(type(native) is bool and (native or node==self.nodes[0]),"standalone-V5 is limited to the original seed")
   need(node.alias not in self.foreground_sessions,"unknown prior start cannot be repeated")
   spec=self._host(node)
   session=owner.ForegroundSession(node,self.run_id,self.work,self.expected[str(node.node_id)],self.foreground_helper,
    source_commit=SOURCE_COMMIT,source_tree=SOURCE_TREE,actual_host=spec,
    python_path=spec["python_path"],python_sha256=spec["python_sha256"],
    python_runtime_path=spec["python_runtime_path"],python_runtime_sha256=spec["python_runtime_sha256"],
    native=native,child_kind="native",toy_sha256=None,read_index_observation="on" if native else "off")
   row={"node_id":node.node_id,"alias":node.alias,"run_id":self.run_id,"launch_id":session.launch_id,
    "child_kind":"native","native_ha":native,"local_phase":str(session.phase),
    "remote_canonical_phase":session.receipt["remote_canonical_phase"],"payload":dict(session.payload),
    "normal_stop_live_verified":False,"canonical_cleanup_verified":False,"failed_stop_seen":False,
    "status":"not_submitted","stop_attempts":[],
    "binary_sha256":self.expected[str(node.node_id)],"remote_binary_path":node.root+"/heptabao-server",
    "build_binding":dict(next(b for b in self.report["owner_binary_bindings"] if b["node_id"]==node.node_id))}
   # The full object is registered before start; a deferred cancellation may
   # occur before its receiver thread exists and cleanup still owns that object.
   self.foreground_sessions[node.alias]=session
   self._owner_all_sessions[session.launch_id]=session;self._owner_rows[session.launch_id]=row
   self.report["owner_launches"].append(row);self.report["foreground_sessions"].append(session.receipt)
   try:
    pid=session.start();row["status"]="running";return pid
   except BaseException as error:
    row["status"]="start_failed";row["start_failure_type"]=type(error).__name__;raise
   finally:self._sync_row(session)
  if node.alias not in self.foreground_sessions:
   # Never fall back to detached PID control. No second signal is authorized
   # for an already completed or never-submitted local session.
   return None
  session=self.foreground_sessions[node.alias];row=self._owner_rows[session.launch_id]
  attempt={"started_ns":time.time_ns(),"status":"failed"}
  row["stop_attempts"].append(attempt)
  try:
   pid=session.stop()
   final=json.loads(json.dumps(session.receipt))
   need(final.get("original_stop_deadline_satisfied") is True and final.get("stopped") is True
    and final["stop_elapsed_seconds"]<5
    and final["local_ssh_cleanup"]["leader_reaped"] is True
    and final["local_ssh_cleanup"]["owned_live_group_empty"] is True
    and final["remote_cleanup"]["leader_reaped"] is True
    and final["remote_cleanup"]["owned_live_group_empty"] is True,"actual final live stop receipt not qualified")
   live_path=session.phase/"final-live-stop.public.json"
   exact_new_or_same(live_path,owner.canonical(final))
   row.update(final_live_stop_receipt_path=str(live_path),final_live_stop_receipt_sha256=sha(live_path),
              normal_stop_live_verified=True)
   # This read-only clock never grants or extends the preceding five seconds.
   observed=reconcile.reconcile(node.alias,session.payload,timeout=15)
   need(observed["status"]=="verified","canonical cleanup is not independently verified")
   canonical_path=session.phase/"canonical-cleanup.public.json"
   if canonical_path.exists():
    prior=json.loads(canonical_path.read_text())
    need(prior["record_sha256"]==observed["record_sha256"],"remote canonical identity changed")
   else:owner.new_file(canonical_path,owner.canonical(observed))
   row.update(canonical_reconciliation_path=str(canonical_path),canonical_reconciliation_sha256=sha(canonical_path),
              remote_record_sha256=observed["record_sha256"],canonical_cleanup_verified=True,status="passed")
   attempt.update(status="passed",finished_ns=time.time_ns())
   del self.foreground_sessions[node.alias]
   return pid
  except BaseException as error:
   row["failed_stop_seen"]=True;row["status"]="stop_failed"
   attempt.update(failure_type=type(error).__name__,finished_ns=time.time_ns())
   raise
  finally:self._sync_row(session)
 def _owner_final_checks(self):
  rows=self.report["owner_launches"];intents={}
  for phase in sorted(self.work.glob("foreground-node-*")):
   need(phase.is_dir() and not phase.is_symlink(),"local owner phase changed")
   path=phase/"launch-intent.json"
   if path.exists():
    need(path.is_file() and not path.is_symlink(),"local intent changed")
    intent=json.loads(path.read_text());key=intent["launch_id"]
    need(key not in intents,"duplicate local owner launch id");intents[key]=(path,intent)
  actual=owner.ps_rows();accounted=len(rows)==len(intents) and len(self._owner_rows)==len(rows)
  births_absent=True
  for row in rows:
   session=self._owner_all_sessions[row["launch_id"]];self._sync_row(session)
   item=intents.get(row["launch_id"])
   if item is None:accounted=False;births_absent=False;continue
   path,intent=item
   accounted=accounted and intent["payload"]==row["payload"] and intent["alias"]==row["alias"]
   accounted=accounted and intent["node"]==row["node_id"] and intent["submission_count"]==row["submission_count"]==1
   accounted=accounted and str(path)==row["launch_intent_path"] and sha(path)==row["launch_intent_sha256"]
   birth=row["local_ssh_identity"]
   gone=birth is not None and not any(owner.stable(p)==birth["ps"] for p in actual)
   row["original_ssh_birth_observed_absent"]=gone
   births_absent=births_absent and gone
  flags=(
   set(self._owner_preflights)==ALIASES and self._owner_admitted,
   accounted and bool(rows),
   bool(rows) and all(r["normal_stop_live_verified"] and not r["failed_stop_seen"]
    and r["session_receipt"].get("original_stop_deadline_satisfied") is True for r in rows),
   bool(rows) and all(r["canonical_cleanup_verified"] for r in rows),
   bool(rows) and births_absent,
   {r["alias"] for r in rows if r["native_ha"]}==ALIASES
    and len([r for r in rows if not r["native_ha"]])==1
    and next((r["node_id"] for r in rows if not r["native_ha"]),None)==self.nodes[0].node_id)
  self.report["owner_checks"]=[{"case":name,"passed":value is True} for name,value in zip(OWNER_CASES,flags)]
  self.report["owner_passed_check_count"]=sum(x["passed"] for x in self.report["owner_checks"])
  self.report["owner_launch_count"]=len(rows)
  self.report["owner_submitted_intent_count"]=len(intents)
  self.report["owner_gate_qualified"]=all(flags) and not self.foreground_sessions
  return self.report["owner_gate_qualified"]
 def cleanup(self):
  outcome=super().cleanup()
  try:owner_ok=self._owner_final_checks()
  except Exception as error:
   self.report["owner_gate_qualified"]=False;self.report["owner_gate_failure_type"]=type(error).__name__;owner_ok=False
  if not owner_ok:self.report.setdefault("failure_code","allhosts_original_owner_gate_unresolved")
  self.checkpoint()
  return bool(outcome and owner_ok)
 def check(self,name,condition,**details):
  if name=="native.complete" and condition is True:
   need(self._owner_final_checks(),"every historical product launch must pass independent owner gates")
  return super().check(name,condition,**details)

def main(argv=None):
 return history.native.execute_fixture(*history.parsed_arguments(argv),run_type=OfficialHistoryRun)
if __name__=="__main__":raise SystemExit(main(sys.argv[1:]))
