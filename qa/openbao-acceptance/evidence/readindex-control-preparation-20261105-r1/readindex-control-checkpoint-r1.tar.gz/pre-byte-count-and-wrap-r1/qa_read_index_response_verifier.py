#!/usr/bin/env python3
"""Pure synthetic response-control QA. No request or product is started."""
import base64
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("read_index_verifier_qa", HERE / "read_index_response_verifier.py")
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
LAUNCH, ATTEMPT = "1" * 32, "0123456789abcdef0123456789abcdef"


def document():
    return {"v": 1, "phase": "pre_write", "process_id": 12345, "attempt_id": ATTEMPT,
            "launch_id": LAUNCH, "log_lost_before": 0, "log_writer_failed": False,
            "writer_completed": False, "client_delivery_observed": False,
            "payload_binding_state": 1, "payload_bindings": [[1, 1, 200, True]],
            "read_index": {"v": 1, "complete": True, "started": 1, "completed": 1,
                "dropped": 0, "collector_busy": False,
                "events": [[1, 1, 1, 5, None, None, None, [5, 1, 90], [5, 1, 91],
                            [5, 1, 91], None, 1, 0, 100, 1000, False,
                            [8, [5, 1, 95], 4, 6, [5, 1, 94], 4, 0, 15, False]]]}}


def headers(value=None, raw=None):
    if raw is None:
        raw = json.dumps(value if value is not None else document(), separators=(",", ":")).encode()
    return [["Content-Type", "application/json"],
            ["X-HeptaBao-Read-Observation", "1," + LAUNCH + "," + ATTEMPT],
            ["X-HeptaBao-Read-Index-Trace", base64.urlsafe_b64encode(raw).decode().rstrip("=")]]


def validate(value=None, fields=None):
    return verifier.validate_envelope(headers(value) if fields is None else fields,
                                     launch_id=LAUNCH, process_id=12345, node_id=1)


def refuse(code, callback):
    try:
        callback()
    except verifier.Refusal as error:
        assert str(error) == code, (code, str(error))
    else:
        raise AssertionError("required refusal absent")


def changed(path, value, code):
    candidate = document()
    target = candidate
    for key in path[:-1]:
        target = target[key]
    target[path[-1]] = value
    refuse(code, lambda: validate(candidate))


def positive():
    row = validate()
    assert row["status"] == "envelope_observed_only" and row["events"][0]["read_policy_calls"] == 1
    assert all(row[key] is False for key in ("payload_read_qualified", "server_write_terminal_qualified",
                                            "independent_leader_log_qualified", "replacement_qualified"))


def peer_tuple():
    producer = [1, 1, 1, 5, 2, 1, 77, [5, 1, 90], [5, 1, 91], [5, 1, 91], None, 1, 0, 200, 1000, False, None]
    consumer = [1, 2, 1, 5, 2, 1, 77, [5, 1, 90], [5, 1, 91], [5, 1, 92], 92, 0, 0, 300, 1000, False, None]
    p, c = verifier.validate_event(producer, 1), verifier.validate_event(consumer, 1)
    matched = verifier.correlate_peer_records(c, p)
    assert matched["record_tuple_matches"] is True and matched["actual_independent_log_origin_admitted"] is False
    p["rpc"] = (2, 1, 78)
    refuse("independent_peer_witness_mismatch", lambda: verifier.correlate_peer_records(c, p))
    consumer[10] = 89
    refuse("follower_state_machine_not_applied", lambda: verifier.validate_event(consumer, 1))


def duplicate_header():
    rows = headers()
    rows.append(["x-HeptaBao-READ-Observation", rows[1][1]])
    refuse("duplicate_observation_header", lambda: validate(fields=rows))


def noncanonical():
    refuse("trace_base64url_noncanonical", lambda: verifier.decode_trace("e31"))
    rows = headers()
    rows[2][1] += "="
    refuse("trace_base64url_shape", lambda: validate(fields=rows))


def duplicate_json():
    raw = json.dumps(document(), separators=(",", ":")).encode().replace(b'"v":1,', b'"v":1,"v":1,', 1)
    refuse("duplicate_json_key", lambda: validate(fields=headers(raw=raw)))


def zero_is_not_proof():
    value = document()
    value["read_index"].update(started=0, completed=0, events=[])
    value.update(payload_binding_state=0, payload_bindings=[])
    row = validate(value)
    assert row["zero_actual_readindex_calls"] is True and row["payload_read_qualified"] is False
    refuse("final_payload_binding_contract_not_yet_frozen", lambda: verifier.qualify_payload_read(row))


def u64_precision():
    value = document()
    for position in (7, 8, 9):
        value["read_index"]["events"][0][position][2] = (1 << 63) + 123
    value["read_index"]["events"][0][16][1][2] = (1 << 63) + 123
    value["read_index"]["events"][0][16][4][2] = (1 << 63) + 123
    row = validate(value)
    assert row["events"][0]["read_log"][2] == (1 << 63) + 123


def request_uuid():
    assert verifier.expected_response_request_id(ATTEMPT) == "01234567-89ab-cdef-0123-456789abcdef"


def response_body(request_id=None):
    value = {"request_id": request_id or verifier.expected_response_request_id(ATTEMPT),
             "data": {"data": {"synthetic_only": "data"}, "metadata": {"version": 19}}}
    return json.dumps(value, separators=(",", ":")).encode()


def association(value=None, body=None, status=200):
    return verifier.validate_payload_association(validate(value), response_body() if body is None else body,
                                                 response_status=status)


def selected_application_can_advance():
    value = document()
    result = association(value)
    assert result["status"] == "association_observed_only"
    assert result["selected_application"]["publication_log"][2] > result["successful_witness"]["local_applied"][2]
    assert all(result[key] is False for key in ("wire_origin_admitted", "independent_payload_correctness",
                                               "independent_leader_log_qualified", "payload_read_qualified",
                                               "replacement_qualified"))


def selection_not_enough(path, value):
    candidate = document()
    selected = candidate["read_index"]["events"][0][16]
    selected[path] = value
    refuse("selected_root_verification_incomplete", lambda: association(candidate))


def failed_witness_cannot_bind():
    candidate = document()
    candidate["read_index"]["events"][0][12] = 2
    refuse("payload_binding_without_successful_witness", lambda: association(candidate))


def no_ordinal_cannot_bind():
    candidate = document()
    candidate["payload_bindings"] = []
    refuse("final_payload_binding_unavailable", lambda: association(candidate))


def positive_rpc_request_id():
    event = document()["read_index"]["events"][0]
    event[4:7] = [2, 1, 0]
    refuse("producer_rpc_identity", lambda: verifier.validate_event(event, 1))


def main(output):
    cases = [
        ("bounded_leader_envelope_never_grants_payload", positive),
        ("exact_peer_tuple_and_independent_local_apply", peer_tuple),
        ("duplicate_case_insensitive_header_refused", duplicate_header),
        ("noncanonical_base64_or_padding_refused", noncanonical),
        ("duplicate_json_key_refused", duplicate_json),
        ("zero_events_preserved_as_no_readindex_proof", zero_is_not_proof),
        ("u64_log_index_preserved_without_float_rounding", u64_precision),
        ("original_attempt_uuid_has_no_rewritten_bits", request_uuid),
        ("foreign_owner_pid_refused", lambda: changed(["process_id"], 12346, "actual_owner_process_association")),
        ("prewrite_delivery_claim_refused", lambda: changed(["client_delivery_observed"], True, "prewrite_cannot_claim_writer_or_delivery")),
        ("writer_log_loss_refused", lambda: changed(["log_lost_before"], 1, "process_observation_log_incomplete")),
        ("collector_busy_refused", lambda: changed(["read_index", "collector_busy"], True, "read_index_incomplete")),
        ("dropped_event_refused", lambda: changed(["read_index", "dropped"], 1, "read_index_dropped")),
        ("event_denominator_gap_refused", lambda: changed(["read_index", "started"], 2, "complete_event_denominator")),
        ("bool_counter_refused", lambda: changed(["read_index", "completed"], True, "read_index_completed")),
        ("floating_counter_refused", lambda: changed(["read_index", "completed"], 1.0, "trace_noninteger_number")),
        ("nan_counter_refused", lambda: changed(["read_index", "completed"], float("nan"), "trace_noninteger_number")),
        ("expired_success_refused", lambda: changed(["read_index", "events", 0, 15], True, "success_outside_original_deadline")),
        ("leader_without_actual_policy_call_refused", lambda: changed(["read_index", "events", 0, 11], 0, "actual_leader_read_policy_execution")),
        ("foreign_read_term_refused", lambda: changed(["read_index", "events", 0, 7, 0], 4, "read_log_leader_term")),
        ("local_apply_behind_read_refused", lambda: changed(["read_index", "events", 0, 9, 2], 89, "local_apply_does_not_cover_read")),
        ("partial_rpc_identity_refused", lambda: changed(["read_index", "events", 0, 4], 2, "partial_rpc_identity")),
        ("overflowing_u64_refused", lambda: changed(["read_index", "events", 0, 7, 2], 1 << 64, "event_read_log")),
        ("same_selected_application_may_exceed_earlier_frontier", selected_application_can_advance),
        ("selected_application_behind_read_refused", lambda: changed(["read_index", "events", 0, 16, 1, 2], 89, "selected_application_does_not_cover_read")),
        ("publication_above_actual_selected_application_refused", lambda: changed(["read_index", "events", 0, 16, 4, 2], 96, "publication_not_covered_by_selected_application")),
        ("unknown_selection_stage_refused", lambda: changed(["read_index", "events", 0, 16, 7], 16, "unknown_selection_stage")),
        ("incomplete_selected_root_stages_cannot_bind", lambda: selection_not_enough(7, 7)),
        ("failed_selected_verification_cannot_bind", lambda: selection_not_enough(6, 1)),
        ("inconsistent_selection_cannot_bind", lambda: selection_not_enough(8, True)),
        ("missing_selected_root_cannot_bind", lambda: selection_not_enough(2, None)),
        ("final_body_attempt_mismatch_refused", lambda: refuse("final_response_request_association", lambda: association(body=response_body("00000000-0000-0000-0000-000000000000")))),
        ("non200_cannot_claim_payload_binding", lambda: refuse("payload_response_not_success", lambda: association(status=503))),
        ("failed_readindex_cannot_bind_payload", failed_witness_cannot_bind),
        ("no_actual_ordinal_cannot_bind_payload", no_ordinal_cannot_bind),
        ("noneligible_binding_state_cannot_retain_binding", lambda: changed(["payload_binding_state"], 3, "ineligible_state_has_payload_binding")),
        ("unknown_payload_ordinal_refused", lambda: changed(["payload_bindings", 0, 1], 2, "payload_binding_unknown_event")),
        ("zero_rpc_id_cannot_claim_authenticated_producer", positive_rpc_request_id),
    ]
    rows = []
    for name, callback in cases:
        try:
            callback()
            rows.append({"case": name, "passed": True})
        except BaseException as error:
            rows.append({"case": name, "passed": False, "failure_type": type(error).__name__,
                         "fixed_error": str(error) if isinstance(error, verifier.Refusal) else None})
    passed = sum(row["passed"] for row in rows)
    result = {"schema": "heptabao.readindex-client-control-qa.draft.v1", "status": "passed" if passed == len(cases) else "failed",
              "required": len(cases), "passed": passed, "checks": rows,
              "verifier_sha256": hashlib.sha256((HERE / "read_index_response_verifier.py").read_bytes()).hexdigest(),
              "products_started": False, "network_requests": 0, "payload_binding_contract_frozen": False,
              "product_readindex_qualified": False, "replacement_qualified": False,
              "scope": "synthetic envelope/refusal controls only; no real response or original product evidence"}
    path = Path(output)
    path.parent.mkdir(mode=0o700, exist_ok=False)
    with path.open("xb") as stream:
        stream.write((json.dumps(result, sort_keys=True, indent=2) + "\n").encode())
    print(json.dumps({"status": result["status"], "required": len(cases), "passed": passed,
                      "result": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}))
    return 0 if result["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1]))
