#!/usr/bin/env python3
"""One fixed HA HTTP operation, using one local CLOCK_MONOTONIC deadline.

Credential-bearing input/output is private original-parent IPC, never a public
report. There is no discovery, login, redirect, proxy, retry or product launcher.
An independently pinned private admission binds every allowed endpoint and file.
"""
from __future__ import annotations

import base64
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import select
import socket
import ssl
import stat
import subprocess
import sys
import time

MIB = 1024 * 1024
JSON_LIMIT, ARCHIVE_LIMIT, EXPORT_LIMIT = 4 * MIB, 131 * MIB, 64 * MIB
HTTP_SECONDS, REAP_SECONDS = 15, 5
CLOCK_DOMAIN = "local-os.clock_gettime.CLOCK_MONOTONIC.ns"
SCHEMA = "heptabao.native-readindex-wire-admission.v1"
DRAFT_ONLY = True
WIRE_METADATA_BYTES = 16384
OBSERVATION_HEADER_BYTES = 12288
HOSTS = {
    "mac": ("hepta-mac-local", "MacBook-Pro.local"),
    "rog": ("rog-ts", "qian-qi-ROG-Flow-Z13-GZ302EA-GZ302EA"),
    "pocket4": ("hepta-pocket4", "alex-G1628-04"),
}
HEX64 = re.compile(r"[0-9a-f]{64}")


class Refusal(RuntimeError):
    """Only fixed non-sensitive error codes are passed to this exception."""


def need(condition, code):
    if not condition:
        raise Refusal(code)


def clock_ns():
    need(hasattr(time, "CLOCK_MONOTONIC") and hasattr(time, "clock_gettime_ns"), "clock_unavailable")
    return time.clock_gettime_ns(time.CLOCK_MONOTONIC)


def remaining(deadline_ns):
    need(type(deadline_ns) is int, "deadline_type")
    value = (deadline_ns - clock_ns()) / 1_000_000_000
    need(value > 0, "original_http_deadline")
    return value


def private_read(path, maximum, deadline_ns):
    remaining(deadline_ns)
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), "rb") as source:
        before = os.fstat(source.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and not before.st_mode & 0o077
             and 0 <= before.st_size <= maximum, "private_file_contract")
        pieces, count = [], 0
        while True:
            remaining(deadline_ns)
            block = source.read(min(65536, maximum + 1 - count))
            remaining(deadline_ns)
            if not block:
                break
            pieces.append(block)
            count += len(block)
            need(count <= maximum, "private_file_bound")
        after = os.fstat(source.fileno())
        identity = lambda row: (row.st_dev, row.st_ino, row.st_size, row.st_mtime_ns, row.st_ctime_ns)
        need(identity(before) == identity(after) and count == before.st_size, "private_file_changed")
    remaining(deadline_ns)
    return b"".join(pieces)


def under_root(value, root):
    need(isinstance(value, str), "private_path_type")
    path = Path(value)
    need(path.is_absolute() and path.resolve(strict=False) == path
         and path != root and path.is_relative_to(root), "private_path_scope")
    parent = path.parent
    while parent != root.parent:
        row = parent.lstat()
        need(stat.S_ISDIR(row.st_mode) and not parent.is_symlink()
             and row.st_uid == os.geteuid() and not row.st_mode & 0o077, "private_parent_contract")
        if parent == root:
            break
        parent = parent.parent
    return path


def load_admission(path, expected_sha256, deadline_ns):
    need(isinstance(expected_sha256, str) and HEX64.fullmatch(expected_sha256), "admission_pin")
    path = Path(path)
    need(path.is_absolute() and path.resolve(strict=True) == path, "admission_path")
    raw = private_read(path, MIB, deadline_ns)
    need(hashlib.sha256(raw).hexdigest() == expected_sha256, "admission_changed")
    value = json.loads(raw)
    need(isinstance(value, dict) and set(value) == {
        "schema", "run_id", "scope", "engine", "cohort", "production_authority",
        "source_commit", "source_tree", "root", "nodes", "archive_files", "tls_policy"}, "admission_shape")
    need(value["schema"] == SCHEMA and value["production_authority"] is False
         and value["scope"] in ("native128", "synthetic_qa")
         and value["engine"] == "heptabao", "admission_scope")
    need(re.fullmatch(r"[0-9a-f]{32}", value["run_id"]) is not None
         and re.fullmatch(r"[0-9a-f]{40}", value["source_commit"]) is not None
         and re.fullmatch(r"[0-9a-f]{40}", value["source_tree"]) is not None, "admission_source")
    if value["scope"] == "native128":
        need(not DRAFT_ONLY, "readindex_product_observation_contract_not_frozen")
        need(value["cohort"] == "official-history128-read-observation", "native_read_observation_cohort")
    else:
        need(value["cohort"] == "synthetic_qa", "qa_cohort")
    need(value["tls_policy"] in ("matched-tls12-rsa", "native128-original"), "fixed_tls_policy")
    if value["scope"] == "native128":
        need(value["tls_policy"] == "native128-original", "original_native128_tls_policy")
    root = Path(value["root"])
    need(root == path.parent and root.resolve(strict=True) == root, "admission_root")
    under_root(str(path), root)
    need(isinstance(value["nodes"], list) and len(value["nodes"]) == (1 if value["scope"] == "synthetic_qa" else 3), "fixed_node_count")
    labels, ids, destinations = set(), set(), set()
    for node in value["nodes"]:
        need(isinstance(node, dict) and set(node) == {
            "id", "label", "alias", "actual_hostname", "physical_binding_sha256",
            "ip", "port", "ca_file", "ca_sha256", "leaf_sha256"}, "node_shape")
        need(isinstance(node["id"], str) and re.fullmatch(r"[a-z0-9_-]{1,32}", node["id"])
             and node["id"] not in ids, "node_id")
        ids.add(node["id"])
        need(node["label"] in HOSTS and node["label"] not in labels, "physical_node_label")
        labels.add(node["label"])
        need((node["alias"], node["actual_hostname"]) == HOSTS[node["label"]], "physical_node_metadata")
        for field in ("physical_binding_sha256", "ca_sha256", "leaf_sha256"):
            need(isinstance(node[field], str) and HEX64.fullmatch(node[field]), "node_pin")
        ip = ipaddress.ip_address(node["ip"])
        need(ip.version == 4 and str(ip) == node["ip"] and type(node["port"]) is int
             and 1024 <= node["port"] <= 65535, "direct_endpoint")
        if value["scope"] == "synthetic_qa":
            need(ip == ipaddress.ip_address("127.0.0.1"), "qa_loopback_only")
        else:
            need(any(ip in ipaddress.ip_network(r) for r in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16")), "private_direct_endpoint")
        need((node["ip"], node["port"]) not in destinations, "duplicate_endpoint")
        destinations.add((node["ip"], node["port"]))
        under_root(node["ca_file"], root)
    need(value["archive_files"] == [], "read_observation_has_no_archive_authority")
    remaining(deadline_ns)
    return value


def validate_operation(admission, packet):
    need(isinstance(packet, dict) and set(packet) == {
        "clock_domain", "deadline_ns", "node_id", "token", "method", "path", "body",
        "archive_in", "archive_sha256", "archive_out"}, "packet_shape")
    need(packet["clock_domain"] == CLOCK_DOMAIN, "packet_clock_domain")
    node = next((n for n in admission["nodes"] if n["id"] == packet["node_id"]), None)
    need(node is not None, "node_not_enrolled")
    method, path = packet["method"], packet["path"]
    need(method == "GET" and isinstance(path, str)
         and re.fullmatch(r"oracle271/data/history(?:\?version=(?:[1-9]|1[0-9]|20))?", path),
         "fixed_native_history_read_only")
    need(all(packet[name] is None for name in ("body", "archive_in", "archive_out", "archive_sha256")),
         "read_observation_has_no_mutation_or_archive")
    token = packet["token"]
    need(isinstance(token, str) and 0 < len(token) <= 16384
         and all(32 < ord(c) < 127 for c in token), "private_token_contract")
    return node, None, None


class TLSReader:
    def __init__(self, connection, deadline_ns):
        self.connection, self.deadline_ns, self.buffer = connection, deadline_ns, bytearray()

    def receive(self):
        self.connection.settimeout(remaining(self.deadline_ns))
        block = self.connection.recv(65536)
        remaining(self.deadline_ns)  # Includes EOF: a late return can never grant success.
        return block

    def exact(self, count):
        while len(self.buffer) < count:
            block = self.receive()
            need(block, "truncated_http_body")
            self.buffer.extend(block)
        raw = bytes(self.buffer[:count])
        del self.buffer[:count]
        remaining(self.deadline_ns)
        return raw

    def line(self, maximum):
        while True:
            end = self.buffer.find(b"\r\n")
            if end >= 0:
                need(end + 2 <= maximum, "http_line_bound")
                return self.exact(end + 2)[:-2]
            need(len(self.buffer) < maximum, "http_line_bound")
            block = self.receive()
            need(block, "truncated_http_header")
            self.buffer.extend(block)

    def eof(self):
        need(not self.buffer, "forbidden_http_tail")
        need(self.receive() == b"", "forbidden_http_tail")
        remaining(self.deadline_ns)


def response_header(reader):
    lines, count = [], 0
    while True:
        line = reader.line(64 * 1024)
        count += len(line) + 2
        need(count <= 64 * 1024, "http_header_bound")
        if not line:
            break
        lines.append(line)
    need(lines and re.fullmatch(rb"HTTP/1\.1 [2-5][0-9][0-9](?: [\x20-\x7e]*)?", lines[0]), "http11_status_required")
    status_code = int(lines[0].split(b" ")[1])
    headers = {}
    for line in lines[1:]:
        name, separator, value = line.partition(b":")
        need(separator and re.fullmatch(rb"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name)
             and all(c == 9 or 32 <= c < 127 for c in value), "http_header_syntax")
        headers.setdefault(name.lower().decode("ascii"), []).append(value.strip(b" \t"))
    raw = b"\r\n".join(lines) + b"\r\n\r\n"
    return status_code, headers, raw


def observed_diagnostic_headers(raw_header):
    # Preserve every actual occurrence and order; a dict would hide duplicates.
    # Never publish token/cookie or other arbitrary response header values.
    selected, count = [], 0
    for line in raw_header[:-4].split(b"\r\n")[1:]:
        name, _, value = line.partition(b":")
        if name.lower() not in (b"x-heptabao-read-observation", b"x-heptabao-read-index-trace"):
            continue
        count += len(line) + 2
        need(count <= OBSERVATION_HEADER_BYTES, "observation_header_byte_bound")
        selected.append([name.decode("ascii"), value.strip(b" \t").decode("ascii")])
    return selected, count


def response_body(reader, status_code, headers, consume, maximum):
    lengths, encodings = headers.get("content-length", []), headers.get("transfer-encoding", [])
    if status_code == 204:
        need(not lengths and not encodings, "http204_no_framing")
        reader.eof()
        return 0
    need(len(lengths) <= 1 and len(encodings) <= 1 and not (lengths and encodings), "ambiguous_http_framing")
    count = 0
    def put(raw):
        nonlocal count
        count += len(raw)
        need(count <= maximum, "response_body_bound")
        consume(raw)
        remaining(reader.deadline_ns)
    if lengths:
        need(re.fullmatch(rb"[0-9]{1,10}", lengths[0]), "content_length_syntax")
        left = int(lengths[0])
        need(left <= maximum, "response_body_bound")
        while left:
            block = reader.exact(min(65536, left))
            put(block)
            left -= len(block)
        reader.eof()
    elif encodings:
        need(encodings[0].lower() == b"chunked", "unsupported_transfer_encoding")
        while True:
            line = reader.line(4096)
            need(re.fullmatch(rb"[0-9a-fA-F]{1,16}(?:;[\x20-\x7e]*)?", line), "chunk_size_syntax")
            size = int(line.split(b";", 1)[0], 16)
            need(count + size <= maximum, "response_body_bound")
            if size == 0:
                trailer_bytes = 0
                while True:
                    trailer = reader.line(8192)
                    trailer_bytes += len(trailer) + 2
                    need(trailer_bytes <= 64 * 1024, "trailer_bound")
                    if not trailer:
                        break
                    name, sep, value = trailer.partition(b":")
                    need(sep and re.fullmatch(rb"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name)
                         and name.lower() not in (b"content-length", b"transfer-encoding")
                         and all(c == 9 or 32 <= c < 127 for c in value), "trailer_syntax")
                break
            left = size
            while left:
                block = reader.exact(min(65536, left))
                put(block)
                left -= len(block)
            need(reader.exact(2) == b"\r\n", "chunk_terminator")
        reader.eof()
    else:
        if reader.buffer:
            put(bytes(reader.buffer))
            reader.buffer.clear()
        while True:
            block = reader.receive()
            if not block:
                break
            put(block)
    remaining(reader.deadline_ns)
    return count


def perform(admission_path, admission_sha256, packet, deadline_ns):
    began = clock_ns()
    need(type(deadline_ns) is int and deadline_ns <= began + HTTP_SECONDS * 1_000_000_000, "original15s_maximum")
    remaining(deadline_ns)
    admission = load_admission(admission_path, admission_sha256, deadline_ns)
    need(packet.get("deadline_ns") == deadline_ns, "packet_deadline_binding")
    node, raw, parsed_body = validate_operation(admission, packet)
    ca = private_read(node["ca_file"], MIB, deadline_ns)
    need(hashlib.sha256(ca).hexdigest() == node["ca_sha256"], "ca_pin_changed")
    raw = raw or b""
    context = ssl.create_default_context(cadata=ca.decode("ascii"))
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    if admission["tls_policy"] == "matched-tls12-rsa":
        context.maximum_version = ssl.TLSVersion.TLSv1_2
        context.set_ciphers("ECDHE-RSA-AES128-GCM-SHA256")
    context.set_alpn_protocols(["http/1.1"])
    if hasattr(ssl, "OP_IGNORE_UNEXPECTED_EOF"):
        context.options &= ~ssl.OP_IGNORE_UNEXPECTED_EOF
    remaining(deadline_ns)
    tcp, tls, output = None, None, None
    pieces, body_digest = [], hashlib.sha256()
    try:
        tcp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        tcp.settimeout(remaining(deadline_ns))
        tcp.connect((node["ip"], node["port"]))
        remaining(deadline_ns)
        tls = context.wrap_socket(tcp, server_hostname=node["ip"], do_handshake_on_connect=False,
                                  suppress_ragged_eofs=False)
        tls.settimeout(remaining(deadline_ns))
        tls.do_handshake()
        remaining(deadline_ns)
        leaf = tls.getpeercert(binary_form=True)
        need(leaf and hashlib.sha256(leaf).hexdigest() == node["leaf_sha256"], "leaf_pin_changed")
        need(tls.selected_alpn_protocol() in (None, "http/1.1"), "http2_not_admitted")
        connected = clock_ns()
        method, path = packet["method"], packet["path"]
        header = [method + " /v1/" + path + " HTTP/1.1", "Host: " + node["ip"] + ":" + str(node["port"]),
                  "Accept: application/json", "Connection: close",
                  "Content-Type: " + ("application/octet-stream" if packet["archive_in"] else "application/json")]
        if packet["token"]:
            header.append("X-Vault-Token: " + packet["token"])
        if raw or method in ("POST", "PUT"):
            header.append("Content-Length: " + str(len(raw)))
        for part in (("\r\n".join(header) + "\r\n\r\n").encode("ascii"), raw):
            view = memoryview(part)
            while view:
                tls.settimeout(remaining(deadline_ns))
                count = tls.send(view[:65536])
                remaining(deadline_ns)
                need(count > 0, "request_send_closed")
                view = view[count:]
        reader = TLSReader(tls, deadline_ns)
        code, headers, raw_header = response_header(reader)
        observed_headers, observed_header_bytes = observed_diagnostic_headers(raw_header)
        headers_at = clock_ns()
        maximum = JSON_LIMIT
        def consume(block):
            body_digest.update(block)
            if output is not None:
                output.write(block)
            else:
                pieces.append(block)
        count = response_body(reader, code, headers, consume, maximum)
        if output is not None:
            output.flush()
            os.fsync(output.fileno())
            remaining(deadline_ns)
            output.close()
            output = None
        ended = clock_ns()
        metadata = {"status": code, "leaf_sha256": node["leaf_sha256"],
                    "clock_domain": CLOCK_DOMAIN, "original_deadline_ns": deadline_ns,
                    "http_version": "HTTP/1.1", "tls_version": tls.version(), "cipher": tls.cipher()[0],
                    "header_sha256": hashlib.sha256(raw_header).hexdigest(), "body_bytes": count,
                    "body_sha256": body_digest.hexdigest(), "peer_eof_observed": True,
                    "tls_close_notify_observed": True, "wire_total_ns": ended - began,
                    "connect_tls_ns": connected - began, "request_to_headers_ns": headers_at - connected,
                    "headers_to_body_eof_ns": ended - headers_at, "raw_tls_http204": code == 204}
        metadata.update(read_observation_headers=observed_headers,
                        read_observation_header_bytes=observed_header_bytes,
                        header_bytes=len(raw_header), node_id=node["id"],
                        response_origin_ip=node["ip"], response_origin_port=node["port"])
        result_body = b"".join(pieces)
        remaining(deadline_ns)
        result = metadata, result_body
    finally:
        if output is not None:
            output.close()
        if tls is not None:
            tls.close()
        if tcp is not None:
            tcp.close()
    remaining(deadline_ns)
    return result


def read_pipe(deadline_ns):
    raw = bytearray()
    while True:
        need(select.select([0], [], [], remaining(deadline_ns))[0], "input_deadline")
        block = os.read(0, min(65536, 6 * MIB + 1 - len(raw)))
        remaining(deadline_ns)
        if not block:
            return bytes(raw)
        raw.extend(block)
        need(len(raw) <= 6 * MIB, "input_bound")


def write_pipe(value, deadline_ns):
    os.set_blocking(1, False)
    try:
        view = memoryview(value)
        while view:
            need(select.select([], [1], [], remaining(deadline_ns))[1], "output_deadline")
            try:
                count = os.write(1, view[:65536])
            except BlockingIOError:
                continue
            need(count > 0, "output_closed")
            view = view[count:]
            remaining(deadline_ns)
    finally:
        os.set_blocking(1, True)
    remaining(deadline_ns)


def exchange(admission_path, admission_sha256, packet, *, deadline_ns=None, python=None):
    """Owned original child; the caller's one absolute deadline includes IPC.

    This starts only the wire interpreter. It never launches either product.
    Call from the already-owned HA controller group. An original child is always
    killed/reaped after unknown outcome; there is no bare PID or group signal.
    """
    began = clock_ns()
    deadline_ns = began + HTTP_SECONDS * 1_000_000_000 if deadline_ns is None else deadline_ns
    need(deadline_ns <= began + HTTP_SECONDS * 1_000_000_000, "original15s_maximum")
    remaining(deadline_ns)
    packet = dict(packet, deadline_ns=deadline_ns, clock_domain=CLOCK_DOMAIN)
    raw = json.dumps(packet, separators=(",", ":")).encode()
    remaining(deadline_ns)
    child, result = None, None
    try:
        child = subprocess.Popen([python or sys.executable, "-I", "-S", "-B", str(Path(__file__).resolve()),
                                  "--leaf", str(admission_path), admission_sha256, str(deadline_ns)],
                                 stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                 close_fds=True, env={"PATH": "/usr/bin:/bin", "LANG": "C", "TZ": "UTC"})
        output, errors = child.communicate(raw, timeout=remaining(deadline_ns))
        remaining(deadline_ns)
        need(child.returncode == 0 and not errors and len(output) <= JSON_LIMIT + WIRE_METADATA_BYTES,
             "wire_failed_or_unknown_no_retry")
        header, separator, body = output.partition(b"\n")
        need(separator and len(header) <= WIRE_METADATA_BYTES, "wire_output_framing")
        metadata = json.loads(header)
        need(metadata.get("clock_domain") == CLOCK_DOMAIN and metadata.get("original_deadline_ns") == deadline_ns,
             "wire_clock_binding")
        result = metadata, body
    finally:
        if child is not None and child.poll() is None:
            child.kill()
            child.communicate(timeout=REAP_SECONDS)
        need(child is None or child.returncode is not None, "original_wire_child_not_reaped")
    remaining(deadline_ns)
    return result


def main():
    need(len(sys.argv) == 5 and sys.argv[1] == "--leaf", "private_leaf_entry_only")
    admission, expected_sha256, deadline_ns = sys.argv[2], sys.argv[3], int(sys.argv[4])
    need(deadline_ns <= clock_ns() + HTTP_SECONDS * 1_000_000_000, "original15s_maximum")
    packet = json.loads(read_pipe(deadline_ns))
    metadata, body = perform(admission, expected_sha256, packet, deadline_ns)
    header = json.dumps(metadata, separators=(",", ":"), sort_keys=True).encode()
    need(len(header) <= WIRE_METADATA_BYTES, "wire_metadata_bound")
    remaining(deadline_ns)
    write_pipe(header + b"\n" + body, deadline_ns)
    remaining(deadline_ns)


if __name__ == "__main__":
    try:
        main()
    except Exception:
        # No exception repr, request, path, body, token or key goes to stderr.
        sys.stderr.write("ha_shared_wire_failed\n")
        raise SystemExit(1) from None
