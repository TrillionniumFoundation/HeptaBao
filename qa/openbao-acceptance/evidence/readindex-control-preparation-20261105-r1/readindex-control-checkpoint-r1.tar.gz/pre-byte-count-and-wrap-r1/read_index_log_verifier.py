#!/usr/bin/env python3
"""Closed parsing of original private ReadIndex logs. DRAFT, read-only.

These functions validate supplied bytes. The eventual caller must separately
bind the original owner launch, actual process and binary, remote file custody,
strict TLS exchange and independent complete KV2 oracle. No parser result grants
production, replacement or process-lifetime completeness authority.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

_spec = importlib.util.spec_from_file_location(
    "read_index_log_response_contract", Path(__file__).with_name("read_index_response_verifier.py"))
v = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(v)
Refusal, need, uint, flag = v.Refusal, v.need, v.uint, v.flag
DRAFT_ONLY = True
PREFIX = b"HBHA-READ-OBSERVATION "
MAX_BYTES, MAX_LINE, MAX_RECORDS = 32 * 1024 * 1024, 32 * 1024, 4096
TOP = frozenset(("schema", "launch_id", "process_id", "record_sequence", "kind", "body",
                 "log_lost_before", "log_writer_failed", "diagnostic_only"))
IDENTITY = frozenset(("cwd_device", "cwd_inode", "file_device", "file_inode",
                      "file_uid", "file_mode", "file_nlink"))
LAUNCH = IDENTITY | {"observer_profile", "limits"}
LIMITS = {"records": 4096, "record_bytes": 32768, "output_bytes": 33554432,
          "queue_records": 64, "events_per_request": 64}
EVENT = ("ordinal", "node", "leader", "term", "rpc_source", "rpc_target", "rpc_request_id",
         "read_log_id", "leader_applied", "local_applied", "state_machine_applied_index",
         "read_policy_calls", "outcome", "elapsed_us", "original_budget_us",
         "original_deadline_expired", "selection")
SELECTION = ("application_generation", "application_applied", "root_generation", "replay_epoch",
             "publication_log", "verification_successes", "verification_failures", "stages", "inconsistent")
OUTCOMES = {"success": 0, "not_leader": 1, "deadline": 2, "unavailable": 3,
            "rpc_transport": 4, "rpc_decode": 5, "cancelled": 6}
SNAPSHOT = frozenset(("complete", "started", "completed", "dropped", "events", "busy"))
TERMINAL = frozenset(("attempt_id", "protocol", "http_status", "writer_outcome", "accepted_bytes",
                      "flush_attempted", "elapsed_us", "original_deadline_expired",
                      "client_delivery_observed", "header_complete", "transcript",
                      "payload_binding_state", "payload_ordinal", "accepted_byte_scope"))


def decode_record(raw):
    def forbidden(_):
        raise Refusal("log_noninteger_number")
    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=v.pairs_unique,
                          parse_float=forbidden, parse_constant=forbidden)
    except (UnicodeError, ValueError, RecursionError):
        raise Refusal("log_invalid_json") from None


def compact_log(value):
    if value is None:
        return None
    need(type(value) is dict and set(value) == {"term", "node", "index"}, "log_id_closed_shape")
    return [value["term"], value["node"], value["index"]]


def compact_selection(value):
    if value is None:
        return None
    need(type(value) is dict and set(value) == set(SELECTION), "log_selection_closed_shape")
    row = [value[key] for key in SELECTION]
    row[1], row[4] = compact_log(row[1]), compact_log(row[4])
    return row


def verbose_event(value, *, node_id, peer=False, expected_ordinal=None):
    need(type(value) is dict and set(value) == set(EVENT), "log_event_closed_shape")
    need(type(value["outcome"]) is str and value["outcome"] in OUTCOMES, "log_event_outcome")
    row = [value[key] for key in EVENT]
    for index in (7, 8, 9):
        row[index] = compact_log(row[index])
    row[12], row[16] = OUTCOMES[row[12]], compact_selection(row[16])
    if expected_ordinal is None:
        expected_ordinal = 0 if peer else uint(row[0], "log_http_event_ordinal", positive=True)
    parsed = v.validate_event(row, expected_ordinal, peer_log=peer)
    need(parsed["node"] == node_id, "log_event_foreign_actual_node")
    return parsed


def terminal_body(body, *, node_id):
    need(type(body) is dict and set(body) == TERMINAL, "terminal_closed_shape")
    need(type(body["attempt_id"]) is str and v.HEX32.fullmatch(body["attempt_id"]) is not None,
         "terminal_attempt_identity")
    protocol = body["protocol"]
    need(protocol in ("http1", "http2") and body["accepted_byte_scope"] ==
         ("http1_plaintext" if protocol == "http1" else "http2_data"), "terminal_protocol_scope")
    status = body["http_status"]
    need(status is None or type(status) is int and 100 <= status <= 599, "terminal_status_shape")
    need(body["writer_outcome"] in ("complete", "failed", "abandoned"), "terminal_writer_outcome")
    uint(body["accepted_bytes"], "terminal_accepted_bytes")
    uint(body["elapsed_us"], "terminal_elapsed_us")
    for key in ("flush_attempted", "original_deadline_expired", "header_complete"):
        flag(body[key], "terminal_boolean_field")
    need(body["client_delivery_observed"] is False, "server_terminal_cannot_claim_client_delivery")
    state, ordinal = body["payload_binding_state"], body["payload_ordinal"]
    need(type(state) is int and 0 <= state <= 4, "terminal_payload_binding_state")
    if ordinal is not None:
        uint(ordinal, "terminal_payload_ordinal", positive=True)
    need(state == 1 or ordinal is None, "terminal_ineligible_payload_binding")
    snapshot = body["transcript"]
    need(type(snapshot) is dict and set(snapshot) == SNAPSHOT, "terminal_snapshot_closed_shape")
    for key in ("complete", "busy"):
        flag(snapshot[key], "terminal_snapshot_boolean")
    for key in ("started", "completed", "dropped"):
        uint(snapshot[key], "terminal_snapshot_counter")
    need(type(snapshot["events"]) is list and len(snapshot["events"]) <= 64,
         "terminal_snapshot_event_bound")
    events = [verbose_event(event, node_id=node_id) for event in snapshot["events"]]
    ordinals = [event["ordinal"] for event in events]
    need(len(ordinals) == len(set(ordinals)) and all(1 <= number <= 64 for number in ordinals),
         "terminal_snapshot_ordinal_set")
    if snapshot["complete"]:
        need(snapshot["started"] == snapshot["completed"] == len(events)
             and snapshot["dropped"] == 0 and snapshot["busy"] is False
             and ordinals == list(range(1, len(events) + 1)), "terminal_complete_event_denominator")
    if ordinal is not None:
        need(ordinal in ordinals, "terminal_payload_unknown_ordinal")
    return {**body, "transcript": {**snapshot, "events": events}}


def validate_log_bytes(raw, *, launch_id, process_id, node_id, file_identity):
    need(type(raw) is bytes and 0 < len(raw) <= MAX_BYTES and raw.endswith(b"\n"), "private_log_byte_bound_or_tail")
    need(type(launch_id) is str and v.HEX32.fullmatch(launch_id) is not None, "log_expected_owner_launch")
    uint(process_id, "log_expected_actual_pid", positive=True)
    uint(node_id, "log_expected_actual_node", positive=True)
    need(type(file_identity) is dict and set(file_identity) == IDENTITY, "log_expected_file_identity")
    for key, value in file_identity.items():
        uint(value, "log_file_identity_integer")
    need(file_identity["file_mode"] == 0o600 and file_identity["file_nlink"] == 1,
         "log_private_regular_file_identity")
    lines = raw.splitlines(keepends=True)
    need(1 <= len(lines) <= MAX_RECORDS, "private_log_record_bound")
    records, sequences, attempts = [], set(), set()
    for position, line in enumerate(lines):
        need(len(line) <= MAX_LINE and line.startswith(PREFIX) and line.endswith(b"\n")
             and not line.endswith(b"\r\n"), "private_log_record_framing")
        row = decode_record(line[len(PREFIX):-1])
        need(type(row) is dict and set(row) == TOP, "private_log_record_closed_shape")
        need(row["schema"] == "heptabao.read-index-observation.v1" and row["diagnostic_only"] is True,
             "private_log_record_schema")
        need(row["launch_id"] == launch_id and type(row["process_id"]) is int
             and row["process_id"] == process_id, "private_log_foreign_owner")
        sequence = uint(row["record_sequence"], "private_log_record_sequence", positive=True)
        need(sequence <= MAX_RECORDS and sequence not in sequences, "private_log_duplicate_or_overflow_sequence")
        sequences.add(sequence)
        need(uint(row["log_lost_before"], "private_log_lost_counter") == 0
             and row["log_writer_failed"] is False, "private_log_observed_loss")
        kind, body = row["kind"], row["body"]
        if position == 0:
            need(kind == "launch" and sequence == 1 and type(body) is dict and set(body) == LAUNCH,
                 "private_log_first_launch_record")
            need(body["observer_profile"] == "on" and type(body["limits"]) is dict
                 and set(body["limits"]) == set(LIMITS)
                 and all(type(body["limits"][key]) is int and body["limits"][key] == value
                         for key, value in LIMITS.items()), "private_log_frozen_limits")
            need(all(type(body[key]) is int and body[key] == value for key, value in file_identity.items()),
                 "private_log_launch_file_rebound")
            parsed = body
        elif kind == "authenticated_peer_read_index":
            parsed = verbose_event(body, node_id=node_id, peer=True, expected_ordinal=0)
        elif kind == "http_terminal":
            parsed = terminal_body(body, node_id=node_id)
            need(parsed["attempt_id"] not in attempts, "duplicate_http_terminal_attempt")
            attempts.add(parsed["attempt_id"])
        else:
            raise Refusal("private_log_unknown_or_repeated_launch_kind")
        records.append({"sequence": sequence, "kind": kind, "body": parsed,
                        "line_bytes": len(line), "line_sha256": hashlib.sha256(line).hexdigest()})
    # Concurrent producers allocate sequence ids before enqueueing. Their file
    # order can differ. A set, not ascending line order, detects internal loss.
    need(sequences == set(range(1, len(lines) + 1)), "private_log_internal_sequence_gap")
    return {"schema": "heptabao.readindex-private-log-validation.draft.v1",
            "status": "log_bytes_observed_only", "launch_id": launch_id,
            "process_id": process_id, "node_id": node_id, "file_identity": dict(file_identity),
            "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(), "records": records,
            "record_count": len(records), "internal_sequence_gaps": False,
            "actual_remote_file_origin_admitted": False, "complete_process_lifetime_proven": False,
            "payload_read_qualified": False, "replacement_qualified": False}


def correlate_unique_peer(consumer, producer_logs):
    need(consumer.get("successful_witness") is True and consumer.get("role") == "follower",
         "successful_follower_required")
    need(type(producer_logs) is list and len(producer_logs) <= 128, "peer_log_inventory_bound")
    matches = []
    for log in producer_logs:
        need(log["schema"] == "heptabao.readindex-private-log-validation.draft.v1",
             "parsed_peer_log_required")
        if log["node_id"] != consumer["leader"]:
            continue
        for record in log["records"]:
            producer = record["body"]
            if record["kind"] != "authenticated_peer_read_index" or producer.get("successful_witness") is not True:
                continue
            if (producer.get("role") == "rpc_leader" and producer["rpc"] == consumer["rpc"]
                    and producer["term"] == consumer["term"] and producer["read_log"] == consumer["read_log"]
                    and producer["leader_applied"] == consumer["leader_applied"]):
                pair = v.correlate_peer_records(consumer, producer)
                matches.append({**pair, "producer_launch_id": log["launch_id"],
                                "producer_process_id": log["process_id"], "producer_log_sha256": log["sha256"],
                                "producer_record_sequence": record["sequence"],
                                "producer_record_sha256": record["line_sha256"]})
    need(len(matches) == 1, "peer_witness_missing_or_ambiguous_across_launches")
    return matches[0]


def correlate_http_terminal(log, envelope, wire_metadata):
    need((log["launch_id"], log["process_id"], log["node_id"]) ==
         (envelope["launch_id"], envelope["process_id"], envelope["node_id"]), "terminal_envelope_owner_mismatch")
    matches = [r for r in log["records"] if r["kind"] == "http_terminal"
               and r["body"]["attempt_id"] == envelope["attempt_id"]]
    need(len(matches) == 1, "original_http_terminal_missing_or_ambiguous")
    record, terminal = matches[0], matches[0]["body"]
    need(terminal["protocol"] == "http1" and wire_metadata["http_version"] == "HTTP/1.1"
         and terminal["http_status"] == wire_metadata["status"], "terminal_actual_wire_status")
    need(terminal["writer_outcome"] == "complete" and terminal["flush_attempted"] is True
         and terminal["original_deadline_expired"] is False and terminal["header_complete"] is True,
         "original_http_writer_not_complete")
    need(wire_metadata["peer_eof_observed"] is True and wire_metadata["tls_close_notify_observed"] is True,
         "original_client_delivery_not_complete")
    snapshot = terminal["transcript"]
    need(snapshot["complete"] is True and snapshot["events"] == envelope["events"], "terminal_actual_transcript_mismatch")
    ordinal = envelope["payload_bindings"][0][1] if envelope["payload_bindings"] else None
    need(terminal["payload_binding_state"] == envelope["payload_binding_state"]
         and terminal["payload_ordinal"] == ordinal, "terminal_actual_payload_binding_mismatch")
    minimum = uint(wire_metadata["body_bytes"], "actual_wire_body_bytes") + uint(wire_metadata["header_bytes"], "actual_wire_header_bytes")
    need(terminal["accepted_bytes"] >= minimum, "terminal_accepted_bytes_below_actual_wire")
    return {"schema": "heptabao.readindex-terminal-correlation.draft.v1",
            "attempt_id": envelope["attempt_id"], "record_sequence": record["sequence"],
            "record_sha256": record["line_sha256"], "writer_accepted_bytes": terminal["accepted_bytes"],
            "client_header_and_decoded_body_bytes": minimum,
            "wire_and_terminal_fields_match": True, "actual_original_origins_admitted": False,
            "payload_read_qualified": False, "replacement_qualified": False}
