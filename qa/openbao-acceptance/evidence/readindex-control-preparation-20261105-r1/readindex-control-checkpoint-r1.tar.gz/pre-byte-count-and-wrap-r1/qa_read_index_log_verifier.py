#!/usr/bin/env python3
"""Pure synthetic private-log controls; never a product or host attestation."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("log_control", HERE / "read_index_log_verifier.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
LAUNCH, ATTEMPT = "1" * 32, "0123456789abcdef0123456789abcdef"
IDENTITY = {"cwd_device": 10, "cwd_inode": 20, "file_device": 10, "file_inode": 30,
            "file_uid": 501, "file_mode": 384, "file_nlink": 1}


def event(*, peer=False, node=1):
    return {"ordinal": 0 if peer else 1, "node": node, "leader": 1, "term": 5,
            "rpc_source": 2 if peer else None, "rpc_target": 1 if peer else None,
            "rpc_request_id": 77 if peer else None,
            "read_log_id": {"term": 5, "node": 1, "index": 90},
            "leader_applied": {"term": 5, "node": 1, "index": 91},
            "local_applied": {"term": 5, "node": 1, "index": 91},
            "state_machine_applied_index": None, "read_policy_calls": 1, "outcome": "success",
            "elapsed_us": 100, "original_budget_us": 1000, "original_deadline_expired": False,
            "selection": None if peer else {"application_generation": 8,
                "application_applied": {"term": 5, "node": 1, "index": 95}, "root_generation": 4,
                "replay_epoch": 6, "publication_log": {"term": 5, "node": 1, "index": 94},
                "verification_successes": 4, "verification_failures": 0, "stages": 15,
                "inconsistent": False}}


def row(kind, body, seq):
    return {"schema": "heptabao.read-index-observation.v1", "launch_id": LAUNCH,
            "process_id": 12345, "record_sequence": seq, "kind": kind, "body": body,
            "log_lost_before": 0, "log_writer_failed": False, "diagnostic_only": True}


def launch():
    return row("launch", {**IDENTITY, "observer_profile": "on", "limits": dict(m.LIMITS)}, 1)


def terminal(seq=2):
    return row("http_terminal", {"attempt_id": ATTEMPT, "protocol": "http1", "http_status": 200,
        "writer_outcome": "complete", "accepted_bytes": 400, "flush_attempted": True,
        "elapsed_us": 200, "original_deadline_expired": False, "client_delivery_observed": False,
        "header_complete": True, "transcript": {"complete": True, "started": 1, "completed": 1,
            "dropped": 0, "events": [event()], "busy": False}, "payload_binding_state": 1,
        "payload_ordinal": 1, "accepted_byte_scope": "http1_plaintext"}, seq)


def encoded(rows):
    return b"".join(m.PREFIX + json.dumps(r, separators=(",", ":")).encode() + b"\n" for r in rows)


def validate(rows=None, *, raw=None, identity=None, launch_id=LAUNCH):
    return m.validate_log_bytes(encoded(rows if rows is not None else [launch(), terminal()]) if raw is None else raw,
        launch_id=launch_id, process_id=12345, node_id=1, file_identity=IDENTITY if identity is None else identity)


def refuse(code, callback):
    try:
        callback()
    except m.Refusal as error:
        assert str(error) == code, (code, str(error))
    else:
        raise AssertionError("required refusal absent")


def mutate(path, value, code):
    rows = [launch(), terminal()]
    cursor = rows
    for key in path[:-1]:
        cursor = cursor[key]
    cursor[path[-1]] = value
    refuse(code, lambda: validate(rows))


def envelope():
    return {"launch_id": LAUNCH, "process_id": 12345, "node_id": 1, "attempt_id": ATTEMPT,
            "events": [m.verbose_event(event(), node_id=1)], "payload_binding_state": 1,
            "payload_bindings": [[1, 1, 200, True]]}


def wire():
    return {"http_version": "HTTP/1.1", "status": 200, "peer_eof_observed": True,
            "tls_close_notify_observed": True, "header_bytes": 100, "body_bytes": 300}


def positive():
    parsed = validate()
    paired = m.correlate_http_terminal(parsed, envelope(), wire())
    assert paired["wire_and_terminal_fields_match"] is True
    assert parsed["complete_process_lifetime_proven"] is False
    assert parsed["actual_remote_file_origin_admitted"] is False
    assert parsed["payload_read_qualified"] is paired["payload_read_qualified"] is False


def consumer():
    value = event(peer=True, node=2)
    value.update(ordinal=1, rpc_source=2, rpc_target=1, read_policy_calls=0,
                 local_applied={"term": 5, "node": 1, "index": 92}, state_machine_applied_index=92)
    return m.verbose_event(value, node_id=2)


def peer_log():
    return validate([launch(), row("authenticated_peer_read_index", event(peer=True), 2)])


def peer_positive():
    log = peer_log()
    assert log["records"][1]["body"]["ordinal"] == 0
    paired = m.correlate_unique_peer(consumer(), [log])
    assert paired["record_tuple_matches"] is True and paired["actual_independent_log_origin_admitted"] is False


def reordered():
    parsed = validate([launch(), row("authenticated_peer_read_index", event(peer=True), 3), terminal(2)])
    assert [r["sequence"] for r in parsed["records"]] == [1, 3, 2]


def incomplete_peer():
    value = event(peer=True)
    value.update(rpc_request_id=None, leader=None, term=None, read_log_id=None, leader_applied=None,
                 local_applied=None, read_policy_calls=0, outcome="cancelled")
    parsed = validate([launch(), row("authenticated_peer_read_index", value, 2)])
    assert parsed["records"][1]["body"]["successful_witness"] is False
    refuse("peer_witness_missing_or_ambiguous_across_launches", lambda: m.correlate_unique_peer(consumer(), [parsed]))


def ambiguous_peers():
    first = peer_log()
    second_rows = [launch(), row("authenticated_peer_read_index", event(peer=True), 2)]
    for item in second_rows:
        item["launch_id"] = "2" * 32
    second = validate(second_rows, launch_id="2" * 32)
    refuse("peer_witness_missing_or_ambiguous_across_launches", lambda: m.correlate_unique_peer(consumer(), [first, second]))


def failed_terminal(field, value, code):
    rows = [launch(), terminal()]
    rows[1]["body"][field] = value
    parsed = validate(rows)
    refuse(code, lambda: m.correlate_http_terminal(parsed, envelope(), wire()))


def changed_transcript():
    rows = [launch(), terminal()]
    rows[1]["body"]["transcript"]["events"][0]["elapsed_us"] = 101
    refuse("terminal_actual_transcript_mismatch", lambda: m.correlate_http_terminal(validate(rows), envelope(), wire()))


def bad_peer_ordinal():
    value = event(peer=True)
    value["ordinal"] = 1
    refuse("event_ordinal_sequence", lambda: validate([launch(), row("authenticated_peer_read_index", value, 2)]))


def repeated_terminal():
    refuse("duplicate_http_terminal_attempt", lambda: validate([launch(), terminal(2), terminal(3)]))


def duplicate_json():
    raw = encoded([launch(), terminal()]).replace(b'"process_id":12345', b'"process_id":12345,"process_id":12345', 1)
    refuse("duplicate_json_key", lambda: validate(raw=raw))


def main(output):
    cases = [
        ("matching_terminal_and_full_client_eof_remain_observations", positive),
        ("peer_zero_ordinal_preserved_and_exact_rpc_tuple_matched", peer_positive),
        ("concurrent_record_file_order_can_differ_from_unique_sequence_set", reordered),
        ("cancelled_peer_before_rpc_id_is_preserved_without_proof", incomplete_peer),
        ("same_rpc_tuple_across_restart_launches_is_ambiguous", ambiguous_peers),
        ("peer_ordinal_is_not_coerced_to_http_ordinal", bad_peer_ordinal),
        ("missing_peer_record_cannot_qualify", lambda: refuse("peer_witness_missing_or_ambiguous_across_launches", lambda: m.correlate_unique_peer(consumer(), []))),
        ("duplicate_json_key_is_rejected", duplicate_json),
        ("partial_final_line_is_rejected", lambda: refuse("private_log_byte_bound_or_tail", lambda: validate(raw=encoded([launch(), terminal()])[:-1]))),
        ("internal_sequence_gap_is_rejected", lambda: mutate([1, "record_sequence"], 3, "private_log_internal_sequence_gap")),
        ("duplicate_sequence_is_rejected", lambda: mutate([1, "record_sequence"], 1, "private_log_duplicate_or_overflow_sequence")),
        ("foreign_process_is_rejected", lambda: mutate([1, "process_id"], 12346, "private_log_foreign_owner")),
        ("foreign_launch_is_rejected", lambda: mutate([1, "launch_id"], "2" * 32, "private_log_foreign_owner")),
        ("launch_file_inode_rebinding_is_rejected", lambda: mutate([0, "body", "file_inode"], 31, "private_log_launch_file_rebound")),
        ("expanded_log_budget_is_rejected", lambda: mutate([0, "body", "limits", "records"], 8192, "private_log_frozen_limits")),
        ("bool_limit_is_not_an_integer", lambda: mutate([0, "body", "limits", "records"], True, "private_log_frozen_limits")),
        ("actual_log_loss_is_rejected", lambda: mutate([1, "log_lost_before"], 1, "private_log_observed_loss")),
        ("writer_failure_is_rejected", lambda: mutate([1, "log_writer_failed"], True, "private_log_observed_loss")),
        ("server_cannot_claim_client_delivery", lambda: mutate([1, "body", "client_delivery_observed"], True, "server_terminal_cannot_claim_client_delivery")),
        ("duplicate_attempt_terminal_is_rejected", repeated_terminal),
        ("terminal_for_foreign_node_is_rejected", lambda: mutate([1, "body", "transcript", "events", 0, "node"], 3, "follower_authenticated_rpc_identity")),
        ("terminal_transcript_must_equal_actual_response", changed_transcript),
        ("deadline_expired_terminal_does_not_qualify_writer", lambda: failed_terminal("original_deadline_expired", True, "original_http_writer_not_complete")),
        ("failed_writer_does_not_qualify", lambda: failed_terminal("writer_outcome", "failed", "original_http_writer_not_complete")),
        ("accepted_bytes_cannot_be_less_than_received_wire", lambda: failed_terminal("accepted_bytes", 399, "terminal_accepted_bytes_below_actual_wire")),
        ("second_launch_record_is_rejected", lambda: mutate([1, "kind"], "launch", "private_log_unknown_or_repeated_launch_kind")),
        ("oversized_log_record_is_rejected", lambda: refuse("private_log_record_framing", lambda: validate(raw=m.PREFIX + b" " * 32768 + b"\n"))),
    ]
    rows = []
    for name, callback in cases:
        try:
            callback()
            rows.append({"case": name, "passed": True})
        except BaseException as error:
            rows.append({"case": name, "passed": False, "failure_type": type(error).__name__,
                         "fixed_error": str(error) if isinstance(error, m.Refusal) else None})
    passed = sum(row["passed"] for row in rows)
    result = {"schema": "heptabao.readindex-private-log-control-qa.draft.v1",
              "status": "passed" if passed == len(cases) else "failed", "required": len(cases),
              "passed": passed, "checks": rows, "actual_remote_log_origin_tested": False,
              "products_started": False, "network_requests": 0, "replacement_qualified": False,
              "files": {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in (
                  "read_index_log_verifier.py", "read_index_response_verifier.py", "qa_read_index_log_verifier.py")}}
    output = Path(output)
    output.mkdir(mode=0o700, parents=True, exist_ok=False)
    raw = (json.dumps(result, sort_keys=True, indent=2) + "\n").encode()
    (output / "result.public.json").write_bytes(raw)
    for name in result["files"]:
        (output / name).write_bytes((HERE / name).read_bytes())
    print(json.dumps({"status": result["status"], "passed": passed, "required": len(cases),
                      "result_sha256": hashlib.sha256(raw).hexdigest(), "output": str(output)}))
    return 0 if passed == len(cases) else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1]))
