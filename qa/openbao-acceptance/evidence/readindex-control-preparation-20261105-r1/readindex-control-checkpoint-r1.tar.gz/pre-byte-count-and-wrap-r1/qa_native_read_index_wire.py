#!/usr/bin/env python3
"""Real loopback TLS controls for the read-only diagnostic wire; no products."""
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import socket
import ssl
import subprocess
import sys
import threading
import time

HERE = Path(__file__).resolve().parent


def need(value, code):
    if not value:
        raise AssertionError(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, raw):
    with Path(path).open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    Path(path).chmod(0o600)


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Peer:
    def __init__(self, cert, key, response, mode="valid", delay=0):
        self.cert, self.key, self.response = cert, key, response
        self.mode, self.delay = mode, delay
        self.stop = threading.Event()
        self.accepted = self.application_bytes = 0
        self.error_type = None
        self.listener = socket.socket()
        self.listener.bind(("127.0.0.1", 0))
        self.port = self.listener.getsockname()[1]
        self.listener.listen(1)
        self.listener.settimeout(0.1)
        self.thread = threading.Thread(target=self.run, daemon=False)
        self.thread.start()

    def run(self):
        tcp = tls = None
        try:
            while not self.stop.is_set():
                try:
                    tcp, _ = self.listener.accept()
                    break
                except socket.timeout:
                    continue
            if tcp is None:
                return
            self.accepted = 1
            context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.minimum_version = context.maximum_version = ssl.TLSVersion.TLSv1_2
            context.set_ciphers("ECDHE-RSA-AES128-GCM-SHA256")
            context.set_alpn_protocols(["http/1.1"])
            context.load_cert_chain(self.cert, self.key)
            tcp.settimeout(2)
            tls = context.wrap_socket(tcp, server_side=True)
            request = bytearray()
            while b"\r\n\r\n" not in request:
                chunk = tls.recv(4096)
                if not chunk:
                    return
                request.extend(chunk)
                self.application_bytes += len(chunk)
                need(len(request) <= 65536, "synthetic_request_bound")
            if self.stop.wait(self.delay):
                return
            tls.sendall(self.response)
            if self.mode == "tail":
                tls.sendall(b"forbidden-tail")
            if self.mode == "ragged":
                fd = tls.detach()
                tls = None
                os.close(fd)
                return
            if self.mode == "no_eof":
                self.stop.wait(3)
                return
            tls.settimeout(1)
            try:
                plain = tls.unwrap()
                tls = None
                plain.close()
            except (ssl.SSLError, OSError, TimeoutError):
                pass
        except BaseException as error:
            self.error_type = type(error).__name__
        finally:
            if tls is not None:
                tls.close()
            if tcp is not None:
                tcp.close()

    def close(self):
        self.stop.set()
        self.listener.close()
        self.thread.join(3)
        need(not self.thread.is_alive(), "synthetic_peer_not_joined")


def main(output):
    os.umask(0o077)
    output = Path(output).resolve()
    output.mkdir(mode=0o700)
    wire = load("native_read_wire_control", HERE / "native_read_index_wire.py")
    qa = load("read_index_wire_synthetic_document", HERE / "qa_read_index_response_verifier.py")
    verifier = qa.verifier
    for name in ("native_read_index_wire.py", "read_index_response_verifier.py", "qa_native_read_index_wire.py"):
        write(output / name, (HERE / name).read_bytes())
    config = output / "openssl.conf"
    write(config, b"[req]\nprompt=no\ndistinguished_name=dn\nx509_extensions=ext\n[dn]\nCN=127.0.0.1\n[ext]\nsubjectAltName=IP:127.0.0.1\nbasicConstraints=critical,CA:TRUE\nkeyUsage=critical,digitalSignature,keyEncipherment,keyCertSign\nextendedKeyUsage=serverAuth\n")
    cert, key = output / "synthetic-ca.pem", output / "synthetic-key.pem"
    certificate = subprocess.run(["/usr/bin/openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", str(key), "-out", str(cert), "-days", "2", "-config", str(config)],
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=15)
    need(certificate.returncode == 0, "synthetic_certificate_failed")
    cert.chmod(0o600)
    key.chmod(0o600)
    ca = cert.read_bytes()
    leaf = sha(ssl.PEM_cert_to_DER_cert(ca.decode()))
    checks = []

    def run_case(name, *, mode="valid", headers=None, seconds=2, expected=True,
                 packet_change=None, admission_change=None, direct=False, extra_assert=None):
        root = output / ("case-%02d" % len(checks))
        root.mkdir(mode=0o700)
        write(root / "ca.pem", ca)
        fields = qa.headers() if headers is None else headers
        body = json.dumps({"request_id": verifier.expected_response_request_id(qa.ATTEMPT),
                           "data": {"synthetic_only": "x" * (2 * 1024 * 1024)}}, separators=(",", ":")).encode()
        head = b"HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: " + str(len(body)).encode() + b"\r\nConnection: close\r\n"
        head += b"".join((key + ": " + value + "\r\n").encode("ascii") for key, value in fields if key.lower() != "content-type") + b"\r\n"
        peer = Peer(str(cert), str(key), head + body, mode=mode)
        value = {"schema": wire.SCHEMA, "run_id": "01" * 16, "scope": "synthetic_qa", "engine": "heptabao",
                 "cohort": "synthetic_qa", "production_authority": False,
                 "source_commit": "1f188df0f2affebb92702222e9fe5dfb4712194c",
                 "source_tree": "74bcb2b2af2fc9d349f007cd847fc2f16c08c01a", "root": str(root),
                 "archive_files": [], "tls_policy": "matched-tls12-rsa",
                 "nodes": [{"id": "qa", "label": "mac", "alias": "hepta-mac-local", "actual_hostname": "MacBook-Pro.local",
                            "physical_binding_sha256": "0" * 64, "ip": "127.0.0.1", "port": peer.port,
                            "ca_file": str(root / "ca.pem"), "ca_sha256": sha(ca), "leaf_sha256": leaf}]}
        if admission_change:
            value.update(admission_change)
        admission = root / "admission.public.json"
        encoded = (json.dumps(value, sort_keys=True) + "\n").encode()
        write(admission, encoded)
        packet = {"node_id": "qa", "token": "synthetic-only-no-production-authority", "method": "GET",
                  "path": "oracle271/data/history", "body": None, "archive_in": None, "archive_out": None,
                  "archive_sha256": None}
        if packet_change:
            packet.update(packet_change)
        began = wire.clock_ns()
        deadline = began + int(seconds * 1000000000)
        result, error, code = None, None, None
        try:
            if direct:
                result = wire.perform(admission, sha(encoded), dict(packet, clock_domain=wire.CLOCK_DOMAIN, deadline_ns=deadline), deadline)
            else:
                result = wire.exchange(admission, sha(encoded), packet, deadline_ns=deadline)
        except BaseException as caught:
            error = type(caught).__name__
            if isinstance(caught, wire.Refusal):
                code = str(caught)
        finally:
            peer.close()
        elapsed = (wire.clock_ns() - began) / 1000000000
        need((result is not None) is expected, name + "_unexpected_outcome")
        if result is not None:
            metadata, received = result
            need(received == body and metadata["body_sha256"] == sha(body)
                 and metadata["body_bytes"] == len(body) and metadata["header_sha256"] == sha(head)
                 and metadata["header_bytes"] == len(head)
                 and metadata["tls_close_notify_observed"] is True and metadata["peer_eof_observed"] is True
                 and metadata["original_deadline_ns"] == deadline and metadata["clock_domain"] == wire.CLOCK_DOMAIN
                 and metadata["response_origin_ip"] == "127.0.0.1" and metadata["response_origin_port"] == peer.port,
                 name + "_original_wire_binding")
        if extra_assert:
            extra_assert(result, peer, error, code, elapsed)
        checks.append({"case": name, "passed": True, "expected_success": expected, "elapsed_seconds": elapsed,
                       "original_budget_seconds": seconds, "error_type": error, "fixed_refusal": code,
                       "accepted_connections": peer.accepted, "peer_joined": True,
                       "body_bytes": len(body) if result is not None else None})

    def big_metadata(result, *_):
        metadata, body = result
        need(len(json.dumps(metadata).encode()) > 1024, "large_metadata_path_not_exercised")
        envelope = verifier.validate_envelope(metadata["read_observation_headers"], launch_id=qa.LAUNCH, process_id=12345, node_id=1)
        association = verifier.validate_payload_association(envelope, body, response_status=200)
        need(association["payload_read_qualified"] is False, "synthetic_claimed_product")

    def duplicate(result, *_):
        need(len(result[0]["read_observation_headers"]) == 3, "duplicate_was_collapsed")
        qa.refuse("duplicate_observation_header", lambda: verifier.validate_envelope(result[0]["read_observation_headers"], launch_id=qa.LAUNCH, process_id=12345, node_id=1))

    def no_diagnostics(result, *_):
        need(result[0]["read_observation_headers"] == [] and result[0]["read_observation_header_bytes"] == 0,
             "default_off_headers_not_empty")

    def no_connect(_result, peer, _error, _code, _elapsed):
        need(peer.accepted == 0 and peer.application_bytes == 0, "forbidden_operation_connected")

    status, failure = "failed", None
    try:
        run_case("large_actual_body_and_diagnostic_metadata_survive_original_ipc", extra_assert=big_metadata)
        fields = qa.headers()
        fields.append(["x-HeptaBao-READ-Observation", fields[1][1]])
        run_case("duplicate_headers_preserved_then_client_refused", headers=fields, extra_assert=duplicate)
        run_case("default_off_has_no_diagnostic_headers", headers=[], extra_assert=no_diagnostics)
        run_case("ragged_tls_eof_refused", mode="ragged", expected=False, direct=True,
                 extra_assert=lambda r, p, e, c, t: need(e == "SSLEOFError" and p.application_bytes > 0, "ragged_tls_reason"))
        run_case("forbidden_tail_refused", mode="tail", expected=False, direct=True,
                 extra_assert=lambda r, p, e, c, t: need(c == "forbidden_http_tail", "tail_reason"))
        run_case("missing_eof_consumes_original_shared_deadline", mode="no_eof", seconds=0.3, expected=False,
                 extra_assert=lambda r, p, e, c, t: need(p.application_bytes > 0 and 0.25 <= t <= 1.5, "shared_deadline_not_observed"))
        run_case("post_refused_before_connect", expected=False, direct=True, packet_change={"method": "POST"}, extra_assert=no_connect)
        run_case("product_scope_refused_while_draft", expected=False, direct=True,
                 admission_change={"scope": "native128", "cohort": "official-history128-read-observation", "tls_policy": "native128-original"}, extra_assert=no_connect)
        run_case("diagnostic_header_limit_enforced", expected=False, direct=True,
                 headers=[["X-HeptaBao-Read-Index-Trace", "x" * 12288]],
                 extra_assert=lambda r, p, e, c, t: need(c == "observation_header_byte_bound", "header_overflow_reason"))
        status = "passed"
    except BaseException as error:
        failure = {"type": type(error).__name__, "label": str(error) if isinstance(error, AssertionError) else None}
    result = {"schema": "heptabao.native-readindex-wire-control-qa.draft.v1", "status": status,
              "passed": len(checks), "required": 9, "checks": checks, "failure": failure,
              "wire_sha256": sha((HERE / "native_read_index_wire.py").read_bytes()),
              "verifier_sha256": sha((HERE / "read_index_response_verifier.py").read_bytes()),
              "qa_sha256": sha(Path(__file__).read_bytes()), "products_started": False,
              "production_authority": False, "product_readindex_qualified": False,
              "replacement_qualified": False, "scope": "synthetic TLS peer and parser controls only"}
    path = output / "result.public.json"
    write(path, (json.dumps(result, sort_keys=True, indent=2) + "\n").encode())
    print(json.dumps({"status": status, "passed": len(checks), "required": 9, "result": str(path), "sha256": sha(path.read_bytes())}))
    return 0 if status == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1]))
