#!/usr/bin/env python3
"""Read-only, bounded parsing of real response observations. DRAFT ONLY.

No process, network, credential, replay, or product operation is performed here.
Syntactically complete telemetry is never substituted for the pending exact
selected-root-to-final-payload contract or for independent KV2 correctness.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re
from decimal import Decimal

DRAFT_ONLY = True
U64_MAX = (1 << 64) - 1
MAX_EVENTS = 64
MAX_EXTRA_HEADER_BYTES = 12288
MAX_TRACE_JSON_BYTES = 9000
MAX_RESPONSE_BYTES = 4 * 1024 * 1024
ASSOCIATION = "x-heptabao-read-observation"
TRACE = "x-heptabao-read-index-trace"
TOP_FIELDS = frozenset((
    "v", "phase", "process_id", "attempt_id", "launch_id", "read_index",
    "log_lost_before", "log_writer_failed", "writer_completed",
    "client_delivery_observed", "payload_bindings", "payload_binding_state",
))
READ_FIELDS = frozenset((
    "v", "complete", "started", "completed", "dropped", "collector_busy", "events",
))
HEADER_NAME = re.compile(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+")
HEX32 = re.compile(r"[0-9a-f]{32}")
HEX64 = re.compile(r"[0-9a-f]{64}")
BASE64URL = re.compile(r"[A-Za-z0-9_-]+")
OUTCOMES = frozenset(range(7))


class Refusal(RuntimeError):
    """Fixed labels only. Never interpolate a response or credential."""


def need(value, code):
    if not value:
        raise Refusal(code)


def uint(value, code, *, positive=False):
    need(type(value) is int and (1 if positive else 0) <= value <= U64_MAX, code)
    return value


def flag(value, code):
    need(type(value) is bool, code)
    return value


def pairs_unique(items):
    out = {}
    for key, value in items:
        need(key not in out, "duplicate_json_key")
        out[key] = value
    return out


def decode_trace_json(raw):
    need(type(raw) is bytes and 0 < len(raw) <= MAX_TRACE_JSON_BYTES, "trace_json_bound")

    def forbidden_number(_):
        raise Refusal("trace_noninteger_number")

    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=pairs_unique,
                          parse_float=forbidden_number, parse_constant=forbidden_number)
    except (UnicodeError, ValueError, RecursionError) as error:
        raise Refusal("invalid_trace_json") from None


def decode_trace(value):
    need(type(value) is str and len(value) <= 12000 and BASE64URL.fullmatch(value) is not None,
         "trace_base64url_shape")
    try:
        raw = base64.b64decode(value + "=" * ((-len(value)) % 4), altchars=b"-_", validate=True)
    except (ValueError, base64.binascii.Error):
        raise Refusal("trace_base64url_decode") from None
    need(base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=") == value,
         "trace_base64url_noncanonical")
    return decode_trace_json(raw), raw


def diagnostic_headers(fields):
    """Accept actual ordered header fields, never a lossy collapsed dictionary."""
    need(type(fields) in (list, tuple) and len(fields) <= 256, "actual_header_field_list")
    selected, extra_bytes, total_bytes = {}, 0, 0
    for row in fields:
        need(type(row) in (list, tuple) and len(row) == 2, "header_field_pair")
        name, value = row
        need(type(name) is str and type(value) is str and len(name) <= 256 and len(value) <= 65536
             and HEADER_NAME.fullmatch(name) is not None
             and all(c == "\t" or 32 <= ord(c) < 127 for c in value), "header_ascii_syntax")
        total_bytes += len(name) + 2 + len(value) + 2
        need(total_bytes <= 65536, "actual_header_block_bound")
        lowered = name.lower()
        if lowered not in (ASSOCIATION, TRACE):
            continue
        need(lowered not in selected, "duplicate_observation_header")
        # Exact names, colon-space, value and CRLF. Raw wire header bounds are
        # independently enforced by the pinned strict TLS/HTTP parser.
        extra_bytes += len(name) + 2 + len(value) + 2
        need(extra_bytes <= MAX_EXTRA_HEADER_BYTES, "observation_header_byte_bound")
        selected[lowered] = value
    need(set(selected) == {ASSOCIATION, TRACE}, "missing_observation_header")
    match = re.fullmatch(r"1,([0-9a-f]{32}),([0-9a-f]{32})", selected[ASSOCIATION])
    need(match is not None, "observation_association_shape")
    trace, raw = decode_trace(selected[TRACE])
    return trace, {"launch_id": match.group(1), "attempt_id": match.group(2),
                   "extra_header_bytes": extra_bytes, "trace_json_bytes": len(raw),
                   "trace_json_sha256": hashlib.sha256(raw).hexdigest()}


def log_id(value, code, *, required=False):
    if value is None:
        need(not required, code)
        return None
    need(type(value) is list and len(value) == 3, code)
    for number in value:
        uint(number, code)
    return tuple(value)


def covers_log(applied, read, code):
    # Both index ordering and the actual term/node at an equal index matter.
    # Do not compare just a passive index or borrow another node's apply value.
    need(applied[2] >= read[2] and applied[0] >= read[0]
         and (applied[2] != read[2] or applied == read), code)


def validate_selection(value, read, successful):
    if value is None:
        return None
    need(type(value) is list and len(value) == 9, "selected_application_closed_shape")
    app_generation, app_applied, root_generation, replay_epoch, publication, verified, failed, stages, inconsistent = value
    uint(app_generation, "selected_application_generation")
    app_applied = log_id(app_applied, "selected_application_applied_log", required=True)
    for field, code in ((root_generation, "selected_root_generation"),
                        (replay_epoch, "selected_replay_epoch")):
        if field is not None:
            uint(field, code)
    publication = log_id(publication, "selected_publication_log")
    uint(verified, "selected_successful_verifications")
    uint(failed, "selected_failed_verifications")
    need(uint(stages, "selected_verification_stages") <= 15, "unknown_selection_stage")
    flag(inconsistent, "selected_inconsistent_flag")
    if successful:
        covers_log(app_applied, read, "selected_application_does_not_cover_read")
    # The application snapshot may be newer than the earlier ReadIndex local
    # frontier. Its own applied log, not that earlier passive frontier, is the
    # upper bound for the root selected by this same actual witness.
    if publication is not None:
        covers_log(app_applied, publication, "publication_not_covered_by_selected_application")
    return {"application_generation": app_generation,
            "application_applied_log": app_applied, "root_generation": root_generation,
            "replay_epoch": replay_epoch, "publication_log": publication,
            "verification_successes": verified, "verification_failures": failed,
            "stages": stages, "inconsistent": inconsistent}


def validate_event(row, expected_ordinal, *, peer_log=False):
    need(type(row) is list and len(row) == 17, "event_closed_shape")
    ordinal, node, leader, term, rpc_source, rpc_target, rpc_request, read, leader_applied, local_applied, state_applied, calls, outcome, elapsed, budget, expired, selection = row
    need(type(peer_log) is bool, "event_scope_type")
    need(type(expected_ordinal) is int and (expected_ordinal == 0 if peer_log else expected_ordinal > 0),
         "event_scope_ordinal")
    need(uint(ordinal, "event_ordinal", positive=not peer_log) == expected_ordinal, "event_ordinal_sequence")
    uint(node, "event_actual_node", positive=True)
    for value, name in ((leader, "event_leader"), (term, "event_term"),
                        (rpc_source, "rpc_source"), (rpc_target, "rpc_target"),
                        (rpc_request, "rpc_request_id"), (state_applied, "state_machine_applied")):
        if value is not None:
            uint(value, name)
    uint(calls, "read_policy_call_count")
    need(type(outcome) is int and outcome in OUTCOMES, "event_outcome_code")
    uint(elapsed, "event_elapsed_us")
    uint(budget, "event_original_budget_us")
    flag(expired, "event_original_deadline_flag")
    read = log_id(read, "event_read_log", required=outcome == 0)
    leader_applied = log_id(leader_applied, "event_leader_applied", required=outcome == 0)
    local_applied = log_id(local_applied, "event_local_applied", required=outcome == 0)
    rpc = (rpc_source, rpc_target, rpc_request)
    # A peer attempt can be cancelled after recording its authenticated source
    # and target but before the existing RPC request id becomes available.
    # Preserve that failed observation; it cannot become a successful witness.
    incomplete_peer = (peer_log and outcome != 0 and rpc_source is not None
                       and rpc_target is not None and rpc_request is None)
    need(all(v is None for v in rpc) or all(v is not None for v in rpc) or incomplete_peer,
         "partial_rpc_identity")
    if peer_log:
        need(rpc_source is not None and rpc_source > 0 and rpc_source != node
             and rpc_target == node and (rpc_request is None or rpc_request > 0)
             and selection is None, "peer_record_actual_scope")
    result = {"ordinal": ordinal, "node": node, "leader": leader, "term": term,
              "rpc": rpc, "read_log": read, "leader_applied": leader_applied,
              "local_applied": local_applied, "state_machine_applied_index": state_applied,
              "read_policy_calls": calls, "outcome_code": outcome,
              "elapsed_us": elapsed, "original_budget_us": budget,
              "original_deadline_expired": expired, "successful_witness": outcome == 0}
    result["selection"] = validate_selection(selection, read, outcome == 0)
    if outcome != 0:
        # Refusals and cancelled spans remain observations. They grant no read
        # witness, even when their last remembered numeric fields look current.
        return result
    uint(leader, "success_leader", positive=True)
    uint(term, "success_term", positive=True)
    need(not expired and budget > 0 and elapsed <= budget, "success_outside_original_deadline")
    need(read[0] == term and read[1] == leader, "read_log_leader_term")
    covers_log(leader_applied, read, "leader_apply_does_not_cover_read")
    covers_log(local_applied, read, "local_apply_does_not_cover_read")
    if node == leader:
        need(calls > 0 and state_applied is None, "actual_leader_read_policy_execution")
        if rpc_source is None:
            result["role"] = "local_leader"
        else:
            need(rpc_source > 0 and rpc_source != node and rpc_target == node and rpc_request > 0,
                 "producer_rpc_identity")
            result["role"] = "rpc_leader"
    else:
        need(calls == 0 and rpc_source == node and rpc_target == leader and rpc_request is not None
             and rpc_request > 0,
             "follower_authenticated_rpc_identity")
        need(state_applied is not None and state_applied >= read[2], "follower_state_machine_not_applied")
        result["role"] = "follower"
    if peer_log:
        need(result["role"] == "rpc_leader", "peer_success_not_actual_leader")
    return result


def validate_envelope(fields, *, launch_id, process_id, node_id):
    need(type(launch_id) is str and HEX32.fullmatch(launch_id) is not None, "expected_owner_launch")
    uint(process_id, "expected_actual_pid", positive=True)
    uint(node_id, "expected_actual_node", positive=True)
    trace, association = diagnostic_headers(fields)
    need(type(trace) is dict and set(trace) == TOP_FIELDS, "trace_closed_shape")
    need(type(trace["v"]) is int and trace["v"] == 1 and trace["phase"] == "pre_write", "trace_version_phase")
    need(type(trace["attempt_id"]) is str and HEX32.fullmatch(trace["attempt_id"]) is not None
         and trace["attempt_id"] == association["attempt_id"], "actual_attempt_association")
    need(trace["launch_id"] == association["launch_id"] == launch_id
         and type(trace["process_id"]) is int and trace["process_id"] == process_id,
         "actual_owner_process_association")
    need(trace["writer_completed"] is False and trace["client_delivery_observed"] is False,
         "prewrite_cannot_claim_writer_or_delivery")
    need(uint(trace["log_lost_before"], "log_lost_counter") == 0
         and trace["log_writer_failed"] is False, "process_observation_log_incomplete")
    reads = trace["read_index"]
    need(type(reads) is dict and set(reads) == READ_FIELDS, "read_index_closed_shape")
    need(type(reads["v"]) is int and reads["v"] == 1 and reads["complete"] is True
         and reads["collector_busy"] is False, "read_index_incomplete")
    started = uint(reads["started"], "read_index_started")
    completed = uint(reads["completed"], "read_index_completed")
    need(uint(reads["dropped"], "read_index_dropped") == 0, "read_index_dropped")
    need(type(reads["events"]) is list and started == completed == len(reads["events"])
         and completed <= MAX_EVENTS, "complete_event_denominator")
    events = [validate_event(row, index) for index, row in enumerate(reads["events"], 1)]
    need(all(event["node"] == node_id for event in events), "event_wrong_actual_node")
    state, bindings = trace["payload_binding_state"], trace["payload_bindings"]
    need(type(state) is int and 0 <= state <= 4, "payload_binding_state")
    need(type(bindings) is list and len(bindings) <= 1, "payload_binding_denominator")
    if state != 1:
        need(bindings == [], "ineligible_state_has_payload_binding")
    for binding in bindings:
        need(type(binding) is list and len(binding) == 4 and type(binding[0]) is int
             and binding[0] == 1 and type(binding[2]) is int and binding[2] == 200
             and binding[3] is True, "payload_binding_closed_shape")
        uint(binding[1], "payload_binding_ordinal", positive=True)
        need(binding[1] <= completed, "payload_binding_unknown_event")
    return {"schema": "heptabao.readindex-envelope-validation.draft.v1",
            "status": "envelope_observed_only", **association, "process_id": process_id,
            "node_id": node_id, "event_count": completed, "events": events,
            "payload_binding_state": state, "payload_bindings": bindings,
            "zero_actual_readindex_calls": started == 0,
            "payload_read_qualified": False, "server_write_terminal_qualified": False,
            "independent_leader_log_qualified": False, "replacement_qualified": False}


def correlate_peer_records(consumer, producer):
    """Only already validated *actual* records may enter the eventual caller."""
    need(consumer.get("successful_witness") is True and consumer.get("role") == "follower",
         "successful_follower_required")
    need(producer.get("successful_witness") is True and producer.get("role") == "rpc_leader",
         "successful_rpc_producer_required")
    need(consumer["rpc"] == producer["rpc"] and consumer["leader"] == producer["node"]
         and consumer["node"] == producer["rpc"][0] and consumer["term"] == producer["term"]
         and consumer["read_log"] == producer["read_log"]
         and consumer["leader_applied"] == producer["leader_applied"], "independent_peer_witness_mismatch")
    return {"source_node": consumer["node"], "target_node": producer["node"],
            "rpc_request_id": consumer["rpc"][2], "term": consumer["term"],
            "read_log": list(consumer["read_log"]), "record_tuple_matches": True,
            "actual_independent_log_origin_admitted": False}


def expected_response_request_id(attempt_id):
    need(type(attempt_id) is str and HEX32.fullmatch(attempt_id) is not None, "attempt_id_shape")
    # Pinned crypto::uuid_from_bytes inserts separators without rewriting bits.
    return "-".join((attempt_id[:8], attempt_id[8:12], attempt_id[12:16],
                     attempt_id[16:20], attempt_id[20:]))


def validate_payload_association(envelope, body, *, response_status):
    """Check an actual response association; independent origin remains required.

    This pure parser cannot establish where caller-supplied bytes came from.
    The eventual frozen caller must bind the original strict TLS exchange and
    current owner launch/PID/binary and separately compare complete KV2 payload
    semantics with the exact original oracle.
    """
    need(type(response_status) is int and response_status == 200,
         "payload_response_not_success")
    need(type(body) is bytes and 0 < len(body) <= MAX_RESPONSE_BYTES,
         "payload_response_body_bound")
    need(envelope["payload_binding_state"] == 1
         and len(envelope["payload_bindings"]) == 1, "final_payload_binding_unavailable")
    binding = envelope["payload_bindings"][0]
    ordinal = binding[1]
    matches = [event for event in envelope["events"] if event["ordinal"] == ordinal]
    need(len(matches) == 1 and matches[0]["successful_witness"] is True,
         "payload_binding_without_successful_witness")
    event = matches[0]
    selected = event["selection"]
    need(selected is not None and selected["stages"] == 15
         and selected["inconsistent"] is False and selected["verification_successes"] > 0
         and selected["verification_failures"] == 0
         and selected["root_generation"] is not None and selected["replay_epoch"] is not None
         and selected["publication_log"] is not None, "selected_root_verification_incomplete")

    def invalid_constant(_):
        raise Refusal("nonfinite_payload_json")

    try:
        document = json.loads(body.decode("utf-8"), object_pairs_hook=pairs_unique,
                              parse_float=Decimal, parse_constant=invalid_constant)
    except (ValueError, UnicodeError, RecursionError):
        raise Refusal("invalid_payload_json") from None
    need(type(document) is dict and type(document.get("data")) is dict
         and document.get("request_id") == expected_response_request_id(envelope["attempt_id"]),
         "final_response_request_association")
    return {"schema": "heptabao.readindex-payload-association.draft.v1",
            "status": "association_observed_only", "ordinal": ordinal,
            "launch_id": envelope["launch_id"], "attempt_id": envelope["attempt_id"],
            "process_id": envelope["process_id"], "node_id": envelope["node_id"],
            "response_body_bytes": len(body), "response_body_sha256": hashlib.sha256(body).hexdigest(),
            "response_status": response_status, "selected_application": selected,
            "successful_witness": event, "selected_root_to_final_wire_association": True,
            "wire_origin_admitted": False, "independent_payload_correctness": False,
            "independent_leader_log_qualified": False, "payload_read_qualified": False,
            "replacement_qualified": False}


def qualify_payload_read(*args, **kwargs):
    # No configurable boolean can turn an envelope or passive frontier into
    # proof of the actual final KV2 payload. This is closed until the exact
    # producer binding schema and original wire/owner evidence are frozen.
    raise Refusal("final_payload_binding_contract_not_yet_frozen")
