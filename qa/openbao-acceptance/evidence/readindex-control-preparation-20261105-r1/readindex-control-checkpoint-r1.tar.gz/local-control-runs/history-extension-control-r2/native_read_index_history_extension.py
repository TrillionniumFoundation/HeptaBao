#!/usr/bin/env python3
"""Draft addition to the unchanged 98+30 real-host history fixture.

Only its existing history GETs use the strict observation wire. All mutations,
snapshot transfers, owner stop calls and original checks stay in the parent.
Historical logs are read only after all original product actions have ended.
This module cannot launch a product until a new source/control freeze enables
it and the separate original-owner, build, KV2 and recovery gates admit it.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import stat
import sys
import time

DRAFT_ONLY = True
HERE = Path(__file__).resolve().parent
PINS = {
    "native_read_index_wire.py": "509389e7e18f7ff8b5c04f684ff9d73abe3acaec2292f805d0af9827539a566e",
    "read_index_response_verifier.py": "bf1ae91ee8bbce2f4a3b873b3c3e32f26f618b845343b8014b73b4f2d9a9aceb",
    "read_index_log_verifier.py": "f7be7505113343dd0a047fe1db0956dc54e250e5e0adf7a006a525bd0594d288",
}
READ_PATH = re.compile(r"oracle271/data/history(?:\?version=(?:[1-9]|1[0-9]|20))?")
OWNER_IDENTITY_FIELDS = frozenset((
    "schema", "node_id", "alias", "root", "run_id", "launch_id", "source_commit", "source_tree",
    "helper_sha256", "binary_sha256", "child_kind", "native_ha", "read_index_observation", "observation",
    "target_pid", "target_original_birth", "actual_child_executable_at_ready", "original_ssh_birth",
    "ready_wire_receipt_sha256", "ready_canonical_receipt_sha256", "payload_sha256", "scope",
    "fresh_remote_executable_probe", "read_capability"))
ORIGINAL_HISTORY_STAGES = (
    "official271_native_large_import", "official271_snapshot_rollback",
    "official271_leader_kill_cold_rejoin", "official271_all_hosts_cold_restart")
LOG_COLLECTION_SECONDS = 15
LOG_COLLECTION_TOTAL_BYTES = 64 * 1024 * 1024
MAX_RECORDED_GETS = 1024


class Refusal(RuntimeError):
    pass


def need(condition, code):
    if not condition:
        raise Refusal(code)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()


def load(name, filename):
    path = HERE / filename
    need(path.is_file() and not path.is_symlink() and sha(path.read_bytes()) == PINS[filename],
         "readindex_extension_dependency_changed")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


wire = load("readindex_history_strict_wire", "native_read_index_wire.py")
response = load("readindex_history_response", "read_index_response_verifier.py")
logs = load("readindex_history_logs", "read_index_log_verifier.py")


def new_bytes(path, raw):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as out:
        out.write(raw)
        out.flush()
        os.fsync(out.fileno())
    return {"path": str(path), "bytes": len(raw), "sha256": sha(raw)}


def original_bytes(binding, maximum):
    need(type(binding) is dict and set(binding) == {"path", "bytes", "sha256"}
         and type(binding["path"]) is str and type(binding["bytes"]) is int
         and 0 <= binding["bytes"] <= maximum and type(binding["sha256"]) is str
         and re.fullmatch(r"[0-9a-f]{64}", binding["sha256"]), "readindex_private_evidence_binding")
    path = Path(binding["path"])
    need(path.is_absolute() and path.parent.resolve(strict=True) == path.parent,
         "readindex_private_evidence_parent")
    with os.fdopen(os.open(path, os.O_RDONLY | os.O_NOFOLLOW), "rb") as source:
        before = os.fstat(source.fileno())
        need(stat.S_ISREG(before.st_mode) and before.st_uid == os.geteuid()
             and before.st_nlink == 1 and stat.S_IMODE(before.st_mode) == 0o600
             and before.st_size <= maximum, "readindex_private_evidence_contract")
        raw = source.read(maximum + 1)
        after = os.fstat(source.fileno())
        identity = lambda r: (r.st_dev, r.st_ino, r.st_size, r.st_mtime_ns, r.st_ctime_ns)
        need(identity(before) == identity(after) and len(raw) == before.st_size,
             "readindex_private_evidence_changed")
    need(len(raw) == binding["bytes"] and sha(raw) == binding["sha256"], "readindex_original_bytes_changed")
    return raw


def validate_current_identity(value, *, node, run_id, source_commit, source_tree,
                              binary_sha256, helper_sha256, native):
    need(type(value) is dict and set(value) == OWNER_IDENTITY_FIELDS, "current_original_owner_closed_schema")
    need(type(native) is bool and type(node.node_id) is int and node.node_id > 0
         and type(value["node_id"]) is int, "current_original_owner_value_types")
    need(value["schema"] == "heptabao.original-owner-observation-identity.v1"
         and value["node_id"] == node.node_id and value["alias"] == node.alias
         and value["root"] == node.root and value["run_id"] == run_id,
         "current_original_owner_node_or_root")
    need(value["source_commit"] == source_commit and value["source_tree"] == source_tree
         and value["binary_sha256"] == binary_sha256 and value["helper_sha256"] == helper_sha256,
         "current_original_owner_source_or_binary")
    need(value["child_kind"] == "native" and value["native_ha"] is native
         and value["read_index_observation"] == ("on" if native else "off"), "actual_owner_observer_profile")
    need(value["fresh_remote_executable_probe"] is False and value["read_capability"] is False,
         "original_ready_identity_is_not_fresh_probe")
    pid, launch = value["target_pid"], value["launch_id"]
    need(type(pid) is int and pid > 0 and type(launch) is str
         and re.fullmatch(r"[0-9a-f]{32}", launch), "current_original_pid_and_launch")
    executable = value["actual_child_executable_at_ready"]
    need(type(executable) is dict and type(executable["pid"]) is int
         and type(value["target_original_birth"]) is dict
         and type(value["target_original_birth"]["ps"]) is dict
         and type(value["target_original_birth"]["ps"]["pid"]) is int
         and executable["pid"] == pid == value["target_original_birth"]["ps"]["pid"]
         and executable["executable_sha256"] == binary_sha256
         and executable["executable"] == str(Path(node.root) / "heptabao-server"),
         "current_original_actual_executable")
    for key in ("ready_wire_receipt_sha256", "ready_canonical_receipt_sha256", "payload_sha256"):
        need(type(value[key]) is str and re.fullmatch(r"[0-9a-f]{64}", value[key]), "current_original_receipt_pin")
    descriptor = value["observation"]
    expected_descriptor = {"profile": "on" if native else "off",
        "environment_key": "HB_READ_INDEX_OBSERVATION_V1", "environment_value": launch if native else None,
        "environment_key_inherited": False, "cwd": node.root, "cwd_binding": "explicit_private_fixture_root",
        "log_path": str(Path(node.root) / ("read-index-observation-" + launch + ".log")),
        "log_required": native, "log_cap_bytes": logs.MAX_BYTES}
    need(type(descriptor) is dict and descriptor == expected_descriptor
         and descriptor["environment_key_inherited"] is False and descriptor["log_required"] is native
         and type(descriptor["log_cap_bytes"]) is int,
         "current_original_observer_environment_or_path")
    return value


def file_identity_from_capture(metadata):
    identity = metadata["file_identity"]
    launch = metadata["launch_record"]["body"]
    need(type(identity) is dict, "original_remote_log_file_identity_missing")
    return {"cwd_device": launch["cwd_device"], "cwd_inode": launch["cwd_inode"],
            "file_device": identity["device"], "file_inode": identity["inode"],
            "file_uid": identity["uid"], "file_mode": identity["mode"], "file_nlink": identity["nlink"]}


class ReadIndexHistoryMixin:
    """Installed only by a separately frozen adapter with an actual parent module.

    READ_INDEX_PARENT and READ_INDEX_COLLECTOR must be exact pinned modules in
    that adapter. This is deliberately not a generic command-line plugin.
    """

    def __init__(self, *args):
        need(not DRAFT_ONLY and not wire.DRAFT_ONLY, "readindex_live_extension_not_frozen")
        super().__init__(*args)
        self._ri_parent = self.READ_INDEX_PARENT
        self._ri_collector = self.READ_INDEX_COLLECTOR
        self._ri_exact = self._ri_parent.history.exact
        self._ri_records, self._ri_groups, self._ri_identities = [], [], {}
        self._ri_root = None
        self._ri_finalized = False
        self.report.update(read_index_payload_observation_qualified=False,
            read_index_http_gets=[], read_index_history_groups=[], read_index_closed_logs=[],
            read_index_observation_scope="existing history GETs only; no extra request or changed mutation",
            read_index_process_lifetime_completeness_proven=False,
            read_index_executed_minority_failure_proven=False,
            read_index_added_log_collection_seconds=LOG_COLLECTION_SECONDS)

    def prepare(self):
        result = super().prepare()
        root = self.work / "read-index-evidence"
        root.mkdir(mode=0o700)
        (root / "gets").mkdir(mode=0o700)
        (root / "logs").mkdir(mode=0o700)
        ca = self._ri_exact.private_read(self.work / "ca.crt")
        need(sha(ca) == self.ca_sha256, "original_history_ca_changed")
        new_bytes(root / "ca.pem", ca)
        nodes = []
        for node in self.nodes:
            label = next(label for label, (alias, _) in wire.HOSTS.items() if alias == node.alias)
            actual = self._owner_preflights[node.alias]
            build = next(row for row in self.report["owner_binary_bindings"] if row["node_id"] == node.node_id)
            need(actual["host"] == wire.HOSTS[label][1] and build["binary_sha256"] == self.expected[str(node.node_id)],
                 "readindex_actual_host_and_binary_binding")
            physical = new_bytes(root / ("physical-" + str(node.node_id) + ".json"),
                                 canonical({"preflight": actual, "build_binding": build}))
            nodes.append({"id": str(node.node_id), "label": label, "alias": node.alias,
                "actual_hostname": actual["host"], "physical_binding_sha256": physical["sha256"],
                "ip": node.ip, "port": node.api_port, "ca_file": str(root / "ca.pem"),
                "ca_sha256": self.ca_sha256, "leaf_sha256": self.peers[str(node.node_id)]["certificate_sha256"]})
        admission = {"schema": wire.SCHEMA, "run_id": self.run_id, "scope": "native128",
            "engine": "heptabao", "cohort": "official-history128-read-observation", "production_authority": False,
            "source_commit": self.args.source_commit, "source_tree": self.args.source_tree,
            "root": str(root), "nodes": nodes, "archive_files": [], "tls_policy": "native128-original"}
        self._ri_admission = new_bytes(root / "wire-admission.private.json", canonical(admission))
        self._ri_root = root
        for filename in PINS:
            self.source_files[str(HERE / filename)] = PINS[filename]
        for path in (Path(__file__), Path(self._ri_collector.__file__)):
            self.source_files[str(path.resolve())] = sha(path.read_bytes())
        return result

    def _ri_identity(self, node, session):
        return validate_current_identity(session.current_original_observation_identity(), node=node,
            run_id=self.run_id, source_commit=self.args.source_commit, source_tree=self.args.source_tree,
            binary_sha256=self.expected[str(node.node_id)], helper_sha256=self._ri_parent.HELPER_SHA256,
            native=session.payload["native_ha"])

    def owned_process_action(self, node, action, *, native=True):
        # No observation work precedes or delays a stop, including ACK->kill.
        result = super().owned_process_action(node, action, native=native)
        if action == "start":
            session = self.foreground_sessions[node.alias]
            identity = self._ri_identity(node, session)
            need(session.launch_id not in self._ri_identities, "readindex_duplicate_original_launch")
            self._ri_identities[session.launch_id] = identity
        return result

    def wire(self, node, method, path, body=None, *, archive_in=None, archive_out=None):
        if method != "GET" or type(path) is not str or READ_PATH.fullmatch(path) is None:
            return super().wire(node, method, path, body, archive_in=archive_in, archive_out=archive_out)
        deadline = wire.clock_ns() + 15_000_000_000
        need(self._ri_root is not None and node in self.nodes and node.api_connect_port is None
             and body is None and archive_in is None and archive_out is None, "readindex_fixed_original_get")
        need(len(self._ri_records) < MAX_RECORDED_GETS, "readindex_added_evidence_get_bound")
        session = self.foreground_sessions[node.alias]
        identity = self._ri_identity(node, session)
        need(identity == self._ri_identities[session.launch_id] and session.payload["native_ha"] is True,
             "readindex_current_original_launch_changed")
        seq = len(self._ri_records) + 1
        directory = self._ri_root / "gets" / ("get-%05d" % seq)
        directory.mkdir(mode=0o700)
        entry = {"sequence": seq, "stage": self.stage, "node_id": node.node_id, "alias": node.alias,
                 "launch_id": session.launch_id, "path": path, "status": "started", "payload_qualified": False}
        self._ri_records.append({"public": entry, "owner": identity, "directory": directory})
        self.report["read_index_http_gets"].append(entry)
        intent = {"schema": "heptabao.readindex-existing-get-intent.v1", "sequence": seq,
                  "method": method, "path": path, "stage": self.stage, "owner": identity,
                  "original_deadline_ns": deadline, "wire_admission": self._ri_admission,
                  "automatic_retry": False, "credential_headers_persisted": False}
        entry["intent"] = new_bytes(directory / "intent.public.json", canonical(intent))
        record = self._ri_records[-1]
        try:
            packet = {"node_id": str(node.node_id), "token": self.root_token, "method": "GET", "path": path,
                      "body": None, "archive_in": None, "archive_sha256": None, "archive_out": None}
            metadata, raw = wire.exchange(self._ri_admission["path"], self._ri_admission["sha256"],
                                          packet, deadline_ns=deadline)
            need(self._ri_identity(node, session) == identity, "readindex_owner_changed_during_actual_get")
            need(metadata["node_id"] == str(node.node_id) and metadata["response_origin_ip"] == node.ip
                 and metadata["response_origin_port"] == node.api_port and metadata["leaf_sha256"] ==
                 self.peers[str(node.node_id)]["certificate_sha256"] and metadata["body_bytes"] == len(raw)
                 and metadata["body_sha256"] == sha(raw) and metadata["original_deadline_ns"] == deadline,
                 "readindex_original_wire_identity_or_bytes")
            envelope = response.validate_envelope(metadata["read_observation_headers"],
                launch_id=identity["launch_id"], process_id=identity["target_pid"], node_id=node.node_id)
            code = metadata["status"]
            need(code in (200, 404), "original_history_get_status")
            decoded = self._ri_exact.decode(raw)
            entry["response"] = new_bytes(directory / "response.private.json", raw)
            entry["wire"] = new_bytes(directory / "wire.public.json", canonical(metadata))
            entry["status"] = code
            record.update(envelope=envelope, wire=metadata)
            if code == 200:
                association = response.validate_payload_association(envelope, raw, response_status=code)
                value = decoded["data"]
                version = value["metadata"]["version"]
                need(type(version) is int and 1 <= version <= 20, "original_payload_version")
                if "?version=" in path:
                    need(version == int(path.rsplit("=", 1)[1]), "actual_payload_requested_version")
                if version <= 19:
                    expected = self.api_payloads[str(version)]
                    oracle_scope = "actual_original_openbao271_api_payload"
                else:
                    need(self.stage == "official271_snapshot_rollback" and path == "oracle271/data/history",
                         "version20_only_original_postsnapshot_read")
                    expected = {"after_snapshot": True}
                    oracle_scope = "original_fixed_postsnapshot_mutation_payload"
                need(self._ri_exact.same_json_tokens(value["data"], expected), "independent_actual_payload_mismatch")
                entry.update(version=version, payload_oracle_scope=oracle_scope,
                    expected_payload_sha256=sha(self._ri_exact.canonical(expected)),
                    independent_payload_correctness=True,
                    original_official_source_receipt_sha256=self.args.official_full34_summary_sha256,
                    selected_application=association["selected_application"])
                record["association"] = association
            else:
                entry.update(payload_oracle_scope="tombstone_not_successful_payload", independent_payload_correctness=False)
            wire.remaining(deadline)
            new_bytes(directory / "response-observation.public.json", canonical(entry))
            wire.remaining(deadline)
            return code, decoded
        except BaseException as error:
            entry.update(status="failed_or_unknown_no_retry", failure_type=type(error).__name__)
            if isinstance(error, (Refusal, wire.Refusal, response.Refusal)):
                entry["failure_code"] = str(error)
            raise

    def observe_history(self, node):
        first = len(self._ri_records)
        observed = super().observe_history(node)
        records = self._ri_records[first:]
        need(len(records) == 19 and [r["public"]["path"] for r in records] ==
             ["oracle271/data/history?version=" + str(i) for i in range(1, 20)], "same_original19_get_denominator")
        for version, record in enumerate(records, 1):
            entry = record["public"]
            raw = original_bytes(entry["response"], wire.JSON_LIMIT)
            actual = self._ri_exact.decode(raw)
            need(self._ri_exact.same_json_tokens(observed["versions"][str(version)],
                 {"status": entry["status"], "data": actual["data"]}), "original_history_uses_same_received_bytes")
        group = {"stage": self.stage, "node_id": node.node_id,
                 "sequences": [r["public"]["sequence"] for r in records],
                 "history_sha256": sha(self._ri_exact.canonical(observed)), "full_history_verified": False}
        self._ri_groups.append(group)
        self.report["read_index_history_groups"].append(group)
        return observed

    def verify_history(self, nodes, expected=None):
        first = len(self._ri_groups)
        result = super().verify_history(nodes, expected)
        expected_value = self.original if expected is None else expected
        expected_sha = sha(self._ri_exact.canonical(expected_value))
        for group in self._ri_groups[first:]:
            need(group["history_sha256"] == expected_sha, "original_full_history_expected_projection")
            group.update(full_history_verified=True, expected_history_sha256=expected_sha,
                full_history_oracle_scope=("actual_original_openbao271_history" if expected is None
                                           else "original_explicit_same_run_history"))
        return result

    def _ri_finish(self):
        need(not self._ri_finalized, "readindex_finalization_not_repeatable")
        self._ri_finalized = True
        need(not self.foreground_sessions and self.report["owner_gate_qualified"] is True,
             "readindex_logs_require_all_original_products_closed")
        need(set(self._ri_identities) == set(self._owner_all_sessions), "every_original_launch_has_identity")
        deadline = time.monotonic() + LOG_COLLECTION_SECONDS
        parsed, total = {}, 0
        for launch, session in self._owner_all_sessions.items():
            remaining = deadline - time.monotonic()
            need(remaining > 0, "readindex_all_logs_original_collection_deadline")
            original = self._ri_identities[launch]
            captured = self._ri_collector.collect_closed_observation(session.node.alias, session.payload,
                self._ri_root / "logs" / launch, expected_current_identity=original, timeout=remaining)
            receipt = captured["receipt"]
            self.report["read_index_closed_logs"].append({"launch_id": launch, "path": captured["path"],
                "sha256": captured["sha256"], "status": receipt["status"],
                "completed_within_original_read_deadline": captured["completed_within_original_read_deadline"]})
            need(captured["completed_within_original_read_deadline"] is True and receipt["status"] == "captured"
                 and receipt["original_owner_closed_observed"] is True and receipt["current_owner_identity_bound"] is True,
                 "original_closed_log_capture_unavailable_or_late")
            if not session.payload["native_ha"]:
                need(receipt["remote_log_status"] == "absent_profile_off" and receipt["raw_log"] is None,
                     "standalone_seed_observer_must_be_off")
                continue
            binding = receipt["raw_log"]
            raw = original_bytes(binding, logs.MAX_BYTES)
            total += len(raw)
            need(total <= LOG_COLLECTION_TOTAL_BYTES, "readindex_all_logs_total_byte_bound")
            metadata_path = Path(captured["path"]).with_name("remote-read.public.json")
            metadata_raw = original_bytes({"path": str(metadata_path), "bytes": metadata_path.lstat().st_size,
                                           "sha256": receipt["remote_read_sha256"]}, 65536)
            metadata = json.loads(metadata_raw)
            parsed[launch] = logs.validate_log_bytes(raw, launch_id=launch, process_id=original["target_pid"],
                node_id=session.node.node_id, file_identity=file_identity_from_capture(metadata))
            need(time.monotonic() < deadline, "readindex_all_logs_original_collection_deadline")
        leaders, roles, successes = set(), set(), 0
        for record in self._ri_records:
            entry = record["public"]
            need(entry["status"] in (200, 404), "readindex_recorded_get_failed_or_unknown")
            if entry["status"] != 200:
                continue
            need(entry["independent_payload_correctness"] is True, "readindex_payload_oracle_not_complete")
            original_bytes(entry["response"], wire.JSON_LIMIT)
            original_bytes(entry["wire"], wire.WIRE_METADATA_BYTES)
            envelope = record["envelope"]
            terminal = logs.correlate_http_terminal(parsed[entry["launch_id"]], envelope, record["wire"])
            event = record["association"]["successful_witness"]
            peer = None
            if event["role"] == "follower":
                peer = logs.correlate_unique_peer(event, list(parsed.values()))
                roles.add("follower")
            else:
                need(event["role"] == "local_leader" and event["node"] == event["leader"]
                     and event["rpc"] == (None, None, None) and event["read_policy_calls"] > 0,
                     "readindex_local_leader_policy_missing")
                roles.add("leader")
            leaders.add(event["leader"])
            correlation = {"schema": "heptabao.readindex-actual-get-correlation.v1", "sequence": entry["sequence"],
                "terminal": terminal, "peer": peer, "owner": entry["launch_id"],
                "wire": entry["wire"], "response": entry["response"], "oracle_scope": entry["payload_oracle_scope"],
                "expected_payload_sha256": entry["expected_payload_sha256"], "replacement_qualified": False}
            entry["correlation"] = new_bytes(record["directory"] / "correlation.public.json", canonical(correlation))
            entry["payload_qualified"] = True
            successes += 1
            need(time.monotonic() < deadline, "readindex_all_logs_original_collection_deadline")
        coverage = []
        for stage in ORIGINAL_HISTORY_STAGES:
            for node in self.nodes:
                groups = [g for g in self._ri_groups if g["stage"] == stage and g["node_id"] == node.node_id
                          and g["full_history_verified"] and g["full_history_oracle_scope"] == "actual_original_openbao271_history"]
                need(len(groups) == 1, "readindex_original_history_coverage_missing_or_ambiguous")
                selected = [self._ri_records[i - 1]["public"] for i in groups[0]["sequences"]]
                qualified = [row for row in selected if row["payload_qualified"]]
                need(len(qualified) == 17 and {row["version"] for row in qualified} == set(range(3, 20)),
                     "readindex_same_original17_live_versions_missing")
                coverage.append({"stage": stage, "node_id": node.node_id, "live_payloads": 17,
                                 "history_sha256": groups[0]["history_sha256"]})
        need(successes >= 12 * 17 and roles == {"leader", "follower"} and len(leaders) >= 2,
             "readindex_actual_roles_and_leader_transition_not_observed")
        self.report.update(read_index_payload_observation_qualified=True,
            read_index_successful_payload_count=successes, read_index_original_history_coverage=coverage,
            read_index_actual_leader_nodes=sorted(leaders), read_index_actual_reader_roles=sorted(roles),
            read_index_captured_log_bytes=total, read_index_original_get_count=len(self._ri_records))
        need(time.monotonic() < deadline, "readindex_all_logs_original_collection_deadline")
        return deadline

    def cleanup(self):
        outcome = super().cleanup()
        if outcome:
            try:
                deadline = self._ri_finish()
                self.checkpoint()
                need(time.monotonic() < deadline, "readindex_final_report_fsync_collection_deadline")
                return self.report["read_index_payload_observation_qualified"] is True
            except BaseException as error:
                self.report["read_index_payload_observation_qualified"] = False
                self.report["read_index_failure_type"] = type(error).__name__
                if isinstance(error, (Refusal, response.Refusal, logs.Refusal)):
                    self.report["read_index_failure_code"] = str(error)
        self.checkpoint()
        return bool(outcome and self.report["read_index_payload_observation_qualified"])
