#!/usr/bin/env python3
"""Local synthetic integration controls. Never a product or physical-host proof.

The real extension's constructor stays closed. Model owners and model producer
logs exercise the final evidence join using real local private-file I/O. These
models must never be supplied to a product admission gate.
"""
from __future__ import annotations
import base64
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("history_extension_control", HERE / "native_read_index_history_extension.py")
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def raw_json(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()


class ModelParent:
    constructor_calls = 0

    def __init__(self, *args):
        ModelParent.constructor_calls += 1
        raise AssertionError("draft must close before parent construction")

    def cleanup(self):
        self.order.append("original_parent_cleanup")
        return True

    def owned_process_action(self, node, action, *, native=True):
        self.order.append(("original_parent_action", action))
        return "model-parent-result"

    def wire(self, node, method, path, body=None, *, archive_in=None, archive_out=None):
        self.order.append(("original_parent_wire", method, path, body, archive_in, archive_out))
        return "unchanged-model-parent-result"

    def checkpoint(self):
        self.checkpoints += 1


class ModelRun(m.ReadIndexHistoryMixin, ModelParent):
    pass


def record(launch, pid, kind, body, sequence):
    return {"schema": "heptabao.read-index-observation.v1", "launch_id": launch, "process_id": pid,
            "record_sequence": sequence, "kind": kind, "body": body,
            "log_lost_before": 0, "log_writer_failed": False, "diagnostic_only": True}


def event(node, leader, phase, rpc_id, *, peer=False):
    index, term = 90 + phase * 100, 5 + phase
    log = lambda i: {"term": term, "node": leader, "index": i}
    follower = node != leader
    remote = follower or peer
    value = {"ordinal": 0 if peer else 1, "node": node, "leader": leader, "term": term,
        "rpc_source": (rpc_id[0] if peer else node) if remote else None,
        "rpc_target": leader if remote else None, "rpc_request_id": rpc_id[1] if remote else None,
        "read_log_id": log(index), "leader_applied": log(index + 1), "local_applied": log(index + 2),
        "state_machine_applied_index": index + 2 if follower else None,
        "read_policy_calls": 0 if follower else 1, "outcome": "success", "elapsed_us": 100,
        "original_budget_us": 1000, "original_deadline_expired": False,
        "selection": None if peer else {"application_generation": 8 + phase,
            "application_applied": log(index + 5), "root_generation": 4 + phase, "replay_epoch": 6 + phase,
            "publication_log": log(index + 4), "verification_successes": 4, "verification_failures": 0,
            "stages": 15, "inconsistent": False}}
    return value


def compact(value):
    log = lambda item: None if item is None else [item["term"], item["node"], item["index"]]
    selected = value["selection"]
    selection = None if selected is None else [selected["application_generation"], log(selected["application_applied"]),
        selected["root_generation"], selected["replay_epoch"], log(selected["publication_log"]),
        selected["verification_successes"], selected["verification_failures"], selected["stages"], selected["inconsistent"]]
    return [value["ordinal"], value["node"], value["leader"], value["term"], value["rpc_source"],
        value["rpc_target"], value["rpc_request_id"], log(value["read_log_id"]), log(value["leader_applied"]),
        log(value["local_applied"]), value["state_machine_applied_index"], value["read_policy_calls"],
        0, value["elapsed_us"], value["original_budget_us"], value["original_deadline_expired"], selection]


class ModelCollector:
    def __init__(self, run, rows, identities, *, late=False, unbound=False):
        self.run, self.rows, self.identities = run, rows, identities
        self.late, self.unbound = late, unbound

    def collect_closed_observation(self, alias, payload, destination, *, expected_current_identity, timeout):
        assert not self.run.foreground_sessions and self.run.report["owner_gate_qualified"] is True
        assert expected_current_identity is self.run._ri_identities[payload["launch_id"]]
        assert 0 < timeout <= 15
        self.run.order.append("model_closed_log_after_original_cleanup")
        destination.mkdir(mode=0o700)
        launch = payload["launch_id"]
        source = self.rows[launch]
        raw = b"".join(m.logs.PREFIX + raw_json(item) for item in source)
        raw_binding = m.new_bytes(destination / "closed-observation.log", raw)
        identity = self.identities[launch]
        metadata = {"file_identity": {"device": identity["file_device"], "inode": identity["file_inode"],
            "uid": identity["file_uid"], "mode": identity["file_mode"], "nlink": identity["file_nlink"]},
            "launch_record": source[0]}
        meta_binding = m.new_bytes(destination / "remote-read.public.json", raw_json(metadata))
        receipt = {"status": "captured", "original_owner_closed_observed": True,
            "current_owner_identity_bound": not self.unbound, "raw_log": raw_binding,
            "remote_read_sha256": meta_binding["sha256"]}
        bound = m.new_bytes(destination / "result.public.json", raw_json(receipt))
        return {**bound, "receipt": receipt, "completed_within_original_read_deadline": not self.late}


def fixture(root):
    root.mkdir(mode=0o700)
    (root / "gets").mkdir(mode=0o700)
    (root / "logs").mkdir(mode=0o700)
    run = object.__new__(ModelRun)
    run.order, run.checkpoints = [], 0
    run._ri_root, run._ri_finalized = root, False
    run.nodes = [SimpleNamespace(node_id=i, alias="model" + str(i), root="/model/node" + str(i)) for i in (1, 2, 3)]
    run.foreground_sessions = {}
    run.report = {"owner_gate_qualified": True, "read_index_payload_observation_qualified": False,
                  "read_index_closed_logs": [], "replacement_qualified": False, "synthetic_control_only": True}
    run._ri_records, run._ri_groups = [], []
    run._ri_identities, run._owner_all_sessions = {}, {}
    rows, identities = {}, {}
    for node in run.nodes:
        launch, pid = "%032x" % node.node_id, 1000 + node.node_id
        identity = {"cwd_device": 10, "cwd_inode": 20 + node.node_id,
            "file_device": 10, "file_inode": 30 + node.node_id,
            "file_uid": os.geteuid(), "file_mode": 0o600, "file_nlink": 1}
        identities[launch] = identity
        body = {**identity, "observer_profile": "on", "limits": dict(m.logs.LIMITS)}
        rows[launch] = [record(launch, pid, "launch", body, 1)]
        run._ri_identities[launch] = {"target_pid": pid, "model_only": True}
        run._owner_all_sessions[launch] = SimpleNamespace(node=node, payload={"native_ha": True, "launch_id": launch})
    for phase, stage in enumerate(m.ORIGINAL_HISTORY_STAGES):
        leader = 1 if phase < 2 else 2
        for node in run.nodes:
            group = {"stage": stage, "node_id": node.node_id, "sequences": [], "history_sha256": "d" * 64,
                     "full_history_verified": True, "full_history_oracle_scope": "actual_original_openbao271_history"}
            for version in range(1, 20):
                sequence = len(run._ri_records) + 1
                launch, pid = "%032x" % node.node_id, 1000 + node.node_id
                directory = root / "gets" / ("get-%05d" % sequence)
                directory.mkdir(mode=0o700)
                entry = {"sequence": sequence, "stage": stage, "node_id": node.node_id, "launch_id": launch,
                    "status": 404 if version < 3 else 200, "payload_qualified": False, "version": version,
                    "independent_payload_correctness": version >= 3, "payload_oracle_scope": "pure_model_payload_oracle",
                    "expected_payload_sha256": "e" * 64}
                item = {"public": entry, "directory": directory}
                run._ri_records.append(item)
                group["sequences"].append(sequence)
                if version < 3:
                    continue
                attempt = "%032x" % sequence
                actual_event = event(node.node_id, leader, phase, (node.node_id, sequence))
                doc = {"v": 1, "phase": "pre_write", "process_id": pid, "attempt_id": attempt, "launch_id": launch,
                    "log_lost_before": 0, "log_writer_failed": False, "writer_completed": False,
                    "client_delivery_observed": False, "payload_binding_state": 1, "payload_bindings": [[1, 1, 200, True]],
                    "read_index": {"v": 1, "complete": True, "started": 1, "completed": 1, "dropped": 0,
                                   "collector_busy": False, "events": [compact(actual_event)]}}
                fields = [["X-HeptaBao-Read-Observation", "1," + launch + "," + attempt],
                          ["X-HeptaBao-Read-Index-Trace", base64.urlsafe_b64encode(raw_json(doc)).decode().rstrip("=")]]
                envelope = m.response.validate_envelope(fields, launch_id=launch, process_id=pid, node_id=node.node_id)
                payload = raw_json({"request_id": m.response.expected_response_request_id(attempt),
                                    "data": {"data": {"model": version}, "metadata": {"version": version}}})
                association = m.response.validate_payload_association(envelope, payload, response_status=200)
                wire = {"http_version": "HTTP/1.1", "status": 200, "peer_eof_observed": True,
                    "tls_close_notify_observed": True, "header_bytes": 100, "body_bytes": len(payload),
                    "http_plaintext_bytes": 100 + len(payload), "encoded_body_bytes": len(payload),
                    "response_framing": "content_length"}
                entry["response"] = m.new_bytes(directory / "response.private.json", payload)
                entry["wire"] = m.new_bytes(directory / "wire.public.json", raw_json(wire))
                item.update(envelope=envelope, wire=wire, association=association)
                terminal = {"attempt_id": attempt, "protocol": "http1", "http_status": 200,
                    "writer_outcome": "complete", "accepted_bytes": wire["http_plaintext_bytes"],
                    "flush_attempted": True, "elapsed_us": 200, "original_deadline_expired": False,
                    "client_delivery_observed": False, "header_complete": True,
                    "transcript": {"complete": True, "started": 1, "completed": 1, "dropped": 0,
                                   "events": [actual_event], "busy": False},
                    "payload_binding_state": 1, "payload_ordinal": 1, "accepted_byte_scope": "http1_plaintext"}
                rows[launch].append(record(launch, pid, "http_terminal", terminal, len(rows[launch]) + 1))
                if node.node_id != leader:
                    peer_launch, peer_pid = "%032x" % leader, 1000 + leader
                    peer = event(leader, leader, phase, (node.node_id, sequence), peer=True)
                    rows[peer_launch].append(record(peer_launch, peer_pid, "authenticated_peer_read_index", peer,
                                                   len(rows[peer_launch]) + 1))
            run._ri_groups.append(group)
    run._ri_collector = ModelCollector(run, rows, identities)
    return run, rows


def refusal(run, expected):
    try:
        run._ri_finish()
    except (m.Refusal, m.response.Refusal, m.logs.Refusal) as error:
        assert str(error) == expected, (expected, str(error))
    else:
        raise AssertionError("required integration refusal absent")
    assert run.report["read_index_payload_observation_qualified"] is False


def draft_closes_parent(root):
    assert m.DRAFT_ONLY is True and m.wire.DRAFT_ONLY is True
    try:
        ModelRun()
    except m.Refusal as error:
        assert str(error) == "readindex_live_extension_not_frozen"
    else:
        raise AssertionError("draft constructor admitted")
    assert ModelParent.constructor_calls == 0


def stop_and_other_requests_keep_parent_order(root):
    run = object.__new__(ModelRun)
    run.order = []
    run._ri_identity = lambda *_: (_ for _ in ()).throw(AssertionError("stop acquired observation first"))
    assert run.owned_process_action(None, "stop") == "model-parent-result"
    assert run.order == [("original_parent_action", "stop")]
    for method, path in (("POST", "oracle271/data/history"), ("GET", "sys/storage/raft/snapshot"),
                         ("GET", "other/data/history?version=19"), ("DELETE", "oracle271/data/history")):
        assert run.wire(None, method, path, {"original": True}, archive_in="original-in", archive_out="original-out") == "unchanged-model-parent-result"
    assert len(run.order) == 5


def complete_join(root):
    run, _ = fixture(root)
    assert run.cleanup() is True
    assert run.report["read_index_successful_payload_count"] == 204
    assert run.report["read_index_original_get_count"] == 228
    assert run.report["read_index_actual_leader_nodes"] == [1, 2]
    assert run.report["read_index_actual_reader_roles"] == ["follower", "leader"]
    assert run.order[0] == "original_parent_cleanup" and run.checkpoints == 1
    assert run.report["replacement_qualified"] is False


def missing_terminal(root):
    run, rows = fixture(root)
    launch = "%032x" % 1
    target = next(item for item in rows[launch] if item["kind"] == "http_terminal")
    rows[launch].remove(target)
    refusal(run, "original_http_terminal_missing_or_ambiguous")


def wrong_accepted_count(root):
    run, rows = fixture(root)
    target = next(item for item in rows["%032x" % 1] if item["kind"] == "http_terminal")
    target["body"]["accepted_bytes"] += 1
    refusal(run, "terminal_accepted_bytes_differ_from_actual_wire")


def unavailable_current_owner_binding(root):
    run, _ = fixture(root)
    run._ri_collector.unbound = True
    refusal(run, "original_closed_log_capture_unavailable_or_late")


def late_closed_capture(root):
    run, _ = fixture(root)
    run._ri_collector.late = True
    refusal(run, "original_closed_log_capture_unavailable_or_late")


def missing_original_history_group(root):
    run, _ = fixture(root)
    run._ri_groups[-1]["full_history_verified"] = False
    refusal(run, "readindex_original_history_coverage_missing_or_ambiguous")


def actual_leader_rpc_role_cannot_replace_local_read(root):
    run, _ = fixture(root)
    row = next(item for item in run._ri_records if item["public"]["status"] == 200)
    row["association"]["successful_witness"] = dict(row["association"]["successful_witness"], role="rpc_leader")
    refusal(run, "readindex_local_leader_policy_missing")


def report_fsync_late_refuses(root):
    run = object.__new__(ModelRun)
    run.order, run.checkpoints = [], 0
    run.report = {"read_index_payload_observation_qualified": False}
    def finish():
        run.report["read_index_payload_observation_qualified"] = True
        return time.monotonic() - 1
    run._ri_finish = finish
    assert run.cleanup() is False
    assert run.report["read_index_payload_observation_qualified"] is False
    assert run.report["read_index_failure_code"] == "readindex_final_report_fsync_collection_deadline"


CASES = (draft_closes_parent, stop_and_other_requests_keep_parent_order, complete_join,
         missing_terminal, wrong_accepted_count, unavailable_current_owner_binding,
         late_closed_capture, missing_original_history_group,
         actual_leader_rpc_role_cannot_replace_local_read, report_fsync_late_refuses)


def main():
    root = Path(sys.argv[1]).resolve()
    root.mkdir(mode=0o700)
    rows = []
    for function in CASES:
        row = {"case": function.__name__, "passed": False}
        rows.append(row)
        try:
            function(root / function.__name__)
            row["passed"] = True
        except BaseException as error:
            row.update(failure_type=type(error).__name__, failure=str(error))
    result = {"schema": "heptabao.history-extension-local-model-control.v1", "scope": __doc__,
        "required": len(CASES), "passed": sum(row["passed"] for row in rows), "cases": rows,
        "controller_sha256": digest(Path(__file__).read_bytes()),
        "extension_sha256": digest((HERE / "native_read_index_history_extension.py").read_bytes()),
        "products_started": False, "actual_remote_hosts_tested": False, "credentials_tested": False,
        "original128_executed": False, "physical_readindex_qualified": False,
        "replacement_qualified": False, "draft_entry_remains_closed": m.DRAFT_ONLY is True and m.wire.DRAFT_ONLY is True}
    path = root / "result.public.json"
    path.write_bytes(raw_json(result))
    print(json.dumps({"result": str(path), "result_sha256": digest(path.read_bytes()),
                      "passed": result["passed"], "required": result["required"], "product_qualification": False}))
    return 0 if result["passed"] == result["required"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
