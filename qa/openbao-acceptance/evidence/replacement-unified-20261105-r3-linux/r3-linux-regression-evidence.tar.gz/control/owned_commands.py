#!/usr/bin/env python3
"""Own one command group through its original wait, with Linux wait4 metrics."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time

PENDING_SIGNAL = None

def _signal(signum, frame):
    global PENDING_SIGNAL
    PENDING_SIGNAL = signum

for _sig in (signal.SIGINT, signal.SIGTERM):
    signal.signal(_sig, _signal)

def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f, "sha256").hexdigest()

def write_new(path, value):
    path = Path(path)
    with path.open("x") as f:
        json.dump(value, f, sort_keys=True, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def remaining_group(pgid):
    raw = subprocess.check_output(
        ["/bin/ps", "-axo", "pid=,ppid=,pgid=,stat="], text=True, timeout=10)
    records = []
    for line in raw.splitlines():
        parts = line.split()
        if len(parts) == 4 and int(parts[2]) == pgid:
            records.append({"pid": int(parts[0]), "ppid": int(parts[1]),
                            "pgid": int(parts[2]), "state": parts[3]})
    return records

class Commands:
    def __init__(self, output, cwd, env):
        self.output = Path(output)
        self.cwd = Path(cwd)
        self.env = dict(env)
        self.records = []

    def run(self, label, argv, cap_seconds, *, cwd=None):
        assert PENDING_SIGNAL is None, "cancelled before command"
        assert label.replace("-", "").replace("_", "").isalnum()
        started = time.monotonic()
        timed_out = False
        term_at = None
        killed = False
        with (self.output / (label + ".stdout")).open("xb") as out, \
             (self.output / (label + ".stderr")).open("xb") as err:
            p = subprocess.Popen(
                argv, cwd=str(cwd or self.cwd), env=self.env,
                stdin=subprocess.DEVNULL, stdout=out, stderr=err,
                start_new_session=True)
            while True:
                waited, status, usage = os.wait4(p.pid, os.WNOHANG)
                if waited == p.pid:
                    p.returncode = os.waitstatus_to_exitcode(status)
                    break
                now = time.monotonic()
                timed_out = timed_out or now - started >= cap_seconds
                if (timed_out or PENDING_SIGNAL is not None) and term_at is None:
                    # The original child has not been reaped, so its PID cannot recycle.
                    try:
                        os.killpg(p.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
                    term_at = now
                if term_at is not None and now - term_at >= 5 and not killed:
                    try:
                        os.killpg(p.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    killed = True
                time.sleep(0.20)
            out.flush()
            err.flush()
            os.fsync(out.fileno())
            os.fsync(err.fileno())
        record = {
            "label": label, "argv": list(argv), "cwd": str(cwd or self.cwd),
            "exit_code": p.returncode, "direct_child_reaped": True,
            "owned_pgid": p.pid, "remaining": remaining_group(p.pid),
            "elapsed_seconds": time.monotonic() - started,
            "cap_seconds": cap_seconds, "timed_out": timed_out,
            "cancelled_by_signal": PENDING_SIGNAL,
            "resource_usage": {
                "user_seconds": usage.ru_utime,
                "system_seconds": usage.ru_stime,
                "max_rss_kib": usage.ru_maxrss,
                "minor_page_faults": usage.ru_minflt,
                "major_page_faults": usage.ru_majflt,
                "voluntary_context_switches": usage.ru_nvcsw,
                "involuntary_context_switches": usage.ru_nivcsw,
                "scope": "Linux wait4 of original child, including descendants reaped by it; max_rss is largest process RSS, not summed simultaneous group RSS",
            },
            "stdout_sha256": sha(self.output / (label + ".stdout")),
            "stderr_sha256": sha(self.output / (label + ".stderr")),
        }
        self.records.append(record)
        write_new(self.output / (label + ".public.json"), record)
        assert record["exit_code"] == 0, label + ": nonzero original child exit"
        assert not record["timed_out"] and record["cancelled_by_signal"] is None, label + ": timeout/cancel"
        assert not record["remaining"], label + ": surviving owned group"
        return record
