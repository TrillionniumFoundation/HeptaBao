#!/usr/bin/env python3
"""Build one frozen unified candidate; retain binaries only after original Cargo exits."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import owned_commands
from owned_commands import Commands, sha, write_new

os.umask(0o077)
p = argparse.ArgumentParser()
p.add_argument("--commit", required=True)
p.add_argument("--tree", required=True)
p.add_argument("--prior-terminal-receipt", required=True)
p.add_argument("--prior-terminal-receipt-sha256", required=True)
a = p.parse_args()
assert re.fullmatch("[0-9a-f]{40}", a.commit)
assert re.fullmatch("[0-9a-f]{40}", a.tree)
assert a.commit not in ("df026fe323dd7cf0f0ec57d7d2d9c5a79897053c", "9208e0765f566f3bd7908e6567d2e39008156b9b")
root = Path("/home/qian-qi/heptabao-replacement-unified-20261105-r3")
source, output, target = root / "source", root / "normal-release-r1", root / "target"
prior = Path("/home/qian-qi/heptabao-replacement-unified-20261105-r1")
prior_target = prior / "target"
cargo_home = Path("/home/qian-qi/heptabao-native-20261029-c1bd-r1/cargo-home")
toolchain = Path("/home/qian-qi/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin")
assert os.uname().sysname == "Linux" and os.uname().machine == "x86_64"
assert root.is_dir() and not root.is_symlink()
assert source.is_dir() and not source.is_symlink()
assert not output.exists() and not target.exists()
assert cargo_home.is_dir() and toolchain.is_dir()
assert sha(a.prior_terminal_receipt) == a.prior_terminal_receipt_sha256
authority = json.loads(Path(a.prior_terminal_receipt).read_text())
assert authority["job_id"] == "1a1aa2cb2b5-fc05-3eae"
assert authority["state"] == "succeeded" and authority["exit_code"] == 0
assert authority.get("state") in ("succeeded", "failed")
assert type(authority.get("exit_code")) is int
assert authority.get("terminal_publication_confirmed") is True
assert authority.get("terminal_publication_protocol") == 1
assert authority.get("output_complete") is True and authority.get("output_durable") is True
assert all(v is None for v in authority.get("log_errors", {}).values())
assert not any(authority.get("log_truncated", {}).values())
stage_path = root / "source-stage-r1/result.public.json"
stage = json.loads(stage_path.read_text())
assert stage["status"] == "passed" and stage["commit"] == a.commit and stage["tree"] == a.tree
prior_result_path = prior / "regression-aggregate-r1/result.public.json"
assert sha(prior_result_path) == "6804101a1d42b186f1a082e2f9f7d12a58b1ca3dddd0019f74926d0e979d2c5e"
prior_result = json.loads(prior_result_path.read_text())
assert prior_result["source_commit"] == "9208e0765f566f3bd7908e6567d2e39008156b9b"
assert prior_result["expected"] == prior_result["attempted_once"] == 176
assert prior_result["full_denominator_retained"] and prior_result["source_clean_after"]
assert prior_result["status"] == "failed" and prior_result["failed"] == 2
for suite in prior_result["suites"].values():
    assert suite["all_owned_groups_empty"] and suite["source_unchanged"] and suite["binary_unchanged"]
    authority_path = Path(suite["executor"]["path"])
    assert sha(authority_path) == suite["executor"]["sha256"]
    terminal = json.loads(authority_path.read_text())
    assert terminal["terminal_publication_confirmed"] and terminal["output_complete"] and terminal["output_durable"]
    assert terminal["exit_code"] == suite["executor"]["exit_code"]
space_path = root / "control/cache-space-r1/result.public.json"
assert sha(space_path) == "fc90351cd677312b88ed7362e027c12203f31db5fd8529257fb640273628fa22"
space = json.loads(space_path.read_text())
assert space["space_gate_passed"] is True and space["reflink_supported"] is False
assert prior_target.stat().st_dev == root.stat().st_dev
remaining_space_budget = space["required_free_bytes"] - space["reserve_bytes"]["fresh_checkout"]
assert shutil.disk_usage(root).free >= remaining_space_budget, "new checkout changed original capacity admission"
assert shutil.disk_usage(root).free >= 8 * 1024**3, "insufficient capacity for isolated cache/build"
output.mkdir(mode=0o700)
profile = {
    "PATH": str(toolchain) + ":/usr/bin:/bin",
    "CARGO_HOME": str(cargo_home), "CARGO_TARGET_DIR": str(target),
    "CARGO_BUILD_JOBS": "1", "CARGO_PROFILE_RELEASE_OPT_LEVEL": "3",
    "CARGO_PROFILE_RELEASE_CODEGEN_UNITS": "16", "CARGO_PROFILE_RELEASE_LTO": "false",
    "CARGO_PROFILE_RELEASE_DEBUG": "0", "CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS": "true",
    "CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS": "true", "CARGO_PROFILE_RELEASE_PANIC": "unwind",
    "RUSTFLAGS": "", "CARGO_TERM_COLOR": "never",
}
env = dict(os.environ)
env.update(profile)
env.pop("CARGO_ENCODED_RUSTFLAGS", None)
commands = Commands(output, source, env)
def git(*args):
    return subprocess.check_output(["/usr/bin/git", "-C", str(source), *args],
                                   text=True, timeout=30).strip()
def freeze():
    return {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain"), "cargo_lock_sha256": sha(source / "Cargo.lock")}
before = freeze()
assert before == {"commit": a.commit, "tree": a.tree, "status": "",
                  "cargo_lock_sha256": stage["cargo_lock_sha256"]}
result = {
    "schema": "heptabao.unified-linux-release-controller.v1",
    "status": "failed", "source_commit": a.commit, "source_tree": a.tree,
    "source_stage_sha256": sha(stage_path), "source_before": before,
    "profile": profile, "normal_default_features": True, "fixture_features": [],
    "production_changed": False, "traffic_cutover": False,
    "started_ns": time.time_ns(), "controller_sha256": sha(__file__),
    "commands_helper_sha256": sha(Path(__file__).with_name("owned_commands.py")),
    "prior_executor_terminal_receipt": str(a.prior_terminal_receipt),
    "prior_executor_terminal_receipt_sha256": a.prior_terminal_receipt_sha256,
    "prior_regression_status": prior_result["status"],
    "prior_candidate_qualification_borrowed": False,
    "prior_regression_result_path": str(prior_result_path),
    "prior_regression_result_sha256": sha(prior_result_path),
    "cache_source": str(prior_target), "cache_destination": str(target),
    "space_admission_receipt_sha256": sha(space_path),
    "required_remaining_space_bytes": remaining_space_budget,
    "cache_copy_mechanism": "explicit cp --reflink=never; independent files",
    "cache_scope": "warm dependency cache copied to independent target after prior executor and owned commands terminated; no hardlinks to prior target; internal hardlink topology may be preserved",
    "executor_cgroup": Path("/proc/self/cgroup").read_text().strip(),
}
write_new(output / "intent.public.json", result)
try:
    # Snapshot an idle Cargo target under its existing lock; never compete for it.
    with (prior_target / "release/.cargo-lock").open("rb") as cargo_lock:
        fcntl.flock(cargo_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        copied = commands.run("copy-idle-target-cache",
            ["/bin/cp", "-a", "--reflink=never", "--", str(prior_target), str(target)], 300)
        fcntl.flock(cargo_lock, fcntl.LOCK_UN)
    assert target.is_dir() and not target.is_symlink()
    assert (target / "release/.cargo-lock").stat().st_ino != (prior_target / "release/.cargo-lock").stat().st_ino
    result["cache_copy"] = copied
    rustc = subprocess.check_output([str(toolchain / "rustc"), "-vV"], text=True, timeout=30)
    assert "release: 1.98.0" in rustc and "host: x86_64-unknown-linux-gnu" in rustc
    assert "88d9e12ae178fab0fb5cc050a94da85685d449ea" in rustc
    result["rustc_vv"] = rustc
    command = [str(toolchain / "cargo"), "build", "--release", "--locked", "--offline",
               "-p", "heptabao-server", "--bin", "heptabao-server",
               "--bin", "heptabao-seed", "--message-format=json-render-diagnostics"]
    build = commands.run("normal-release-build", command, 1800)
    result["build"] = build
    assert owned_commands.PENDING_SIGNAL is None
    assert freeze() == before
    events = []
    for line in (output / "normal-release-build.stdout").read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    finishes = [e for e in events if e.get("reason") == "build-finished"]
    assert len(finishes) == 1 and finishes[0].get("success") is True
    artifact_dir = output / "artifacts"
    artifact_dir.mkdir(mode=0o700)
    artifacts = {}
    for name in ("heptabao-server", "heptabao-seed"):
        matching = [e for e in events if e.get("reason") == "compiler-artifact"
                    and e.get("target", {}).get("name") == name and e.get("executable")]
        assert len(matching) == 1
        event = matching[0]
        assert sorted(event["features"]) == ["default", "native-v6-ha", "native-v6-storage"]
        assert event["profile"] == {"opt_level": "3", "debuginfo": 0,
            "debug_assertions": True, "overflow_checks": True, "test": False}
        original = Path(event["executable"])
        assert original.is_file() and not original.is_symlink()
        assert original.resolve().is_relative_to(target.resolve())
        digest = sha(original)
        retained = artifact_dir / name
        with original.open("rb") as src, retained.open("xb") as dst:
            shutil.copyfileobj(src, dst, 1024 * 1024)
            dst.flush()
            os.fsync(dst.fileno())
        retained.chmod(0o500)
        assert sha(retained) == digest and sha(original) == digest
        artifacts[name] = {
            "path": str(retained), "sha256": digest, "bytes": retained.stat().st_size,
            "compiler_executable": str(original), "features": event["features"],
            "profile": event["profile"], "fresh": event.get("fresh"),
        }
    fd = os.open(artifact_dir, os.O_RDONLY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    assert owned_commands.PENDING_SIGNAL is None
    assert freeze() == before
    release_result = {
        "schema": "heptabao.native-default-build-result.v1",
        "normal_default_candidate": True, "formal_qualification": False,
        "source_commit": a.commit, "source_tree": a.tree, "source_freeze_verified": True,
        "native_abi": "x86_64-unknown-linux-gnu", "build_exit_code": 0,
        "build_finished_success": True, "timed_out": False,
        "owned_group_survivors_after_wait": False,
        "elapsed_seconds": build["elapsed_seconds"], "resource_usage": build["resource_usage"],
        "command": command, "rustc_vv": rustc,
        "build_driver_path": __file__, "build_driver_sha256": sha(__file__),
        "commands_helper_sha256": result["commands_helper_sha256"],
        "cargo_events_sha256": build["stdout_sha256"],
        "cargo_stderr_sha256": build["stderr_sha256"],
        "requested_release_profile": {k:v for k,v in profile.items() if k.startswith("CARGO_PROFILE_RELEASE_")},
        "cache_scope": result["cache_scope"],
        "artifacts": artifacts,
    }
    write_new(output / "normal-release-result.public.json", release_result)
    native_receipt = {
        "schema": "heptabao.native-build.v1", "source_commit": a.commit,
        "source_tree": a.tree, "source_freeze_verified": True,
        "native_abi": "x86_64-unknown-linux-gnu", "build_exit_code": 0,
        "binary_sha256": artifacts["heptabao-server"]["sha256"],
        "features": artifacts["heptabao-server"]["features"],
        "provenance": {
            "result_path": str(output / "normal-release-result.public.json"),
            "result_sha256": sha(output / "normal-release-result.public.json"),
            "cargo_events_sha256": build["stdout_sha256"],
        },
    }
    write_new(output / "native-build.public.json", native_receipt)
    result["release_artifacts"] = artifacts
    result["native_build_receipt_sha256"] = sha(output / "native-build.public.json")
    result["source_after"] = freeze()
    result["status"] = "passed"
except BaseException as exc:
    result["failure_type"] = type(exc).__name__
    result["failure"] = str(exc)
finally:
    result["commands"] = commands.records
    result["terminal_ns"] = time.time_ns()
    write_new(output / "result.public.json", result)
    print(json.dumps({"status": result["status"],
                      "source_commit": a.commit, "source_tree": a.tree,
                      "result_path": str(output / "result.public.json"),
                      "result_sha256": sha(output / "result.public.json"),
                      "production_changed": False}), flush=True)
raise SystemExit(0 if result["status"] == "passed" else 1)
