#!/usr/bin/env python3
"""Verify an exact Git bundle after the preserved bounded HTTPS acquisition failed."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import time
from owned_commands import Commands, sha, write_new

os.umask(0o077)
p = argparse.ArgumentParser()
p.add_argument("--bundle", required=True)
p.add_argument("--bundle-sha256", required=True)
a = p.parse_args()
root = Path("/home/qian-qi/heptabao-replacement-unified-20261105-r3")
source = root / "source"
output = root / "source-stage-bundle-r1"
commit = "6b16a9292d046bbc42aec65045fa105aaa1ac5de"
tree = "0de9c516e94a47cb89e2e0f5ac2146e60913cfef"
parent = "9208e0765f566f3bd7908e6567d2e39008156b9b"
bundle = Path(a.bundle)
assert bundle.is_absolute() and bundle.is_file() and not bundle.is_symlink()
assert bundle.resolve().is_relative_to((root / "control").resolve())
assert re.fullmatch("[0-9a-f]{64}", a.bundle_sha256)
assert sha(bundle) == a.bundle_sha256
old = root / "source-stage-r1/result.public.json"
assert sha(old) == "f46a47be73a5aa92bee9b394242febe6f26dc0dc9ee4c1feca433947d9d9d24f"
old_result = json.loads(old.read_text())
assert old_result["status"] == "failed" and old_result["commit"] == commit and old_result["tree"] == tree
assert old_result["independent_git_objects"] is True
assert all(c["direct_child_reaped"] and not c["remaining"] for c in old_result["commands"])
last = old_result["commands"][-1]
assert last["label"] == "fetch-published-ref" and last["timed_out"] is True and last["cap_seconds"] == 180
assert source.is_dir() and not source.is_symlink()
assert {p.name for p in source.iterdir()} == {".git"}, "unexpected files in the owned no-checkout clone"
assert not (source / ".git/objects/info/alternates").exists()
output.mkdir(mode=0o700)
env = dict(os.environ)
env["GIT_TERMINAL_PROMPT"] = "0"
commands = Commands(output, source, env)
def git(*args):
    return subprocess.check_output(["/usr/bin/git", "-C", str(source), *args], text=True, timeout=30).strip()
assert git("rev-parse", "HEAD") == parent
result = {
    "schema": "heptabao.unified-linux-source-stage.v1",
    "status": "failed", "commit": commit, "tree": tree,
    "source": str(source), "independent_git_objects": True,
    "required_parents": [parent], "acquisition": "verified Git bundle from independently frozen Mac tree after bounded HTTPS timeout",
    "prior_failed_https_receipt_path": str(old), "prior_failed_https_receipt_sha256": sha(old),
    "bundle_path": str(bundle), "bundle_sha256": a.bundle_sha256,
    "controller_sha256": sha(__file__), "commands_helper_sha256": sha(Path(__file__).with_name("owned_commands.py")),
    "production_changed": False, "started_ns": time.time_ns(),
}
write_new(output / "intent.public.json", result)
try:
    commands.run("verify-git-bundle", ["/usr/bin/git", "-C", str(source), "bundle", "verify", str(bundle)], 30)
    heads = git("bundle", "list-heads", str(bundle)).splitlines()
    assert heads == [commit + " HEAD"], "bundle head differs from published frozen commit"
    result["bundle_heads"] = heads
    commands.run("fetch-exact-bundle", ["/usr/bin/git", "-C", str(source), "fetch", "--no-tags", str(bundle), "HEAD"], 180)
    assert git("rev-parse", "FETCH_HEAD^{commit}") == commit
    commands.run("checkout-exact", ["/usr/bin/git", "-C", str(source), "checkout", "--detach", commit], 30)
    assert git("rev-parse", "HEAD") == commit and git("rev-parse", "HEAD^{tree}") == tree
    assert git("status", "--porcelain") == ""
    commands.run("verify-required-parent", ["/usr/bin/git", "-C", str(source), "merge-base", "--is-ancestor", parent, commit], 30)
    commands.run("fsck-exact", ["/usr/bin/git", "-C", str(source), "fsck", "--connectivity-only", "--no-dangling"], 120)
    assert sha(bundle) == a.bundle_sha256 and sha(old) == result["prior_failed_https_receipt_sha256"]
    result["cargo_lock_sha256"] = sha(source / "Cargo.lock")
    result["instruction_paths"] = [path for path in git("ls-files").splitlines() if Path(path).name == "AGENTS.md"]
    result["source_clean"] = True
    result["status"] = "passed"
except BaseException as exc:
    result["failure_type"] = type(exc).__name__
    result["failure"] = str(exc)
finally:
    result["commands"] = commands.records
    result["terminal_ns"] = time.time_ns()
    write_new(output / "result.public.json", result)
    print(json.dumps({"status": result["status"], "commit": commit, "tree": tree,
        "result_path": str(output / "result.public.json"), "result_sha256": sha(output / "result.public.json")}), flush=True)
raise SystemExit(0 if result["status"] == "passed" else 1)
