#!/usr/bin/env python3
"""Build both normal native libtests from the published unified source, under one 1800s pool."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import owned_commands
from owned_commands import Commands, sha, write_new

os.umask(0o077)
parser = argparse.ArgumentParser()
parser.add_argument("--commit", required=True)
parser.add_argument("--tree", required=True)
parser.add_argument("--release-executor-job-id", required=True)
parser.add_argument("--server-manifest-sha256", required=True)
parser.add_argument("--ha-manifest-sha256", required=True)
parser.add_argument("--release-executor-receipt", required=True)
parser.add_argument("--release-executor-receipt-sha256", required=True)
a = parser.parse_args()
ROOT = Path("/home/qian-qi/heptabao-replacement-unified-20261105-r3")
COMMIT, TREE = a.commit, a.tree
assert re.fullmatch("[0-9a-f]{40}", COMMIT) and re.fullmatch("[0-9a-f]{40}", TREE)
assert COMMIT not in ("9208e0765f566f3bd7908e6567d2e39008156b9b", "df026fe323dd7cf0f0ec57d7d2d9c5a79897053c")
assert re.fullmatch("[0-9a-f-]+", a.release_executor_job_id)
assert re.fullmatch("[0-9a-f]{64}", a.server_manifest_sha256)
assert re.fullmatch("[0-9a-f]{64}", a.ha_manifest_sha256)
SOURCE, TARGET = ROOT / "source", ROOT / "target"
OUTPUT = ROOT / "libtest-build-r1"
RELEASE = ROOT / "normal-release-r1"
toolchain = Path("/home/qian-qi/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin")
assert os.uname().sysname == "Linux" and os.uname().machine == "x86_64"
assert not OUTPUT.exists()
assert sha(a.release_executor_receipt) == a.release_executor_receipt_sha256
authority = json.loads(Path(a.release_executor_receipt).read_text())
assert authority["job_id"] == a.release_executor_job_id
assert authority["state"] == "succeeded" and authority["exit_code"] == 0
assert authority["terminal_publication_confirmed"] and authority["output_complete"] and authority["output_durable"]
release_result = json.loads((RELEASE / "result.public.json").read_text())
assert release_result["status"] == "passed"
assert release_result["source_commit"] == COMMIT and release_result["source_tree"] == TREE
assert release_result["build"]["exit_code"] == 0 and release_result["build"]["direct_child_reaped"]
assert not release_result["build"]["timed_out"] and not release_result["build"]["remaining"]
profile = release_result["profile"]
assert profile["CARGO_TARGET_DIR"] == str(TARGET)
assert profile["CARGO_PROFILE_RELEASE_OPT_LEVEL"] == "3"
assert profile["CARGO_PROFILE_RELEASE_CODEGEN_UNITS"] == "16"
assert profile["CARGO_PROFILE_RELEASE_LTO"] == "false"
assert profile["CARGO_PROFILE_RELEASE_DEBUG"] == "0"
assert profile["CARGO_PROFILE_RELEASE_DEBUG_ASSERTIONS"] == "true"
assert profile["CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS"] == "true"
assert profile["CARGO_PROFILE_RELEASE_PANIC"] == "unwind"
assert profile["CARGO_BUILD_JOBS"] == "1"
manifests = {
    "server-regression-manifest.public.json": a.server_manifest_sha256,
    "ha-regression-manifest.public.json": a.ha_manifest_sha256,
}
for name, digest in manifests.items():
    path = ROOT / "control" / name
    assert sha(path) == digest
    m = json.loads(path.read_text())
    assert m["source_commit"] == COMMIT and m["source_tree"] == TREE
    for f in m["source_files"]:
        assert sha(SOURCE / f["path"]) == f["sha256"]

def git(*args):
    return subprocess.check_output(["/usr/bin/git", "-C", str(SOURCE), *args],
                                   text=True, timeout=30).strip()
def freeze():
    return {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain"),
            "cargo_lock_sha256": sha(SOURCE / "Cargo.lock")}
before = freeze()
assert before == release_result["source_after"]
assert all(sha(v["path"]) == v["sha256"] for v in release_result["release_artifacts"].values())
with (TARGET / "release/.cargo-lock").open("rb") as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    fcntl.flock(lock, fcntl.LOCK_UN)
OUTPUT.mkdir(mode=0o700)
env = dict(os.environ)
env.update(profile)
env.pop("CARGO_ENCODED_RUSTFLAGS", None)
commands = Commands(OUTPUT, SOURCE, env)
result = {
    "schema": "heptabao.unified-linux-libtest-build.v1",
    "status": "failed", "source_commit": COMMIT, "source_tree": TREE,
    "source_before": before, "source_unchanged": False,
    "profile": profile, "production_changed": False, "traffic_cutover": False,
    "controller_sha256": sha(__file__),
    "commands_helper_sha256": sha(Path(__file__).with_name("owned_commands.py")),
    "release_result_sha256": sha(RELEASE / "result.public.json"),
    "artifacts": release_result["release_artifacts"],
    "normal_release_result_path": str(RELEASE / "result.public.json"),
    "release_executor_receipt_sha256": a.release_executor_receipt_sha256,
    "manifest_sha256": manifests, "shared_libtest_build_cap_seconds": 1800,
    "started_ns": time.time_ns(),
    "executor_cgroup": Path("/proc/self/cgroup").read_text().strip(),
}
write_new(OUTPUT / "intent.public.json", result)
started = time.monotonic()
deadline = started + 1800

def build_library(label, crate, target_name, expected_features, extra):
    remaining = deadline - time.monotonic()
    assert remaining > 0, "original shared 1800s libtest build pool exhausted"
    argv = [str(toolchain / "cargo"), "test", "--release", "--locked", "--offline",
            "-p", crate, *extra, "--lib", "--no-run", "--message-format=json-render-diagnostics"]
    call = commands.run(label, argv, remaining)
    assert owned_commands.PENDING_SIGNAL is None and freeze() == before
    events = []
    for line in (OUTPUT / (label + ".stdout")).read_text().splitlines():
        try:
            events.append(json.loads(line))
        except json.JSONDecodeError:
            pass
    finished = [e for e in events if e.get("reason") == "build-finished"]
    assert len(finished) == 1 and finished[0].get("success") is True
    matches = [e for e in events if e.get("reason") == "compiler-artifact"
               and e.get("target", {}).get("name") == target_name
               and e.get("profile", {}).get("test") is True and e.get("executable")]
    assert len(matches) == 1
    event = matches[0]
    assert sorted(event["features"]) == expected_features
    assert event["profile"] == {"opt_level": "3", "debuginfo": 0,
        "debug_assertions": True, "overflow_checks": True, "test": True}
    original = Path(event["executable"])
    assert original.is_file() and not original.is_symlink()
    assert original.resolve().is_relative_to(TARGET.resolve())
    digest = sha(original)
    retained = OUTPUT / ("retained-" + crate + "-libtest")
    with original.open("rb") as src, retained.open("xb") as dst:
        shutil.copyfileobj(src, dst, 1024 * 1024)
        dst.flush()
        os.fsync(dst.fileno())
    retained.chmod(0o500)
    assert sha(retained) == digest and sha(original) == digest
    artifact = {
        "path": str(retained), "sha256": digest, "bytes": retained.stat().st_size,
        "compiler_executable": str(original), "features": event["features"],
        "profile": event["profile"], "fresh": event.get("fresh"),
        "cargo_events_sha256": call["stdout_sha256"],
    }
    return call, artifact

try:
    call, artifact = build_library("server-libtest-build", "heptabao-server", "heptabao_server",
        ["default", "native-v6-ha", "native-v6-storage"], [])
    result["libtest_build"] = call
    result["libtest_artifact"] = artifact
    print(json.dumps({"phase": "server-libtest-built", "artifact": artifact}), flush=True)
    call, artifact = build_library("ha-libtest-build", "heptabao-ha-service", "heptabao_ha_service",
        ["default", "native-v6-peer-ingress"], ["--features", "native-v6-peer-ingress"])
    result["ha_libtest_build"] = call
    result["ha_libtest_artifact"] = artifact
    assert time.monotonic() < deadline
    assert freeze() == before and owned_commands.PENDING_SIGNAL is None
    assert all(sha(v["path"]) == v["sha256"] for v in release_result["release_artifacts"].values())
    assert sha(result["libtest_artifact"]["path"]) == result["libtest_artifact"]["sha256"]
    assert sha(result["ha_libtest_artifact"]["path"]) == result["ha_libtest_artifact"]["sha256"]
    result["source_after"] = freeze()
    result["source_unchanged"] = True
    result["release_artifacts_unchanged"] = True
    result["status"] = "built"
except BaseException as exc:
    result["failure_type"] = type(exc).__name__
    result["failure"] = str(exc)
finally:
    result["commands"] = commands.records
    result["elapsed_seconds"] = time.monotonic() - started
    result["terminal_ns"] = time.time_ns()
    write_new(OUTPUT / "build-result.public.json", result)
    print(json.dumps({"status": result["status"], "source_commit": COMMIT,
        "source_tree": TREE, "result": str(OUTPUT / "build-result.public.json"),
        "result_sha256": sha(OUTPUT / "build-result.public.json")}), flush=True)
raise SystemExit(0 if result["status"] == "built" else 1)
