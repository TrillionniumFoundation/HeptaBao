#!/usr/bin/env python3
"""Create an independent source checkout at one exact published commit/tree."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import time
from owned_commands import Commands, sha, write_new

os.umask(0o077)
p = argparse.ArgumentParser()
p.add_argument("--commit", required=True)
p.add_argument("--tree", required=True)
p.add_argument("--remote-ref", required=True)
p.add_argument("--required-parent", action="append", default=[])
a = p.parse_args()
assert re.fullmatch("[0-9a-f]{40}", a.commit)
assert re.fullmatch("[0-9a-f]{40}", a.tree)
assert a.commit not in ("df026fe323dd7cf0f0ec57d7d2d9c5a79897053c", "9208e0765f566f3bd7908e6567d2e39008156b9b"), "do not rerun old candidates"
assert re.fullmatch("refs/heads/[A-Za-z0-9._/-]+", a.remote_ref), "explicit branch required"
assert all(re.fullmatch("[0-9a-f]{40}", s) for s in a.required_parent)
root = Path("/home/qian-qi/heptabao-replacement-unified-20261105-r3")
base = Path("/home/qian-qi/heptabao-replacement-unified-20261105-r1/source")
source = root / "source"
output = root / "source-stage-r1"
assert root.is_dir() and not root.is_symlink()
assert base.is_dir() and not base.is_symlink()
assert not source.exists() and not source.is_symlink()
output.mkdir(mode=0o700)
env = dict(os.environ)
env["GIT_TERMINAL_PROMPT"] = "0"
for key in ("GIT_TRACE", "GIT_TRACE_CURL", "GIT_TRACE_PACKET", "GIT_CURL_VERBOSE"):
    env.pop(key, None)
cmd = Commands(output, root, env)
result = {
    "schema": "heptabao.unified-linux-source-stage.v1",
    "status": "failed", "commit": a.commit, "tree": a.tree,
    "remote": "https://github.com/TrillionniumFoundation/HeptaBao.git",
    "remote_ref": a.remote_ref, "source": str(source),
    "base_source": str(base), "independent_git_objects": True,
    "required_parents": a.required_parent, "production_changed": False,
    "started_ns": time.time_ns(), "controller_sha256": sha(__file__),
    "commands_helper_sha256": sha(Path(__file__).with_name("owned_commands.py")),
}
write_new(output / "intent.public.json", result)
def read_git(*args):
    return subprocess.check_output(
        ["/usr/bin/git", "-C", str(source), *args],
        text=True, timeout=30).strip()
try:
    cmd.run("clone-local-independent",
            ["/usr/bin/git", "clone", "--no-hardlinks", "--no-checkout",
             str(base), str(source)], 180)
    cmd.run("set-published-origin",
            ["/usr/bin/git", "-C", str(source), "remote", "set-url", "origin", result["remote"]], 30)
    cmd.run("fetch-published-ref",
            ["/usr/bin/git", "-C", str(source), "fetch", "--no-tags", "origin", a.remote_ref], 180)
    result["fetched_head"] = read_git("rev-parse", "FETCH_HEAD^{commit}")
    cmd.run("verify-published-ancestry",
            ["/usr/bin/git", "-C", str(source), "merge-base", "--is-ancestor", a.commit, "FETCH_HEAD"], 30)
    cmd.run("checkout-exact",
            ["/usr/bin/git", "-C", str(source), "checkout", "--detach", a.commit], 30)
    assert read_git("rev-parse", "HEAD") == a.commit
    assert read_git("rev-parse", "HEAD^{tree}") == a.tree
    assert read_git("status", "--porcelain") == ""
    for i, parent in enumerate(a.required_parent):
        cmd.run("verify-parent-" + str(i),
                ["/usr/bin/git", "-C", str(source), "merge-base", "--is-ancestor", parent, a.commit], 30)
    cmd.run("fsck-exact", ["/usr/bin/git", "-C", str(source), "fsck", "--connectivity-only", "--no-dangling"], 120)
    result["cargo_lock_sha256"] = sha(source / "Cargo.lock")
    result["source_clean"] = True
    tracked = read_git("ls-files").splitlines()
    result["instruction_paths"] = [s for s in tracked if Path(s).name == "AGENTS.md"]
    result["status"] = "passed"
except BaseException as exc:
    result["failure_type"] = type(exc).__name__
    result["failure"] = str(exc)
finally:
    result["commands"] = cmd.records
    result["terminal_ns"] = time.time_ns()
    write_new(output / "result.public.json", result)
    print(json.dumps({k: result[k] for k in ("status", "commit", "tree", "source")}), flush=True)
    print(json.dumps({"result_path": str(output / "result.public.json"),
                      "result_sha256": sha(output / "result.public.json")}), flush=True)
raise SystemExit(0 if result["status"] == "passed" else 1)
