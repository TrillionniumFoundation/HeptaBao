#!/usr/bin/env python3
"""Package immutable, public synthetic R3 evidence; never run a product or qualification test."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tarfile

ROOT = Path("/home/qian-qi/heptabao-replacement-unified-20261105-r3")
SOURCE = ROOT / "source"
PUBLIC = Path("/run/media/qian-qi/TOSHIBA_DEV_1TB/heptabao-r3-linux-public-evidence-20261105-r1")
R1 = Path("/home/qian-qi/heptabao-replacement-unified-20261105-r1")
REFERENCE_MAC_PACKAGER_SHA256 = "4bca620492b045539fe67f267a41e2130d98abbe6d46bf9fe6c9389050b38366"
COMMIT = "6b16a9292d046bbc42aec65045fa105aaa1ac5de"
TREE = "0de9c516e94a47cb89e2e0f5ac2146e60913cfef"
REFERENCE_MAC_POLICY_SHA256 = "aa8485b9677c9a8c06532d0fde9182c5ce1cf980daeb6bac0689c08b594a929b"
PINS = {
    "normal-release-r1/result.public.json": "a97dd5ff24a2d3e9d5d908f295ea73c44a421649c15dfd6e28461c5038006107",
    "normal-release-r1/native-build.public.json": "2b3d2d02092da7c234fd69a2c766368c482cc3aba55e45462ee39c95a8b713c9",
    "libtest-build-r1/build-result.public.json": "5a4d4bf27afaa684bc5dc954dc5f8c722137080b726b40b0d4b9b036d47e331a",
    "server-regressions-r1/result.public.json": "33a2ee0427b61770c7531d5c3c45973dafa40b8cbb28eee06cb810769ab2c641",
    "ha-regressions-r1/result.public.json": "ac51b0ed2f26ff151507319c45f668b38484c21bba8f68af35ff6511a0c3b828",
    "regression-r1/result.public.json": "64e2b5cc57005ceb8a6c24cd8ca1033b4fc3c3e7a28236804123a39882cd00f5",
    "source-stage-r1/result.public.json": "f46a47be73a5aa92bee9b394242febe6f26dc0dc9ee4c1feca433947d9d24f",
    "source-stage-bundle-r1/result.public.json": "e484620b25f43c1b1ae54626e0e20bc872865e6527c8dc4df20741eb37011213",
    "control/server-regression-manifest.public.json": "ee44d8dc29f0762b532d13af3ecf2417638855e9464ca0bb052ae3f2dd35ba9e",
    "control/ha-regression-manifest.public.json": "132ae0404e4d40ac9adc159533176b0e54d4ab1b32928aabf8b9b977c2e15287",
    "control/regression-preparation.public.json": "1fe41bf90f5073981980b2b9a64f703672d2ce08e6ebf58503f757bee3413f8e",
    "control/run_unified_regressions.py": "5d352d362c01d42c7f6795efdf18b8b876c6af9899ebfb1eb5a4572420c1ec25",
    "control/aggregate_unified_regressions.py": "a7f66f9b8ea516bccaa2121864734118b9ebde120ac9b0f534d53ea8704096cc"
}
SCAN_SPECS = [
    ("pem_private_key", rb"-----BEGIN (?:[A-Z0-9]+ )?PRIVATE KEY-----"),
    ("vault_bearer_token", rb"(?<![A-Za-z0-9_])(?:hvs|hvb|hvr|s)\.[A-Za-z0-9_-]{16,}"),
    ("json_credential_value", rb'(?i)"(?:root_token|client_token|secret_id|private_key|unseal_key|recovery_key)"\s*:\s*"[^"\r\n]{1,}"'),
    ("auth_header_value", rb'(?im)(?:X-(?:Vault|Bao)-Token|Authorization)\s*["\x27]?\s*[:=]\s*["\x27]?(?:Bearer[ \t]+)?[A-Za-z0-9._~+/=-]{16,}'),
]
PATTERNS = [(name, re.compile(pattern)) for name, pattern in SCAN_SPECS]
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_TOTAL_BYTES = 64 * 1024 * 1024

def require(value, label):
    if not value:
        raise RuntimeError(label)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()

def stamp(info):
    return tuple(getattr(info, key) for key in (
        "st_dev", "st_ino", "st_mode", "st_uid", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns"))

def read_regular(path):
    path = Path(path)
    require(path.is_absolute() and path.resolve(strict=True) == path, "symlink_parent_or_relative_input")
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
            and before.st_uid == os.geteuid() and before.st_size <= MAX_FILE_BYTES,
            "nonregular_linked_foreign_or_oversized_input")
    with path.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        require(stamp(opened) == stamp(before), "input_identity_changed_on_open")
        raw = stream.read(MAX_FILE_BYTES + 1)
        after = os.fstat(stream.fileno())
    require(stamp(before) == stamp(after) and len(raw) == before.st_size
            and stamp(path.lstat()) == stamp(before), "input_changed_during_read")
    raw.decode("utf-8")
    require(b"\0" not in raw, "nontext_public_input")
    return raw, stamp(before)

def read_json(path, expected=None):
    raw, _ = read_regular(path)
    if expected:
        require(digest(raw) == expected, "pinned_public_input_changed:" + str(path))
    return json.loads(raw)

def write_new(path, raw):
    raw = canonical(raw) if not isinstance(raw, bytes) else raw
    with Path(path).open("xb") as stream:
        stream.write(raw); stream.flush(); os.fsync(stream.fileno())

def git(*args):
    return subprocess.check_output(
        ["/usr/bin/git", "-C", str(SOURCE), *args], text=True, timeout=20).strip()

def source_frozen():
    require(git("rev-parse", "HEAD") == COMMIT and git("rev-parse", "HEAD^{tree}") == TREE
            and not git("status", "--porcelain", "--untracked-files=all"), "r3_source_not_frozen")

def scan(raw):
    return [{"category": name, "offset": match.start()}
            for name, pattern in PATTERNS for match in pattern.finditer(raw)]

def pack(payloads):
    target = io.BytesIO()
    with gzip.GzipFile(fileobj=target, mode="wb", filename="", mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name in sorted(payloads):
                raw = payloads[name]
                entry = tarfile.TarInfo(name)
                entry.size = len(raw); entry.mode = 0o644
                entry.uid = entry.gid = 0
                entry.uname = entry.gname = ""
                entry.mtime = 0
                entry.type = tarfile.REGTYPE
                archive.addfile(entry, io.BytesIO(raw))
    return target.getvalue()

def main():
    os.umask(0o077)
    source_frozen()
    reference = read_json(PUBLIC / "reference-mac-evidence-policy.public.json", REFERENCE_MAC_POLICY_SHA256)
    require(reference["patterns"] == [{"name": n, "bytes_regex": p.decode("ascii")} for n,p in SCAN_SPECS],
            "declared scanner differs from reviewed reference")
    for relative, expected in PINS.items():
        read_json(ROOT / relative, expected) if relative.endswith(".json") else require(
            digest(read_regular(ROOT / relative)[0]) == expected, "pinned_controller_changed")

    aggregate = read_json(ROOT / "regression-r1/result.public.json")
    require((aggregate["status"], aggregate["passed"], aggregate["expected_unique_tests"]) == ("failed", 180, 181)
            and aggregate["original_176_passed"] == 175 and aggregate["original_176_retained"] is True
            and aggregate["original_60_passed"] == 60 and aggregate["full_denominator_retained"] is True
            and aggregate["source_unchanged"] is True and aggregate["all_owned_groups_empty"] is True
            and len(aggregate["tests"]) == 181, "candidate_outcome_changed")
    build = read_json(ROOT / "libtest-build-r1/build-result.public.json")
    require(build["status"] == "built" and build["source_commit"] == COMMIT
            and build["source_tree"] == TREE, "normal_build_binding_changed")
    prep = read_json(ROOT / "control/regression-preparation.public.json")
    require(prep["expected_unique_tests"] == 181 and prep["original_176_names_retained"] is True
            and prep["original_60_names_and_budgets_retained"] is True, "regression_plan_changed")
    release = read_json(ROOT / "normal-release-r1/result.public.json")
    require(release["status"] == "passed" and release["source_commit"] == COMMIT
            and release["source_tree"] == TREE and release["source_before"] == release["source_after"],
            "normal_release_changed")
    native = read_json(ROOT / "normal-release-r1/native-build.public.json")
    provenance = Path(native["provenance"]["result_path"])
    require(provenance == ROOT / "normal-release-r1/normal-release-result.public.json",
            "normal_release_provenance_path_changed")
    read_json(provenance, native["provenance"]["result_sha256"])
    artifact_pins = {**release["release_artifacts"], "server-libtest": build["libtest_artifact"],
                     "ha-libtest": build["ha_libtest_artifact"]}
    for artifact in artifact_pins.values():
        path = Path(artifact["path"])
        require(path.resolve(strict=True).is_relative_to(ROOT) and path.is_file()
                and not path.is_symlink() and path.stat().st_nlink == 1, "retained_artifact_identity")
        with path.open("rb") as stream:
            require(hashlib.file_digest(stream, "sha256").hexdigest() == artifact["sha256"],
                    "retained_artifact_changed")
    terminals = read_json(PUBLIC / "executor-terminals.public.json")
    require(len(terminals["observations"]) == 9, "executor_terminal_denominator_changed")

    witnesses = [
        ("pem_private_key", b"-----" + b"BEGIN RSA PRIVATE KEY" + b"-----"),
        ("vault_bearer_token", b"hvs" + b"." + b"w" * 36),
        ("json_credential_value", b'{"' + b'client_' + b'token": "' + b"w" * 24 + b'"}'),
        ("auth_header_value", b"X-Vault-" + b"Token: " + b"w" * 24),
    ]
    positive = []
    for name, payload in witnesses:
        hits = scan(payload)
        require(any(hit["category"] == name for hit in hits), "scanner_positive_control_failed")
        positive.append({"category": name, "actual_expected_pattern_hit": True,
                         "synthetic_witness_bytes_not_published": True})

    policy = {
        "schema": "heptabao.public-evidence-selection-and-scan-policy.v1",
        "source_commit": COMMIT, "source_tree": TREE,
        "reference_mac_policy_sha256": REFERENCE_MAC_POLICY_SHA256,
        "derived_from_mac_packager_sha256": REFERENCE_MAC_PACKAGER_SHA256,
        "reference_scope": "scanner patterns and deterministic format only; no Mac results borrowed",
        "declared_scanner_patterns_exactly_match_reference": True,
        "packager_byte_identical_to_prior_temporary_script": False,
        "selection": "Explicit public filenames and receipt-derived test ordinals; no recursive directory inclusion.",
        "regular_file_only": True, "symlinks_and_hardlinks_refused": True,
        "excluded": ["private-run", "credentials", "secret material", "snapshots", "backups",
                     "binary executables", "Git bundles", "runtime data stores", "archive payloads"],
        "patterns": [{"name": name, "bytes_regex": expression.decode("ascii")}
                     for name, expression in SCAN_SPECS],
        "positive_controls": positive, "positive_control_count": len(positive),
        "scan_claim": "No hits for these declared patterns in the explicitly selected public bytes; private paths are never selected.",
        "tar_format": "USTAR", "tar_regular_members_only": True,
        "tar_uid": 0, "tar_gid": 0, "tar_mode": "0644", "tar_mtime": 0,
        "gzip_mtime": 0, "gzip_filename": "", "gzip_compresslevel": 9,
        "maximum_file_bytes": MAX_FILE_BYTES, "maximum_selected_bytes": MAX_TOTAL_BYTES,
    }
    write_new(PUBLIC / "evidence-policy.public.json", policy)

    members = {}
    identities = {}
    selections = []
    def add(path, archive_name, category):
        archive_path = PurePosixPath(archive_name)
        lower_parts = [part.lower() for part in archive_path.parts]
        require(not archive_path.is_absolute() and all(part not in ("", ".", "..")
                for part in archive_path.parts) and len(archive_name.encode()) <= 255,
                "unsafe_member_name")
        require(not any("private" in part or part in ("credentials", "secrets", "snapshots", "backups")
                        for part in lower_parts), "private_member_name_refused")
        require(not archive_name.lower().endswith((
            ".pem", ".key", ".p12", ".pfx", ".crt", ".der", ".zip", ".tar", ".gz", ".tgz", ".bundle")),
            "credential_or_payload_extension_refused")
        require(archive_name not in members, "duplicate_public_member")
        raw, identity = read_regular(path)
        members[archive_name] = raw
        identities[archive_name] = (Path(path), identity)
        selections.append({"path": archive_name, "source": str(path), "category": category})
        require(sum(map(len, members.values())) <= MAX_TOTAL_BYTES, "public_byte_bound")
        return raw

    test_counts = {}
    for suite, expected, status, passed in (
            ("server", 172, "failed", 171), ("ha", 9, "passed", 9)):
        prefix = suite + "-regressions-r1"
        directory = ROOT / prefix
        result = read_json(directory / "result.public.json")
        require(result["status"] == status and result["passed"] == passed
                and result["expected_unique_tests"] == expected and result["attempted_once"] == expected
                and len(result["tests"]) == expected and result["source_unchanged"] is True,
                "suite_result_changed")
        inventory = read_json(directory / "actual-test-inventory.public.json")
        require(inventory["missing_required_names"] == [] and inventory["required_unique_count"] == expected,
                "compiled_inventory_gap")
        manifest = read_json(ROOT / ("control/" + suite + "-regression-manifest.public.json"))
        names = list(dict.fromkeys(name for group in manifest["groups"] for name in group["required_exact_names"]))
        require(len(names) == expected and set(names) == {row["name"] for row in result["tests"]},
                "suite_name_set_changed")
        labels = set()
        for row in result["tests"]:
            receipt_name = row["process_receipt"]
            require(re.fullmatch(r"test-[0-9]{4}\.public\.json", receipt_name), "test_receipt_not_public")
            label = receipt_name[:-len(".public.json")]
            require(label not in labels, "test_process_receipt_reused")
            labels.add(label)
            intent = read_json(directory / (label + ".intent.public.json"))
            process = read_json(directory / receipt_name)
            require(intent["name"] == row["name"] and process["argv"][1:] ==
                    [row["name"], "--exact", "--nocapture", "--test-threads=1"],
                    "actual_exact_test_changed")
            for suffix in (".intent.public.json", ".public.json", ".stdout", ".stderr"):
                raw = add(directory / (label + suffix), prefix + "/" + label + suffix, "actual_exact_test")
                if suffix in (".stdout", ".stderr"):
                    require(digest(raw) == process[suffix[1:] + "_sha256"], "original_test_log_changed")
        require(len(labels) == expected, "test_log_denominator_changed")
        test_counts[suite] = len(labels)
        for name in ("actual-test-inventory.public.json", "all-tests-list.public.json",
                     "all-tests-list.stdout", "all-tests-list.stderr",
                     "intent.public.json", "progress.public.json", "result.public.json"):
            add(directory / name, prefix + "/" + name, "suite_public_receipt")
    for name in ("intent.public.json", "result.public.json"):
        add(ROOT / "regression-r1" / name, "regression-r1/" + name, "aggregate_public_receipt")
    for directory, names in (
            ("normal-release-r1", ("intent.public.json","native-build.public.json","normal-release-result.public.json","result.public.json")),
            ("libtest-build-r1", ("intent.public.json","build-result.public.json")),
            ("source-stage-r1", ("intent.public.json","result.public.json")),
            ("source-stage-bundle-r1", ("intent.public.json","result.public.json"))):
        for name in names:
            add(ROOT/directory/name, directory+"/"+name, "original_public_provenance")
    for directory, result_name in (
            ("normal-release-r1","result.public.json"),("libtest-build-r1","build-result.public.json"),
            ("source-stage-r1","result.public.json"),("source-stage-bundle-r1","result.public.json")):
        result = read_json(ROOT/directory/result_name)
        labels=set()
        for declared in result["commands"]:
            label=declared["label"]
            require(re.fullmatch(r"[a-z0-9-]+",label) and label not in labels,"command_label_not_unique")
            labels.add(label)
            process=read_json(ROOT/directory/(label+".public.json"))
            require(process==declared and process["direct_child_reaped"] is True and not process["remaining"],
                    "original_command_custody_changed")
            if directory in ("normal-release-r1","libtest-build-r1","source-stage-bundle-r1"):
                require(process["exit_code"]==0 and not process["timed_out"],"successful_command_changed")
            for suffix in (".public.json",".stdout",".stderr"):
                raw=add(ROOT/directory/(label+suffix),directory+"/"+label+suffix,"original_command_receipt_or_log")
                if suffix in (".stdout",".stderr"):
                    require(digest(raw)==process[suffix[1:]+"_sha256"],"original_command_log_changed")
    control_names = [
        "owned_commands.py","stage_linux_source.py","stage_linux_source_bundle.py",
        "build_linux_release.py","build_linux_release.before-bundle-r1.py",
        "build_linux_libtests.py","build_linux_libtests.before-artifact-envelope-r1.py",
        "run_unified_regressions.py","run_unified_regressions_linux.py","aggregate_unified_regressions.py",
        "server-regression-manifest.public.json","ha-regression-manifest.public.json",
        "regression-preparation.public.json","preparation.public.json",
        "source-bundle-controls-preparation.public.json","space-admission-update.public.json",
        "regression-executor-bindings.public.json","cache-space-r1/result.public.json",
        "git-commit-payload-proof-r1/result.public.json","git-commit-payload-proof-r1/commit.raw"]
    for name in control_names:
        add(ROOT/"control"/name,"control/"+name,"explicit_public_controller_or_binding")
    for name in ("server-regression-manifest.public.json","ha-regression-manifest.public.json"):
        add(R1/"control"/name,"baseline-r1/"+name,"original_exact_denominator_reference")
    add(R1/"regression-aggregate-r1/result.public.json","baseline-r1/original-linux176-result.public.json",
        "prior_failed_candidate_reference_only")
    for observation in terminals["observations"]:
        raw_path = PUBLIC / observation["raw_response_path"]
        raw = add(raw_path, "evidence/" + observation["raw_response_path"], "unmodified_executor_terminal")
        require(digest(raw) == observation["raw_response_sha256"]
                and json.loads(raw) == observation["value"][0], "executor_terminal_bytes_changed")
        state = observation["value"][0]
        require(state["output_complete"] is True and state["output_durable"] is True
                and state["state"] in ("failed", "succeeded"), "executor_not_terminal")
    add(PUBLIC / "reference-mac-evidence-policy.public.json", "evidence/reference-mac-evidence-policy.public.json", "scanner_reference_only")
    add(PUBLIC / "executor-terminals.public.json", "evidence/executor-terminals.public.json",
        "executor_terminal_index")
    add(PUBLIC / "evidence-policy.public.json", "evidence/evidence-policy.public.json", "publication_policy")
    add(Path(__file__).absolute(), "evidence/pack_r3_public_evidence.py", "publication_controller")

    source_frozen()
    hits = []
    for name, raw in sorted(members.items()):
        hits.extend({"path": name, **hit} for hit in scan(raw))
    if hits:
        write_new(PUBLIC / "sensitive-scan-rejection.public.json",
                  {"status": "publication_refused", "hits": hits,
                   "matched_bytes_not_published": True, "candidate_acceptance_status": "failed"})
        raise RuntimeError("sensitive_pattern_hit_publication_refused")
    entries = [{"path": name, "bytes": len(raw), "sha256": digest(raw)}
               for name, raw in sorted(members.items())]
    manifest = {
        "schema": "heptabao.synthetic-regression-evidence-bundle.v2",
        "source_commit": COMMIT, "source_tree": TREE,
        "entries": entries, "file_count": len(entries),
        "scope": "Linux R3 synthetic full181 exact logs, normal release and libtest original command receipts, failed bounded source acquisition and subsequent exact bundle proof, immutable executor observations and explicit controls; no private runtime data or production credentials",
        "platform": "Linux", "native_abi": "x86_64-unknown-linux-gnu",
        "candidate_acceptance_status": "failed", "candidate_passed": 180, "candidate_denominator": 181,
        "original_176_passed": 175, "original_176_retained": True, "original_60_passed": 60,
        "test_log_denominators": test_counts, "failure_logs_preserved_without_redaction": True,
        "full_denominator_retained": True, "source_unchanged": True,
        "normal_release_controller_sha256": PINS["normal-release-r1/result.public.json"],
        "normal_build_result_sha256": PINS["libtest-build-r1/build-result.public.json"],
        "native_build_sha256": PINS["normal-release-r1/native-build.public.json"],
        "aggregate_result_sha256": PINS["regression-r1/result.public.json"],
        "reference_mac_policy_sha256": REFERENCE_MAC_POLICY_SHA256,
        "derived_from_mac_packager_sha256": REFERENCE_MAC_PACKAGER_SHA256,
        "declared_scanner_patterns_exactly_match_reference": True,
        "packager_byte_identical_to_prior_temporary_script": False,
        "sensitive_pattern_hits": [], "pattern_positive_witnesses_passed": len(positive),
        "declared_sensitive_pattern_count": len(PATTERNS),
        "policy_sha256": digest(members["evidence/evidence-policy.public.json"]),
        "executor_terminal_count": 9, "executor_failed_states_preserved": [
            row["name"] for row in terminals["observations"] if row["value"][0]["state"] == "failed"],
        "strict_tls_control_qa_included": False,
        "full34_original31_enforces_tls_close_notify": False,
        "formal_full34_executed_for_r3": False, "physical_ha_executed_for_r3": False,
        "build_cancellation_fault_qualification_claimed": False,
        "authbus_qualified": False, "production_changed": False, "old_services_deleted": False,
        "full_replacement_qualified": False,
        "deterministic_format": {"tar": "USTAR", "uid": 0, "gid": 0, "mode": "0644",
                                 "mtime": 0, "gzip_mtime": 0, "gzip_filename": "", "gzip_level": 9},
        "selection": sorted(selections, key=lambda row: row["path"]),
    }
    manifest_raw = canonical(manifest)
    require(not scan(manifest_raw), "sensitive_pattern_in_public_manifest")
    payloads = {**members, "MANIFEST.public.json": manifest_raw}
    packed = pack(payloads)
    require(pack(payloads) == packed, "deterministic_pack_replay_differs")
    require(packed[:2] == b"\x1f\x8b" and packed[4:8] == b"\0\0\0\0"
            and not packed[3] & 8, "gzip_header_not_deterministic")
    tar_raw = gzip.decompress(packed)
    require(tar_raw[257:263] == b"ustar\0", "archive_not_ustar")
    with tarfile.open(fileobj=io.BytesIO(packed), mode="r:gz") as archive:
        observed = archive.getmembers()
        require(len(observed) == len(payloads) and {row.name for row in observed} == set(payloads),
                "archive_member_set_changed")
        for row in observed:
            require(row.isfile() and row.type == tarfile.REGTYPE and row.uid == row.gid == 0
                    and row.mode == 0o644 and row.mtime == 0 and not row.pax_headers
                    and row.uname == row.gname == "", "archive_metadata_changed")
            raw = archive.extractfile(row).read()
            require(raw == payloads[row.name] and digest(raw) == digest(payloads[row.name]),
                    "archive_member_bytes_changed")
            require(not scan(raw), "sensitive_pattern_after_compression")
    for name, (path, identity) in identities.items():
        raw, now = read_regular(path)
        require(now == identity and raw == members[name], "source_evidence_changed_during_pack")
    source_frozen()
    manifest_path = PUBLIC / "r3-linux-regression-evidence-manifest.public.json"
    archive_path = PUBLIC / "r3-linux-regression-evidence.tar.gz"
    write_new(manifest_path, manifest_raw)
    write_new(archive_path, packed)
    receipt = {
        "schema": "heptabao.public-evidence-package-receipt.v1",
        "status": "public_evidence_packaged", "candidate_acceptance_status": "failed",
        "source_commit": COMMIT, "source_tree": TREE,
        "manifest_path": str(manifest_path), "manifest_sha256": digest(manifest_raw),
        "manifest_bytes": len(manifest_raw), "archive_path": str(archive_path),
        "archive_sha256": digest(packed), "archive_bytes": len(packed),
        "entry_count": len(entries), "tar_member_count_including_manifest": len(payloads),
        "selected_uncompressed_bytes": sum(len(raw) for raw in members.values()),
        "deterministic_rebuild_identical": True, "every_tar_member_readback_verified": True,
        "every_source_evidence_byte_unchanged_after_pack": True,
        "sensitive_pattern_hits": [], "positive_controls_passed": len(positive),
        "candidate_passed": 180, "candidate_denominator": 181, "original176_passed": 175,
        "original60_passed": 60, "full_replacement_qualified": False,
        "product_processes_started_by_packager": False, "published_to_repository": False,
        "packager_sha256": digest(members["evidence/pack_r3_public_evidence.py"]),
        "packager_execution_path": str(Path(__file__).absolute()),
        "packager_retained_path": str(PUBLIC / "pack_r3_public_evidence.py"),
        "persistent_archive_filesystem": "existing TOSHIBA noexec ext4; archive data only",
    }
    write_new(PUBLIC / "r3-linux-regression-evidence-receipt.public.json", receipt)
    print(json.dumps(receipt, sort_keys=True))

if __name__ == "__main__":
    main()
