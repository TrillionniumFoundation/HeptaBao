from pathlib import Path
import hashlib,json,os,subprocess,sys,time

os.umask(0o077)
assert __debug__ and sys.version_info >= (3,11)
root=Path('/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r10')
predecessor=Path('/Volumes/T5/hepta-vnext-recovery-20261013/replacement-unified-20261105-r9')
source=root/'source';control=root/'control/source-freeze-published-r1'
commit='b33b8d0de9c7689ff89f8ed11cd2151726972f4f'
tree='89a8af5b7bcb1d7472e1f12e1dec7adb7d2cf726'
parent='fa37c0fc6f28317d5f432bbbc2bbae062c4be064'
parent_tree='b1911f24c0b5c2c2ca67590b4e52c7d47dbf43af'
parent_freeze_pin='e02e9e8c73252de458961b3c8ad8fecc5a410e7040befe97f643f7ceea7015d3'
review_pin='d1ea69ba8d6e4125d78f21d4cd4c8504e649db1cb9f22c1d216e0bc046486004'
relative='crates/heptabao-server/src/http_response_framing_tests.rs'
before_pin='b897652bebbb717642cabd9cb719e53570e33b44a3a34bb19e63576eb188a2be'
after_pin='3890c3c09d67c16b22bf1ddb772d15d37ede766c108a5a5296a5aee9a7e5eb70'
raw_commit_pin='8e570c55c909506292cc53e860db6efcc03fef28b26ea78c1bde4df1fb56c4de'
remote_api_pin='c7ee5a9bc38622bb72902e7965379d004094933dc3437bb128ce1a20abfc0b47'
def digest(raw):return hashlib.sha256(raw).hexdigest()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(argv,timeout=30,stdin=None):
 p=subprocess.run(argv,input=stdin,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=timeout)
 if p.returncode:raise RuntimeError('source_git_command_failed_'+str(p.returncode))
 return p.stdout
def git(path,*args,stdin=None):return run(['/usr/bin/git','-C',str(path),*args],stdin=stdin).decode().strip()
def write(path,raw):
 with path.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
def encoded(value):return (json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
assert root.is_absolute() and root.parent.resolve(strict=True)==root.parent and not root.exists()
assert (git(predecessor/'source','rev-parse','HEAD'),git(predecessor/'source','rev-parse','HEAD^{tree}'),git(predecessor/'source','status','--porcelain','--untracked-files=all'))==(parent,parent_tree,'')
old_freeze=predecessor/'control/source-freeze-published-r1/freeze.public.json'
assert sha(old_freeze)==parent_freeze_pin
frozen=json.loads(old_freeze.read_bytes())
assert frozen['source_commit']==parent and frozen['source_tree']==parent_tree and frozen['source_clean'] is True and len(frozen['files'])==23
assert sha(predecessor/'source'/relative)==before_pin
payload=json.load(sys.stdin);assert set(payload)=={'candidate_text','raw_commit','root_review_text','remote_commit_text'}
candidate=payload['candidate_text'].encode();raw_commit=payload['raw_commit'].encode()
review=payload['root_review_text'].encode();remote_api=payload['remote_commit_text'].encode()
assert digest(candidate)==after_pin and len(candidate)==12621
assert digest(raw_commit)==raw_commit_pin and len(raw_commit)==784
assert hashlib.sha1(b'commit '+str(len(raw_commit)).encode()+b'\0'+raw_commit).hexdigest()==commit
assert digest(review)==review_pin and digest(remote_api)==remote_api_pin
remote=json.loads(remote_api);assert remote['sha']==commit and remote['tree']['sha']==tree and [r['sha'] for r in remote['parents']]==[parent]
review_doc=json.loads(review);assert review_doc['source_change_approved'] is True and review_doc['parent_commit']==parent and review_doc['parent_tree']==parent_tree
root.mkdir(mode=0o700);(root/'control').mkdir(mode=0o700);control.mkdir(mode=0o700)
clone_stdout=run(['/usr/bin/git','clone','--no-hardlinks','--no-checkout','--origin','predecessor',str(predecessor/'source'),str(source)],timeout=300)
write(control/'clone.stdout',clone_stdout)
git(source,'checkout','--detach',parent)
assert sha(source/relative)==before_pin
with (source/relative).open('wb') as f:f.write(candidate);f.flush();os.fsync(f.fileno())
git(source,'add','--',relative)
assert git(source,'hash-object',relative)=='5ac95a924c8e5f2b0aab5f98549c3daf816dc207'
assert git(source,'write-tree')==tree
assert git(source,'hash-object','-t','commit','-w','--stdin',stdin=raw_commit)==commit
git(source,'checkout','--detach',commit)
assert run(['/usr/bin/git','-C',str(source),'cat-file','commit',commit])==raw_commit
fsck=run(['/usr/bin/git','-C',str(source),'fsck','--full','--no-dangling'],timeout=180)
write(control/'fsck.stdout',fsck)
assert (git(source,'rev-parse','HEAD'),git(source,'rev-parse','HEAD^{tree}'),git(source,'rev-parse','HEAD^'),git(source,'status','--porcelain','--untracked-files=all'))==(commit,tree,parent,'')
assert git(source,'diff','--name-only',parent,commit).splitlines()==[relative]
assert git(source,'diff','--numstat',parent,commit)==('1\t0\t'+relative)
changed=git(source,'diff','--name-only','1f188df0f2affebb92702222e9fe5dfb4712194c',commit).splitlines()
assert len(changed)==24 and set(changed)=={r['path'] for r in frozen['files']}|{relative}
for r in frozen['files']:
 p=source/r['path'];assert p.resolve(strict=True)==p and sha(p)==r['sha256'] and p.stat().st_size==r['bytes']
files=[{'path':name,'sha256':sha(source/name),'bytes':(source/name).stat().st_size} for name in changed]
assert sha(source/relative)==after_pin
assert sha(source/'Cargo.lock')==sha(predecessor/'source/Cargo.lock')=='d2d07ea13e42a8d4ba65fafc642ca98ae1a7de68f6cd46a69043332267f378d5'
write(control/'published-commit.raw',raw_commit);write(control/'remote-commit.original.json',remote_api);write(control/'root-review.original.json',review)
bundle=control/'r10-published-source.bundle'
run(['/usr/bin/git','-C',str(source),'bundle','create',str(bundle),'HEAD','^'+parent],timeout=60)
bundle_heads=git(source,'bundle','list-heads',str(bundle));assert bundle_heads==commit+' HEAD'
run(['/usr/bin/git','-C',str(source),'bundle','verify',str(bundle)],timeout=30)
assert (git(predecessor/'source','rev-parse','HEAD'),git(predecessor/'source','rev-parse','HEAD^{tree}'),git(predecessor/'source','status','--porcelain','--untracked-files=all'))==(parent,parent_tree,'')
assert sha(old_freeze)==parent_freeze_pin and sha(predecessor/'source'/relative)==before_pin
result={'schema':'heptabao.readindex-source-published-freeze.v1','status':'published_exact_object_frozen_not_compiled','source_commit':commit,'source_tree':tree,'source_root':str(source),'source_clean':True,'parent_commit':parent,'parent_tree':parent_tree,'parent_source_root':str(predecessor/'source'),'parent_source_freeze':{'path':str(old_freeze),'sha256':parent_freeze_pin},'original_parent_unchanged':True,'files':files,'new_github_blob_count':1,'exact_parent_diff':{'paths':[relative],'additions':1,'deletions':0},'cargo_lock_sha256':sha(source/'Cargo.lock'),'published_branch':'codex/heptabao-readindex-observation-20261105-r10','published_commit_object':{'path':str(control/'published-commit.raw'),'bytes':len(raw_commit),'sha256':raw_commit_pin},'remote_commit_api':{'path':str(control/'remote-commit.original.json'),'bytes':len(remote_api),'sha256':remote_api_pin},'root_review':{'path':str(control/'root-review.original.json'),'sha256':review_pin},'fsck_completed':True,'bundle':{'path':str(bundle),'bytes':bundle.stat().st_size,'sha256':sha(bundle),'heads':bundle_heads,'required_parent':parent},'cargo_invoked':False,'tests_run':False,'products_started':False,'production_changed':False,'created_ns':time.time_ns()}
path=control/'freeze.public.json';write(path,encoded(result))
print(json.dumps({'status':result['status'],'source_commit':commit,'source_tree':tree,'source_clean':True,'result':str(path),'result_sha256':sha(path),'files':len(files),'bundle':result['bundle'],'products_started':False},sort_keys=True))
