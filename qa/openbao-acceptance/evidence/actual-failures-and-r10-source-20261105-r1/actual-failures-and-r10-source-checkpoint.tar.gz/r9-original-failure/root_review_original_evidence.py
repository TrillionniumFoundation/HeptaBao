#!/usr/bin/env python3
"""Review existing original bytes only; never launch, probe or qualify products."""
import base64
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/d1dc83a5698d')

def read(rel):
    return json.loads((ROOT / rel).read_bytes())

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def sdk(value):
    assert value.get('isError') is not True
    blocks = [x['text'] for x in value.get('content', []) if x.get('type') == 'text']
    assert len(blocks) == 1
    return json.loads(blocks[0])

def checked_files(rows):
    for row in rows:
        raw = Path(row['path']).read_bytes()
        assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
    return len(rows)

def original_files(response):
    assert response['truncated'] is False
    rows = response['files']
    result = {}
    for row in rows:
        raw = row['text'].encode('utf-8')
        assert row['eof'] is True and len(raw) == row['size']
        assert digest(raw) == row['sha256'] and row['path'] not in result
        result[row['path']] = raw
    return result

def terminal_and_logs(terminal, response, job, exit_code, directory):
    assert terminal['job_id'] == response['job_id'] == job
    assert terminal['exit_code'] == exit_code
    assert terminal['state'] == ('succeeded' if exit_code == 0 else 'failed')
    assert terminal['output_complete'] and terminal['output_durable']
    assert terminal['terminal_publication_confirmed']
    assert not terminal['timed_out'] and not terminal['cancelled'] and not terminal['automatic_retry']
    for name in ('stdout', 'stderr'):
        row = response[name]
        raw = bytes.fromhex(row['bytes_hex'])
        assert raw == row['text'].encode() == (directory / ('executor.' + name + '.original')).read_bytes()
        assert row['offset'] == 0 and row['next_offset'] == row['size'] == len(raw) and row['eof']
        assert terminal['log_bytes'][name] == {'seen': len(raw), 'stored': len(raw)}
        assert terminal['log_synced'][name] and not terminal['log_truncated'][name]
        assert terminal['log_errors'][name] is None

def main():
    r9 = ROOT / 'r9_compile_fix_prepare/evidence-r1'
    m = read('r9_compile_fix_prepare/evidence-r1/readback-manifest.public.json')
    checked_files(m['files'] + m['decoded_manifest_originals'])
    raw_payload = Path(m['raw_original_sdk_payload']['path']).read_bytes()
    assert len(raw_payload) == m['raw_original_sdk_payload']['bytes']
    assert digest(raw_payload) == m['raw_original_sdk_payload']['sha256']
    originals = original_files(sdk(json.loads(raw_payload)))
    for row in m['files']:
        assert originals[row['original_path']] == Path(row['path']).read_bytes()
    captures = read('r9_compile_fix_prepare/evidence-r1/original-api-captures-r1.json')
    captured = {x['key']: x['value'] for x in captures['entries']}
    terminal = sdk(captured['r9_mac_build_latest_status'])
    complete = sdk(read('r9_compile_fix_prepare/evidence-r1/executor-complete-read.api.json'))
    job = '1a1abef4048-fc05-5155'
    terminal_and_logs(terminal, complete, job, 1, r9)
    start = sdk(captured['r9_mac_build_reconcile'])
    worker = json.loads((r9 / 'worker-request.json').read_bytes())
    started = json.loads((r9 / 'worker-started.json').read_bytes())
    assert start['reused'] is True and start['job']['id'] == worker['job_id'] == started['job_id'] == job
    assert worker['request_digest'] == start['job']['request_digest']
    assert worker['launch_nonce'] == started['launch_nonce'] == terminal['launch_nonce']
    original_request = captured['r9_mac_build_request']
    for name in ('executable', 'args', 'timeout_seconds'):
        assert worker[name] == original_request[name]
    assert original_request['idempotency_key'] == start['job']['idempotency_key']
    assert worker['timeout_seconds'] == 4800 and worker['nice'] == 0 and worker['cwd'] is None
    assert worker['execution_mode'] == 'operator' and worker['allow_job_network'] is True
    assert worker['memory_max_bytes'] is None and worker['cpu_quota_percent'] is None and worker['env'] == {}
    result = json.loads((r9 / 'result.public.json').read_bytes())
    assert result['status'] == 'failed' and result['source_commit'] == 'fa37c0fc6f28317d5f432bbbc2bbae062c4be064'
    assert result['source_tree'] == 'b1911f24c0b5c2c2ca67590b4e52c7d47dbf43af'
    assert result['controller_sha256'] == '47afd2c97d8ba1e25b2f74b7014f510f21e36bc85e217d8cb067a394a023018e'
    assert result['runtime_tests_started'] is False and result['production_changed'] is False
    for phase, code, filename in [('release_build', 0, 'normal-release-build'), ('libtest_build', 101, 'normal-libtest-build')]:
        receipt = json.loads((r9 / (filename + '.public.json')).read_bytes())
        assert receipt == result[phase]
        assert receipt['exit_code'] == code and not receipt['timed_out'] and receipt['direct_child_reaped']
        assert receipt['remaining'] == [] and receipt['outer_cap_seconds'] == 1800
        assert digest((r9 / (filename + '.stderr')).read_bytes()) == receipt['stderr_sha256']
    assert all(x['direct_child_reaped'] and x['remaining'] == [] for x in result['cleanup'])
    emitted = [json.loads(x) for x in (r9 / 'executor.stdout.original').read_bytes().splitlines()]
    assert emitted[-1]['result_sha256'] == digest((r9 / 'result.public.json').read_bytes())
    assert emitted[0]['server_sha256'] == result['artifacts']['heptabao-server']['sha256']
    assert 'missing field `status`' in (r9 / 'normal-libtest-build.stderr').read_text()

    r6 = ROOT / 'r6_mac_build_prepare/recovered-original-evidence-r1'
    r6m = json.loads((r6 / 'manifest.public.json').read_bytes())
    checked_files(r6m['records'])
    r6terminal = json.loads((r6 / 'executor-terminal.rpc-capture.public.json').read_bytes())['response']
    r6logs = json.loads((r6 / 'executor-complete-read.rpc-capture.public.json').read_bytes())['response']
    terminal_and_logs(r6terminal, r6logs, '1a1ab9e89cb-fc05-4f0d', 1, r6)
    r6rows = {}
    for name in ['executor-original-worker.rpc-capture.public.json', 'original-failure-files.rpc-capture.public.json']:
        r6rows.update(original_files(json.loads((r6 / name).read_bytes())['response']))
    for raw in r6rows.values():
        assert any(Path(x['path']).read_bytes() == raw for x in r6m['records'])
    r6result = json.loads((r6 / 'normal-build-result.original.json').read_bytes())
    assert r6result['status'] == 'failed' and r6result['release_build']['exit_code'] == 101
    assert r6m['complete'] is False and r6m['raw_cargo_json_local'] is False

    pocket = ROOT / 'r9_pocket_build_prepare/live-initial-evidence-r1'
    pm = json.loads((pocket / 'manifest.public.json').read_bytes())
    checked_files(pm['files'])
    assert digest(Path(pm['raw_capture']['path']).read_bytes()) == pm['raw_capture']['sha256']
    pc = json.loads((pocket / 'original-api-captures.json').read_bytes())
    pf = original_files(sdk(pc['response']))
    for row in pm['files']:
        assert pf[row['runtime_path']] == Path(row['path']).read_bytes()
    ps = sdk(pc['normal_actual_start'])
    pw = json.loads((pocket / '01-request.json').read_bytes())
    pstarted = json.loads((pocket / '02-started.json').read_bytes())
    pi = json.loads((pocket / '03-intent.public.json').read_bytes())
    pj = '1a1abfad211-fc05-517a'
    assert ps['job']['id'] == pw['job_id'] == pstarted['job_id'] == pj
    bare_unit = 'hepta-runtime-job-' + pj
    assert pw['unit'] == ps['job']['unit'] == ps['launch']['unit'] == bare_unit
    assert pw['request_digest'] == ps['job']['request_digest']
    assert pw['launch_nonce'] == pstarted['launch_nonce']
    assert pw['memory_max_bytes'] == 8 * 1024**3 and pw['timeout_seconds'] == 2100 and pw['nice'] == 10
    for name in ('executable', 'args', 'cwd', 'timeout_seconds', 'memory_max_bytes', 'nice'):
        assert pw[name] == pc['normal_submission'][name]
    assert pi['executor_cgroup'].split('/')[-1] == bare_unit + '.service'
    assert pi['resource_admission']['actual_unit']['memory_max'] == str(8 * 1024**3)
    assert pi['resource_admission']['actual_unit']['path'].endswith('/' + bare_unit + '.service')
    assert pi['resource_admission']['actual_unit']['events']['oom'] == 0
    assert pi['source_commit'] == result['source_commit'] and pi['source_tree'] == result['source_tree']
    stage = json.loads((pocket / '04-result.public.json').read_bytes())
    assert stage['status'] == 'passed' and stage['commit'] == result['source_commit'] and stage['tree'] == result['source_tree']
    assert stage['source_clean'] is True and stage['cargo_invoked'] is False
    assert len(stage['prior_candidate_immutable_before']) == 12
    assert stage['prior_candidate_immutable_before'] == stage['prior_candidate_immutable_after']
    assert stage['prior_source_before'] == stage['prior_source_after']
    observed = sdk(pc['normal_running_status'])
    assert observed['job_id'] == pj and observed['state'] == 'running'
    assert observed['systemd']['ExecMainPID'] == str(pstarted['supervisor_pid'])
    assert observed['systemd']['InvocationID'] == pstarted['invocation_id']

    review = {
        'schema': 'heptabao.root-original-evidence-readback.v1',
        'r9_mac': {'job_id': job, 'actual_terminal': 'failed', 'exit_code': 1,
                   'release': 'Cargo exit 0; retained server hash bound to phase output',
                   'libtest': 'Cargo exit 101; E0063 missing status initializer',
                   'source_commit': result['source_commit'], 'source_tree': result['source_tree'],
                   'original_worker_request_and_started_bound': True, 'original_executor_full_logs_bound': True,
                   'original_result_and_phase_receipts_bound': True,
                   'raw_cargo_stdout_locally_complete': False, 'server_binary_locally_rehashed_by_root': False,
                   'runtime_tests_started': False, 'build_test_qualified': False},
        'r6_mac': {'actual_terminal': 'failed', 'exit_code': 1, 'original_local_manifest_records_verified': len(r6m['records']),
                   'original_worker_and_result_files_bound': True, 'raw_cargo_stdout_locally_complete': False},
        'r9_pocket_initial_observation': {'job_id': pj, 'actual_observed_state': 'running', 'actual_bare_worker_unit': bare_unit,
                   'kernel_unit_component': bare_unit + '.service', 'memory_max_bytes': 8 * 1024**3,
                   'original_worker_and_cgroup_observation_bound': True, 'original_stage_result_bound': True,
                   'prior_12_immutable_files_unchanged': True, 'stage_executor_full_stdout_locally_available': False,
                   'normal_terminal_observed_in_this_review': False, 'build_test_qualified': False},
        'original_r5_history_wire': {'sha256': '71a81748c07f22a2584993239b28e2e02babe97e5de8fc1f6911d7353fa3bc22',
                   'original_runtime_readback_bound': True, 'preparation_sha256': 'a0b46d2b7fa5804470649e9799827b0a1c1f147c920397336cbd4af661dcd753'},
        'formal_dr25_executions': 0, 'formal_kv2_qualified': False, 'physical_ha_qualified': False,
        'authbus_qualified': False, 'production_changed': False, 'replacement_qualified': False,
        'scope': 'Independent local review of original captured bytes; no new remote operation or product execution.'}
    output = ROOT / 'r9_compile_fix_prepare/root-original-evidence-review.public.json'
    output.write_text(json.dumps(review, sort_keys=True, indent=2) + '\n')
    print(json.dumps({'path': str(output), 'sha256': digest(output.read_bytes()), 'status': 'reviewed_with_explicit_gaps'}))

if __name__ == '__main__':
    main()
