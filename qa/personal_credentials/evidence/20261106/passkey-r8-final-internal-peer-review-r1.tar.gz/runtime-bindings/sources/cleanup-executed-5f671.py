import runpy,pathlib,json,hashlib,os,fcntl,stat,time,socket,re
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r8");root=b/"live-r8";driver=b/"passkey_live.r8.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
def sha(raw):return hashlib.sha256(raw).hexdigest()
try:
 journal=json.loads(m["private_file"](root/"journal.private.json",8*1024*1024));buildraw=m["private_file"](b/"artifacts/build.receipt.json",1048576);assert sha(buildraw)=="97a6daec5bb7276b935498fb3c8501df9ecc57a118641cffb9f2df3ae6edd009";m["validate_journal"](journal,json.loads(buildraw),"97a6daec5bb7276b935498fb3c8501df9ecc57a118641cffb9f2df3ae6edd009")
 assert all(v in ("restored_original","already_original") for v in journal["restoration"].values()) and {k:d.setting(k) for k in m["SETTING_KEYS"]}==journal["original_settings"]
 assert all(d.package_hash(p) is None for p in m["OWNED"])
 reverse=d.adb_call("reverse","--list");assert reverse.returncode==0 and not reverse.stderr and not any("tcp:38491" in row for row in reverse.stdout.decode().splitlines())
 with socket.socket() as sock:sock.settimeout(3);assert sock.connect_ex(("127.0.0.1",38491))!=0
 side=root/"documents.private.json";raw=m["private_file"](side,65536);plan=json.loads(raw)
 directory="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r8";canonical_directory=directory.replace("/sdcard/","/storage/emulated/0/",1)
 dirs=[directory,directory+"/latest-recovery",directory+"/G08-target",directory+"/G10-target",directory+"/G08-retest-target",directory+"/G10-retest-target"];leaf="HeptaBao-passkey-backup.hbv";seedleaf="heptabao-passkey-qa-r8-seed.hbv"
 assert plan["device_sha256"]==m["DEVICE_SHA256"] and plan["directory"]==directory and plan["initial_directory_absent"] is True and plan["directory_created"] is True
 assert len(plan["directories"])==6 and set(x["path"] for x in plan["directories"])==set(dirs)
 for x in plan["directories"]:assert x["initial_absent"] is True and x["mkdir_intent"] is True and x["created"] is True
 expected={p+"/"+seedleaf:(615,"bb527d9aa00987a243b378ac31eb15d2caf203e106348a8e1ed60cff7f674917") for p in dirs}
 expected[directory+"/"+leaf]=(2064,"01c1006cf0767236d71c437d63d113e68faacf3c10adcb0c65a87bef5956b4e7")
 expected[directory+"/latest-recovery/"+leaf]=(2063,"7a25c8e573cbd9ffcbbe2db5371f289809307524de7414e21d690306dfcfc201")
 for case in ("G08","G10"):
  baseline=json.loads(m["private_file"](root/(case+"-destination-baseline.public.json"),65536))["file"];path=directory+"/"+case+"-target/"+leaf
  assert baseline["device_path"]==path and type(baseline["bytes"]) is int and 615<baseline["bytes"]<=8*1024*1024 and re.fullmatch(r"[0-9a-f]{64}",baseline["sha256"])
  expected[path]=(baseline["bytes"],baseline["sha256"])
 for case,label in (("G08","r8-G08-unconsumed-target-retest-1"),("G10","r8-G10-wrong-password-target-retest-1")):
  baseline=json.loads(m["private_file"](root/(label+"-destination-baseline.public.json"),65536))["file"];path=directory+"/"+case+"-retest-target/"+leaf
  assert baseline=={"device_path":path,"bytes":615,"sha256":"bb527d9aa00987a243b378ac31eb15d2caf203e106348a8e1ed60cff7f674917"}
  expected[path]=(baseline["bytes"],baseline["sha256"])
 assert len(plan["files"])==12 and set(x["path"] for x in plan["files"])==set(expected)
 for item in plan["files"]:
  path=item["path"];size,digest=expected[path];assert item["initial_absent"] is True and item["write_intent"] is True and item["written"] is True and item["bytes"]==size and item["sha256"]==digest
  info=d.shell("stat","-c","%f %s",path).split();assert len(info)==2 and stat.S_ISREG(int(info[0],16)) and int(info[1])==size
  assert d.shell("test","!","-L",path)=="" and d.shell("sha256sum",path).split()[0]==digest and d.shell("readlink","-f",path)==path.replace("/sdcard/","/storage/emulated/0/",1)
 for path in dirs:
  assert d.shell("test","-d",path)=="" and d.shell("test","!","-L",path)==""
  children={pathlib.PurePosixPath(x).name for x in list(expected)+dirs if x!=path and str(pathlib.PurePosixPath(x).parent)==path}
  assert set(d.shell("ls","-A",path).splitlines())==children
 for name,size,digest in [("M04-phone-backup.hbv",2064,expected[directory+"/"+leaf][1]),("G11_RECOVERY_EXPORT-phone-backup.hbv",2063,expected[directory+"/latest-recovery/"+leaf][1])]:
  captured=m["private_file"](b/"private"/name,8*1024*1024);assert len(captured)==size and sha(captured)==digest
 for prefix in (directory,canonical_directory):
  allowed={x if prefix==directory else x.replace("/sdcard/","/storage/emulated/0/",1) for x in list(expected)+dirs if x!=directory}
  value=d.shell("content","query","--uri","content://media/external/file","--projection","_id:_data","--where","_data LIKE '"+prefix+"/%'")
  rows=[] if value=="No result found." else value.splitlines()
  for line in rows:
   match=re.fullmatch(r"Row: \d+ _id=\d+, _data=(.+)",line);assert match and match.group(1) in allowed
 with (root/"documents.before-cleanup.private.json").open("xb") as out:out.write(raw);out.flush();os.fsync(out.fileno())
 parent=os.open(root,os.O_RDONLY|os.O_DIRECTORY);os.fsync(parent);os.close(parent)
 plan["cleanup_intent_unix_ns"]=time.time_ns();plan["cleanup_exact_paths"]=sorted(expected);plan["cleanup_exact_directories"]=sorted(dirs,key=len,reverse=True);m["atomic"](side,plan)
 def absent(path):
  q=d.adb_call("shell","if [ -e "+path+" ] || [ -L "+path+" ]; then printf EXISTS; else printf ABSENT; fi");assert q.returncode==0 and q.stdout==b"ABSENT" and not q.stderr
 def media_absent(path):assert d.shell("content","query","--uri","content://media/external/file","--projection","_id","--where","_data='"+path+"'")=="No result found."
 for path in sorted(expected):
  size,digest=expected[path]
  info=d.shell("stat","-c","%f %s",path).split();assert len(info)==2 and stat.S_ISREG(int(info[0],16)) and int(info[1])==size
  assert d.shell("test","!","-L",path)=="" and d.shell("sha256sum",path).split()[0]==digest and d.shell("readlink","-f",path)==path.replace("/sdcard/","/storage/emulated/0/",1)
  d.shell("rm","--",path)
  for indexed in (path,path.replace("/sdcard/","/storage/emulated/0/",1)):
   absent(indexed);d.shell("content","delete","--uri","content://media/external/file","--where","_data='"+indexed+"'");media_absent(indexed)
 for path in sorted(dirs,key=len,reverse=True):
  assert d.shell("test","-d",path)=="" and d.shell("test","!","-L",path)=="" and d.shell("readlink","-f",path)==path.replace("/sdcard/","/storage/emulated/0/",1) and d.shell("ls","-A",path)=="";d.shell("rmdir",path)
  for indexed in (path,path.replace("/sdcard/","/storage/emulated/0/",1)):
   absent(indexed);d.shell("content","delete","--uri","content://media/external/file","--where","_data='"+indexed+"'");media_absent(indexed)
 for prefix in (directory,canonical_directory):assert d.shell("content","query","--uri","content://media/external/file","--projection","_id","--where","_data LIKE '"+prefix+"/%'")=="No result found."
 settings={k:d.setting(k) for k in m["SETTING_KEYS"]};assert settings==journal["original_settings"] and all(d.package_hash(p) is None for p in m["OWNED"])
 reverse=d.adb_call("reverse","--list");assert reverse.returncode==0 and not reverse.stderr and not any("tcp:38491" in row for row in reverse.stdout.decode().splitlines())
 rpraw=m["private_file"](b/"rp-r8/result.manifest.json",1048576);rpmanifest=json.loads(rpraw);rp=rpmanifest["state"];rpstate=m["private_file"](b/"rp-r8/state.public.json",8*1024*1024)
 assert rpmanifest["source_sha256"]=="386de84bb5335f21998a000b4a1267eaa17fadbde1e1753d5df1c30325709a63" and rpmanifest["state_sha256"]==sha(rpstate)
 assert rp["credential_count"]==1 and rp["counters"]["registrations"]==1 and rp["counters"]["authentications"]>=8 and rp["credentials"][0]["credential_id"]=="MoAAtn4aJbaUv3-_S5n-QV7-qpGospx1kxLVxhIZaRc" and rp["credentials"][0]["public_key_sha256"]=="77831f62d82845291f2128f6ba6c9466fe8cc40d44086267b13de2dc19b7ff75"
 plan["cleanup_complete"]=True;plan["cleaned_unix_ns"]=time.time_ns();m["atomic"](side,plan)
 report={"schema":1,"ok":True,"scope":"r8_synthetic_phone_cleanup","settings_match_original":True,"settings_sha256":{k:sha(v.encode()) for k,v in settings.items()},"packages_absent_including_retained":True,"owned_packages":sorted(m["OWNED"]),"reverse_absent":True,"owned_documents_absent":True,"owned_document_count":12,"owned_directory_count":6,"owned_media_index_absent":True,"media_alias_and_canonical_checked":True,"owned_directory_media_rows_checked":True,"M04_and_G11_current_ciphertext_private_captures_preserved":True,"credential_entry":"synthetic_only_adb_input_text_child_argv","rp":rp,"rp_last_manifest_sha256":sha(rpraw),"rp_port_closed":True,"production_qualified":False,"completed_unix_ns":time.time_ns()}
 m["atomic"](root/"cleanup.result.public.json",report)
 old=m["private_file"](b/"case-results.public.json",4*1048576);ledger=json.loads(old);assert len(ledger["cases"])==18
 for row in ledger["cases"]:
  if row["id"]!="M07":assert row["status"] in ("passed","failed","blocked") and len(row["evidence"])>0
 row=next(x for x in ledger["cases"] if x["id"]=="M07");assert row["status"]=="missing"
 with (b/"case-results.before-cleanup.public.json").open("xb") as out:out.write(old);out.flush();os.fsync(out.fileno())
 fd=os.open(b,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
 row.update({"status":"passed","executed":True,"evidence":[{"path":str(root/"cleanup.result.public.json"),"sha256":sha((root/"cleanup.result.public.json").read_bytes())}]})
 phases=[]
 for p in sorted((b/"attempts").glob("*.result.public.json")):
  raw=m["private_file"](p,1048576);ev=json.loads(raw);phases.append({"file":p.name,"sha256":sha(raw),"case":ev["case"],"phase":ev["phase"],"exit_code":ev["exit_code"],"error":ev.get("result",{}).get("error")})
 for k in ("passed","failed","blocked","missing"):ledger[k]=sum(x["status"]==k for x in ledger["cases"])
 ledger.update(expected=18,executed=sum(x["executed"] for x in ledger["cases"]),p4_qualified=False,production_qualified=False,fixed_profile_all_passed=ledger["passed"]==18,master_entered=True,credential_entry="synthetic_only_adb_input_text_child_argv",credential_manager_create_verified=True,credential_manager_get_verified=True,same_device_fresh_process_restore_verified=True,counter_rollback_rejection_verified=True,reset_executed=True,reset_cases=["M05","G11"],phase_evidence=phases,failed_phase_attempts=[x for x in phases if x["exit_code"]!=0],cleanup_sha256=sha((root/"cleanup.result.public.json").read_bytes()),input_helper_sha256="6107824e7021d6d3c5c8741ad93922dc750595ce4bc4942f5a30b1d20230e146",phase_runner_sha256="45547627264563b447072222f7bf0371d6c00a7e99bd6480dbf926c85f236af3",reset_helper_sha256="413a17831a115b3c9688933dfba17835ccee9323be659b58c7810fcb5d986115",runtime_source_bundle_sha256="93ae4e2bb76d9e761bb088d86a7c69326fca469bbb3ba610eab1c4b8565ab77d",provider_apk_sha256="b16e82916330fac6909f82696089798c3ec76d7b4058fe9290e7e841b9e00459",rp_final_public_state=rp)
 ledger.setdefault("observations",[]).extend([{"kind":"control_plane_audit_gap","job":"1a1b14f4e13-fc05-77ab","original_launch_audit_recorded":False,"original_warning_preserved":True,"subsequent_product_success_does_not_repair_audit_gap":True},{"kind":"report_file_create_only_collision","job":"1a1b16c242d-fc05-7896","original_job_state":"failed","original_exit_code":1,"G02_behavior_only_reconciled_separately":True,"original_stdout_stderr_source_preserved":True},{"kind":"auxiliary_export_summary_reference_correction","original_result_sha256":"ff366c92bf1ed848000240661a717ecf3997a467648e50f0eacbe3f5c969d866","correction_note_sha256":"f288ac737f29f8871fe4b4602a54b47719a83d5d3a75b240eceb918c4299f54d","originals_preserved":True}])
 supplemental=[]
 for label in ("r8-G07-cancel-retest-1","r8-G08-unconsumed-target-retest-1","r8-G10-wrong-password-target-retest-1"):
  p=root/(label+"-result.public.json");raw=m["private_file"](p,1048576);ev=json.loads(raw)
  assert ev["candidate"]==label and ev["expected"]==1 and ev["status"] in ("passed","failed")
  supplemental.append({"candidate":label,"expected":1,"executed":ev["executed"],"status":ev["status"],"result_sha256":sha(raw),"path":str(p)})
 supplement={"schema":1,"expected":3,"executed":sum(x["executed"] for x in supplemental),"passed":sum(x["status"]=="passed" for x in supplemental),"failed":sum(x["status"]=="failed" for x in supplemental),"cases":supplemental,"not_merged_into_original_eighteen":True,"original_G07_and_G10_failed_results_preserved":True,"original_G08_causal_evidence_limitation":"The original test had consumed the selected destination through a prior valid Write; only the separate unconsumed-target retest directly tests the intended selection policy.","production_qualified":False}
 m["atomic"](root/"supplemental-three-case-results.public.json",supplement)
 ledger["supplemental_separate_profile"]={"path":str(root/"supplemental-three-case-results.public.json"),"sha256":sha((root/"supplemental-three-case-results.public.json").read_bytes()),"expected":3,"passed":supplement["passed"],"failed":supplement["failed"],"not_merged":True}
 ledger["observations"].append({"kind":"original_G08_causal_evidence_limitation","original_result_sha256":"94c9b3e2d8032fc5efb584a1d1e5dd5adae2b8b03c214f34139e99a79636d70e","prior_valid_Write_consumed_destination":True,"original_report_preserved":True,"separate_retest":"r8-G08-unconsumed-target-retest-1"})
 assert ledger["expected"]==18 and ledger["passed"]==16 and ledger["failed"]==2 and ledger["missing"]==0 and ledger["executed"]==18
 m["atomic"](b/"case-results.public.json",ledger)
 print(json.dumps({"ok":True,"cleanup_path":str(root/"cleanup.result.public.json"),"cleanup_sha256":sha((root/"cleanup.result.public.json").read_bytes()),"ledger_path":str(b/"case-results.public.json"),"ledger_sha256":sha((b/"case-results.public.json").read_bytes()),"expected":18,"executed":ledger["executed"],"counts":{k:ledger[k] for k in ("passed","failed","blocked","missing")},"settings_match_original":True,"packages_absent":True,"reverse_absent":True,"documents_and_media_absent":True},sort_keys=True),flush=True)
finally:os.close(lock)
