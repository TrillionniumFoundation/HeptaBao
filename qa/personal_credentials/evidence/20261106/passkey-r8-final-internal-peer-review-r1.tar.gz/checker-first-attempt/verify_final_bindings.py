#!/usr/bin/env python3
"""Read frozen public evidence; never run device/controller/product code."""
import ast
import hashlib
import json
import pathlib
import sys
import tarfile

blocked_external_calls = []
def audit(event, args):
    if event.startswith("socket.") or event in ("subprocess.Popen", "os.system", "os.posix_spawn", "os.spawn"):
        blocked_external_calls.append(event)
        raise RuntimeError("external action forbidden in evidence review")
sys.addaudithook(audit)

ROOT = pathlib.Path(sys.argv[1]).resolve()
checks = []
def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)
def digest(data):
    return hashlib.sha256(data).hexdigest()
def unique_object(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError("duplicate JSON key")
        out[key] = value
    return out
def parse(data):
    return json.loads(data, object_pairs_hook=unique_object)
def raw(relative):
    path = ROOT / relative
    if path.is_symlink() or not path.is_file():
        raise ValueError("nonregular input")
    return path.read_bytes()
def obj(relative):
    return parse(raw(relative))
def pinned(relative, expected):
    value = raw(relative)
    check("sha256:" + relative, digest(value) == expected)
    return value

NESTED = {
 "passkey-r8-M05-G11-peer-review-r1.tar.gz": (160471, "33949ab832b25162451224b27221f217339bf699d22a21f165d3e26589c6fcc5"),
 "passkey-r8-G11-outcome-originals-checkpoint-r1.tar.gz": (22574, "031742b2eabda35623c7563f6c56b8bd05da6ea5232461089161d219fc0448a0"),
 "passkey-r8-G02-peer-review-r1.tar.gz": (75897, "b6ee83a63186eda2ff3693f4d795be60ded9647def3f09c7cda092b8771ac023"),
 "passkey-r8-G07-retest-peer-review-r1.tar.gz": (16464, "e266355848f41ff24c2f683874b7ae5390a5caf99ea0c27f790fa8da8bc17e1f"),
 "passkey-r8-G07-actual-outcome-peer-review-r1.tar.gz": (21056, "0b217c18e0427d4c7da4a534afbcd2dc2bb66c796e5e6d157c711155b1ba54bf"),
 "passkey-r8-SAF-retest-peer-review-r1.tar.gz": (11285, "bc7981a46ea0e3da6581583ae832f3ef1c7239c90161e848e8ea443cd842f1f0"),
 "passkey-r8-SAF-actual-outcome-peer-review-r1.tar.gz": (25672, "92e4dba0cc3f487efb3325aec15628a54a452d4e1fcbe95423892772b8475193"),
}
for name, (size, sha) in NESTED.items():
    value = raw("nested/" + name)
    check("frozen_nested_archive:" + name, len(value) == size and digest(value) == sha)

def member(archive, name):
    with tarfile.open(ROOT / "nested" / archive, "r:gz") as tf:
        matches = [x for x in tf.getmembers() if x.name == name]
        if len(matches) != 1 or not matches[0].isfile() or matches[0].size > 2000000:
            raise ValueError("invalid selected tar member")
        return tf.extractfile(matches[0]).read()

source_manifest = parse(pinned("runtime-bindings/source-full-manifest.original.public.json", "de250857c34765c310637da139b1b96786bdca178c424b96fc7c5ed8a7a6a10b"))
source_items = {x["relative"]: x for x in source_manifest["files"]}
check("source_manifest_is_112_item_metadata_inventory", len(source_items) == len(source_manifest["files"]) == 112)
selected = obj("runtime-bindings/selected-originals.manifest.public.json")["files"]
check("selected_manifest_has_exactly_28_originals", len(selected) == 28)
for entry in selected:
    rel = entry["relative"]
    value = raw("runtime-bindings/" + rel)
    check("selected_origin:" + rel, entry == source_items[rel] and len(value) == entry["bytes"] and digest(value) == entry["sha256"])

JOBS = [
 "1a1b167df18-fc05-7868", "1a1b1693a95-fc05-7879",
 "1a1b19254d9-fc05-799f", "1a1b199799c-fc05-79c5",
 "1a1b1a15c1c-fc05-79ee", "1a1b1a2fa69-fc05-7a00",
 "1a1b1a6e043-fc05-7a1a", "1a1b18d3623-fc05-7983",
]
requests = {}
launches = {}
for job in JOBS:
    prefix = "report-finalization/" if job.endswith("7983") else "runtime-bindings/" + job + "/"
    values = {}
    for leaf in ("request.public.json", "launch.public.json", "binding.public.json"):
        value = raw(prefix + leaf)
        origin = source_items[job + "/" + leaf]
        check("recorded_original:" + job + "/" + leaf, len(value) == origin["bytes"] and digest(value) == origin["sha256"])
        values[leaf] = parse(value)
    req, launch, binding = (values[x] for x in ("request.public.json", "launch.public.json", "binding.public.json"))
    j = launch["job"]
    check("request_launch_binding:" + job,
        j["id"] == job == binding["job_id"] and req["host"] == j["host"] == "pocket4"
        and req["executable"] == j["executable"] == "/usr/bin/python3"
        and req["args"] == j["args"] and req["idempotency_key"] == j["idempotency_key"]
        and j["request_digest"] == binding["request_digest"]
        and launch["audit_recorded"] is True and launch["reused"] is False
        and launch["local_record_pending"] is False and j["launch_state"] == "launched")
    requests[job], launches[job] = req, launch
check("no_duplicate_request_idempotency_key", len({x["idempotency_key"] for x in requests.values()}) == 8)

# Literal extraction parses controller source but never imports or executes it.
def literal_source(request):
    tree = ast.parse(request["stdin"])
    values = [ast.literal_eval(n.value) for n in tree.body
              if isinstance(n, ast.Assign) and len(n.targets) == 1
              and isinstance(n.targets[0], ast.Name) and n.targets[0].id == "source"]
    if len(values) != 1 or not isinstance(values[0], str):
        raise ValueError("no unique literal source")
    return values[0].encode()

g11_archive = "passkey-r8-G11-outcome-originals-checkpoint-r1.tar.gz"
g11_code = literal_source(requests[JOBS[1]])
check("G11_request_executes_original_reviewed_source",
      digest(g11_code) == "5f0a95551a9df45e3700ed5c9932d7372e8dab6ee585ac0aef1091c4a4029cab"
      and g11_code == member(g11_archive, "originals/runtime-sources/G11-stale-saf-restore-real-cm-get-r8.py"))
reset_args = requests[JOBS[0]]["args"]
check("G11_reset_case_build_and_checkpoint_exact",
      reset_args[reset_args.index("--case-id")+1] == "G11"
      and reset_args[reset_args.index("--expected-build-sha256")+1] == "97a6daec5bb7276b935498fb3c8501df9ecc57a118641cffb9f2df3ae6edd009"
      and reset_args[reset_args.index("--expected-checkpoint-sha256")+1] == "80cf80b96277b904e5efe7e6dbf0f75323c52a6be0cb062e01123aaad810704b"
      and reset_args[1] == "/home/alex/HeptaBaoPasskey-20261106-r8/passkey_reset_provider_r8.py")
for job, archive, leaf, candidate_path, sha in [
 (JOBS[2], "passkey-r8-G07-retest-peer-review-r1.tar.gz", "candidate2/candidate.py", "G07-retest-source-candidate-2", "ddd38fc035952771c5ef7d992aee0f7b4444129f559b7729bd3b2766d424af8c"),
 (JOBS[3], "passkey-r8-SAF-retest-peer-review-r1.tar.gz", "candidate.c71d.py", "SAF-retest-source-candidate-1", "c71d841702d6e544bba0bb7e42ca37b77062a0fb15b4e04966910a0a1294bf80"),
]:
    expected = ('import pathlib,hashlib\np=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r8/' + candidate_path
        + '/candidate.py")\nraw=p.read_bytes()\nassert hashlib.sha256(raw).hexdigest()=="' + sha
        + '"\nexec(compile(raw,str(p),"exec"))\n')
    check("supplementary_fixed_source_wrapper:" + job, requests[job]["stdin"] == expected and digest(member(archive, leaf)) == sha)

restore_code = literal_source(requests[JOBS[4]])
cleanup_wrapper = literal_source(requests[JOBS[5]])
release_code = literal_source(requests[JOBS[6]])
check("M07_restore_request_literal", digest(restore_code) == "21a0889ad4bf86c6bf35c74d31b96350350f4ec15b9c773610b02df054a31044")
check("M07_cleanup_request_is_pinned_wrapper", digest(cleanup_wrapper) == "899391024cd8f1aaaa72445ed0b8a9378e71b724394b53f8b2c504f6ee065ff9")
cleanup_core = pinned("runtime-bindings/sources/cleanup-executed-5f671.py", "5f671100aa0a34209ea0d24d4914dd5603e54b25e0cd97a028fe2211990db5a0")
check("M07_cleanup_wrapper_pins_reviewed_core", b"5f671100aa0a34209ea0d24d4914dd5603e54b25e0cd97a028fe2211990db5a0" in cleanup_wrapper and b"cleanup-source-candidate-1/candidate.py" in cleanup_wrapper)
check("release_request_matches_original_source", release_code == raw("runtime-bindings/sources/release-executed.py") and digest(release_code) == "0783677df45fbd2c2e00646ad5314b25b6c463f588a4b72980fe0437edb80ab9")

# Later canonical recorded terminal values are compared to earlier direct reads.
prior_list = obj("runtime-bindings/prior-release-terminals.public.json")
prior = {x["job_id"]: x for x in prior_list}
check("recorded_33_prior_terminal_jobs_unique", len(prior) == len(prior_list) == 33)
direct_statuses = {
 JOBS[0]: parse(member(g11_archive, "originals/runtime/reset_status_direct.tool-response.original.json")),
 JOBS[1]: parse(member(g11_archive, "originals/runtime/outcome_status_direct.tool-response.original.json")),
 JOBS[2]: parse(member("passkey-r8-G07-actual-outcome-peer-review-r1.tar.gz", "runtime-status.direct.tool-response.original.json")),
 JOBS[3]: parse(member("passkey-r8-SAF-actual-outcome-peer-review-r1.tar.gz", "runtime-status.direct.tool-response.original.json")),
 JOBS[6]: obj("observations/release-runtime-status.direct.tool-response.original.json"),
}
for job, direct in direct_statuses.items():
    check("actual_successful_terminal:" + job, direct["job_id"] == job and direct["state"] == "succeeded"
          and direct["exit_code"] == 0 and direct["output_complete"] is True and direct["output_durable"] is True)
    if job in prior:
        check("later_terminal_agrees_with_original_direct_read:" + job,
              all(prior[job][k] == direct[k] for k in ("job_id", "state", "exit_code", "launch_nonce", "output_complete", "output_durable")))
for job in JOBS:
    if job != JOBS[6]:
        p = prior[job]
        check("selected_job_terminal_in_release_inventory:" + job, p["state"] == "succeeded" and p["exit_code"] == 0 and p["output_complete"] is True and p["output_durable"] is True)

# Validate the newly supplied direct release log chunk against exact saved bytes.
read = obj("observations/release-runtime-read.direct.tool-response.original.json")
check("release_read_job_identity", read["job_id"] == JOBS[6])
for channel in ("stdout", "stderr"):
    chunk = read[channel]
    data = bytes.fromhex(chunk["bytes_hex"])
    check("release_original_log:" + channel, chunk["offset"] == 0 and chunk["size"] == len(data)
          and chunk["eof"] is True and data == raw("observations/release-runtime-" + channel + ".original.txt"))
release_stdout = parse(raw("observations/release-runtime-stdout.original.txt"))
ledger_raw = pinned("observations/case-results.public.json", "05a64950b8de86881315cc21239cee8bcc3550e6fa638f62d390f31195762341")
release_raw = pinned("observations/release-r8.public.json", "1a7733695f719f281c244379e383a3c39bba5ac9caf55c49b352ffeb6e76ab38")
cleanup_raw = pinned("observations/cleanup.result.public.json", "043ee37d7449d7dff676ae47d9fbe4884d60aa5d49ec14cf80d849570133d490")
supp_raw = pinned("observations/supplemental-three-case-results.public.json", "92f732ccc412d0e67f2d02e9e5f5f58e9fb4d14ab62f130c748c1e2244915dc9")
ledger, release, cleanup, supp = map(parse, (ledger_raw, release_raw, cleanup_raw, supp_raw))
check("direct_release_stdout_binds_final_originals", release_stdout["release_sha256"] == digest(release_raw)
      and release_stdout["case_ledger_sha256"] == digest(ledger_raw) and release_stdout["cleanup_sha256"] == digest(cleanup_raw))
counts = {"expected":18, "executed":18, "passed":16, "failed":2, "blocked":0, "missing":0}
check("original_eighteen_denominator_and_failures_preserved",
      all(ledger[k] == release[k] == v for k,v in counts.items())
      and len(ledger["cases"]) == len({c["id"] for c in ledger["cases"]}) == 18
      and all(c["executed"] is True for c in ledger["cases"])
      and {c["id"] for c in ledger["cases"] if c["status"] == "failed"} == {"G07","G10"})
check("separate_three_supplementary_profiles_not_merged", supp["expected"] == supp["executed"] == supp["passed"] == 3 and supp["failed"] == 0
      and supp["not_merged_into_original_eighteen"] is True and release["supplemental_separate_profile"]["not_merged"] is True
      and release["supplemental_separate_profile"]["sha256"] == digest(supp_raw))
supplemental_archives = [
 ("passkey-r8-G07-actual-outcome-peer-review-r1.tar.gz", "r8-G07-cancel-retest-1-result.public.json"),
 ("passkey-r8-SAF-actual-outcome-peer-review-r1.tar.gz", "r8-G08-unconsumed-target-retest-1-result.public.json"),
 ("passkey-r8-SAF-actual-outcome-peer-review-r1.tar.gz", "r8-G10-wrong-password-target-retest-1-result.public.json"),
]
for row, (archive, leaf) in zip(supp["cases"], supplemental_archives):
    check("supplement_result_binds_original:" + row["candidate"], row["status"] == "passed" and row["executed"] == row["expected"] == 1 and row["result_sha256"] == digest(member(archive, leaf)))
observations = {x["kind"]:x for x in ledger["observations"]}
gap = observations["control_plane_audit_gap"]
check("M05_original_launch_audit_gap_remains",
      gap["job"] == "1a1b14f4e13-fc05-77ab" and gap["original_launch_audit_recorded"] is False
      and gap["original_warning_preserved"] is True and gap["subsequent_product_success_does_not_repair_audit_gap"] is True)
check("G08_original_causal_limitation_remains", observations["original_G08_causal_evidence_limitation"]["prior_valid_Write_consumed_destination"] is True
      and release["original_G08_causal_gap_not_hidden"] is True)
check("G11_auxiliary_summary_correction_does_not_replace_original",
      observations["auxiliary_export_summary_reference_correction"]["originals_preserved"] is True)

g02 = parse(pinned("report-finalization/G02-result.reconciled.public.json", "259ae1af35bf83a86ba56cd2e4d4dc3d3e4e6365092f332a36f30f4866f56f89"))
check("G02_separate_report_preserves_original_failure", g02["status"] == "passed" and g02["new_phone_or_ADB_actions"] == 0
      and g02["original_runtime_job"] == "1a1b16c242d-fc05-7896" and g02["original_runtime_state"] == "failed"
      and g02["original_exit_code"] == 1 and g02["original_failure_preserved"] is True
      and prior[g02["original_runtime_job"]]["state"] == "failed" and prior[g02["original_runtime_job"]]["exit_code"] == 1)
check("G02_reconciliation_preserves_original_clock_limits",
      g02["candidate"]["negative_elapsed_conservative_wall_ns"] < 180_000_000_000
      and g02["candidate"]["index_elapsed_conservative_wall_ns"] < 300_000_000_000
      and g02["candidate"]["options_delta"] == 1 and g02["candidate"]["verification_attempts_delta"] == 0
      and g02["candidate"]["no_G02_reexecution"] is True)

restore = parse(raw("observations/M07-core-restore.stdout"))
rp_terminal = obj("observations/M07-rp-terminal.public.json")
rp_lines = [parse(x) for x in raw("observations/M07-rp-stopped.stdout").splitlines()]
check("M07_restore_observed_original_settings_packages_and_reverse", restore["exit_code"] == 0 and restore["phase"] == "restore"
      and all(v == "restored_original" for v in restore["result"]["restoration"].values())
      and len(restore["result"]["packages_removed"]) == 3 and restore["result"]["reverse_restoration"] == "removed_and_absence_verified")
check("M07_RP_stop_has_actual_terminal_and_stopped_record", rp_terminal["job_id"] == "1a1b10fd11a-fc05-7576"
      and rp_terminal["state"] == "cancelled" and rp_terminal["exit_code"] == 0
      and rp_terminal["output_complete"] is True and rp_terminal["output_durable"] is True
      and rp_lines[-1] == {"status":"synthetic_rp_stopped"}
      and release["rp_stopped_stdout_sha256"] == digest(raw("observations/M07-rp-stopped.stdout")))
check("M07_release_after_exact_owned_cleanup", cleanup["owned_document_count"] == release["owned_files_count"] == 12
      and cleanup["owned_directory_count"] == release["owned_directories_count"] == 6
      and all(cleanup[k] is True for k in ("owned_documents_absent","owned_media_index_absent","packages_absent_including_retained","settings_match_original","reverse_absent"))
      and all(release[k] is True for k in ("released","owned_documents_and_media_index_absent","owned_directory_media_rows_absent","owned_packages_absent_including_retained","settings_match_original","owned_reverse_absent","rp_stop_observed_before_document_cleanup"))
      and cleanup["settings_sha256"] == release["settings_sha256"]
      and cleanup["rp"] == ledger["rp_final_public_state"])
check("scope_is_not_production_or_broad_P4_qualification", all(x["production_qualified"] is False for x in (ledger,release,cleanup,supp,g02))
      and ledger["p4_qualified"] is False and release["p4_qualified"] is False
      and release["credential_entry"] == "synthetic_only_adb_input_text_child_argv")
check("review_performed_no_network_subprocess_or_ADB", not blocked_external_calls)
print(json.dumps({
 "schema":1, "scope":"read_only_binding_and_final_outcome_consistency",
 "ok":True, "checks_passed":len(checks), "checks":checks,
 "original_profile":counts, "supplemental_profile":{"expected":3,"executed":3,"passed":3,"failed":0,"merged":False},
 "nested_original_archives":7, "selected_source_manifest_originals":31,
 "source_manifest_total":112, "all_112_files_included":False,
 "new_device_actions":0,"new_ADB_actions":0,"network_calls":0,"subprocess_calls":0,
 "external_security_review":False,"production_qualified":False,"p4_qualified":False,
 "request_launch_serialization":"canonical copies of recorded structured values, not original wire JSON or cryptographic attestation",
 "M05_original_audit_gap_preserved":True
},sort_keys=True,indent=2))

