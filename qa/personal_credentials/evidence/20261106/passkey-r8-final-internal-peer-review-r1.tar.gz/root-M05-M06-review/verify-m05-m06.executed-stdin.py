from pathlib import Path,PurePosixPath
import hashlib,json,stat
base=Path('/workspace/scratch/heptabao-p0-recovery-20261106/passkey-r8-G11-review/originals'); r=base/'live-r8'
def load(n): return json.loads((r/n).read_bytes())
def sha(n): return hashlib.sha256((r/n).read_bytes()).hexdigest()
idx=load('G11-inputs-index.public.json')
assert sha('G11-inputs-index.public.json')=='f3e22f8699a7a69249e6038d58a407abe5cbdf6d9c3887df4c9f8e0ab1c0f847'
assert len(idx['files'])==52
for e in idx['files']:
 rel=PurePosixPath(e['path']).relative_to('/home/alex/HeptaBaoPasskey-20261106-r8');assert '..' not in rel.parts
 p=base/rel;assert stat.S_ISREG(p.lstat().st_mode)
 b=p.read_bytes();assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256'],e['path']
m05=load('M05-result.public.json');m06=load('M06-result.public.json');before=load('M06-rp-before.public.json');after=load('M06-rp-after.public.json')
assert sha('M05-result.public.json')=='c79d52f5d89bf17709356592d9a1089ab81dabe5fc55afeaed92a98552d9346e'
assert sha('M06-result.public.json')=='b8bce609cf195eb24cb351836d7cd33a0010a1679c269e9f6f54e1c572327afd'
assert m05['status']==m06['status']=='passed' and m05['ordinary_saf'] is True and m05['observed_unlocked_public_count']==1
assert m05['new_process_observation']['observed_after_verified_old_process_absence'] is True and m05['new_process_observation']['provider_pid_count']==1
assert m05['reset_result_sha256']==sha('provider-reset-M05-result.public.json')
assert m05['completion_witness_sha256']==sha('provider-reset-M05-completion.public.json')
note=load('M05-rp-serialization-note.public.json')
assert sha(note['original_canonical_file'])==note['original_canonical_file_sha256']
assert sha(note['raw_response_file'])==note['raw_response_sha256']
assert load(note['original_canonical_file'])==load(note['raw_response_file'])==before
assert m05['rp_after_sha256']==sha('M06-rp-before.public.json')==m06['rp_before_sha256']=='d25d8324649b04a77f93597dc328f5e54bad391e2ceee95324d638db0979b4f0'
assert m06['rp_after_sha256']==sha('M06-rp-after.public.json')=='be993ea820161bf2e802407fd6f15a47c302112bf63d482ce0cff13195da9ee3'
assert m06['rp_after']==after and m06['independent_rp_submissions_by_wrapper']==0
assert m06['challenge_and_ticket_limit_seconds']==180 and 0<m06['cm_begin_to_observation_ns']<180_000_000_000
b,a=before['credentials'][0],after['credentials'][0]
assert before['credential_count']==after['credential_count']==1
assert b['credential_id']==a['credential_id']=='MoAAtn4aJbaUv3-_S5n-QV7-qpGospx1kxLVxhIZaRc'
assert b['public_key_sha256']==a['public_key_sha256']=='77831f62d82845291f2128f6ba6c9466fe8cc40d44086267b13de2dc19b7ff75'
assert (b['sign_count'],a['sign_count'],b['flags'],a['flags'])==(1,2,13,29)
assert before['counters']['authentications']==1 and after['counters']['authentications']==2
assert before['counters']['registrations']==after['counters']['registrations']==1
assert before['counters']['rejected']==after['counters']['rejected']==0
assert after['counters']['options']==before['counters']['options']+1
launch=load('M05_RESTORE-runtime-launch.public.json');s05=load('M05_RESTORE-runtime-terminal.public.json');s06=load('M06-runtime-terminal.public.json')
assert launch['audit_recorded'] is False and launch['audit_warning']=='Operation result retained; completion audit unavailable. Reconcile using the existing job_id.'
assert launch['job']['id']==s05['job_id']=='1a1b14f4e13-fc05-77ab' and s06['job_id']=='1a1b1520d2f-fc05-77ba'
for s in (s05,s06):
 assert s['state']=='succeeded' and s['exit_code']==0 and s['output_complete'] is True and s['output_durable'] is True and s['terminal_publication_confirmed'] is True and s['automatic_retry'] is False
out={'schema':1,'scope':'internal_read_only_M05_M06_original_receipt_semantic_binding_review','whitelist_files_verified':52,'whitelist_sha256':sha('G11-inputs-index.public.json'),'M05_receipt_sha256':sha('M05-result.public.json'),'M06_receipt_sha256':sha('M06-result.public.json'),'ordinary_SAF_new_process_restore_observed_in_receipt':True,'same_public_credential_and_key':True,'sign_count_before':1,'sign_count_after':2,'flags_before':13,'flags_after':29,'RP_authentications_before':1,'RP_authentications_after':2,'CM_elapsed_ns':m06['cm_begin_to_observation_ns'],'original_challenge_ticket_limit_seconds':180,'M05_RP_original_canonical_and_later_raw_values_equal':True,'later_raw_observation_not_relabelled_as_earlier_original':True,'M05_launch_audit_warning_preserved':True,'later_terminal_audit_success_does_not_fill_launch_audit_gap':True,'review_phone_actions':0,'review_network_calls':0,'G11_admitted_by_this_review':False,'entire_phone_profile_qualified_by_this_review':False,'physical_device_migration_qualified':False,'external_security_review':False,'production_qualified':False}
p=Path('/workspace/scratch/heptabao-root-recovery-20261106/passkey-r8-review');p.mkdir(exist_ok=True)
f=p/'root-M05-M06-semantic-review.public.json';f.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2));print(json.dumps({'file':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}))
