# r8 Passkey internal review — final evidence synthesis

The original fixed profile ends at **18 executed, 16 passed, 2 failed, 0 missing and 0 blocked**. The original G07 and G10 failures remain. Three later, independently declared one-case profiles passed separately. They are recorded as **3/3 supplementary cases**, never as a replacement 18/18 or a combined 21/21.

This packet gathers seven unchanged review archives and the newly supplied original request/launch bindings, final G02 reconciliation, cleanup and release evidence. It is an internal review of the exact synthetic r8 combination. It grants no production qualification, broad P4 support or external security approval.

## What the observations establish

- **M05/M06:** an owned provider data reset was followed by ordinary SAF restore in a fresh process and a real Credential Manager authentication. The accepted credential/public key stayed the same; the counter moved from 1 to 2 and flags from 13 to 29. This happened on the same physical phone. The original M05 restore launch reported `audit_recorded=false`; its warning remains.
- **G11:** a current counter-2 recovery backup was preserved before a separately admitted single reset. Restoring the earlier counter-1 ciphertext through ordinary SAF and using the real Credential Manager path produced an RP `counter_rollback_or_replay` rejection. The accepted counter and public key did not change.
- **G02:** the original device job failed during create-only report publication after its actual wrong-password conditions had been observed. The original failed job and output remain. A later host-only reconciliation published a separate behavior result without another phone action.
- **Supplementary G07:** one Back left Operation, a second Back closed the same-request chooser, and the fixture received the exact cancellation callback. The negative path took 25.356217615 seconds and the public-index interval 78.139060865 seconds, within the original 180/300-second bounds. No verification or accepted credential/counter change followed.
- **Supplementary G08/G10:** ordinary SAF selected new, unconsumed destinations. The test placed the fixed 615-byte synthetic ciphertext into each previously empty, owned target to supply a nonempty preservation baseline. This was explicit QA preparation, not a successful product export. G08 then started a new picker and cancelled; valid-password Write was refused with `choose_backup_destination_first`. G10 used a wrong password and was refused with `wrong_key_or_corrupt`. Both preserved the target bytes and RP state. The product clears the old target when it starts a new picker; the evidence does not attribute this clearing to the Cancel callback.
- **M07/release:** the recorded restore and independent release found the original three settings restored, three owned packages absent including retained package entries, the owned reverse absent, and the RP stopped with a terminal cancellation/exit0 and its explicit stopped record. Twelve owned files, six owned directories and their checked media entries were absent at PV's handoff.

The original G08 result has a narrower meaning because its setup had already consumed the old destination with a valid Write. That limitation and the original G07/G10 failures are present in the final ledger and are not repaired by relabeling them.

## New bindings and preserved originals

The seven files in `nested/` are exact frozen archives, with their original SHA256 values. Existing notes inside those archives which said request/launch material was still missing are not edited. This packet appends that subsequently retrieved material and closes the selected gaps.

`runtime-bindings/source-full-manifest.original.public.json` is the original inventory of 112 files. The existing selected manifest covers 28 of those originals. Three additional G02 finalization request/launch/binding files are in `report-finalization/`, for **31 selected source-manifest members** in total. The inventory's remaining files are not claimed to be included here. The G02 reconciled result is an additional original report.

The copied request/launch files are canonical JSON of originally recorded structured tool values. They are not raw wire captures or cryptographic attestation. The new source bindings match the frozen G11 source, G07 `ddd38...` candidate and SAF `c71d...` candidate. M07 cleanup has two distinct layers: request wrapper `899391...` verifies and executes cleanup core `5f671...`. The release request's literal source matches `078367...`.

Earlier direct Runtime status/log reads remain in the nested outcome packages. Their immutable terminal identity, launch nonce, state and completion fields agree with the later recorded terminal values. The newly retrieved release has its own direct Runtime status/read original and exact stdout/stderr bytes.

The four files in `root-M05-M06-review/` are root's original separate internal semantic review, restored byte-for-byte from its preserved originals. They were not rerun for this aggregate.

## Verification performed for this packet

`verify_final_bindings.py` reads metadata and frozen archive members; it does not execute product or controller source. It completed **121 consistency assertions**, including original archive identities, selected source-manifest entries, eight request/launch/binding chains, AST-bound wrappers, terminal agreement, fixed denominators, original failures, G02 reconciliation, cleanup and release. This count is not a device-case count.

The actual argv, source SHA, stdout, stderr and exit status are in `consistency.execution.public.json` and its associated original output files. The checker denies network and external-process calls and made no ADB call.

The first checker attempt is retained under `checker-first-attempt/`. It incorrectly required a newline where the actual SAF wrapper used a semicolon. The final check compares the complete ordered AST, including literal paths, hash assertion and execution expression; the original device/source evidence did not change.

To repeat only this read-only consistency check after extraction:

```bash
python3 -B /absolute/path/to/packet/verify_final_bindings.py /absolute/path/to/packet
```

## Limits and review ownership

This is evidence for the pinned synthetic native application, certificate, device and private RP. It does not establish physical cross-device Passkey migration, arbitrary websites or Digital Asset Links, general platform compatibility, production credential safety or an external security audit. The test password entry used the acknowledged synthetic-only ADB input child argv path; it is not evidence of a production no-argv credential path.

The M05 launch audit gap remains. The G11 auxiliary export's original wrong summary reference and separate correction remain. Earlier independent local r8 input/reset 20/55 output originals were lost in the first scratch reset and have not been reconstructed or passed off as recovered. Other author originals and subsequent fresh checks are separate records.

p0_audit performed the internal peer review but also authored ancestor reset safety code and some earlier diagnostics/host controls. PV authored and operated the r8 phone workflow; root provided the separate M05/M06 internal semantic review. These roles do not constitute independent external review.

Only explicitly allowlisted synthetic metadata, source, controlled logs and frozen review packets are included. Private-named reset metadata inside earlier packets contains parameters, hashes and state; raw passwords, recovery keys, signing keys, encrypted vault payloads and raw private journals are excluded. The release assertions apply to the observed PV handoff point, not to later authorized work on the phone.

