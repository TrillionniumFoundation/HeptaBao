#!/usr/bin/env python3
"""Independent host-only rerun of the frozen r7 reset helper; no device I/O."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

PINS = {
    "passkey_reset_provider_r7.py": "f321cb6033ac3245291805dd72123e7f732c571b785ad74b2b14307a8054f6db",
    "passkey_reset_provider.r5b.py": "2a21f7bcc013abab41f3eba38f612afb6ec869933aee438053a7a5abc81cf48b",
    "passkey_live.py": "e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd",
    "passkey_phone_profile_r7.py": "a568f1e51f4d4e6c096b0b871bb7a9be5f7da88cf3aef39fca17e59bf8564706",
    "profile.public.json": "8a2c3e83c878ea5a6c6d646f94559d0de5154fd9b8210604bcdc879349a7165d",
    "build.public.json": "e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b",
}
LAUNCHER = r'''import json, os, runpy, sys, urllib.request, unittest.mock
from pathlib import Path
audit_path, helper, driver = map(Path, sys.argv[1:])
blocked = []
def guard(event, args):
    if event.startswith("socket.") or event in {
        "subprocess.Popen", "os.system", "os.posix_spawn", "os.posix_spawnp", "os.exec", "pty.spawn"
    }:
        blocked.append(event)
        raise AssertionError("independent_host_external_call_forbidden")
sys.addaudithook(guard)
sys.argv = [str(helper), "--driver", str(driver), "--self-test"]
try:
    runpy.run_path(str(helper), run_name="__main__")
finally:
    data = (json.dumps({"schema": 1, "scope": "python_audit_external_call_guard", "blocked_event_names": blocked,
        "attempted_external_events": len(blocked), "actual_adb_calls": 0, "actual_network_calls": 0}, sort_keys=True) + "\n").encode()
    fd = os.open(audit_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())
'''

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())
    assert path.read_bytes() == data

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", type=Path, required=True)
    args = parser.parse_args()
    work = args.work.absolute()
    work.mkdir(mode=0o700)
    source = Path(__file__).resolve().parent / "source"
    inputs = {name: (source / name).read_bytes() for name in PINS}
    assert {name: sha(data) for name, data in inputs.items()} == PINS
    old = ast.parse(inputs["passkey_reset_provider.r5b.py"])
    new = ast.parse(inputs["passkey_reset_provider_r7.py"])
    nodes = lambda tree: {n.name: ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    old_nodes, new_nodes = nodes(old), nodes(new)
    unchanged = [name for name in old_nodes if old_nodes[name] == new_nodes.get(name)]
    assert all(name in unchanged for name in ("main", "execute_reset", "private_read", "reset_history", "rp_state", "read_rp", "validate_stale_input", "backup_observation", "provider_pid"))
    old_validate = next(n for n in old.body if isinstance(n, ast.FunctionDef) and n.name == "validate_inputs")
    new_validate = next(n for n in new.body if isinstance(n, ast.FunctionDef) and n.name == "validate_inputs")
    assert ast.dump(new_validate.body[0], include_attributes=False) == ast.dump(ast.parse("validate_fixed_build(build, build_sha)").body[0], include_attributes=False)
    new_validate.body.pop(0)
    assert ast.dump(old_validate, include_attributes=False) == ast.dump(new_validate, include_attributes=False)
    profile_tree = ast.parse(inputs["passkey_phone_profile_r7.py"])
    profile = next(ast.literal_eval(n.value) for n in profile_tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "PROFILE" for t in n.targets))
    assert profile == json.loads(inputs["profile.public.json"])
    constants = {}
    for node in new.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and isinstance(node.value, ast.Constant):
            constants[node.targets[0].id] = ast.literal_eval(node.value)
    build = json.loads(inputs["build.public.json"])
    assert constants["PROFILE_SOURCE_SHA256"] == PINS["passkey_phone_profile_r7.py"]
    assert constants["PROFILE_PUBLIC_SHA256"] == PINS["profile.public.json"]
    assert constants["BUILD_RECEIPT_SHA256"] == profile["build_receipt_sha256"] == PINS["build.public.json"]
    assert constants["PROVIDER_APK_SHA256"] == profile["provider_apk_sha256"] == build["artifacts"]["provider"]["sha256"]
    assert constants["FIXTURE_CERT_SHA256"] == profile["fixture_certificate_sha256"] == build["fixture_certificate_sha256"] == build["artifacts"]["fixture-good"]["certificate_sha256"]
    launcher = work / "deny_external_calls.py"
    write(launcher, LAUNCHER.encode())
    argv = [sys.executable, "-B", str(launcher), str(work / "external-guard.public.json"), str(source / "passkey_reset_provider_r7.py"), str(source / "passkey_live.py")]
    started = time.time_ns()
    completed = subprocess.run(argv, capture_output=True, cwd=work, timeout=60, env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
    finished = time.time_ns()
    write(work / "stdout.original.json", completed.stdout)
    write(work / "stderr.original.txt", completed.stderr)
    assert completed.returncode == 0, "frozen_helper_host_test_failed"
    report = json.loads(completed.stdout)
    audit = json.loads((work / "external-guard.public.json").read_bytes())
    assert audit["attempted_external_events"] == 0
    after = {name: sha((source / name).read_bytes()) for name in PINS}
    assert after == PINS
    receipt = {"schema": 1, "scope": "independent_host_only_frozen_helper_review", "external_security_review": False,
        "started_unix_ns": started, "finished_unix_ns": finished, "argv": argv, "cwd": str(work),
        "environment_override": {"PYTHONDONTWRITEBYTECODE": "1"}, "python_executable_sha256": sha(Path(sys.executable).read_bytes()),
        "exit_code": completed.returncode, "stdout_sha256": sha(completed.stdout), "stderr_sha256": sha(completed.stderr),
        "input_sha256_before": PINS, "input_sha256_after": after, "unchanged_ast_nodes": unchanged,
        "validate_inputs_delta_only_fixed_build_call": True, "fixed_profile_build_apk_certificate_crosscheck": True,
        "helper_report": report, "external_guard": audit, "actual_reset_executed": False,
        "phone_qualification_inferred": False, "old_results_inherited": False}
    write(work / "receipt.public.json", (json.dumps(receipt, indent=2, sort_keys=True) + "\n").encode())
    fd = os.open(work, os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(fd)
    finally: os.close(fd)
    print(json.dumps({"work": str(work), "receipt_sha256": sha((work / "receipt.public.json").read_bytes()), "helper_report": report, "attempted_external_events": 0}, sort_keys=True))

if __name__ == "__main__":
    main()
