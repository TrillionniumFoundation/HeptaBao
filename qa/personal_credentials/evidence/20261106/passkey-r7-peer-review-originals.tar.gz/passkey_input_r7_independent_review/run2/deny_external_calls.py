import json, os, runpy, sys, urllib.request, unittest.mock
from pathlib import Path
audit_path, helper, driver = map(Path, sys.argv[1:])
blocked = []
def guard(event, args):
    if event.startswith("socket.") or event in {
        "subprocess.Popen", "os.system", "os.posix_spawn", "os.posix_spawnp", "os.exec", "pty.spawn"
    }:
        blocked.append(event)
        raise AssertionError("independent_host_external_call_forbidden")
sys.addaudithook(guard)
sys.argv = [str(helper), "--driver", str(driver), "--self-test"]
try:
    runpy.run_path(str(helper), run_name="__main__")
finally:
    data = (json.dumps({"schema": 1, "scope": "python_audit_external_call_guard", "blocked_event_names": blocked,
        "attempted_external_events": len(blocked), "actual_adb_calls": 0, "actual_network_calls": 0}, sort_keys=True) + "\n").encode()
    fd = os.open(audit_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())
