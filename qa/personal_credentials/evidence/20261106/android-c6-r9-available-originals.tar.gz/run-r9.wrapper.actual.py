#!/usr/bin/env python3
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
os.umask(0o077)
base=Path('/home/alex/heptabao-android-autofill-20261106-r1')
qa=base/'android_live.revision12.py'
build=base/'candidate6/build-receipt.json'
release=Path('/home/alex/HeptaBaoPasskey-20261106-r7/release-r7.public.json')
output=base/'run-r9'
adb=Path('/home/alex/.local/bin/adb')
expected={
 str(qa):'7443b8115260ac08feb23dbdd8c9e14ed448933380642b0c53d5f4d60cf10c9c',
 str(build):'327060e7d1a5bb5edd3634307a448d9e87c3cb578a3a2b5e09cc1b256760a33e',
 str(release):'810a8267bc196622bcfacac2f7d52f031c7eb567fcd302c7c3f87d581be6d8a9',
 str(base/'candidate6/artifact-review.json'):'9ef1698dfe6deafb77cd495fa48039652e61303968232da90b899c4170d4a148',
 str(base/'candidate6/stage.public.json'):'7f6e44db3b4f979b23bfcb2e9de8a209607b5208219815f56292e898f652fd39',
 str(base/'candidate6/source.manifest.public.json'):'b2e977c7ef7214676ee1247c33d92cf5d43ed5c6f08aa3223842acf7e0f786c4',
 str(base/'candidate6/public-transport/source.tar.gz'):'d887e60f986302bb731a9591c260a2eaf8e24161a5cefe39a6b9c40e6d812400',
 str(base/'candidate6/apks/provider.apk'):'10028da82fede388096362d0bf2c6d106bd1e8823a12c17c022f8115adcf262a',
 str(base/'candidate6/apks/fixture-good.apk'):'fe132993d1ffae96987af214456bd1804a5ed12b844e5ea9bbd0531109d8f035',
 str(base/'candidate6/apks/fixture-wrong-certificate.apk'):'fea79164c6693ff393bbf8ec01a64302c919bb34c7f90ced13dd7963139aac3b',
 str(base/'candidate6/apks/fixture-wrong-package.apk'):'9c2e196fe270f87d373e32df0a63ff7773fdad25aca0db9c2f81acfac0609422'}
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write_once(path,obj):
 data=(json.dumps(obj,sort_keys=True,indent=2)+chr(10)).encode()
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as stream: stream.write(data);stream.flush();os.fsync(stream.fileno())
 parent=os.open(Path(path).parent,os.O_RDONLY|os.O_DIRECTORY)
 try: os.fsync(parent)
 finally: os.close(parent)
 return hashlib.sha256(data).hexdigest()
try:
 if output.exists() or output.is_symlink(): raise ValueError()
 before={path:digest(path) for path in expected}
 if before!=expected: raise ValueError()
 adb_before=digest(adb)
 argv=['/usr/bin/python3','-u',str(qa),'--adb',str(adb),'--apks',str(base/'candidate6/apks'),'--build-receipt',str(build),'--master-file',str(base/'master.private'),'--output',str(output)]
 binding={'schema':1,'candidate':'android-autofill-candidate6','run':'r9','qa_revision':12,'expected_case_count':12,'synthetic_only':True,'production_qualified':False,'credential_entry':'synthetic_only_adb_input_text_argv','device_exclusive_handoff':'passkey-r7-release-sha256-bound','argv':argv,'input_sha256':before,'adb_sha256':adb_before,'wrapper_sha256':digest(__file__),'created_unix_ns':time.time_ns()}
 binding_sha=write_once(base/'run-r9.launch.public.json',binding)
 print(json.dumps({'phase':'launch_bound','run':'r9','qa_sha256':expected[str(qa)],'binding_sha256':binding_sha}),flush=True)
 started=time.time_ns()
 proc=subprocess.run(argv,check=False)
 after={path:digest(path) for path in expected};adb_after=digest(adb)
 execution={'schema':1,'run':'r9','launch_binding_sha256':binding_sha,'started_unix_ns':started,'finished_unix_ns':time.time_ns(),'exit_code':proc.returncode,'input_sha256_before':before,'input_sha256_after':after,'inputs_unchanged':before==after,'adb_sha256_before':adb_before,'adb_sha256_after':adb_after,'adb_unchanged':adb_before==adb_after,'wrapper_sha256':digest(__file__)}
 if (output/'report.json').is_file(): execution['phone_report_sha256']=digest(output/'report.json')
 execution_sha=write_once(base/'run-r9.execution.public.json',execution)
 print(json.dumps({'phase':'execution_finished','run':'r9','exit_code':proc.returncode,'inputs_unchanged':before==after,'adb_unchanged':adb_before==adb_after,'execution_sha256':execution_sha}),flush=True)
 sys.exit(proc.returncode if before==after and adb_before==adb_after else 1)
except Exception:
 print(json.dumps({'ok':False,'error':'launch_or_execution_binding_failed','run':'r9'}),flush=True)
 sys.exit(1)
