import pathlib,hashlib,json,os,runpy,fcntl,urllib.request,subprocess,stat
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 side=root/"documents.private.json";plan=json.loads(m["private_file"](side,65536));path="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7/HeptaBao-passkey-backup.hbv"
 matches=[x for x in plan["files"] if x["path"]==path];assert len(matches)==1 and matches[0]["initial_absent"] is True and matches[0]["write_intent"] is True and matches[0]["written"] is False
 assert d.shell("test","-f",path)=="" and d.shell("test","!","-L",path)==""
 size=int(d.shell("stat","-c","%s",path));assert 615<size<=8*1024*1024
 digest=d.shell("sha256sum",path).split()[0];assert len(digest)==64
 got=d.adb_call("exec-out","cat",path,timeout=30);assert got.returncode==0 and not got.stderr and len(got.stdout)==size and hashlib.sha256(got.stdout).hexdigest()==digest
 p=b/"private/M04-phone-backup.hbv";fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  with os.fdopen(fd,"wb",closefd=False) as f:f.write(got.stdout);f.flush();os.fsync(f.fileno())
 finally:os.close(fd)
 parent=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(parent);os.close(parent)
 assert hashlib.sha256(m["private_file"](p,8*1024*1024)).hexdigest()==digest
 with urllib.request.urlopen("http://127.0.0.1:38491/state",timeout=5) as response:assert response.status==200;rpraw=response.read(1048577)
 before=m["private_file"](root/"M04-rp-before.public.json",1048576);assert rpraw==before;rp=json.loads(rpraw)
 events=[]
 for candidate in (b/"attempts").glob("*.result.public.json"):
  raw=m["private_file"](candidate,1048576);v=json.loads(raw)
  if v["case"]=="M04" and v["phase"]=="inspect" and v["exit_code"]==0 and any(n.get("text")=="Encrypted backup written and read-back verified" for n in v.get("result",{}).get("nodes",[])):
   events.append((v["finished_unix_ns"],candidate,raw,v))
 assert len(events)==1;_,eventpath,eventraw,event=events[0]
 matches[0].update({"written":True,"sha256":digest,"bytes":size,"ciphertext_captured_private":True});m["atomic"](side,plan)
 public={"schema":1,"case":"M04","observed_outcome":"passed","ordinary_saf_export":True,"ui_status":"Encrypted backup written and read-back verified","ui_event_file":eventpath.name,"ui_event_sha256":hashlib.sha256(eventraw).hexdigest(),"actual_write_job":"1a1b0cf52e8-fc05-7320","backup":{"path":path,"bytes":size,"sha256":digest},"private_capture_readback_verified":True,"rp_before_sha256":hashlib.sha256(before).hexdigest(),"rp_after_sha256":hashlib.sha256(rpraw).hexdigest(),"rp_raw_unchanged":True,"credential":rp["credentials"][0],"build_receipt_sha256":"e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b","core_driver_sha256":"e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd","input_helper_sha256":"0ba29978acd83d7cccad6ff4d25d4ee32304c2c2584a02b74fee28be8db87f56","reset_authorized_by_this_receipt":False}
 m["atomic"](root/"M04-observed-backup.public.json",public);print(json.dumps(public,sort_keys=True),flush=True)
finally:os.close(lock)
steps=[{"phase":"tap","selector":"CHOOSE ENCRYPTED VAULT FILE"},{"phase":"tap","selector_kind":"description","selector":"显示根目录"},{"phase":"tap","selector":"下载"},{"phase":"tap","selector":"HeptaBao-Passkey-QA-20261106-r7"},{"phase":"tap","selector":"heptabao-passkey-qa-r7-seed.hbv"},{"phase":"inspect"},{"phase":"input-master","wrong":True},{"phase":"hide-keyboard"},{"phase":"tap","selector":"IMPORT ENCRYPTED VAULT INTO A FRESH STORE"},{"phase":"inspect"}]
r=subprocess.run(["/usr/bin/python3",str(b/"run_phases.input-r7.public.py"),"--case","G01","--steps",json.dumps(steps)],check=False);raise SystemExit(r.returncode)
