import pathlib,hashlib,json,os,runpy,fcntl,subprocess
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py";runner=b/"run_phases.input-r7.public.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 j=json.loads(m["private_file"](root/"journal.private.json",8*1024*1024));raw=m["private_file"](b/"artifacts/build.receipt.json",1048576);assert hashlib.sha256(raw).hexdigest()=="e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b"
 m["validate_journal"](j,json.loads(raw),"e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b");assert {k:d.setting(k) for k in m["SETTING_KEYS"]}==j["owned_settings"];assert d.package_hash(m["PROVIDER"])=="b16e82916330fac6909f82696089798c3ec76d7b4058fe9290e7e841b9e00459"
 side=root/"documents.private.json";plan=json.loads(m["private_file"](side,65536));base="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7";assert plan["directory"]==base and plan["directory_created"] is True and "subdirectories" not in plan
 plan["subdirectories"]=[]
 for case in ["G08","G10"]:
  directory=base+"/"+case+"-target";path=directory+"/HeptaBao-passkey-backup.hbv"
  q=d.adb_call("shell","if [ -e "+directory+" ] || [ -L "+directory+" ]; then printf EXISTS; else printf ABSENT; fi");assert q.returncode==0 and q.stdout==b"ABSENT" and not q.stderr
  plan["subdirectories"].append({"path":directory,"source_case":case,"initial_absent":True,"create_intent":True,"created":False})
  plan["files"].append({"path":path,"source_case":case,"initial_absent":True,"write_intent":True,"written":False,"sha256":None,"bytes":None})
 m["atomic"](side,plan)
 for item in plan["subdirectories"]:
  assert d.shell("mkdir",item["path"])=="";assert d.shell("test","-d",item["path"])=="";assert d.shell("test","!","-L",item["path"])==""
  item["created"]=True;m["atomic"](side,plan)
 public={"schema":1,"case":"G08/G10","owned_empty_subdirectories_created":True,"prior_intent_durable":True,"directories":[x["path"] for x in plan["subdirectories"]],"no_backup_modified":True,"case_passed":False}
 m["atomic"](root/"G08-G10-destination-intents.public.json",public);print(json.dumps(public,sort_keys=True),flush=True)
finally:os.close(lock)
def phases(steps):
 r=subprocess.run(["/usr/bin/python3",str(runner),"--case","G08","--steps",json.dumps(steps)],capture_output=True)
 print(r.stdout.decode("utf-8","strict"),end="",flush=True)
 if r.stderr:print(json.dumps({"fixed_error":"driver_stderr_present","stderr_bytes":len(r.stderr)}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 return [json.loads(x) for x in r.stdout.decode("utf-8","strict").splitlines()]
phases([{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"UNLOCK PUBLIC CREDENTIAL LIST"},{"phase":"inspect"},{"phase":"tap","selector":"CHOOSE ENCRYPTED BACKUP DESTINATION"},{"phase":"tap","selector_kind":"description","selector":"显示根目录"},{"phase":"tap","selector":"下载"},{"phase":"tap","selector":"HeptaBao-Passkey-QA-20261106-r7"},{"phase":"tap","selector":"G08-target"},{"phase":"inspect"}])
lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 foreground,nodes=d.ui();assert foreground==("com.google.android.documentsui","com.android.documentsui.picker.PickActivity")
 fields=[n for n in nodes if n.get("package")=="com.google.android.documentsui" and n.get("class")=="android.widget.EditText" and n.get("resource-id")=="android:id/title"]
 assert len(fields)==1 and fields[0].get("text")=="HeptaBao-passkey-backup.hbv"
 assert any(n.get("resource-id")=="com.google.android.documentsui:id/breadcrumb_text" and n.get("text")=="G08-target" for n in nodes)
 m["atomic"](root/"G08-picker-target.public.json",{"schema":1,"case":"G08","exact_owned_directory_verified":True,"fixed_leaf":"HeptaBao-passkey-backup.hbv","case_passed":False})
finally:os.close(lock)
phases([{"phase":"tap","selector":"保存"},{"phase":"inspect"}])
