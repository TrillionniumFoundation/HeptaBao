import pathlib,hashlib,json,os,runpy,fcntl,subprocess
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py";runner=b/"run_phases.input-r7.public.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));side=root/"documents.private.json";path="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7/G10-target/HeptaBao-passkey-backup.hbv";original="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7/HeptaBao-passkey-backup.hbv"
def lock():
 fd=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);return fd
def info(path):
 assert d.shell("test","-f",path)=="" and d.shell("test","!","-L",path)==""
 return {"path":path,"bytes":int(d.shell("stat","-c","%s",path)),"sha256":d.shell("sha256sum",path).split()[0]}
fd=lock()
try:
 foreground,nodes=d.ui();assert foreground==("org.heptabao.passkey.preview","org.heptabao.passkey.preview.HomeActivity") and any(n.get("text")=="Destination chosen; enter password and write encrypted backup" for n in nodes)
 before=info(path);assert before["bytes"]==0 and before["sha256"]==hashlib.sha256(b"").hexdigest()
 saved=info(original);assert saved["bytes"]==2064 and saved["sha256"]=="6dc86b115179d0db22cdc8c2c7d1a8457d97bb78b4fdda6daf065e91e7f036a1"
 plan=json.loads(m["private_file"](side,65536));matches=[x for x in plan["files"] if x["path"]==path];assert len(matches)==1 and matches[0]["initial_absent"] is True and matches[0]["written"] is False
 matches[0].update({"written":True,"created_by_ordinary_picker":True,"bytes":before["bytes"],"sha256":before["sha256"]});m["atomic"](side,plan)
 m["atomic"](root/"G10-destination-before.public.json",{"schema":1,"case":"G10","capture_after_ordinary_picker_before_wrong_password":True,"destination":before,"M04_backup":saved,"case_passed":False})
finally:os.close(fd)
steps=[{"phase":"input-master","wrong":True},{"phase":"hide-keyboard"},{"phase":"tap","selector":"WRITE ENCRYPTED BACKUP TO CHOSEN FILE"},{"phase":"inspect"}]
r=subprocess.run(["/usr/bin/python3",str(runner),"--case","G10","--steps",json.dumps(steps)],capture_output=True);print(r.stdout.decode("utf-8","strict"),end="",flush=True)
if r.stderr:print(json.dumps({"fixed_error":"driver_stderr_present","stderr_bytes":len(r.stderr)}),flush=True)
if r.returncode:raise SystemExit(r.returncode)
events=[json.loads(x) for x in r.stdout.decode("utf-8","strict").splitlines()]
assert any(n.get("text")=="wrong_key_or_corrupt" for n in events[-1]["result"]["nodes"])
fd=lock()
try:
 after=info(path);after_saved=info(original);assert after==before and after_saved==saved
 result={"schema":1,"case":"G10","observed_outcome":"passed","ordinary_picker_destination_chosen":True,"baseline_after_picker_before_wrong_password":True,"wrong_synthetic_password_entered":True,"ui_refusal":"wrong_key_or_corrupt","before":before,"after":after,"M04_backup_unchanged":True,"case_passed_by_phase":False}
 m["atomic"](root/"G10-observed-result.public.json",result);print(json.dumps(result,sort_keys=True),flush=True)
finally:os.close(fd)
