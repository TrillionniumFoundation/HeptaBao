import pathlib,hashlib,json,os,runpy,fcntl,urllib.request,subprocess,time
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));m["private_directory"](root);d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 j=json.loads(m["private_file"](root/"journal.private.json",8*1024*1024));buildraw=m["private_file"](b/"artifacts/build.receipt.json",1024*1024);assert hashlib.sha256(buildraw).hexdigest()=="e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b"
 m["validate_journal"](j,json.loads(buildraw),"e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b");assert {k:d.setting(k) for k in m["SETTING_KEYS"]}==j["owned_settings"]
 assert d.package_hash(m["PROVIDER"])=="b16e82916330fac6909f82696089798c3ec76d7b4058fe9290e7e841b9e00459"
 side=root/"documents.private.json";plan=json.loads(m["private_file"](side,65536));directory="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7";destination=directory+"/HeptaBao-passkey-backup.hbv"
 assert plan["directory"]==directory and plan["directory_created"] is True and all(x["path"]!=destination for x in plan["files"])
 q=d.adb_call("shell","if [ -e "+destination+" ] || [ -L "+destination+" ]; then printf EXISTS; else printf ABSENT; fi")
 assert q.returncode==0 and q.stdout==b"ABSENT" and q.stderr==b""
 plan["files"].append({"path":destination,"initial_absent":True,"write_intent":True,"written":False,"source_case":"M04","sha256":None,"bytes":None});m["atomic"](side,plan)
 with urllib.request.urlopen("http://127.0.0.1:38491/state",timeout=5) as response:
  assert response.status==200;rpraw=response.read(1048577)
 assert len(rpraw)<=1048576;rp=json.loads(rpraw);assert rp["credential_count"]==1 and rp["credentials"][0]["public_key_sha256"]=="588a26a1d8d77142d66b59be5d93c9c8191b5131b16bc266c09406a2fbd8cce5" and rp["credentials"][0]["sign_count"]==0
 p=root/"M04-rp-before.public.json";fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 try:
  with os.fdopen(fd,"wb",closefd=False) as f:f.write(rpraw);f.flush();os.fsync(f.fileno())
 finally:os.close(fd)
 parent=os.open(root,os.O_RDONLY|os.O_DIRECTORY);os.fsync(parent);os.close(parent)
 public={"schema":1,"case":"M04","scope":"pre_action_owned_destination_intent","destination":destination,"initial_absent":True,"rp_snapshot_sha256":hashlib.sha256(rpraw).hexdigest(),"rp_revision":rp["revision"],"credential":rp["credentials"][0],"documents_journal_sha256":hashlib.sha256(side.read_bytes()).hexdigest(),"case_passed":False}
 m["atomic"](root/"M04-export-intent.public.json",public);print(json.dumps(public,sort_keys=True),flush=True)
finally:os.close(lock)
steps=[{"phase":"launch-provider"},{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"UNLOCK PUBLIC CREDENTIAL LIST"},{"phase":"inspect"},{"phase":"tap","selector":"CHOOSE ENCRYPTED BACKUP DESTINATION"},{"phase":"inspect"}]
r=subprocess.run(["/usr/bin/python3",str(b/"run_phases.input-r7.public.py"),"--case","M04","--steps",json.dumps(steps)],check=False);raise SystemExit(r.returncode)
