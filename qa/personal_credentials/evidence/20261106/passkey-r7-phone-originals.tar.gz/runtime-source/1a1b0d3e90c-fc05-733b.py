import pathlib,subprocess,json
b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7")
sets=[("G01",[{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"UNLOCK PUBLIC CREDENTIAL LIST"},{"phase":"inspect"},{"phase":"rp-state"}]),("G09",[{"phase":"tap","selector":"CHOOSE ENCRYPTED VAULT FILE"},{"phase":"tap","selector_kind":"description","selector":"显示根目录"},{"phase":"tap","selector":"下载"},{"phase":"tap","selector":"HeptaBao-Passkey-QA-20261106-r7"},{"phase":"tap","selector":"heptabao-passkey-qa-r7-seed.hbv"},{"phase":"inspect"},{"phase":"tap","selector":"CHOOSE ENCRYPTED VAULT FILE"},{"phase":"back"},{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"IMPORT ENCRYPTED VAULT INTO A FRESH STORE"},{"phase":"inspect"}])]
for case,steps in sets:
 r=subprocess.run(["/usr/bin/python3",str(b/"run_phases.input-r7.public.py"),"--case",case,"--steps",json.dumps(steps)],check=False)
 if r.returncode:raise SystemExit(r.returncode)
