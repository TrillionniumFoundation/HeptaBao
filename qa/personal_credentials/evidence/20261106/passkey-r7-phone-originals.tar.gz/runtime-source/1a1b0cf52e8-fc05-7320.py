import pathlib,hashlib,json,runpy,os,fcntl,subprocess
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 foreground,nodes=d.ui();assert foreground==("com.google.android.documentsui","com.android.documentsui.picker.PickActivity")
 names=[n for n in nodes if n.get("package")=="com.google.android.documentsui" and n.get("class")=="android.widget.EditText" and n.get("resource-id")=="android:id/title"]
 assert len(names)==1 and names[0].get("text")=="HeptaBao-passkey-backup.hbv"
 assert any(n.get("resource-id")=="com.google.android.documentsui:id/breadcrumb_text" and n.get("text")=="HeptaBao-Passkey-QA-20261106-r7" for n in nodes)
 public={"schema":1,"case":"M04","ordinary_picker_destination_verified":True,"fixed_leaf":"HeptaBao-passkey-backup.hbv","fixed_owned_directory":"HeptaBao-Passkey-QA-20261106-r7","arbitrary_picker_text_output":False}
 m["atomic"](root/"M04-picker-target.public.json",public);print(json.dumps(public,sort_keys=True),flush=True)
finally:os.close(lock)
steps=[{"phase":"tap","selector":"保存"},{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"WRITE ENCRYPTED BACKUP TO CHOSEN FILE"},{"phase":"inspect"},{"phase":"rp-state"}]
r=subprocess.run(["/usr/bin/python3",str(b/"run_phases.input-r7.public.py"),"--case","M04","--steps",json.dumps(steps)],check=False);raise SystemExit(r.returncode)
