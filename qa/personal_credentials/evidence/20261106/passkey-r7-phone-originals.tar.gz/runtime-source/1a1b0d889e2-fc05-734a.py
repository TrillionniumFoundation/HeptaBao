import pathlib,subprocess,json
b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");runner=b/"run_phases.input-r7.public.py"
def phases(steps):
 r=subprocess.run(["/usr/bin/python3",str(runner),"--case","G09","--steps",json.dumps(steps)],capture_output=True)
 print(r.stdout.decode("utf-8","strict"),end="",flush=True)
 if r.stderr:print(json.dumps({"fixed_error":"driver_stderr_present","stderr_bytes":len(r.stderr)}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 return [json.loads(x) for x in r.stdout.decode("utf-8","strict").splitlines()]
ready=False
for i in range(4):
 event=phases([{"phase":"inspect"}])[-1];ui=event["result"];foreground=ui["foreground"]
 if foreground==["org.heptabao.passkey.preview","org.heptabao.passkey.preview.HomeActivity"]:
  assert any(n.get("text")=="Document selection cancelled" for n in ui["nodes"]);ready=True;break
 assert foreground==["com.google.android.documentsui","com.android.documentsui.picker.PickActivity"]
 phases([{"phase":"back"}])
assert ready
phases([{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"IMPORT ENCRYPTED VAULT INTO A FRESH STORE"},{"phase":"inspect"},{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"UNLOCK PUBLIC CREDENTIAL LIST"},{"phase":"inspect"},{"phase":"rp-state"}])
