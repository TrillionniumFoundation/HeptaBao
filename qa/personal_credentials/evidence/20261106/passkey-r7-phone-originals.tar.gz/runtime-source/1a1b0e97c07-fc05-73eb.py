import runpy,pathlib,json,hashlib,os,fcntl,stat,time,socket,re
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 journal=json.loads(m["private_file"](root/"journal.private.json",8*1024*1024));buildraw=m["private_file"](b/"artifacts/build.receipt.json",1048576);assert hashlib.sha256(buildraw).hexdigest()=="e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b";m["validate_journal"](journal,json.loads(buildraw),"e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b")
 assert all(v=="restored_original" for v in journal["restoration"].values())
 assert {k:d.setting(k) for k in m["SETTING_KEYS"]}==journal["original_settings"]
 assert all(d.package_hash(p) is None for p in m["OWNED"])
 reverse=d.adb_call("reverse","--list");assert reverse.returncode==0 and not reverse.stderr and not any("tcp:38491" in row for row in reverse.stdout.decode().splitlines())
 side=root/"documents.private.json";raw=m["private_file"](side,65536);plan=json.loads(raw)
 directory="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7";canonical_directory="/storage/emulated/0/Download/HeptaBao-Passkey-QA-20261106-r7"
 assert plan["device_sha256"]==m["DEVICE_SHA256"] and plan["directory"]==directory and plan["initial_directory_absent"] is True and plan["directory_created"] is True
 seed="bb527d9aa00987a243b378ac31eb15d2caf203e106348a8e1ed60cff7f674917";backup="6dc86b115179d0db22cdc8c2c7d1a8457d97bb78b4fdda6daf065e91e7f036a1";empty=hashlib.sha256(b"").hexdigest()
 expected={directory+"/heptabao-passkey-qa-r7-seed.hbv":(615,seed),directory+"/HeptaBao-passkey-backup.hbv":(2064,backup)}
 subdirectories=[directory+"/G08-target",directory+"/G10-target"]
 for path in subdirectories:
  expected[path+"/heptabao-passkey-qa-r7-seed.hbv"]=(615,seed);expected[path+"/HeptaBao-passkey-backup.hbv"]=(0,empty)
 assert len(plan["files"])==6 and set(x["path"] for x in plan["files"])==set(expected)
 assert len(plan["subdirectories"])==2 and set(x["path"] for x in plan["subdirectories"])==set(subdirectories)
 for item in plan["subdirectories"]:assert item["initial_absent"] is True and item["create_intent"] is True and item["created"] is True
 for item in plan["files"]:
  path=item["path"];size,digest=expected[path];assert item["initial_absent"] is True and item["write_intent"] is True and item["written"] is True and item["bytes"]==size and item["sha256"]==digest
  info=d.shell("stat","-c","%f %s",path).split();assert len(info)==2 and stat.S_ISREG(int(info[0],16)) and int(info[1])==size
  assert d.shell("test","!","-L",path)=="" and d.shell("sha256sum",path).split()[0]==digest and d.shell("readlink","-f",path)==path.replace("/sdcard/","/storage/emulated/0/",1)
 preserved=m["private_file"](b/"private/M04-phone-backup.hbv",8*1024*1024);assert len(preserved)==2064 and hashlib.sha256(preserved).hexdigest()==backup
 for path in subdirectories+[directory]:
  assert d.shell("test","-d",path)=="" and d.shell("test","!","-L",path)==""
 # All descendant media rows must belong to the predeclared exact owned files/directories.
 allowed={x.replace("/sdcard/","/storage/emulated/0/",1) for x in list(expected)+subdirectories}
 index=d.shell("content","query","--uri","content://media/external/file","--projection","_id:_data","--where","_data LIKE '"+canonical_directory+"/%'")
 rows=[] if index=="No result found." else index.splitlines()
 for line in rows:
  match=re.fullmatch(r"Row: \d+ _id=\d+, _data=(.+)",line);assert match and match.group(1) in allowed
 with (root/"documents.before-cleanup.private.json").open("xb") as out:out.write(raw);out.flush();os.fsync(out.fileno())
 parent=os.open(root,os.O_RDONLY|os.O_DIRECTORY);os.fsync(parent);os.close(parent)
 plan["cleanup_intent_unix_ns"]=time.time_ns();plan["cleanup_exact_paths"]=sorted(expected);plan["cleanup_exact_directories"]=subdirectories+[directory];m["atomic"](side,plan)
 def absent(path):
  q=d.adb_call("shell","if [ -e "+path+" ] || [ -L "+path+" ]; then printf EXISTS; else printf ABSENT; fi")
  assert q.returncode==0 and q.stdout==b"ABSENT" and not q.stderr
 def media_absent(path):
  assert d.shell("content","query","--uri","content://media/external/file","--projection","_id","--where","_data='"+path+"'")=="No result found."
 for path in sorted(expected):
  canonical=path.replace("/sdcard/","/storage/emulated/0/",1);d.shell("rm","--",path);absent(path);absent(canonical)
  for indexed in [path,canonical]:
   d.shell("content","delete","--uri","content://media/external/file","--where","_data='"+indexed+"'");media_absent(indexed)
 for path in subdirectories+[directory]:
  assert d.shell("ls","-A",path)=="";d.shell("rmdir",path)
  for indexed in [path,path.replace("/sdcard/","/storage/emulated/0/",1)]:
   absent(indexed);d.shell("content","delete","--uri","content://media/external/file","--where","_data='"+indexed+"'");media_absent(indexed)
 assert d.shell("content","query","--uri","content://media/external/file","--projection","_id","--where","_data LIKE '"+canonical_directory+"/%'")=="No result found."
 final_settings={k:d.setting(k) for k in m["SETTING_KEYS"]};assert final_settings==journal["original_settings"] and all(d.package_hash(p) is None for p in m["OWNED"])
 reverse=d.adb_call("reverse","--list");assert reverse.returncode==0 and not reverse.stderr and not any("tcp:38491" in row for row in reverse.stdout.decode().splitlines())
 with socket.socket() as sock:sock.settimeout(3);assert sock.connect_ex(("127.0.0.1",38491))!=0
 rpraw=m["private_file"](b/"rp-r7/result.manifest.json",1048576);rpmanifest=json.loads(rpraw);rp=rpmanifest["state"];rpstate=m["private_file"](b/"rp-r7/state.public.json",4*1048576)
 assert rpmanifest["source_sha256"]=="386de84bb5335f21998a000b4a1267eaa17fadbde1e1753d5df1c30325709a63" and rpmanifest["state_sha256"]==hashlib.sha256(rpstate).hexdigest()
 assert rp["credential_count"]==1 and rp["counters"]["registrations"]==1 and rp["counters"]["authentications"]==0 and rp["counters"]["options"]==2
 assert rp["credentials"][0]["credential_id"]=="8gyD2VEc9HRwh-E-E8gSMSbZpckKiQCU58DUw1M7qXc" and rp["credentials"][0]["public_key_sha256"]=="588a26a1d8d77142d66b59be5d93c9c8191b5131b16bc266c09406a2fbd8cce5" and rp["credentials"][0]["sign_count"]==0
 plan["cleanup_complete"]=True;plan["cleaned_unix_ns"]=time.time_ns();m["atomic"](side,plan)
 report={"schema":1,"ok":True,"scope":"r7_synthetic_phone_cleanup","settings_match_original":True,"settings_sha256":{k:hashlib.sha256(v.encode()).hexdigest() for k,v in final_settings.items()},"packages_absent":True,"owned_packages":sorted(m["OWNED"]),"retained_package_records_checked":True,"reverse_absent":True,"owned_documents_absent":True,"owned_document_count":6,"owned_directory_count":3,"owned_media_index_absent":True,"media_alias_and_canonical_checked":True,"owned_directory_media_rows_checked":True,"M04_ciphertext_private_capture_preserved":True,"master_entered":True,"credential_entry":"synthetic_only_adb_input_text_argv","credential_manager_create_exercised":True,"credential_manager_get_completed":False,"rp":rp,"rp_last_manifest_sha256":hashlib.sha256(rpraw).hexdigest(),"rp_server_terminal_scope":"configured_3600_second_timeout_after_create_and_failed_get","rp_port_closed":True,"production_qualified":False,"completed_unix_ns":time.time_ns()}
 m["atomic"](root/"cleanup.result.public.json",report)
 phases=[];events=[]
 for path in sorted((b/"attempts").glob("*.result.public.json")):
  raw=m["private_file"](path,1048576);value=json.loads(raw);events.append(value)
  phases.append({"file":path.name,"sha256":hashlib.sha256(raw).hexdigest(),"case":value["case"],"phase":value["phase"],"exit_code":value["exit_code"],"error":value.get("result",{}).get("error")})
 def has_text(case,text):
  return any(x["case"]==case and x["phase"]=="inspect" and x["exit_code"]==0 and any(n.get("text")==text for n in x.get("result",{}).get("nodes",[])) for x in events)
 assert has_text("M01","Unlocked public list: 0 passkeys; five minute limit")
 assert any(x["case"]=="M02" and x["phase"]=="rp-state" and x.get("result",{}).get("rp",{}).get("counters",{}).get("registrations")==1 for x in events)
 assert has_text("M03","platform_invocation_failed")
 assert has_text("G01","wrong_key_or_corrupt") and has_text("G01","Unlocked public list: 1 passkeys; five minute limit")
 assert has_text("G09","choose_encrypted_vault_first") and has_text("G09","Unlocked public list: 1 passkeys; five minute limit")
 for case,file in [("M04","M04-observed-backup.public.json"),("G08","G08-observed-result.public.json"),("G10","G10-observed-result.public.json")]:
  assert json.loads(m["private_file"](root/file,1048576))["observed_outcome"]=="passed"
 old=m["private_file"](b/"case-results.public.json",4*1048576);ledger=json.loads(old);assert len(ledger["cases"])==18 and all(x["status"]=="missing" for x in ledger["cases"])
 with (b/"case-results.initial.public.json").open("xb") as out:out.write(old);out.flush();os.fsync(out.fileno())
 descriptions={
 "M01":"ordinary_SAF_full_retry_import_with_0ba_input_supplement",
 "M02":"real_Android_CredentialManager_create_provider_approval_and_independent_RP_registration",
 "M04":"ordinary_SAF_encrypted_backup_written_and_readback_verified",
 "G01":"wrong_master_import_refused_and_existing_one_credential_reopened",
 "G08":"new_export_selection_cancelled_old_target_not_reused",
 "G09":"new_import_selection_cancelled_old_stage_not_reused",
 "G10":"wrong_master_export_refused_destination_unchanged_after_picker_baseline",
 "M07":"settings_packages_reverse_documents_media_and_RP_listener_cleanup"}
 for row in ledger["cases"]:
  case=row["id"]
  if case in descriptions:
   row.update(status="passed",executed=True,evidence=[{"observation":descriptions[case],"phase_results":[x for x in phases if x["case"]==case]}])
  elif case=="M03":
   row.update(status="failed",executed=True,evidence=[{"ui_code":"platform_invocation_failed","rp_authentication_options_issued":True,"accepted_authentications":0,"accepted_counter":0,"inference":"fixed_fixture_omits_normal_allowed_provider_permission_required_by_platform_contract","actual_exception_class_observed":False,"permission_granted_during_run":False,"phase_results":[x for x in phases if x["case"]==case]}])
  else:
   row.update(status="blocked",executed=False,evidence=[{"prerequisite":"M03","reason":"no_successful_get_positive_control_for_fixed_fixture;new_permission_only_fixture_requires_new_complete_profile_run"}])
 counts={key:sum(x["status"]==key for x in ledger["cases"]) for key in ("passed","failed","blocked","missing")}
 assert counts=={"passed":8,"failed":1,"blocked":9,"missing":0}
 ledger.update(expected=18,executed=sum(x["executed"] for x in ledger["cases"]),**counts,p4_qualified=False,production_qualified=False,master_entered=True,credential_entry="synthetic_only_adb_input_text_argv",credential_manager_exercised=True,credential_manager_create_verified=True,credential_manager_get_verified=False,reset_executed=False,phase_evidence=phases,failed_phase_attempts=[x for x in phases if x["exit_code"]!=0],initial_ledger_sha256=hashlib.sha256(old).hexdigest(),cleanup_sha256=hashlib.sha256((root/"cleanup.result.public.json").read_bytes()).hexdigest(),input_helper_sha256="0ba29978acd83d7cccad6ff4d25d4ee32304c2c2584a02b74fee28be8db87f56",phase_runner_sha256="3b50d89e0688e640453025c8994aa787f4f527a880062e3e1cf8538429dd8eff",input_supplement_admission_sha256="1436ad8b01b53568336766a37556f4bcedff73868e7e382f67ec379f7cbd5462",runtime_source_bundle_sha256="e2e79c7e35a507c11ba2a52a67c5a4882528d2447fa1c489977a64ad992f91b6",provider_apk_sha256="b16e82916330fac6909f82696089798c3ec76d7b4058fe9290e7e841b9e00459",rp_final_public_state=rp)
 ledger["observations"]=[
 {"kind":"input_guard_before_supplement","job":"1a1b0b6744d-fc05-724e","error":"password_field_not_empty","master_read_or_entered":False,"preserved":True},
 {"kind":"CM_transition_inspect","job":"1a1b0c44067-fc05-72b6","error":"focused_window_unavailable","create_tap_had_occurred":True,"subsequent_settled_system_selector_observed":True,"preserved":True},
 {"kind":"picker_navigation_guard","job":"1a1b0d3e90c-fc05-733b","error":"password_activity_changed","master_read_or_entered_for_failed_phase":False,"preserved":True},
 {"kind":"unindexed_owned_folder_preparation","job":"1a1b0df864e-fc05-7381","error":"ui_target_not_unique","no_unknown_target_clicked":True,"later_exact_owned_ciphertext_indexing":True,"preserved":True},
 {"kind":"RP_runtime_limit","job":"1a1b0aea36c-fc05-7224","state":"timed_out","exit_code":124,"timeout_seconds":3600,"after_CM_create_and_failed_get":True,"not_a_credential_rejection_case":True}]
 m["atomic"](b/"case-results.public.json",ledger)
 print(json.dumps({"ok":True,"cleanup_path":str(root/"cleanup.result.public.json"),"cleanup_sha256":hashlib.sha256((root/"cleanup.result.public.json").read_bytes()).hexdigest(),"ledger_path":str(b/"case-results.public.json"),"ledger_sha256":hashlib.sha256((b/"case-results.public.json").read_bytes()).hexdigest(),"expected":18,"executed":9,**counts,"settings_match_original":True,"packages_absent":True,"reverse_absent":True,"owned_documents_absent":True,"owned_media_index_absent":True,"owned_files":6,"owned_directories":3,"master_entered":True,"credential_manager_create_verified":True,"credential_manager_get_verified":False,"reset_executed":False},sort_keys=True),flush=True)
finally:os.close(lock)
