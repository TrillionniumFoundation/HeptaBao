import pathlib,hashlib,os,json,runpy,fcntl,subprocess,sys,time
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");driver=b/"passkey_live.r7.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));root=b/"live-r7";m["private_directory"](b);m["private_directory"](root);d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"))
lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 j=json.loads(m["private_file"](root/"journal.private.json",8*1024*1024));buildraw=(b/"artifacts/build.receipt.json").read_bytes();assert hashlib.sha256(buildraw).hexdigest()=="e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b";build=json.loads(buildraw);m["validate_journal"](j,build,"e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b")
 assert {k:d.setting(k) for k in m["SETTING_KEYS"]}==j["owned_settings"]
 profile=(b/"profile.public.json").read_bytes();assert hashlib.sha256(profile).hexdigest()=="8a2c3e83c878ea5a6c6d646f94559d0de5154fd9b8210604bcdc879349a7165d"
 with (root/"profile.public.json").open("xb") as f:f.write(profile);f.flush();os.fsync(f.fileno())
 directory="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7";destination=directory+"/heptabao-passkey-qa-r7-seed.hbv"
 source=b/"artifacts/seed.hbv";raw=source.read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest=="bb527d9aa00987a243b378ac31eb15d2caf203e106348a8e1ed60cff7f674917" and len(raw)==615
 assert d.shell("test","-d","/sdcard/Download")==""
 q=d.adb_call("shell","if [ -e "+directory+" ] || [ -L "+directory+" ]; then printf EXISTS; else printf ABSENT; fi")
 assert q.returncode==0 and q.stdout==b"ABSENT" and q.stderr==b""
 side=root/"documents.private.json";assert not side.exists()
 plan={"schema":1,"device_sha256":m["DEVICE_SHA256"],"directory":directory,"initial_directory_absent":True,"mkdir_intent":True,"directory_created":False,"files":[{"path":destination,"sha256":digest,"bytes":len(raw),"initial_absent":True,"write_intent":True,"written":False}],"started_unix_ns":time.time_ns()}
 m["atomic"](side,plan)
 assert d.shell("mkdir",directory)==""
 plan["directory_created"]=True;m["atomic"](side,plan)
 # Newly created owned directory; only ciphertext is copied and later removed by its exact digest.
 pushed=d.adb_call("push",source,destination,timeout=30);assert pushed.returncode==0
 assert d.shell("sha256sum",destination).split()[0]==digest
 assert int(d.shell("stat","-c","%s",destination))==len(raw)
 plan["files"][0]["written"]=True;m["atomic"](side,plan)
 canonical=d.shell("readlink","-f",destination);assert canonical=="/storage/emulated/0/Download/HeptaBao-Passkey-QA-20261106-r7/heptabao-passkey-qa-r7-seed.hbv"
 d.shell("am","broadcast","--user","0","-a","android.intent.action.MEDIA_SCANNER_SCAN_FILE","-d","file://"+destination)
 deadline=time.monotonic()+10
 while True:
  index=d.shell("content","query","--uri","content://media/external/file","--projection","_id:_data","--where","_data='"+canonical+"'")
  if "_data="+canonical in index and len(index.splitlines())==1:break
  assert time.monotonic()<deadline
  time.sleep(0.25)
 public={"media_index_confirmed":True,"ok":True,"scope":"synthetic_ciphertext_file_staging_only","directory_initial_absent":True,"directory":directory,"canonical_path":canonical,"seed_sha256":digest,"seed_bytes":len(raw),"single_owned_file_media_scan_requested":True,"documents_journal_sha256":hashlib.sha256(side.read_bytes()).hexdigest(),"profile_public_sha256":hashlib.sha256(profile).hexdigest()}
 m["atomic"](root/"documents-prepared.public.json",public);print(json.dumps(public,sort_keys=True),flush=True)
finally:os.close(lock)
steps=json.loads("[{\"phase\":\"tap\",\"selector\":\"CHOOSE ENCRYPTED VAULT FILE\"},{\"phase\":\"tap\",\"selector_kind\":\"description\",\"selector\":\"显示根目录\"},{\"phase\":\"tap\",\"selector\":\"下载\"},{\"phase\":\"tap\",\"selector\":\"HeptaBao-Passkey-QA-20261106-r7\"},{\"phase\":\"tap\",\"selector\":\"heptabao-passkey-qa-r7-seed.hbv\"},{\"phase\":\"inspect\"}]")
r=subprocess.run(["/usr/bin/python3",str(b/"run_phases.public.py"),"--case","M01","--steps",json.dumps(steps)],check=False)
raise SystemExit(r.returncode)
