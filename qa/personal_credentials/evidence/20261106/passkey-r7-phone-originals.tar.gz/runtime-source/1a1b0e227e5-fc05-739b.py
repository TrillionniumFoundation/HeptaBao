import pathlib,hashlib,json,os,runpy,fcntl,subprocess,time
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py";runner=b/"run_phases.input-r7.public.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 side=root/"documents.private.json";plan=json.loads(m["private_file"](side,65536));base="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7";assert plan["directory"]==base and plan["directory_created"] is True
 source=b/"artifacts/seed.hbv";raw=m["private_file"](source,4096);digest=hashlib.sha256(raw).hexdigest();assert len(raw)==615 and digest=="bb527d9aa00987a243b378ac31eb15d2caf203e106348a8e1ed60cff7f674917"
 additions=[]
 for case in ["G08","G10"]:
  directory=base+"/"+case+"-target";path=directory+"/heptabao-passkey-qa-r7-seed.hbv"
  assert any(x["path"]==directory and x["created"] is True for x in plan["subdirectories"]) and all(x["path"]!=path for x in plan["files"])
  q=d.adb_call("shell","if [ -e "+path+" ] || [ -L "+path+" ]; then printf EXISTS; else printf ABSENT; fi");assert q.returncode==0 and q.stdout==b"ABSENT" and not q.stderr
  item={"path":path,"source_case":case,"initial_absent":True,"write_intent":True,"written":False,"sha256":digest,"bytes":615,"purpose":"owned_ciphertext_marker_for_media_index"};plan["files"].append(item);additions.append(item)
 m["atomic"](side,plan)
 for item in additions:
  pushed=d.adb_call("push",source,item["path"],timeout=30);assert pushed.returncode==0 and d.shell("sha256sum",item["path"]).split()[0]==digest
  item["written"]=True;m["atomic"](side,plan)
  canonical=d.shell("readlink","-f",item["path"]);assert canonical==item["path"].replace("/sdcard/","/storage/emulated/0/",1)
  d.shell("am","broadcast","--user","0","-a","android.intent.action.MEDIA_SCANNER_SCAN_FILE","-d","file://"+item["path"])
  deadline=time.monotonic()+10
  while True:
   index=d.shell("content","query","--uri","content://media/external/file","--projection","_id:_data","--where","_data='"+canonical+"'")
   if "_data="+canonical in index and len(index.splitlines())==1:break
   assert time.monotonic()<deadline;time.sleep(0.25)
 public={"schema":1,"case":"G08/G10","owned_ciphertext_markers_indexed":True,"sha256":digest,"bytes_each":615,"paths":[x["path"] for x in additions],"no_plaintext_staging":True,"case_passed":False}
 m["atomic"](root/"G08-G10-media-index.public.json",public);print(json.dumps(public,sort_keys=True),flush=True)
finally:os.close(lock)
def phases(steps):
 r=subprocess.run(["/usr/bin/python3",str(runner),"--case","G08","--steps",json.dumps(steps)],capture_output=True);print(r.stdout.decode("utf-8","strict"),end="",flush=True)
 if r.stderr:print(json.dumps({"fixed_error":"driver_stderr_present","stderr_bytes":len(r.stderr)}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 return [json.loads(x) for x in r.stdout.decode("utf-8","strict").splitlines()]
phases([{"phase":"tap","selector_kind":"description","selector":"显示根目录"},{"phase":"tap","selector":"下载"},{"phase":"tap","selector":"HeptaBao-Passkey-QA-20261106-r7"},{"phase":"tap","selector":"G08-target"},{"phase":"inspect"}])
lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 foreground,nodes=d.ui();assert foreground==("com.google.android.documentsui","com.android.documentsui.picker.PickActivity")
 fields=[n for n in nodes if n.get("package")=="com.google.android.documentsui" and n.get("class")=="android.widget.EditText" and n.get("resource-id")=="android:id/title"]
 assert len(fields)==1 and fields[0].get("text")=="HeptaBao-passkey-backup.hbv"
 assert any(n.get("resource-id")=="com.google.android.documentsui:id/breadcrumb_text" and n.get("text")=="G08-target" for n in nodes)
 m["atomic"](root/"G08-picker-target.public.json",{"schema":1,"case":"G08","exact_owned_directory_verified":True,"fixed_leaf":"HeptaBao-passkey-backup.hbv","case_passed":False})
finally:os.close(lock)
phases([{"phase":"tap","selector":"保存"},{"phase":"inspect"}])
