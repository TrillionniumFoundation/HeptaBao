import pathlib,hashlib,json,os,tarfile,io,stat
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7")
s=b.lstat();assert stat.S_ISDIR(s.st_mode) and s.st_uid==os.geteuid() and stat.S_IMODE(s.st_mode)==0o700 and str(b)==str(b.resolve())
raw=(b/"input-supplement.tar.gz").read_bytes();assert hashlib.sha256(raw).hexdigest()=="09314229f72c57ff3329ad092e19f01faa0be3c8183a93f7dbbeb80fd5542f94"
expected={"passkey_input_r7.py":{"bytes":15637,"sha256":"0ba29978acd83d7cccad6ff4d25d4ee32304c2c2584a02b74fee28be8db87f56"},"run_phases.input-r7.public.py":{"bytes":4867,"sha256":"3b50d89e0688e640453025c8994aa787f4f527a880062e3e1cf8538429dd8eff"},"input-admission.public.json":{"bytes":5107,"sha256":"1436ad8b01b53568336766a37556f4bcedff73868e7e382f67ec379f7cbd5462"}}
with tarfile.open(fileobj=io.BytesIO(raw),mode="r:gz") as t:
 members=t.getmembers();assert len(members)==len(expected) and set(x.name for x in members)==set(expected)
 for x in members:
  assert x.isfile() and "/" not in x.name and x.size==expected[x.name]["bytes"]
  data=t.extractfile(x).read();assert hashlib.sha256(data).hexdigest()==expected[x.name]["sha256"]
  fd=os.open(b/x.name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
  try:
   with os.fdopen(fd,"wb",closefd=False) as f:f.write(data);f.flush();os.fsync(f.fileno())
  finally:os.close(fd)
d=os.open(b,os.O_RDONLY|os.O_DIRECTORY);os.fsync(d);os.close(d)
for name,info in expected.items():
 p=b/name;s=p.lstat();assert stat.S_ISREG(s.st_mode) and s.st_uid==os.geteuid() and stat.S_IMODE(s.st_mode)==0o600 and s.st_nlink==1
 assert hashlib.sha256(p.read_bytes()).hexdigest()==info["sha256"]
print(json.dumps({"ok":True,"scope":"host_only_supplement_ingress","adb_calls":0,"files":expected},sort_keys=True))
