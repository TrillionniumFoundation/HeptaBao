import pathlib,hashlib,os,json,runpy,fcntl,time
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));m["private_directory"](root);d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"))
lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 raw=m["private_file"](root/"journal.private.json",8*1024*1024);j=json.loads(raw);buildraw=m["private_file"](b/"artifacts/build.receipt.json",1024*1024)
 assert hashlib.sha256(buildraw).hexdigest()=="e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b"
 m["validate_journal"](j,json.loads(buildraw),"e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b")
 foreground,nodes=d.ui();assert foreground==(m["PROVIDER"],m["PROVIDER"]+".HomeActivity")
 fields=[n for n in nodes if n.get("package")==m["PROVIDER"] and n.get("password")=="true" and n.get("class")=="android.widget.EditText"]
 assert len(fields)==1;n=fields[0]
 public={"schema":1,"read_only":True,"foreground":foreground,"field_count":len(fields),"hint_present":"hint" in n.attrib,"hint_equals_fixed_source_hint":n.get("hint")=="Vault password","hint_is_true":n.get("hint")=="true","hint_empty":not n.get("hint"),"field_attribute_names":sorted(n.attrib),"text_empty":not n.get("text"),"text_equals_fixed_source_hint":n.get("text")=="Vault password","password":n.get("password"),"class":n.get("class"),"enabled":n.get("enabled"),"focused":n.get("focused"),"raw_ui_saved":False,"master_read":False,"master_entered":False,"build_receipt_sha256":hashlib.sha256(buildraw).hexdigest(),"previous_guard_failure_job":"1a1b0b6744d-fc05-724e"}
 m["atomic"](root/"input-hint-attributes.public.json",public);print(json.dumps(public,sort_keys=True))
finally:os.close(lock)
