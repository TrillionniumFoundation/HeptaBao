import pathlib,hashlib,json,os,runpy,fcntl,subprocess
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py";runner=b/"run_phases.input-r7.public.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));side=root/"documents.private.json";path="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7/G08-target/HeptaBao-passkey-backup.hbv";original="/sdcard/Download/HeptaBao-Passkey-QA-20261106-r7/HeptaBao-passkey-backup.hbv"
def lock(): 
 fd=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB);return fd
def info(path):
 assert d.shell("test","-f",path)=="" and d.shell("test","!","-L",path)==""
 return {"path":path,"bytes":int(d.shell("stat","-c","%s",path)),"sha256":d.shell("sha256sum",path).split()[0]}
fd=lock()
try:
 foreground,nodes=d.ui();assert foreground==("org.heptabao.passkey.preview","org.heptabao.passkey.preview.HomeActivity") and any(n.get("text")=="Destination chosen; enter password and write encrypted backup" for n in nodes)
 before=info(path);assert before["bytes"]==0 and before["sha256"]==hashlib.sha256(b"").hexdigest()
 saved=info(original);assert saved["bytes"]==2064 and saved["sha256"]=="6dc86b115179d0db22cdc8c2c7d1a8457d97bb78b4fdda6daf065e91e7f036a1"
 plan=json.loads(m["private_file"](side,65536));matches=[x for x in plan["files"] if x["path"]==path];assert len(matches)==1 and matches[0]["initial_absent"] is True and matches[0]["written"] is False
 matches[0].update({"written":True,"created_by_ordinary_picker":True,"bytes":before["bytes"],"sha256":before["sha256"]});m["atomic"](side,plan)
 m["atomic"](root/"G08-destination-before.public.json",{"schema":1,"case":"G08","capture_after_ordinary_picker":True,"destination":before,"M04_backup":saved,"case_passed":False})
finally:os.close(fd)
def phases(case,steps):
 r=subprocess.run(["/usr/bin/python3",str(runner),"--case",case,"--steps",json.dumps(steps)],capture_output=True);print(r.stdout.decode("utf-8","strict"),end="",flush=True)
 if r.stderr:print(json.dumps({"fixed_error":"driver_stderr_present","stderr_bytes":len(r.stderr)}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 return [json.loads(x) for x in r.stdout.decode("utf-8","strict").splitlines()]
phases("G08",[{"phase":"tap","selector":"CHOOSE ENCRYPTED BACKUP DESTINATION"}])
ready=False
for i in range(6):
 event=phases("G08",[{"phase":"inspect"}])[-1];ui=event["result"]
 if ui["foreground"]==["org.heptabao.passkey.preview","org.heptabao.passkey.preview.HomeActivity"]:
  assert any(n.get("text")=="Document selection cancelled" for n in ui["nodes"]);ready=True;break
 assert ui["foreground"]==["com.google.android.documentsui","com.android.documentsui.picker.PickActivity"]
 phases("G08",[{"phase":"back"}])
assert ready
events=phases("G08",[{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"WRITE ENCRYPTED BACKUP TO CHOSEN FILE"},{"phase":"inspect"}])
assert any(n.get("text")=="choose_backup_destination_first" for n in events[-1]["result"]["nodes"])
fd=lock()
try:
 after=info(path);after_saved=info(original);assert after==before and after_saved==saved
 result={"schema":1,"case":"G08","observed_outcome":"passed","old_destination_selected":True,"new_picker_cancelled":True,"valid_synthetic_password_entered":True,"ui_refusal":"choose_backup_destination_first","before":before,"after":after,"M04_backup_unchanged":True,"case_passed_by_phase":False}
 m["atomic"](root/"G08-observed-result.public.json",result);print(json.dumps(result,sort_keys=True),flush=True)
finally:os.close(fd)
events=phases("G10",[{"phase":"input-master"},{"phase":"hide-keyboard"},{"phase":"tap","selector":"UNLOCK PUBLIC CREDENTIAL LIST"},{"phase":"inspect"},{"phase":"tap","selector":"CHOOSE ENCRYPTED BACKUP DESTINATION"},{"phase":"tap","selector_kind":"description","selector":"显示根目录"},{"phase":"tap","selector":"下载"},{"phase":"tap","selector":"HeptaBao-Passkey-QA-20261106-r7"},{"phase":"tap","selector":"G10-target"},{"phase":"inspect"}])
assert any(n.get("text")=="Unlocked public list: 1 passkeys; five minute limit" for n in events[3]["result"]["nodes"])
fd=lock()
try:
 foreground,nodes=d.ui();assert foreground==("com.google.android.documentsui","com.android.documentsui.picker.PickActivity")
 fields=[n for n in nodes if n.get("package")=="com.google.android.documentsui" and n.get("class")=="android.widget.EditText" and n.get("resource-id")=="android:id/title"]
 assert len(fields)==1 and fields[0].get("text")=="HeptaBao-passkey-backup.hbv"
 assert any(n.get("resource-id")=="com.google.android.documentsui:id/breadcrumb_text" and n.get("text")=="G10-target" for n in nodes)
 m["atomic"](root/"G10-picker-target.public.json",{"schema":1,"case":"G10","exact_owned_directory_verified":True,"fixed_leaf":"HeptaBao-passkey-backup.hbv","case_passed":False})
finally:os.close(fd)
phases("G10",[{"phase":"tap","selector":"保存"},{"phase":"inspect"}])
