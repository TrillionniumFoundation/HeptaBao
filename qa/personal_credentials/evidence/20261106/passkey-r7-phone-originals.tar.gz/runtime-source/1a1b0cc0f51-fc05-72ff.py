import pathlib,hashlib,json,os,runpy,fcntl,re,time
os.umask(0o077);b=pathlib.Path("/home/alex/HeptaBaoPasskey-20261106-r7");root=b/"live-r7";driver=b/"passkey_live.r7.py"
assert hashlib.sha256(driver.read_bytes()).hexdigest()=="e0fefb8be676cd9e1e2da4d2b88d7abfa728bc4fdfdf725f6957869da976c9cd"
m=runpy.run_path(str(driver));m["private_directory"](root);d=m["Device"](pathlib.Path("/home/alex/.local/bin/adb"));lock=os.open(root/"driver.lock",os.O_RDWR|os.O_NOFOLLOW);fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
try:
 expected="88a5731f2b24ca6a07a8748422e344443cab7c43db3c96e4907aa3137ff8de8f";assert d.package_hash(m["FIXTURE"])==expected
 permission="android.permission.CREDENTIAL_MANAGER_SET_ALLOWED_PROVIDERS"
 raw=d.shell("dumpsys","package",m["FIXTURE"]);requested=False;in_requested=False
 for line in raw.splitlines():
  if line.strip()=="requested permissions:":in_requested=True;continue
  if in_requested:
   if re.fullmatch(r"\s+android\.permission\.[A-Za-z0-9_]+",line):
    if line.strip()==permission:requested=True
   elif line.strip():in_requested=False
 result=d.adb_call("shell","cmd package check-permission "+permission+" "+m["FIXTURE"]+" 0",allow_failure=True)
 answer=result.stdout.decode("utf-8","replace").strip()
 public={"schema":1,"read_only":True,"fixture_apk_sha256":expected,"permission":permission,"requested_permission_observed":requested,"permission_name_occurrences_in_owned_package_dump":raw.count(permission),"permission_query_exit_code":result.returncode,"permission_query_fixed_result":answer if answer in ("granted","denied") else "unrecognized","permission_query_stdout_sha256":hashlib.sha256(result.stdout).hexdigest(),"permission_query_stderr_sha256":hashlib.sha256(result.stderr).hexdigest(),"foreground":d.foreground(),"setting_or_permission_mutation":False,"product_exception_stack_observed":False,"prior_get_begin_job":"1a1b0c756a2-fc05-72d9","prior_ui_and_rp_job":"1a1b0c98756-fc05-72e9"}
 m["atomic"](root/"get-permission-observation.public.json",public);print(json.dumps(public,sort_keys=True))
finally:os.close(lock)
