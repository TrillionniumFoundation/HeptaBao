#!/usr/bin/env python3
"""Read-only verification and new outer handoff of an already completed trial."""
import collections
import gzip
import hashlib
import io
import json
import os
import pathlib
import stat
import tarfile

ROOT = pathlib.Path('/workspace/scratch/personal_vault_broker_stability_20261106_r1')
PEER = pathlib.Path('/workspace/scratch/heptabao-root-recovery-20261106-r2/p5-readonly')
OUT = ROOT / 'final-public-handoff-r1'
INNER = 'broker-stability-30m.originals.tar.gz'
JOB = '1a1b20b8d9e-fc05-7c2d'
ARCHIVE_JOB = '1a1b228e809-fc05-7cb6'
EXPECTED = {
    INNER: (212011, '25e5cbb01c0e3af78a2d6376d1abeb656e62697b5d86fa24b824fa8558f80cf2'),
    'runner.actual.py': (35979, 'decd37a01cd99aa61dc00a144ae48d79f73f005f8179eaf78dc3a4431745f150'),
    'plan.public.json': (4764, '8b7071d5f03461ba8e3cac6309ada7adb31af855fb141146ec918dfdb951d9d9'),
    'bootstrap.actual.py': (1243, '94e2965ec965b5ba79049a5e2f16f07bb0fbc6b33187c20dc680d11ddfdee40a'),
    'runtime-start.request.public.json': (96931, '2725d2c984368f54f768ec53927d743c2919c5f4ef60ff6f3e9175b1dadd331f'),
    'runtime-start.reply.native.original.json': (2317, 'f2010b7c14dd62fd565fb79537c3763add1b963cfd497177e13086bad8352478'),
    'runtime.stdout.original': (7897, '6ca87b650e5fa860eb7e8a0cf2160513c712ef26e89884512f025f643a31bae5'),
    'runtime.stderr.original': (0, 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'),
    'archive.actual.py': (19297, 'c0fa0697594609e2f785134d19f0b1199871195d17574e06b22d148f2b170c60'),
    'archive-receipt.original.public.json': (754, 'f5d56c52026fe363cdc4db9b6c6d01a7b863ed65cce4c00c01e926efa40510bd'),
    'peer-review.original.public.json': (5176, 'f4aabdbc1dc4c6f56b09f04706bac7a6ca0c07e390abea1d94fa4d321ac34701'),
}

def sha(b):
    return hashlib.sha256(b).hexdigest()

def demand(value, message):
    if not value:
        raise ValueError(message)

def read(p, maximum=4 * 1024 * 1024):
    s = p.lstat()
    demand(stat.S_ISREG(s.st_mode) and s.st_nlink == 1 and s.st_size <= maximum, 'unsafe_source')
    fd = os.open(p, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as f:
        b = f.read(maximum + 1)
        after = os.fstat(f.fileno())
    demand(len(b) == s.st_size and (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns) ==
           (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), 'source_changed')
    return b

def pairs(values):
    result = {}
    for k, v in values:
        demand(k not in result, 'duplicate_json_key')
        result[k] = v
    return result

def parse(b):
    return json.loads(b, object_pairs_hook=pairs)

def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + '\n').encode()

def native(container):
    if 'reply' in container:
        container = container['reply']
    if 'result' in container:
        container = container['result']['value']
    demand(container.get('isError', False) is False, 'tool_error')
    texts = [c['text'] for c in container['content'] if c.get('type') == 'text']
    demand(len(texts) == 1, 'native_text_count')
    return parse(texts[0])

def syncdir(p):
    fd = os.open(p, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def create(p, b):
    fd = os.open(p, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        f.write(b)
        f.flush()
        os.fsync(f.fileno())
    syncdir(p.parent)

def terminal(value, job, size):
    demand(value['job_id'] == job and value['state'] == 'succeeded' and value['exit_code'] == 0,
           'terminal_failure')
    for key in ['output_complete', 'output_durable', 'terminal_publication_confirmed']:
        demand(value[key] is True, 'terminal_not_confirmed')
    for key in ['automatic_retry', 'cancelled', 'timed_out']:
        demand(value[key] is False, 'unexpected_terminal_flag')
    demand(value['log_bytes']['stdout'] == {'seen': size, 'stored': size} and
           value['log_bytes']['stderr'] == {'seen': 0, 'stored': 0}, 'terminal_log_count')

def main():
    os.umask(0o077)
    files = {}
    retained = {}
    selected = [
        INNER, 'runner.actual.py', 'plan.public.json', 'bootstrap.actual.py',
        'runtime-start.request.public.json', 'runtime-start.reply.tool-response.json',
        'runtime-start.reply.native.original.json', 'runtime.stdout.original', 'runtime.stderr.original',
        'final-wait.tool-original.json', 'final-read.tool-original.json', 'final-read.native.original.json',
        'archive.actual.py', 'archive-bootstrap.actual.py', 'archive-start.request.public.json',
        'archive-start.reply.tool-original.json', 'archive-final-status.tool-original.json',
        'archive-final-read.tool-original.json', 'archive-receipt.original.public.json',
        'archive-transfer.descriptors.public.json', 'peer-review.original.public.json',
        'upstream-linux-19.receipt.public.json', 'upstream-lib.rs', 'upstream-main.rs',
        'recovered-observation-01-read.tool-original.json',
        'recovered-observation-01-status.tool-original.json',
        'recovered-observation-02-read.tool-original.json',
        'recovered-observation-03-read.tool-original.json',
        'recovered-observation-04-read.tool-original.json',
        'recovered-observation-05-wait.tool-original.json',
        'recovered-observation-06-read.tool-original.json',
        'recovered-observation-07-wait.tool-original.json',
        'terminal-probe-01-read.tool-original.json', 'terminal-probe-01-status.tool-original.json',
    ]
    for name in selected:
        b = read(ROOT / name)
        if name in EXPECTED:
            demand((len(b), sha(b)) == EXPECTED[name], 'frozen_input_mismatch:' + name)
        files['originals/' + name] = b
        retained[ROOT / name] = b

    inner_bytes = files['originals/' + INNER]
    with tarfile.open(fileobj=io.BytesIO(inner_bytes), mode='r:gz') as tar:
        members = tar.getmembers()
        demand(len(members) == 1255 and len({m.name for m in members}) == 1255, 'inner_member_count')
        inner = {}
        for m in members:
            p = pathlib.PurePosixPath(m.name)
            demand(m.isfile() and not p.is_absolute() and '..' not in p.parts and m.size <= 4 * 1024 * 1024,
                   'unsafe_inner_member')
            inner[m.name] = tar.extractfile(m).read()
    im = parse(inner['manifest.public.json'])
    demand(set(inner) == {x['path'] for x in im['files']} | {'manifest.public.json'}, 'inner_manifest_members')
    demand(len(im['files']) == 1254, 'inner_manifest_count')
    for row in im['files']:
        demand((len(inner[row['path']]), sha(inner[row['path']])) == (row['bytes'], row['sha256']),
               'inner_member_hash_mismatch')
    summary = parse(inner['summary.public.json'])
    result = parse(inner['originals/public/result.public.json'])
    demand(result['result'] == 'passed' and result['error'] is None and result['completed_cycles'] == 60 and
           result['completed_operations'] == 60 and result['missing_cycles'] == 0 and
           result['protocol_requests_started'] == 491 and result['broker_processes_started'] == 7 and
           result['issued_grants'] == 122, 'trial_result_counts')
    demand(result['actual_effects']['effects'] == 60 and len(result['actual_effects']['counts']) == 60 and
           set(result['actual_effects']['counts'].values()) == {1}, 'effect_count')
    cleanup = result['cleanup']
    demand(cleanup['all_children_reaped'] is True and cleanup['children_started'] == 621 and
           len(cleanup['child_observations']) == 621 and
           len({c['command_id'] for c in cleanup['child_observations']}) == 621 and
           all(c['reaped'] and c['error'] is None for c in cleanup['child_observations']) and
           cleanup['broker_socket_absent'] and cleanup['fixture_thread_stopped'] and
           cleanup['no_other_processes_signalled'], 'cleanup_failed')
    demand(summary['observed_seconds'] == result['observed_seconds'] == 1800.279368418 and
           summary['protocol_requests'] == 491 and summary['completed_retrievals'] == 250 and
           sum(summary['authorization_denials'].values()) == 180 and
           summary['command_exit_codes'] == {'0': 441, '1_expected_denial': 180}, 'summary_counts')
    for name in ['runner.actual.py', 'plan.public.json', 'upstream-linux-19.receipt.public.json']:
        demand(inner['originals/' + name] == files['originals/' + name], 'inner_outer_original_mismatch')
    request = parse(files['originals/runtime-start.request.public.json'])
    launch = parse(files['originals/runtime-start.reply.native.original.json'])
    demand(request['host'] == 'ai395' and request['executable'] == '/usr/bin/python3' and
           request['args'] == ['-I', '-c', files['originals/bootstrap.actual.py'].decode()] and
           request['idempotency_key'] == 'hb-broker-soak-20261106-r1-decd37a0', 'trial_dispatch_binding')
    payload = parse(request['stdin'])
    for name, item in payload['files'].items():
        b = item['text'].encode()
        demand(b == files['originals/' + name] and sha(b) == item['sha256'], 'trial_payload_binding')
    demand(launch['job']['id'] == JOB and launch['job']['execution_mode'] == 'operator' and
           launch['job']['request_digest'] == '8cd854c7c60aba145a8a49b29fd97c609990429c5e2f31e0b7c41a459794efaa' and
           launch['audit_recorded'] and not launch['reused'], 'trial_launch_binding')
    final = native(parse(files['originals/final-wait.tool-original.json']))
    terminal(final, JOB, 7897)
    full_read = parse(files['originals/final-read.native.original.json'])
    demand(full_read['job_id'] == JOB, 'full_read_job')
    for stream in ['stdout', 'stderr']:
        record = full_read[stream]
        b = bytes.fromhex(record['bytes_hex'])
        demand(record['offset'] == 0 and record['eof'] and record['next_offset'] == record['size'] == len(b),
               'full_read_truncated')
        demand(b == files['originals/runtime.' + stream + '.original'], 'full_read_bytes')
    lines = [parse(x) for x in files['originals/runtime.stdout.original'].splitlines()]
    demand(len(lines) == 62 and lines[-1]['result'] == 'passed' and lines[-1]['completed_cycles'] == 60,
           'stdout_terminal')

    archive_final = native(parse(files['originals/archive-final-status.tool-original.json']))
    terminal(archive_final, ARCHIVE_JOB, 690)
    archive_read = native(parse(files['originals/archive-final-read.tool-original.json']))
    demand(archive_read['job_id'] == ARCHIVE_JOB, 'archive_read_job')
    for stream in ['stdout', 'stderr']:
        r = archive_read[stream]
        b = bytes.fromhex(r['bytes_hex'])
        demand(r['eof'] and r['offset'] == 0 and r['size'] == r['next_offset'] == len(b), 'archive_read_truncated')
        files['originals/archive.' + stream + '.original'] = b
    archive_receipt = parse(files['originals/archive-receipt.original.public.json'])
    demand(parse(files['originals/archive.stdout.original']) == archive_receipt and
           archive_receipt['archive']['sha256'] == sha(inner_bytes), 'archive_receipt_mismatch')

    root_selected = [
        'first-progress.original.json', 'first-progress.tool-original.json',
        'first-runtime-status.tool-original.json', 'result.original.json',
        'root-terminal-review.public.json', 'terminal-read.tool-original.json',
        'terminal-result-chunk2.tool-original.json', 'terminal-result.tool-original.json',
        'terminal-status.tool-original.json', 'terminal-stderr.original.txt', 'terminal-stdout.original.txt',
    ]
    for name in root_selected:
        b = read(PEER / name)
        files['root-readonly-originals/' + name] = b
        retained[PEER / name] = b
    demand(files['root-readonly-originals/result.original.json'] == inner['originals/public/result.public.json'] and
           files['root-readonly-originals/terminal-stdout.original.txt'] == files['originals/runtime.stdout.original'] and
           not files['root-readonly-originals/terminal-stderr.original.txt'], 'root_original_mismatch')
    files['summary.public.json'] = inner['summary.public.json']
    files['result.original.public.json'] = inner['originals/public/result.public.json']
    verification = {
        'schema': 1, 'scope': 'local_read_only_original_byte_and_runtime_binding_verification',
        'product_executed': False, 'adb_used': False, 'network_used': False,
        'inner_archive_bytes': len(inner_bytes), 'inner_archive_sha256': sha(inner_bytes),
        'inner_regular_members': len(inner), 'inner_manifest_entries_checked': len(im['files']),
        'inner_manifest_sha256': sha(inner['manifest.public.json']),
        'inner_command_streams': sum(n.startswith('command-originals/') for n in inner),
        'all_inner_member_sizes_and_sha256_match': True,
        'trial_actual_request_embedded_sources_match': True,
        'trial_launch_and_terminal_match_original_job': True,
        'trial_stdout_stderr_full_original_bytes_verified': True,
        'archive_terminal_and_receipt_match_original_job': True,
        'root_independent_result_and_stream_bytes_match': True,
        'actual_counts_and_cleanup_match_summary': True,
        'no_additional_product_tests_or_controller_restart': True,
        'all_source_original_bytes_preserved': True,
        'early_read_only_metadata_poll_history_complete': False,
        'poll_history_note': 'Some pre-refresh read-only polls were not retained; the persisted actual launch request/response, complete stdout/stderr, controller journal and final terminal are present. No missing poll is reconstructed.',
        'serialization_note': 'Tool-result containers are the original saved SDK objects, not a claim of raw wire framing. Native JSON text and bytes_hex-derived original streams are preserved separately where available.',
        'external_security_review': False, 'long_term_stability_qualified': False, 'production_qualified': False,
    }
    files['local-verification.public.json'] = encode(verification)
    bindings = {
        'schema': 1, 'scope': 'two_distinct_runtime_jobs_original_bindings',
        'trial': {'job_id': JOB, 'host': 'ai395', 'execution_mode': 'operator',
                  'request_digest': launch['job']['request_digest'], 'launch_audit_recorded': True,
                  'request_path': 'originals/runtime-start.request.public.json',
                  'request_file_sha256': sha(files['originals/runtime-start.request.public.json']),
                  'launch_path': 'originals/runtime-start.reply.native.original.json',
                  'terminal_path': 'originals/final-wait.tool-original.json',
                  'terminal': final, 'stdout_bytes': 7897,
                  'stdout_sha256': sha(files['originals/runtime.stdout.original']), 'stderr_bytes': 0},
        'read_only_archive': {'job_id': ARCHIVE_JOB, 'host': 'ai395',
                             'request_path': 'originals/archive-start.request.public.json',
                             'launch_path': 'originals/archive-start.reply.tool-original.json',
                             'terminal_path': 'originals/archive-final-status.tool-original.json',
                             'terminal': archive_final, 'stdout_bytes': 690,
                             'stdout_sha256': sha(files['originals/archive.stdout.original']), 'stderr_bytes': 0,
                             'product_executed': False},
        'runtime_task_identity_attested': False,
        'control_plane_is_not_product_workload_identity': True,
    }
    files['runtime-bindings.public.json'] = encode(bindings)
    files['README.md'] = '''# Bounded 30-minute synthetic broker trial

One original trial passed over **1800.279368418 seconds**. It executed all 60 scheduled
cycles, 60 distinct loopback HTTP effects exactly once, 250 completed-result retrievals
without additional effects, 180 expected authorization denials and one revocation:
491 broker protocol requests. Seven sequential broker processes (six graceful independent
restarts) and all 621 owned child invocations were reaped. The final new process queried
all 60 earlier completed results. There were 441 exit-zero commands and 180 expected
exit-one authorization refusals. The last scheduled cycle ended at 1800.075191901 seconds;
that is distinct from the full observation duration above.

The fixed Linux executable SHA-256 is
`6f9324480fb9e9f9ce08a182cd9822d5236cb866146578d5851845719319d9f5`.
The upstream 19-test receipt is artifact provenance only; its cases are not counted again.
Original Runtime job `1a1b20b8d9e-fc05-7c2d` was observed succeeded/exit 0 with complete,
durable stdout (7897 bytes), empty stderr and confirmed terminal publication. Its actual
request and launch response were persisted before an environment refresh. The controller
was not restarted. A later, separate read-only archive job is retained with its own binding.

`originals/broker-stability-30m.originals.tar.gz` is an unchanged 212011-byte inner archive
with 1255 regular members, including 1242 original command stdout/stderr streams, the
immutable runner/plan, all cycle/resource/event observations, and the original result.
Every inner manifest entry was checked locally by exact size and SHA-256. The root agent's
independent read-only observations and the earlier peer's plan-only review are preserved
separately. Neither is an external security review or an extra product execution.

The 60 samples cover six workload broker epochs, with observed peaks of 3300 KiB broker
RSS / 5 broker file descriptors and 22928 KiB controller RSS / 6 controller descriptors.
These are sampled peaks; the brief seventh recovery process was not resource-sampled.
The 65536-byte stream threshold is checked after a command, and the 32 MiB owned-tree
threshold after each cycle. They are not continuous quotas. RLIMIT_FSIZE supplies an
8 MiB per-file hard limit. The fixture's contact budget counts authenticated, fully read
requests, not every TCP accept. Requested Runtime limits and inherited per-process limits
are recorded without asserting independently measured cgroup enforcement.

This is a short-duration observation of synthetic owner-authorized loopback operations.
It does not qualify long-term stability, load capacity, arbitrary real credentials,
hostile same-UID isolation, physical power-loss recovery, production readiness, external
security review or Runtime task/run attestation. No ADB, product-source mutation or
previous owner-state mutation occurred. Owner keys, grants, bootstrap token and private
broker state are excluded. The new private trial state is retained for controlled recovery.

The final result and complete original streams are present. Some early read-only metadata
polls that existed only in volatile orchestration memory were not retained; they are not
reconstructed. Tool containers preserve their saved SDK representation, not a claim of raw
wire JSON formatting. Derived summaries and the new outer packaging are explicitly marked.
'''.encode()
    files['package_local.actual.py'] = read(pathlib.Path(__file__))
    origins = {}
    for name in files:
        if name.startswith(('originals/', 'root-readonly-originals/')) or name in ['summary.public.json', 'result.original.public.json']:
            origins[name] = 'exact_preserved_original_bytes'
        elif name == 'package_local.actual.py':
            origins[name] = 'local_read_only_packaging_source'
        else:
            origins[name] = 'new_derived_summary_or_verification'
    origins['originals/archive.stdout.original'] = 'exact_original_bytes_recovered_from_original_runtime_bytes_hex'
    origins['originals/archive.stderr.original'] = origins['originals/archive.stdout.original']
    origins['originals/archive-transfer.descriptors.public.json'] = 'derived_transport_metadata_payload_excluded_exact_archive_bytes_retained'
    manifest = {'schema': 1, 'scope': 'bounded_broker_stability_public_outer',
                'files': [{'path': k, 'bytes': len(v), 'sha256': sha(v), 'origin': origins[k]}
                          for k, v in sorted(files.items())],
                'production_qualified': False, 'long_term_stability_qualified': False,
                'external_security_review': False, 'runtime_task_identity_attested': False}
    files['manifest.public.json'] = encode(manifest)
    demand(all(read(p) == b for p, b in retained.items()), 'original_changed_before_package')
    OUT.mkdir(mode=0o700)
    syncdir(ROOT)
    for name in ['summary.public.json', 'local-verification.public.json', 'runtime-bindings.public.json', 'README.md', 'manifest.public.json']:
        create(OUT / name, files[name])
    target = OUT / 'broker-stability-30m-public-evidence.tar.gz'
    fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as f:
        with gzip.GzipFile(fileobj=f, mode='wb', mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w') as tar:
                for name, b in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size = len(b)
                    info.mode = 0o600
                    info.mtime = 0
                    info.uid = info.gid = 0
                    tar.addfile(info, io.BytesIO(b))
        f.flush()
        os.fsync(f.fileno())
    syncdir(OUT)
    packed = read(target)
    with tarfile.open(fileobj=io.BytesIO(packed), mode='r:gz') as tar:
        members = tar.getmembers()
        demand(len(members) == len(files) and {m.name for m in members} == set(files), 'outer_members')
        for m in members:
            demand(m.isfile() and tar.extractfile(m).read() == files[m.name], 'outer_readback')
    demand(all(read(p) == b for p, b in retained.items()), 'original_changed_after_package')
    receipt = {'schema': 1, 'scope': 'local_outer_public_package',
               'archive': {'path': str(target), 'bytes': len(packed), 'sha256': sha(packed)},
               'regular_members': len(files), 'inner_regular_members': len(inner),
               'manifest_sha256': sha(files['manifest.public.json']),
               'local_verification_sha256': sha(files['local-verification.public.json']),
               'runtime_binding_sha256': sha(files['runtime-bindings.public.json']),
               'all_member_bytes_verified_after_write': True, 'originals_changed': False,
               'product_executed': False, 'adb_used': False}
    create(OUT / 'receipt.public.json', encode(receipt))
    create(OUT / 'evidence-index-entry.public.json', encode({
        'file': target.name, 'bytes': len(packed), 'sha256': sha(packed),
        'transformation': 'New outer preserving the unchanged 1255-member original 30-minute synthetic broker archive, actual Runtime request/launch/complete streams/final terminals, root read-only observations and plan-only internal review. New local byte verification and summaries are labelled. Original 60 cycles / 60 effects / 491 requests / 7 broker processes / 621 reaped children; no long-term, production, external-audit or workload-attestation qualification.'}))
    print(json.dumps(receipt, sort_keys=True))

if __name__ == '__main__':
    main()
