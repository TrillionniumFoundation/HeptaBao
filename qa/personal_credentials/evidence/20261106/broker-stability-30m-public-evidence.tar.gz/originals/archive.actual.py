#!/usr/bin/env python3
"""Archive a terminal, already completed run; never execute a product."""
import collections
import gzip
import hashlib
import io
import json
import os
import pathlib
import re
import stat
import tarfile

ROOT = pathlib.Path("/home/qq/hb-soak-20261106-r1")
OUT = ROOT / "public-package-r1"
RUNNER_SHA = "decd37a01cd99aa61dc00a144ae48d79f73f005f8179eaf78dc3a4431745f150"
PLAN_SHA = "8b7071d5f03461ba8e3cac6309ada7adb31af855fb141146ec918dfdb951d9d9"
BIN_SHA = "6f9324480fb9e9f9ce08a182cd9822d5236cb866146578d5851845719319d9f5"
MAX_TOTAL = 12 * 1024 * 1024

def demand(value, code):
    if not value:
        raise RuntimeError(code)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def pack(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True) + "\n").encode()

def read(path, cap=4*1024*1024):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        a = os.fstat(fd)
        demand(stat.S_ISREG(a.st_mode) and a.st_uid == os.getuid() and a.st_nlink == 1
               and not (a.st_mode & 0o022) and a.st_size <= cap, "unsafe_archive_input")
        data = bytearray()
        while len(data) <= cap:
            block = os.read(fd, min(65536, cap + 1 - len(data)))
            if not block:
                break
            data.extend(block)
        b = os.fstat(fd)
        demand(len(data) <= cap and (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)
               == (b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns), "archive_input_changed")
        return bytes(data)
    finally:
        os.close(fd)

def syncdir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def create(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    syncdir(path.parent)

def obj(data):
    def unique(pairs):
        result = {}
        for k,v in pairs:
            demand(k not in result, "duplicate_json_key")
            result[k] = v
        return result
    return json.loads(data, object_pairs_hook=unique)

def main():
    os.umask(0o077)
    root_stat = ROOT.lstat()
    demand(stat.S_ISDIR(root_stat.st_mode) and root_stat.st_uid == os.getuid()
           and stat.S_IMODE(root_stat.st_mode) == 0o700, "unsafe_run_root")
    names = [
        "runner.actual.py", "plan.public.json", "upstream-linux-19.receipt.public.json",
        "public/result.public.json", "public/status.public.json", "public/cycles.public.json",
        "public/resources.public.json", "public/commands.public.json", "public/events.public.jsonl",
    ]
    originals = {name:read(ROOT/name) for name in names}
    demand(sha(originals["runner.actual.py"]) == RUNNER_SHA and sha(originals["plan.public.json"]) == PLAN_SHA,
           "frozen_input_mismatch")
    result = obj(originals["public/result.public.json"])
    status = obj(originals["public/status.public.json"])
    plan = obj(originals["plan.public.json"])
    cycles = obj(originals["public/cycles.public.json"])
    resources = obj(originals["public/resources.public.json"])
    commands = obj(originals["public/commands.public.json"])
    events = [obj(line) for line in originals["public/events.public.jsonl"].splitlines()]
    demand(result["result"] == "passed" and result["error"] is None
           and status["phase"] == "terminal" and status["result"] == "passed", "run_not_passed_terminal")
    demand(result["binary_sha256"] == BIN_SHA and result["runner_sha256"] == RUNNER_SHA
           and result["budget"] == plan["budget"], "result_identity_mismatch")
    demand(result["completed_cycles"] == 60 and result["missing_cycles"] == 0
           and result["protocol_requests_started"] == 491 and result["issued_grants"] == 122
           and result["completed_operations"] == 60 and result["broker_processes_started"] == 7,
           "result_count_mismatch")
    demand(1800 <= result["observed_seconds"] <= 1920, "result_duration_mismatch")
    demand(result["production_qualified"] is False and result["long_term_stability_qualified"] is False
           and result["external_security_review"] is False and result["runtime_task_identity_attested"] is False,
           "qualification_scope_mismatch")
    expected_ids = ["ok-%03d" % i for i in range(1,61)]
    target = result["actual_effects"]
    demand(target["error"] is None and target["contacts"] == target["effects"] == 60
           and target["counts"] == {i:1 for i in expected_ids}, "effect_count_mismatch")
    cleanup = result["cleanup"]
    demand(cleanup["children_started"] == 621 and cleanup["all_children_reaped"]
           and cleanup["fixture_thread_stopped"] and cleanup["broker_socket_absent"]
           and len(cleanup["child_observations"]) == 621
           and all(x["reaped"] and x["action"] == "already_reaped" and x["error"] is None
                   for x in cleanup["child_observations"]), "cleanup_not_complete")
    demand(len(cycles) == len(resources) == 60 and len(commands) == 621, "observation_count_mismatch")
    for i, row in enumerate(cycles,1):
        demand(row["cycle"] == i and row["effects"] == i
               and row["planned_monotonic_ns"] == result["started_monotonic_ns"] + i*30*1000000000
               and row["start"]["monotonic_ns"] >= row["planned_monotonic_ns"]
               and row["end"]["monotonic_ns"] >= row["start"]["monotonic_ns"]
               and row["protocol_requests_started"] == 1 + 7*i + 2*((i-1)//10)
               and row["completed_operation_id"] == "ok-%03d" % i
               and row["denial_operation_id"] == "denied-%03d" % i
               and row["mutation"] == ("task_id","body_base64","path")[(i-1)%3],
               "cycle_sequence_or_causality_mismatch")
    demand([x["sequence"] for x in events] == list(range(1,len(events)+1)), "journal_sequence_gap")
    demand(all(events[i]["monotonic_ns"] <= events[i+1]["monotonic_ns"] for i in range(len(events)-1)),
           "journal_time_regression")
    counts = collections.Counter(x["kind"] for x in events)
    expected_counts = {
        "command_intent":621, "command_terminal":621, "target_effect":60,
        "preflight_passed":1, "broker_ready":7, "completed_retrieval":250,
        "authorization_denied":180, "resource_observation":60,
        "new_operation_completed":60, "cycle_completed":60,
        "final_recovery_verified":1, "controller_terminal":1,
    }
    demand(dict(counts) == expected_counts, "journal_event_count_mismatch")
    demand(events[-1]["kind"] == "controller_terminal" and events[-1]["result"] == "passed",
           "journal_missing_terminal")
    target_events = [x for x in events if x["kind"] == "target_effect"]
    demand([x["operation_id"] for x in target_events] == expected_ids
           and all(x["effect_count"] == i and x["operation_effect_count"] == 1 and x["peer_is_loopback"]
                   for i,x in enumerate(target_events,1)), "target_events_mismatch")
    retrievals = [x for x in events if x["kind"] == "completed_retrieval"]
    demand(all(x["before_effects"] == x["after_effects"] for x in retrievals), "retrieval_redispatched")
    denials = [x for x in events if x["kind"] == "authorization_denied"]
    demand(collections.Counter(x["mutation"] for x in denials)
           == {"task_id":20,"body_base64":20,"path":20,"revoked":60,"expired":60}
           and all(x["before_effects"] == x["after_effects"] for x in denials), "denial_effect_mismatch")
    ready = [x for x in events if x["kind"] == "broker_ready"]
    demand([x["epoch"] for x in ready] == list(range(7))
           and [x["request_limit"] for x in ready] == [71,72,72,72,72,72,60], "restart_budget_mismatch")
    demand(events[-2]["kind"] == "final_recovery_verified" and events[-2]["queried_results"] == 60
           and events[-2]["ledger_entries"] == 60 and events[-2]["revoked_grants"] == 1,
           "final_reopen_mismatch")

    files = {"originals/"+name:data for name,data in originals.items()}
    command_types = collections.Counter()
    for i, command in enumerate(commands,1):
        ident = command["command_id"]
        demand(re.fullmatch(r"%04d-[a-z0-9-]+" % i,ident) is not None, "command_identity_mismatch")
        argv = command["argv"]
        demand(isinstance(argv,list) and argv[0] == str(ROOT/"bin/broker")
               and argv[2] == str(ROOT/"private/broker"), "command_not_owned_binary")
        kind = argv[1]
        demand(kind in {"init","issue","serve","execute","status","revoke"}, "unknown_command")
        command_types[kind] += 1
        demand(command["reaped"] and command["end"]["monotonic_ns"] >= command["start"]["monotonic_ns"],
               "command_not_reaped")
        streams = []
        for stream in ("stdout","stderr"):
            rel = "private/logs/"+ident+"."+stream
            demand(command[stream+"_relative"] == rel, "unexpected_log_path")
            raw = read(ROOT/rel,65536)
            demand(len(raw) == command[stream+"_bytes"] and sha(raw) == command[stream+"_sha256"],
                   "original_stream_mismatch")
            streams.append(raw)
        out,err = streams
        demand(not err, "nonempty_stderr_not_publishable")
        code = command["exit_code"]
        if kind == "serve":
            demand(code == 0 and not out, "serve_result_mismatch")
        elif kind == "init":
            demand(code == 0 and obj(out) == {"ok":True,"synthetic_only":True}, "init_result_mismatch")
        elif kind == "issue":
            value = obj(out)
            demand(code == 0 and set(value) == {"ok","grant_id","expires_at"} and value["ok"] is True
                   and isinstance(value["expires_at"],int)
                   and re.fullmatch(r"[A-Za-z0-9_-]{43}",value["grant_id"]) is not None,
                   "issue_output_not_publishable")
        else:
            value = obj(out)
            if code == 1:
                demand(value == {"ok":False,"error":"authorization_denied"}, "denial_output_not_publishable")
            else:
                demand(code == 0 and set(value) == {"ok","receipt"} and value["ok"] is True, "result_shape")
                receipt = value["receipt"]
                demand(set(receipt) == {"operation_id","outcome","http_status","http_success","signature_pem","public_key"}
                       and receipt["signature_pem"] is None and receipt["public_key"] is None,
                       "result_output_not_publishable")
                if kind == "revoke":
                    demand(receipt == {"operation_id":"","outcome":"revoked","http_status":None,
                                       "http_success":None,"signature_pem":None,"public_key":None},
                           "revoke_result_mismatch")
                else:
                    demand(receipt["operation_id"] in expected_ids and receipt["outcome"] == "completed"
                           and receipt["http_status"] == 204 and receipt["http_success"] is True,
                           "complete_result_mismatch")
        for stream,raw in zip(("stdout","stderr"),streams):
            files["command-originals/"+ident+"."+stream+".original"] = raw
    demand(dict(command_types) == {"init":1,"issue":122,"serve":7,"execute":245,"status":245,"revoke":1},
           "command_type_count_mismatch")
    demand(collections.Counter(c["exit_code"] for c in commands) == {0:441,1:180}, "command_exit_count_mismatch")

    summary = {
        "schema":1, "scope":"bounded_30_minute_synthetic_broker_trial",
        "source_run_id":"soak20261106r1", "source_runtime_job_id":"1a1b20b8d9e-fc05-7c2d",
        "source_runner_sha256":RUNNER_SHA, "source_plan_sha256":PLAN_SHA, "binary_sha256":BIN_SHA,
        "result":"passed", "observed_seconds":result["observed_seconds"],
        "cycles":{"expected":60,"executed":60,"passed":60,"missing":0},
        "protocol_requests":491, "new_effects":60, "each_effect_observed_once":True,
        "completed_retrievals":250, "exact_duplicate_execute_retrievals":65,
        "successful_status_retrievals":185, "authorization_denials":dict(collections.Counter(x["mutation"] for x in denials)),
        "broker_process_invocations":7, "independent_restart_invocations":6, "final_new_process_results_checked":60,
        "children_started":621, "children_reaped":621, "command_exit_codes":{"0":441,"1_expected_denial":180},
        "final_ledger_entries":60, "final_revocation_entries":1, "owner_state_capacity":4096,
        "archived_command_streams":1242, "archived_streams_validated_against_closed_output_schema":True,
        "resource_sampling":{"samples":60,"sampled_broker_epochs":sorted(set(r["broker_epoch"] for r in resources)),
             "final_recovery_process_resource_sampled":False,
             "controller_peak_observed_rss_kib":max(r["controller"]["VmRSS"] for r in resources),
             "broker_peak_observed_rss_kib":max(r["broker"]["VmRSS"] for r in resources),
             "controller_peak_observed_open_fds":max(r["controller"]["open_fd_count"] for r in resources),
             "broker_peak_observed_open_fds":max(r["broker"]["open_fd_count"] for r in resources)},
        "threshold_interpretation":{
             "cli_65536_bytes":"post-command rejection threshold; not a continuously enforced stream quota",
             "owned_tree_33554432_bytes":"post-cycle rejection threshold; not a filesystem quota",
             "file_8388608_bytes":"inherited RLIMIT_FSIZE hard limit per file",
             "fixture_64_contacts":"only requests completing authentication and body verification; not all TCP accepts",
             "memory_cpu_open_files":"inherited per-process RLIMIT_AS/CPU/NOFILE plus originally requested Runtime limits; no independent cgroup enforcement measurement"
        },
        "cleanup":{"all_children_reaped":True,"fixture_thread_stopped":True,"broker_socket_absent":True,
                   "only_new_owned_state_retained":True},
        "no_adb":True,"no_product_source_changes":True,"long_term_stability_qualified":False,
        "production_qualified":False,"external_security_review":False,"runtime_task_identity_attested":False,
        "existing_19_test_receipt_used_for_artifact_provenance_only":True,
        "exclusions":["bootstrap secret","owner.key","broker config/state bytes","operation grant files",
                      "unrelated owner directories","unobserved physical power loss or hostile-owner isolation"],
        "archive_validation_is_not_additional_product_execution":True,
    }
    files["summary.public.json"] = pack(summary)
    files["archive.actual.py"] = read(pathlib.Path(__file__),131072)
    readme = (
        "# Thirty-minute synthetic broker observation\n\n"
        "This package preserves one completed observation of the fixed Linux broker.\n"
        "It is not a long-term stability result, a stress benchmark, production qualification,\n"
        "an independent external security audit, or Runtime workload identity attestation.\n\n"
        "The controller executed 60 scheduled rounds over %.6f seconds: 60 distinct loopback\n"
        "HTTP effects, 250 completed-result retrievals without additional effects, 180 exact\n"
        "authorization denials and one revocation (491 broker requests total). Seven sequential\n"
        "broker serve processes were launched and reaped. The seventh read all 60 original\n"
        "completed receipts. All 621 owned subprocess invocations were reaped; 180 exit-one\n"
        "results were the expected authorization refusals.\n\n"
        "The immutable runner, plan, original upstream build receipt and controller observations\n"
        "are retained byte-for-byte. The 1,242 original command stdout/stderr files are published\n"
        "only after validation against closed, non-secret response schemas and their original\n"
        "recorded hashes. Grants, owner key, bootstrap token and broker state are excluded.\n\n"
        "Limits are distinguished in summary.public.json: CLI output and total-tree limits are\n"
        "post-command/post-cycle rejection thresholds; RLIMIT_FSIZE is the per-file hard limit.\n"
        "The fixture contact count covers authenticated complete requests, not all TCP accepts.\n"
        "Resource figures are sampled observations, not proof of absence of all transient peaks.\n"
        "The six workload epochs were sampled; the brief final recovery process was not.\n\n"
        "The source Runtime request, original launch response and directly observed terminal are\n"
        "preserved by the enclosing handoff packet. This inner package does not manufacture\n"
        "a Runtime terminal observation or fill a missing control-plane record.\n"
    ) % result["observed_seconds"]
    files["README.md"] = readme.encode()
    demand(sum(len(v) for v in files.values()) <= MAX_TOTAL, "archive_total_budget")
    OUT.mkdir(mode=0o700)
    syncdir(ROOT)
    manifest = {
        "schema":1, "scope":"bounded_30_minute_broker_trial_originals",
        "files":[{"path":k,"bytes":len(v),"sha256":sha(v),
                  "origin":"derived_summary" if k in {"README.md","summary.public.json"} else
                           "archive_source" if k=="archive.actual.py" else "exact_original_bytes"}
                 for k,v in sorted(files.items())],
        "production_qualified":False,"long_term_stability_qualified":False,
    }
    files["manifest.public.json"] = pack(manifest)
    for name in ["summary.public.json","README.md","manifest.public.json"]:
        create(OUT/name,files[name])
    target_path = OUT/"broker-stability-30m.originals.tar.gz"
    fd = os.open(target_path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    with os.fdopen(fd,"wb") as f:
        with gzip.GzipFile(fileobj=f,mode="wb",mtime=0) as gz:
            with tarfile.open(fileobj=gz,mode="w") as tar:
                for name,data in sorted(files.items()):
                    info = tarfile.TarInfo(name)
                    info.size=len(data);info.mode=0o600;info.mtime=0;info.uid=0;info.gid=0
                    tar.addfile(info,io.BytesIO(data))
        f.flush();os.fsync(f.fileno())
    syncdir(OUT)
    archive_bytes = read(target_path,MAX_TOTAL)
    receipt = {"schema":1,"scope":"read_only_archive_of_completed_trial",
               "source_runtime_job_id":"1a1b20b8d9e-fc05-7c2d",
               "archive":{"path":str(target_path),"bytes":len(archive_bytes),"sha256":sha(archive_bytes)},
               "manifest":{"bytes":len(files["manifest.public.json"]),"sha256":sha(files["manifest.public.json"])},
               "summary":{"bytes":len(files["summary.public.json"]),"sha256":sha(files["summary.public.json"])},
               "regular_members":len(files),"product_executed":False,"original_sources_changed":False,
               "production_qualified":False,"long_term_stability_qualified":False}
    create(OUT/"receipt.public.json",pack(receipt))
    # Original controller inputs/results are reread after packaging, not rewritten.
    demand(all(read(ROOT/name)==raw for name,raw in originals.items()),"original_changed_during_archive")
    print(json.dumps(receipt,sort_keys=True),flush=True)

if __name__=="__main__":
    main()

