import hashlib,os,pathlib,stat,sys
root=pathlib.Path("/home/qq/hb-soak-20261106-r1")
source=sys.stdin.buffer.read(131073)
if len(source)>131072 or hashlib.sha256(source).hexdigest()!="c0fa0697594609e2f785134d19f0b1199871195d17574e06b22d148f2b170c60":raise SystemExit("archive_source_mismatch")
s=root.lstat()
if not stat.S_ISDIR(s.st_mode) or s.st_uid!=os.getuid() or stat.S_IMODE(s.st_mode)!=0o700:raise SystemExit("unsafe_archive_root")
os.umask(0o077)
path=root/"archive.actual.py"
fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
with os.fdopen(fd,"wb") as f:f.write(source);f.flush();os.fsync(f.fileno())
fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
try:os.fsync(fd)
finally:os.close(fd)
os.execv("/usr/bin/python3",["/usr/bin/python3","-I",str(path)])
