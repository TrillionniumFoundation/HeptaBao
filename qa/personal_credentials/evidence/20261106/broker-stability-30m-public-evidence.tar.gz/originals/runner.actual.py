#!/usr/bin/env python3
"""One bounded, synthetic, owner-account broker stability observation."""
import base64
import hashlib
import hmac
import json
import os
import pathlib
import resource
import secrets
import signal
import socket
import stat
import subprocess
import threading
import time

ROOT = pathlib.Path("/home/qq/hb-soak-20261106-r1")
UPSTREAM = pathlib.Path("/home/qq/heptabao-broker-poll-fix-20261106-r2")
BINARY_SHA = "6f9324480fb9e9f9ce08a182cd9822d5236cb866146578d5851845719319d9f5"
RECEIPT_SHA = "e787df00bcc3d39cab8679463adacf147359e893541d3f9f3a36460c1ac58424"
SOURCE_SHA = {
    "crates/heptabao-credential-broker/src/lib.rs": "3617799f6de0368fa3b4b4c1343510fe9d202ee3a31fc0e067eb312c40732001",
    "crates/heptabao-credential-broker/src/main.rs": "1114f1d166c40e1e3ce324a65ea9c7b2f38a559a87fd60e267413e82b2565f65",
    "crates/heptabao-credential-broker/Cargo.toml": "0f281abd2fb8ee3d37250a5d7d93bba92aa9089b0e49732a7bdbee8ba5b17ad6",
    "crates/heptabao-credential-broker/src/frame_read_tests.rs": "2a203ee7ca0e4c8f9b878abb0727374a57e3f977dc3a09e1d8cad5ed3a5b9fc7",
    "Cargo.lock": "ef3b19cf8b1b360f7888f11e3e5b1523e464762d6c24ce7e92b64d0d7d5c99a9",
}
RUN = "soak20261106r1"
BUDGET = {
    "cycles": 60, "period_seconds": 30, "planned_observation_seconds": 1800,
    "maximum_observation_seconds": 1920, "controller_alarm_seconds": 2000,
    "runtime_timeout_seconds": 2100, "broker_protocol_requests": 491,
    "new_http_effects": 60, "broker_processes": 7, "independent_restarts": 6,
    "issued_grants": 122, "maximum_popen_children": 621,
    "maximum_simultaneous_children": 2, "maximum_fixture_contacts": 64,
    "maximum_ledger_entries": 60, "maximum_revoked_grants": 1,
    "address_space_bytes_per_process": 268435456, "open_files_per_process": 128,
    "cpu_seconds_per_process": 120, "file_size_bytes_per_file": 8388608,
    "minimum_available_disk_bytes": 67108864,
    "maximum_owned_tree_bytes": 33554432, "maximum_cli_output_bytes_per_stream": 65536,
    "cli_timeout_seconds": 25, "broker_start_timeout_seconds": 10,
    "broker_exit_timeout_seconds": 10, "fixture_io_timeout_seconds": 3,
    "poll_retry_scope": "bounded read-only readiness only; no operation retries",
}
ENV = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "RUST_BACKTRACE": "0"}

class Failure(Exception):
    pass

def require(value, code):
    if not value:
        raise Failure(code)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True) + "\n").encode()

def sync_dir(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def owned_dir(path):
    s = path.lstat()
    require(stat.S_ISDIR(s.st_mode) and s.st_uid == os.getuid()
            and stat.S_IMODE(s.st_mode) == 0o700, "unsafe_owned_directory")

def new_dir(path):
    path.mkdir(mode=0o700)
    owned_dir(path)
    sync_dir(path.parent)

def read_regular(path, cap):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_uid == os.getuid()
                and before.st_nlink == 1 and not (before.st_mode & 0o022)
                and before.st_size <= cap, "unsafe_input_file")
        chunks = []
        size = 0
        while True:
            block = os.read(fd, min(65536, cap + 1 - size))
            if not block:
                break
            chunks.append(block)
            size += len(block)
            require(size <= cap, "input_file_too_large")
        after = os.fstat(fd)
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns)
                == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns),
                "input_file_changed")
        return b"".join(chunks)
    finally:
        os.close(fd)

def create(path, data, mode=0o600):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, "wb") as f:
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    sync_dir(path.parent)

def replace_owned(path, data):
    tmp = path.parent / (path.name + ".new-" + secrets.token_hex(8))
    create(tmp, data)
    os.replace(tmp, path)
    sync_dir(path.parent)

def write_all(fd, data):
    while data:
        n = os.write(fd, data)
        require(n > 0, "journal_short_write")
        data = data[n:]

class Journal:
    def __init__(self, path):
        self.lock = threading.Lock()
        self.fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_APPEND | os.O_NOFOLLOW, 0o600)
        self.sequence = 0
        sync_dir(path.parent)
    def add(self, kind, **values):
        with self.lock:
            self.sequence += 1
            row = {"sequence": self.sequence, "kind": kind, "wall_unix_ns": time.time_ns(),
                   "monotonic_ns": time.monotonic_ns(), **values}
            write_all(self.fd, encoded(row))
            os.fsync(self.fd)
            return row
    def close(self):
        if self.fd is not None:
            fd, self.fd = self.fd, None
            os.close(fd)

class Target:
    def __init__(self, token, journal):
        self.token = token.encode()
        self.journal = journal
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.expected = {}
        self.counts = {}
        self.contacts = 0
        self.effects = 0
        self.error = None
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(4)
        self.sock.settimeout(0.2)
        self.port = self.sock.getsockname()[1]
        self.thread = threading.Thread(target=self.serve, name="owned-loopback-fixture", daemon=True)
    def start(self):
        self.thread.start()
    def expect(self, body, operation_id):
        with self.lock:
            self.expected[digest(body)] = operation_id
    def snapshot(self):
        with self.lock:
            return {"contacts": self.contacts, "effects": self.effects,
                    "counts": dict(self.counts), "error": self.error}
    def serve(self):
        while not self.stop.is_set():
            try:
                conn, peer = self.sock.accept()
            except socket.timeout:
                continue
            except OSError:
                if not self.stop.is_set():
                    with self.lock:
                        self.error = "fixture_accept_failed"
                return
            with conn:
                try:
                    deadline = time.monotonic() + BUDGET["fixture_io_timeout_seconds"]
                    raw = b""
                    while b"\r\n\r\n" not in raw:
                        require(time.monotonic() < deadline, "fixture_header_deadline")
                        conn.settimeout(max(0.001, deadline - time.monotonic()))
                        part = conn.recv(4096 - len(raw))
                        require(part, "fixture_header_eof")
                        raw += part
                        require(len(raw) <= 4096, "fixture_header_limit")
                    head, body = raw.split(b"\r\n\r\n", 1)
                    rows = head.split(b"\r\n")
                    require(rows[0] == b"POST /effect HTTP/1.1", "fixture_request_line")
                    headers = {}
                    for row in rows[1:]:
                        require(b":" in row, "fixture_header_shape")
                        k, v = row.split(b":", 1)
                        k = k.lower()
                        require(k not in headers, "fixture_duplicate_header")
                        headers[k] = v.strip()
                    require(hmac.compare_digest(headers.get(b"authorization", b""), b"Bearer " + self.token),
                            "fixture_authorization")
                    require(headers.get(b"content-length", b"").isdigit(), "fixture_length_shape")
                    count = int(headers[b"content-length"])
                    require(0 < count <= 1024 and len(body) <= count, "fixture_body_limit")
                    while len(body) < count:
                        require(time.monotonic() < deadline, "fixture_body_deadline")
                        conn.settimeout(max(0.001, deadline - time.monotonic()))
                        part = conn.recv(count - len(body))
                        require(part, "fixture_body_eof")
                        body += part
                    require(time.monotonic() < deadline, "fixture_body_deadline")
                    key = digest(body)
                    with self.lock:
                        self.contacts += 1
                        require(self.contacts <= BUDGET["maximum_fixture_contacts"], "fixture_contact_budget")
                        op = self.expected.get(key)
                        require(op is not None, "fixture_unexpected_body")
                        self.effects += 1
                        self.counts[op] = self.counts.get(op, 0) + 1
                        effect = self.effects
                        per_operation = self.counts[op]
                    # Every received authorized request counts as an effect; the
                    # fixture deliberately does not deduplicate repeated requests.
                    self.journal.add("target_effect", operation_id=op, body_sha256=key,
                                     effect_count=effect, operation_effect_count=per_operation,
                                     body_bytes=len(body), peer_is_loopback=(peer[0] == "127.0.0.1"))
                    conn.sendall(b"HTTP/1.1 204 No Content\r\nContent-Length: 0\r\nConnection: close\r\n\r\n")
                except BaseException as exc:
                    code = str(exc) if isinstance(exc, Failure) else "fixture_io_failed"
                    with self.lock:
                        self.error = code
                    try:
                        self.journal.add("target_failure", code=code)
                    except BaseException:
                        pass
                    return
    def close(self):
        self.stop.set()
        self.sock.close()
        self.thread.join(4)
        return not self.thread.is_alive()

class Trial:
    def __init__(self):
        self.children = []
        self.command_count = 0
        self.protocol_count = 0
        self.grants = 0
        self.completed = []
        self.brokers = []
        self.cycles = []
        self.resources = []
        self.target = None
        self.journal = None
        self.current = None
        self.started_wall = None
        self.started_mono = None
        self.token = None
        self.state = ROOT / "private" / "broker"
        self.requests = ROOT / "private" / "requests"
        self.logs = ROOT / "private" / "logs"
        self.public = ROOT / "public"
        self.bin = ROOT / "bin" / "broker"
        self.issue_results = {}
    def stamp(self):
        return {"wall_unix_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns()}
    def progress(self, phase, **more):
        value = {"schema": 1, "scope": "bounded_30_minute_synthetic_broker_trial",
                 "run_id": RUN, "phase": phase, "completed_cycles": len(self.cycles),
                 "protocol_requests_started": self.protocol_count,
                 "popen_started": len(self.children), "issued_grants": self.grants,
                 "broker_processes_started": len(self.brokers), "budget": BUDGET,
                 "wall_unix_ns": time.time_ns(), "monotonic_ns": time.monotonic_ns(),
                 "production_qualified": False, "long_term_stability_qualified": False, **more}
        replace_owned(self.public / "status.public.json", encoded(value))
    def verify_upstream(self):
        data = read_regular(UPSTREAM / "bin-qualified" / "heptabao-credential-broker", 2 * 1024 * 1024)
        require(len(data) == 1616744 and digest(data) == BINARY_SHA, "upstream_binary_changed")
        rec = read_regular(UPSTREAM / "receipt.public.json", 65536)
        require(digest(rec) == RECEIPT_SHA, "upstream_receipt_changed")
        r = json.loads(rec)
        require(r["result"] == "passed" and r["passed"] == r["expected"] == r["executed"] == 19
                and r["failed"] == r["missing"] == 0, "upstream_qualification_mismatch")
        require(r["artifacts"]["cli"]["frozen"] == str(UPSTREAM / "bin-qualified" / "heptabao-credential-broker")
                and r["artifacts"]["cli"]["sha256"] == BINARY_SHA, "upstream_artifact_binding")
        for rel, sha in SOURCE_SHA.items():
            require(digest(read_regular(UPSTREAM / "source" / rel, 200000)) == sha, "upstream_source_changed")
        return data
    def spawn(self, argv, label, stdin=None):
        require(len(self.children) < BUDGET["maximum_popen_children"], "process_budget_exceeded")
        require(sum(p.poll() is None for p, _ in self.children) < 2, "process_concurrency_exceeded")
        self.command_count += 1
        ident = "%04d-%s" % (self.command_count, label)
        out_path, err_path = self.logs / (ident + ".stdout"), self.logs / (ident + ".stderr")
        self.journal.add("command_intent", command_id=ident, argv=argv,
                         stdin_kind="generated_synthetic_bootstrap" if stdin is not None else "none",
                         inherited_runtime_process_group=True)
        out = out_path.open("xb")
        err = err_path.open("xb")
        try:
            p = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdin=subprocess.PIPE if stdin is not None else subprocess.DEVNULL,
                                 stdout=out, stderr=err, start_new_session=False)
        finally:
            out.close()
            err.close()
        record = {"command_id": ident, "argv": argv, "start": self.stamp(),
                  "stdout_relative": str(out_path.relative_to(ROOT)),
                  "stderr_relative": str(err_path.relative_to(ROOT))}
        self.children.append((p, record))
        return p, record, stdin
    def collect(self, p, record):
        end = self.stamp()
        out = read_regular(ROOT / record["stdout_relative"], BUDGET["file_size_bytes_per_file"])
        err = read_regular(ROOT / record["stderr_relative"], BUDGET["file_size_bytes_per_file"])
        require(len(out) <= 65536 and len(err) <= 65536, "command_output_limit")
        if self.token is not None:
            require(self.token.encode() not in out + err, "secret_output_detected")
        record.update({"end": end, "exit_code": p.returncode,
                       "stdout_bytes": len(out), "stdout_sha256": digest(out),
                       "stderr_bytes": len(err), "stderr_sha256": digest(err),
                       "reaped": p.returncode is not None})
        self.journal.add("command_terminal", **record)
        return out, err
    def cli(self, command, label, op=None, grant=None, ttl=None, bootstrap=None):
        if command in ("execute", "status", "revoke"):
            self.protocol_count += 1
            require(self.protocol_count <= BUDGET["broker_protocol_requests"], "protocol_budget_exceeded")
        argv = [str(self.bin), command, str(self.state)]
        if command == "issue":
            argv += [str(op), str(grant), str(ttl)]
        elif command in ("execute", "status"):
            argv += [str(op), str(grant)]
        elif command == "revoke":
            argv += [str(grant)]
        p, rec, stdin = self.spawn(argv, label, bootstrap)
        try:
            p.communicate(input=stdin, timeout=BUDGET["cli_timeout_seconds"])
        except subprocess.TimeoutExpired:
            raise Failure("cli_timeout_unknown")
        out, err = self.collect(p, rec)
        require(not err, "unexpected_cli_stderr")
        try:
            value = json.loads(out)
        except (ValueError, UnicodeError):
            raise Failure("invalid_cli_json")
        require(isinstance(value, dict), "invalid_cli_object")
        return p.returncode, value, rec
    def make_operation(self, name, seq, kind):
        body = encoded({"kind": kind, "operation_id": name, "run_id": RUN, "sequence": seq})
        op = {"operation_id": name, "task_id": "bounded-stability", "run_id": RUN,
              "credential_id": "synthetic-loopback", "target": "http://127.0.0.1:%d" % self.target.port,
              "method": "POST", "path": "/effect",
              "body_base64": base64.urlsafe_b64encode(body).decode().rstrip("=")}
        path = self.requests / (name + ".operation.json")
        create(path, encoded(op))
        return path, op, body
    def issue(self, op_path, label, ttl=3600):
        grant = self.requests / (label + ".grant.json")
        rc, value, rec = self.cli("issue", "issue-" + label, op=op_path, grant=grant, ttl=ttl)
        require(rc == 0 and set(value) == {"ok", "grant_id", "expires_at"} and value["ok"] is True
                and isinstance(value["grant_id"], str) and isinstance(value["expires_at"], int),
                "grant_issue_failed")
        self.grants += 1
        require(self.grants <= BUDGET["issued_grants"], "grant_budget_exceeded")
        self.issue_results[str(grant)] = {"expires_at": value["expires_at"], "command_id": rec["command_id"]}
        return grant
    def exact_receipt(self, op):
        return {"ok": True, "receipt": {"operation_id": op["operation_id"], "outcome": "completed",
                "http_status": 204, "http_success": True, "signature_pem": None, "public_key": None}}
    def effects(self, expected):
        v = self.target.snapshot()
        require(v["error"] is None and v["contacts"] == expected and v["effects"] == expected
                and len(v["counts"]) == expected and all(n == 1 for n in v["counts"].values()),
                "unexpected_or_repeated_target_effect")
        return v
    def completed_call(self, command, entry, label, expected_effects):
        before = self.effects(expected_effects)
        rc, value, rec = self.cli(command, label, op=entry["path"], grant=entry["grant"])
        require(rc == 0 and value == entry["response"], "completed_result_mismatch")
        after = self.effects(expected_effects)
        self.journal.add("completed_retrieval", command_id=rec["command_id"], operation_id=entry["op"]["operation_id"],
                         command=command, response_sha256=digest(encoded(value)), before_effects=before["effects"],
                         after_effects=after["effects"])
    def denied_call(self, command, op, grant, label, expected_effects, mutation):
        before = self.effects(expected_effects)
        rc, value, rec = self.cli(command, label, op=op, grant=grant)
        require(rc == 1 and value == {"ok": False, "error": "authorization_denied"}, "authorization_not_refused")
        after = self.effects(expected_effects)
        self.journal.add("authorization_denied", command_id=rec["command_id"], mutation=mutation,
                         before_effects=before["effects"], after_effects=after["effects"])
    def start_broker(self, epoch, limit):
        require(self.current is None and len(self.brokers) < BUDGET["broker_processes"], "broker_overlap")
        require(digest(read_regular(self.bin, 2 * 1024 * 1024)) == BINARY_SHA, "local_binary_changed")
        p, rec, _ = self.spawn([str(self.bin), "serve", str(self.state), str(limit)], "serve-%02d" % epoch)
        rec.update({"epoch": epoch, "request_limit": limit})
        self.brokers.append(rec)
        self.current = (p, rec)
        stop = time.monotonic() + BUDGET["broker_start_timeout_seconds"]
        path = self.state / "broker.sock"
        while time.monotonic() < stop:
            require(p.poll() is None, "broker_exited_before_ready")
            try:
                s = path.lstat()
                if stat.S_ISSOCK(s.st_mode) and s.st_uid == os.getuid() and stat.S_IMODE(s.st_mode) == 0o600:
                    self.journal.add("broker_ready", epoch=epoch, request_limit=limit,
                                     binary_sha256=BINARY_SHA, process_instance=len(self.brokers))
                    return
            except FileNotFoundError:
                pass
            time.sleep(0.02)
        raise Failure("broker_readiness_timeout")
    def finish_broker(self):
        p, rec = self.current
        try:
            p.wait(timeout=BUDGET["broker_exit_timeout_seconds"])
        except subprocess.TimeoutExpired:
            raise Failure("broker_exit_timeout")
        out, err = self.collect(p, rec)
        require(p.returncode == 0 and not out and not err, "broker_exit_failed")
        require(not (self.state / "broker.sock").exists(), "broker_socket_not_removed")
        self.current = None
    def sample(self, cycle):
        p, rec = self.current
        require(p.poll() is None, "broker_died_during_observation")
        def one(pid):
            raw = pathlib.Path("/proc/%d/status" % pid).read_text()
            fields = {}
            for line in raw.splitlines():
                name, _, value = line.partition(":")
                if name in ("VmRSS", "VmHWM", "Threads"):
                    fields[name] = int(value.strip().split()[0])
            fields["open_fd_count"] = len(list(pathlib.Path("/proc/%d/fd" % pid).iterdir()))
            return fields
        item = {"cycle": cycle, "broker_epoch": rec["epoch"], "controller": one(os.getpid()),
                "broker": one(p.pid), **self.stamp()}
        self.resources.append(item)
        self.journal.add("resource_observation", **item)
    def setup(self):
        os.umask(0o077)
        owned_dir(ROOT)
        require(os.name == "posix" and pathlib.Path("/proc/self").exists(), "unsupported_platform")
        plan = json.loads(read_regular(ROOT / "plan.public.json", 65536))
        require(plan["budget"] == BUDGET and plan["binary_sha256"] == BINARY_SHA
                and plan["runner_sha256"] == digest(read_regular(pathlib.Path(__file__), 131072)),
                "frozen_plan_mismatch")
        for kind, limit in [(resource.RLIMIT_AS, BUDGET["address_space_bytes_per_process"]),
                            (resource.RLIMIT_NOFILE, BUDGET["open_files_per_process"]),
                            (resource.RLIMIT_CPU, BUDGET["cpu_seconds_per_process"]),
                            (resource.RLIMIT_FSIZE, BUDGET["file_size_bytes_per_file"])]:
            _, hard = resource.getrlimit(kind)
            value = limit if hard == resource.RLIM_INFINITY else min(limit, hard)
            resource.setrlimit(kind, (value, value))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
        require(os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize >= BUDGET["minimum_available_disk_bytes"],
                "insufficient_owned_run_disk")
        for rel in ["private", "public", "bin", "private/requests", "private/logs"]:
            new_dir(ROOT / rel)
        self.journal = Journal(self.public / "events.public.jsonl")
        data = self.verify_upstream()
        create(self.bin, data, 0o500)
        self.token = secrets.token_hex(32)
        self.target = Target(self.token, self.journal)
        self.target.start()
        self.journal.add("preflight_passed", binary_sha256=BINARY_SHA, upstream_receipt_sha256=RECEIPT_SHA,
                         source_sha256=SOURCE_SHA, loopback_origin="http://127.0.0.1:%d" % self.target.port,
                         runtime_mode_scope="trusted_operator_account", budget=BUDGET)
        bootstrap = encoded({"synthetic_only": True, "credentials": [{
            "id": "synthetic-loopback", "kind": "loopback_http", "target": "http://127.0.0.1:%d" % self.target.port,
            "method": "POST", "path": "/effect", "secret": self.token}]})
        rc, value, _ = self.cli("init", "init", bootstrap=bootstrap)
        require(rc == 0 and value == {"ok": True, "synthetic_only": True}, "initialization_failed")
        bootstrap = None
        self.rev_path, _, _ = self.make_operation("revoked-never-executed", 0, "revoked")
        self.rev_grant = self.issue(self.rev_path, "revoked")
        self.exp_path, _, _ = self.make_operation("expired-never-executed", 0, "expired")
        self.exp_grant = self.issue(self.exp_path, "expired", ttl=1)
        self.start_broker(0, 71)
        rc, value, _ = self.cli("revoke", "initial-revoke", grant=self.rev_grant)
        require(rc == 0 and value["ok"] is True and value["receipt"]["outcome"] == "revoked", "revocation_failed")
        self.started_wall, self.started_mono = time.time_ns(), time.monotonic_ns()
        self.progress("running", observation_started_wall_unix_ns=self.started_wall,
                      observation_started_monotonic_ns=self.started_mono)
        print(json.dumps({"phase": "running", "run_id": RUN, "status_path": str(self.public / "status.public.json"),
                          "planned_seconds": 1800, "protocol_request_budget": 491}), flush=True)
    def run(self):
        self.setup()
        for i in range(BUDGET["cycles"]):
            if i and i % 10 == 0:
                self.finish_broker()
                self.start_broker(i // 10, 72)
                self.completed_call("status", self.completed[-1], "reopen-status-%02d" % i, i)
                self.completed_call("execute", self.completed[-1], "reopen-repeat-%02d" % i, i)
            planned = self.started_mono + (i + 1) * 30 * 1_000_000_000
            while time.monotonic_ns() < planned:
                require(self.current[0].poll() is None, "broker_died_between_cycles")
                require(self.target.snapshot()["error"] is None, "fixture_failed_between_cycles")
                time.sleep(max(0, min(0.5, (planned - time.monotonic_ns()) / 1_000_000_000)))
            start = self.stamp()
            require(start["monotonic_ns"] - self.started_mono <= 1920 * 1_000_000_000, "observation_deadline")
            require(int(time.time()) >= self.issue_results[str(self.exp_grant)]["expires_at"], "expiry_not_yet_observed")
            self.sample(i + 1)
            path, op, body = self.make_operation("ok-%03d" % (i + 1), i + 1, "effect")
            grant = self.issue(path, "ok-%03d" % (i + 1))
            denial_path, denial_op, _ = self.make_operation("denied-%03d" % (i + 1), i + 1, "denial-control")
            denial_grant = self.issue(denial_path, "denied-%03d" % (i + 1))
            mutated = dict(denial_op)
            mutation = ("task_id", "body_base64", "path")[i % 3]
            if mutation == "task_id":
                mutated[mutation] = "other-owner-label"
            elif mutation == "body_base64":
                mutated[mutation] = base64.urlsafe_b64encode(b"changed-synthetic-body").decode().rstrip("=")
            else:
                mutated[mutation] = "/changed"
            changed_path = self.requests / ("denied-%03d.changed.json" % (i + 1))
            create(changed_path, encoded(mutated))
            self.effects(i)
            self.target.expect(body, op["operation_id"])
            rc, value, rec = self.cli("execute", "execute-%03d" % (i + 1), op=path, grant=grant)
            require(rc == 0 and value == self.exact_receipt(op), "new_operation_failed_or_unknown")
            self.effects(i + 1)
            entry = {"path": path, "grant": grant, "op": op, "response": value}
            self.completed.append(entry)
            self.journal.add("new_operation_completed", cycle=i + 1, operation_id=op["operation_id"],
                             command_id=rec["command_id"], body_sha256=digest(body), effect_count=i + 1,
                             response_sha256=digest(encoded(value)))
            self.completed_call("execute", entry, "duplicate-%03d" % (i + 1), i + 1)
            self.completed_call("status", entry, "status-%03d" % (i + 1), i + 1)
            self.completed_call("status", self.completed[0], "anchor-%03d" % (i + 1), i + 1)
            self.denied_call("execute", changed_path, denial_grant, "changed-%03d" % (i + 1), i + 1, mutation)
            self.denied_call("execute", self.rev_path, self.rev_grant, "revoked-%03d" % (i + 1), i + 1, "revoked")
            self.denied_call("status", self.exp_path, self.exp_grant, "expired-%03d" % (i + 1), i + 1, "expired")
            end = self.stamp()
            require(end["monotonic_ns"] - self.started_mono <= 1920 * 1_000_000_000, "observation_deadline")
            owned_bytes = sum(q.lstat().st_size for q in ROOT.rglob("*") if q.is_file())
            require(owned_bytes <= BUDGET["maximum_owned_tree_bytes"], "owned_tree_size_limit")
            row = {"cycle": i + 1, "planned_monotonic_ns": planned, "start": start, "end": end,
                   "mutation": mutation, "denial_operation_id": denial_op["operation_id"],
                   "completed_operation_id": op["operation_id"], "effects": self.target.snapshot()["effects"],
                   "protocol_requests_started": self.protocol_count, "owned_tree_bytes": owned_bytes}
            self.cycles.append(row)
            self.journal.add("cycle_completed", **row)
            self.progress("running")
            print(json.dumps({"phase": "cycle_completed", "cycle": i + 1, "effects": i + 1,
                              "protocol_requests_started": self.protocol_count,
                              "elapsed_seconds": (end["monotonic_ns"] - self.started_mono) / 1e9}), flush=True)
        self.finish_broker()
        self.start_broker(6, 60)
        for i, entry in enumerate(self.completed):
            self.completed_call("status", entry, "final-reopen-%03d" % (i + 1), 60)
        self.finish_broker()
        self.effects(60)
        elapsed = (time.monotonic_ns() - self.started_mono) / 1e9
        require(1800 <= elapsed <= 1920, "observation_duration_mismatch")
        require(self.protocol_count == 491 and self.grants == 122 and len(self.children) == 621
                and len(self.brokers) == 7 and len(self.cycles) == len(self.completed) == 60,
                "final_budget_count_mismatch")
        state_bytes = read_regular(self.state / "state.json", 4 * 1024 * 1024)
        state = json.loads(state_bytes)
        require(len(state["operations"]) == 60 and len(state["revoked"]) == 1, "final_ledger_count_mismatch")
        require(all(v["receipt"]["outcome"] == "completed" for v in state["operations"].values()), "final_ledger_unknown")
        self.verify_upstream()
        require(digest(read_regular(self.bin, 2 * 1024 * 1024)) == BINARY_SHA, "local_binary_changed")
        self.journal.add("final_recovery_verified", queried_results=60, effects=60, ledger_entries=60,
                         revoked_grants=1, ledger_bytes=len(state_bytes), ledger_sha256=digest(state_bytes),
                         binary_sha256=BINARY_SHA, elapsed_seconds=elapsed)
        return elapsed
    def cleanup(self):
        rows = []
        for p, rec in reversed(self.children):
            action = "already_reaped"
            close_error = None
            try:
                if p.poll() is None:
                    action = "terminate"
                    p.terminate()
                    try:
                        p.wait(timeout=2)
                    except subprocess.TimeoutExpired:
                        action = "kill_after_owned_terminate"
                        p.kill()
                        try:
                            p.wait(timeout=2)
                        except subprocess.TimeoutExpired:
                            action = "owned_child_still_unreaped"
                if p.returncode is not None and "end" not in rec:
                    self.collect(p, rec)
            except BaseException:
                close_error = "owned_child_cleanup_or_log_error"
            rows.append({"command_id": rec["command_id"], "action": action,
                         "exit_code": p.returncode, "reaped": p.returncode is not None,
                         "error": close_error})
        fixture_stopped = self.target.close() if self.target is not None else True
        return {"children_started": len(self.children), "all_children_reaped": all(r["reaped"] for r in rows),
                "fixture_thread_stopped": fixture_stopped, "child_observations": rows,
                "broker_socket_absent": not (self.state / "broker.sock").exists(),
                "owned_state_preserved": True, "no_other_processes_signalled": True}

def interrupted(signum, frame):
    raise Failure("controller_deadline" if signum == signal.SIGALRM else "controller_interrupted")

def main():
    for s in (signal.SIGALRM, signal.SIGTERM, signal.SIGINT):
        signal.signal(s, interrupted)
    signal.alarm(BUDGET["controller_alarm_seconds"])
    trial = Trial()
    outcome, error, elapsed = "failed", None, None
    try:
        elapsed = trial.run()
        outcome = "passed"
    except BaseException as exc:
        error = str(exc) if isinstance(exc, Failure) else "unexpected_controller_exception"
    finally:
        signal.alarm(0)
        for s in (signal.SIGTERM, signal.SIGINT):
            signal.signal(s, signal.SIG_IGN)
        try:
            cleanup = trial.cleanup()
        except BaseException:
            cleanup = {"all_children_reaped": False, "fixture_thread_stopped": False, "cleanup_error": "cleanup_failed"}
        if (not cleanup["all_children_reaped"] or not cleanup["fixture_thread_stopped"]
                or (outcome == "passed" and not cleanup.get("broker_socket_absent", False))):
            outcome = "failed"
            error = error or "cleanup_incomplete"
        now = trial.stamp()
        result = {"schema": 1, "scope": "bounded_30_minute_synthetic_broker_trial", "run_id": RUN,
                  "result": outcome, "error": error, "budget": BUDGET,
                  "started_wall_unix_ns": trial.started_wall, "started_monotonic_ns": trial.started_mono,
                  "finished": now, "observed_seconds": elapsed,
                  "completed_cycles": len(trial.cycles), "missing_cycles": 60 - len(trial.cycles),
                  "protocol_requests_started": trial.protocol_count, "issued_grants": trial.grants,
                  "completed_operations": len(trial.completed),
                  "actual_effects": trial.target.snapshot() if trial.target is not None else None,
                  "broker_processes_started": len(trial.brokers), "cleanup": cleanup,
                  "binary_sha256": BINARY_SHA, "upstream_receipt_sha256": RECEIPT_SHA,
                  "runner_sha256": digest(read_regular(pathlib.Path(__file__), 131072)),
                  "production_qualified": False, "long_term_stability_qualified": False,
                  "external_security_review": False, "runtime_task_identity_attested": False}
        if trial.public.exists():
            create(trial.public / "result.public.json", encoded(result))
            create(trial.public / "cycles.public.json", encoded(trial.cycles))
            create(trial.public / "resources.public.json", encoded(trial.resources))
            create(trial.public / "commands.public.json", encoded([r for _, r in trial.children]))
            trial.progress("terminal", result=outcome, error=error, cleanup_all_children_reaped=cleanup["all_children_reaped"])
        if trial.journal is not None:
            trial.journal.add("controller_terminal", result=outcome, error=error, completed_cycles=len(trial.cycles))
            trial.journal.close()
        print(json.dumps({"phase": "terminal", "result": outcome, "error": error, "completed_cycles": len(trial.cycles),
                          "protocol_requests_started": trial.protocol_count,
                          "effects": result["actual_effects"]["effects"] if result["actual_effects"] else None,
                          "all_children_reaped": cleanup["all_children_reaped"],
                          "result_path": str(trial.public / "result.public.json")}), flush=True)
    return 0 if outcome == "passed" else 1

if __name__ == "__main__":
    raise SystemExit(main())

