# Bounded 30-minute synthetic broker trial

One original trial passed over **1800.279368418 seconds**. It executed all 60 scheduled
cycles, 60 distinct loopback HTTP effects exactly once, 250 completed-result retrievals
without additional effects, 180 expected authorization denials and one revocation:
491 broker protocol requests. Seven sequential broker processes (six graceful independent
restarts) and all 621 owned child invocations were reaped. The final new process queried
all 60 earlier completed results. There were 441 exit-zero commands and 180 expected
exit-one authorization refusals. The last scheduled cycle ended at 1800.075191901 seconds;
that is distinct from the full observation duration above.

The fixed Linux executable SHA-256 is
`6f9324480fb9e9f9ce08a182cd9822d5236cb866146578d5851845719319d9f5`.
The upstream 19-test receipt is artifact provenance only; its cases are not counted again.
Original Runtime job `1a1b20b8d9e-fc05-7c2d` was observed succeeded/exit 0 with complete,
durable stdout (7897 bytes), empty stderr and confirmed terminal publication. Its actual
request and launch response were persisted before an environment refresh. The controller
was not restarted. A later, separate read-only archive job is retained with its own binding.

`originals/broker-stability-30m.originals.tar.gz` is an unchanged 212011-byte inner archive
with 1255 regular members, including 1242 original command stdout/stderr streams, the
immutable runner/plan, all cycle/resource/event observations, and the original result.
Every inner manifest entry was checked locally by exact size and SHA-256. The root agent's
independent read-only observations and the earlier peer's plan-only review are preserved
separately. Neither is an external security review or an extra product execution.

The 60 samples cover six workload broker epochs, with observed peaks of 3300 KiB broker
RSS / 5 broker file descriptors and 22928 KiB controller RSS / 6 controller descriptors.
These are sampled peaks; the brief seventh recovery process was not resource-sampled.
The 65536-byte stream threshold is checked after a command, and the 32 MiB owned-tree
threshold after each cycle. They are not continuous quotas. RLIMIT_FSIZE supplies an
8 MiB per-file hard limit. The fixture's contact budget counts authenticated, fully read
requests, not every TCP accept. Requested Runtime limits and inherited per-process limits
are recorded without asserting independently measured cgroup enforcement.

This is a short-duration observation of synthetic owner-authorized loopback operations.
It does not qualify long-term stability, load capacity, arbitrary real credentials,
hostile same-UID isolation, physical power-loss recovery, production readiness, external
security review or Runtime task/run attestation. No ADB, product-source mutation or
previous owner-state mutation occurred. Owner keys, grants, bootstrap token and private
broker state are excluded. The new private trial state is retained for controlled recovery.

The final result and complete original streams are present. Some early read-only metadata
polls that existed only in volatile orchestration memory were not retained; they are not
reconstructed. Tool containers preserve their saved SDK representation, not a claim of raw
wire JSON formatting. Derived summaries and the new outer packaging are explicitly marked.
