import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import zipfile

os.umask(0o077)
ROOT = Path('/Users/qianqi/HeptaBaoAndroid-20261106-r1')
BUILD = ROOT / 'build/candidate6'
OUTPUT = ROOT / 'build/candidate6-review'
OUTPUT.mkdir(mode=0o700, exist_ok=False)
SHA = lambda data: hashlib.sha256(data).hexdigest()
digest = lambda path: SHA(path.read_bytes())
receipt_path = BUILD / 'receipt.json'
assert digest(receipt_path) == '327060e7d1a5bb5edd3634307a448d9e87c3cb578a3a2b5e09cc1b256760a33e'
build = json.loads(receipt_path.read_text())
source_manifest = json.loads((ROOT / 'android-source-r6.manifest.public.json').read_text())
source = ROOT / 'source/round6'
source_before = {name: digest(source / name) for name in source_manifest['files']}
assert source_before == source_manifest['files']
assert build['source_files_before'] == build['source_files_after'] == {name.removeprefix('clients/android/'): value for name, value in source_before.items() if name.startswith('clients/android/')}
bt = Path('/Users/qianqi/Library/Android/sdk/build-tools/34.0.0')
jdk = Path('/Library/Java/JavaVirtualMachines/temurin-17.jdk/Contents/Home')
env = dict(os.environ, JAVA_HOME=str(jdk), PATH=str(jdk / 'bin') + ':/usr/bin:/bin:/usr/sbin:/sbin')
result = {'schema': 1, 'purpose': 'candidate6_actual_apk_static_review_and_transport', 'started_unix_ns': time.time_ns(), 'build_receipt_sha256': digest(receipt_path), 'wrapper_sha256': digest(Path(__file__)), 'commands': [], 'checks': {}, 'device_operations': 0, 'production_qualified': False}


def run(argv, label, cwd=None, success=(0,)):
    started = time.time_ns()
    proc = subprocess.run([str(arg) for arg in argv], cwd=cwd, env=env, capture_output=True, check=False, timeout=120)
    (OUTPUT / (label + '.stdout')).write_bytes(proc.stdout)
    (OUTPUT / (label + '.stderr')).write_bytes(proc.stderr)
    result['commands'].append({'argv': list(map(str, argv)), 'cwd': str(cwd) if cwd else None, 'label': label, 'started_unix_ns': started, 'finished_unix_ns': time.time_ns(), 'exit_code': proc.returncode, 'stdout_sha256': SHA(proc.stdout), 'stderr_sha256': SHA(proc.stderr)})
    assert proc.returncode in success, label
    return proc.stdout


def tree(raw):
    roots, stack = [], []
    for line in raw.decode('utf-8').splitlines():
        element = re.fullmatch(r'( *)E: ([A-Za-z0-9_-]+) \(line=[0-9]+\)', line)
        if element:
            indent = len(element.group(1))
            while stack and stack[-1][0] >= indent:
                stack.pop()
            node = {'element': element.group(2), 'attrs': {}, 'children': []}
            (stack[-1][1]['children'] if stack else roots).append(node)
            stack.append((indent, node))
            continue
        attribute = re.fullmatch(r' *A: (?:http://schemas.android.com/apk/res/android:)?([A-Za-z0-9_.-]+)(?:\(0x[0-9a-f]+\))?=(.*)', line)
        if attribute:
            assert stack
            key, value = attribute.groups()
            assert key not in stack[-1][1]['attrs']
            if value.startswith('"'):
                value, _ = json.JSONDecoder().raw_decode(value)
            stack[-1][1]['attrs'][key] = value
    assert len(roots) == 1
    return roots[0]


def one(parent, element, name=None):
    values = [node for node in parent['children'] if node['element'] == element and (name is None or node['attrs'].get('name') == name)]
    assert len(values) == 1
    return values[0]


try:
    result['checks']['source_inventory_matches_build'] = True
    for path, expected in build['tool_files'].items():
        assert digest(Path(path)) == expected
    result['checks']['tool_files_unchanged'] = True
    assert digest(ROOT / 'deps/bcprov-jdk15to18-1.86.jar') == build['dependency']['sha256']
    result['checks']['dependency_digest_matches'] = True
    hashes_before = {name: digest(Path(row['path'])) for name, row in build['artifacts'].items()}
    assert hashes_before == {name: row['sha256'] for name, row in build['artifacts'].items()}
    result['checks']['four_apk_hashes_match_build'] = True
    for name, row in build['artifacts'].items():
        raw = run([bt / 'apksigner', 'verify', '--verbose', '--print-certs', row['path']], name + '-verify')
        match = re.findall(rb'^Signer #1 certificate SHA-256 digest: ([0-9a-f]{64})$', raw, re.MULTILINE)
        assert match == [row['signer_sha256'].encode()]
    result['checks']['all_four_signatures_match'] = True
    provider = Path(build['artifacts']['provider']['path'])
    manifest_raw = run([bt / 'aapt2', 'dump', 'xmltree', '--file', 'AndroidManifest.xml', provider], 'provider-manifest-tree')
    manifest = tree(manifest_raw)
    assert manifest['element'] == 'manifest' and manifest['attrs']['package'] == 'org.heptabao.personal.preview'
    sdk = one(manifest, 'uses-sdk')['attrs']
    assert sdk['minSdkVersion'] == sdk['targetSdkVersion'] == '34'
    result['checks']['min_target_sdk34'] = True
    assert not any(node['element'].startswith('uses-permission') for node in manifest['children'])
    result['checks']['no_permissions_including_network'] = True
    app = one(manifest, 'application')
    assert app['attrs']['debuggable'] == 'false' and app['attrs']['usesCleartextTraffic'] == 'false'
    result['checks']['nondebug_and_cleartext_disabled'] = True
    assert app['attrs']['allowBackup'] == app['attrs']['fullBackupContent'] == 'false'
    result['checks']['backup_manifest_disabled'] = True
    auth = one(app, 'activity', 'org.heptabao.preview.AuthActivity')
    service = one(app, 'service', 'org.heptabao.preview.VaultAutofillService')
    assert auth['attrs']['exported'] == 'false'
    assert service['attrs']['permission'] == 'android.permission.BIND_AUTOFILL_SERVICE'
    result['checks']['nonexported_auth_and_bound_service'] = True
    extraction = tree(run([bt / 'aapt2', 'dump', 'xmltree', '--file', 'res/xml/data_extraction_rules.xml', provider], 'provider-data-extraction-tree'))
    domains = {'root', 'file', 'database', 'sharedpref', 'external', 'device_root', 'device_file', 'device_database', 'device_sharedpref'}
    for mode in ('cloud-backup', 'device-transfer'):
        section = one(extraction, mode)
        assert len(section['children']) == 9 and all(node['element'] == 'exclude' and node['attrs']['path'] == '.' for node in section['children'])
        assert {node['attrs']['domain'] for node in section['children']} == domains
    resources = run([bt / 'aapt2', 'dump', 'resources', provider], 'provider-resources').decode()
    resource_id = app['attrs']['dataExtractionRules'].removeprefix('@')
    assert re.search(r'\bresource ' + re.escape(resource_id) + r' xml/data_extraction_rules\b', resources)
    result['checks']['cloud_and_device_transfer_nine_domains_excluded'] = True
    with zipfile.ZipFile(provider) as archive:
        dex = archive.read('classes.dex')
        assert all(fragment in dex for fragment in (b'trim_', b'_epoch_advanced', b'memory_locked'))
        result['provider_dex_sha256'] = SHA(dex)
    result['checks']['candidate6_closed_diagnostics_in_dex'] = True
    result['source_hashes_after'] = {name: digest(source / name) for name in source_manifest['files']}
    assert source_before == result['source_hashes_after']
    result['apk_hashes_after'] = {name: digest(Path(row['path'])) for name, row in build['artifacts'].items()}
    assert hashes_before == result['apk_hashes_after']
    result['artifacts'] = build['artifacts']
    result['crypto_interop'] = build['crypto_interop']
    result['checks_passed'] = len(result['checks'])
    result['result'] = 'static_artifact_review_passed_device_not_run'

    transfer = OUTPUT / 'transport'; transfer.mkdir(mode=0o700)
    old = transfer / 'old'; new = transfer / 'new'; replay = transfer / 'replay'
    for directory in (old, new, replay): directory.mkdir(mode=0o700)
    old_apk = ROOT / 'build/candidate5/apks/provider.apk'
    assert digest(old_apk) == '5c643afa5a08c6e8dd0baf751fe56dadf0f66947284d119d2da7051f4ab88ff8'
    shutil.copyfile(old_apk, old / 'provider.apk'); shutil.copyfile(provider, new / 'provider.apk'); shutil.copyfile(old_apk, replay / 'provider.apk')
    patch = run(['/usr/bin/git', '--no-pager', 'diff', '--no-index', '--binary', '--', 'old/provider.apk', 'new/provider.apk'], 'provider-binary-diff', cwd=transfer, success=(1,))
    patch_path = OUTPUT / 'provider-c5-to-c6.patch'; patch_path.write_bytes(patch)
    run(['/usr/bin/git', 'apply', '--binary', '-p2', '--check', patch_path], 'provider-patch-check', cwd=replay)
    run(['/usr/bin/git', 'apply', '--binary', '-p2', patch_path], 'provider-patch-replay', cwd=replay)
    assert digest(replay / 'provider.apk') == digest(provider)
    result['binary_transport'] = {'base_sha256': digest(old_apk), 'target_sha256': digest(provider), 'patch_path': str(patch_path), 'patch_sha256': SHA(patch), 'patch_bytes': len(patch), 'isolated_replay_verified': True, 'no_source_or_old_apk_changed': True}
except Exception as error:
    result['result'] = 'artifact_review_failed'
    result['error_class'] = type(error).__name__
    result['finished_unix_ns'] = time.time_ns()
    (OUTPUT / 'review.failed.public.json').write_text(json.dumps(result, sort_keys=True, indent=2) + chr(10))
    raise
result['finished_unix_ns'] = time.time_ns()
(OUTPUT / 'artifact-review.public.json').write_text(json.dumps(result, sort_keys=True, indent=2) + chr(10))
print(json.dumps({'result': result['result'], 'checks_passed': result['checks_passed'], 'artifact_review_sha256': digest(OUTPUT / 'artifact-review.public.json'), 'binary_transport': result['binary_transport']}, sort_keys=True))
