import hashlib,json,os,pathlib,subprocess,tarfile,time
os.umask(0o077)
root=pathlib.Path('/Users/qianqi/HeptaBaoAndroid-20261106-r1')
archive=root/'android-source-r6.tar.gz'
manifest_path=root/'android-source-r6.manifest.public.json'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(archive)=='d887e60f986302bb731a9591c260a2eaf8e24161a5cefe39a6b9c40e6d812400'
assert sha(manifest_path)=='b2e977c7ef7214676ee1247c33d92cf5d43ed5c6f08aa3223842acf7e0f786c4'
manifest=json.loads(manifest_path.read_text())
source=root/'source/round6';source.mkdir(mode=0o700,exist_ok=False)
with tarfile.open(archive,'r:gz') as stream:
 members=stream.getmembers()
 assert len(members)==20 and set(m.name for m in members)==set(manifest['files'])
 for member in members:
  path=pathlib.PurePosixPath(member.name)
  assert member.isfile() and not path.is_absolute() and '..' not in path.parts
  data=stream.extractfile(member).read()
  assert hashlib.sha256(data).hexdigest()==manifest['files'][member.name]
  target=source/path;target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
  with target.open('xb') as output:output.write(data)
command=['/usr/bin/python3',str(source/'qa/personal_credentials/android_build.py'),
 '--source',str(source/'clients/android'),'--fixture',str(root/'private/fixture-r2'),
 '--sdk','/Users/qianqi/Library/Android/sdk','--java-home','/Library/Java/JavaVirtualMachines/temurin-17.jdk/Contents/Home',
 '--bc-jar',str(root/'deps/bcprov-jdk15to18-1.86.jar'),'--output',str(root/'build/candidate6')]
launch={'schema':1,'argv':command,'source_archive_sha256':sha(archive),'source_manifest_sha256':sha(manifest_path),'wrapper_sha256':sha(pathlib.Path(__file__)),'started_unix_ns':time.time_ns(),'synthetic_only':True,'device_operations':0}
(root/'candidate6.launch.public.json').write_text(json.dumps(launch,sort_keys=True,indent=2)+chr(10))
with (root/'candidate6.build.stdout').open('xb') as output,(root/'candidate6.build.stderr').open('xb') as error:
 result=subprocess.run(command,stdout=output,stderr=error,check=False)
launch.update(exit_code=result.returncode,finished_unix_ns=time.time_ns(),stdout_sha256=sha(root/'candidate6.build.stdout'),stderr_sha256=sha(root/'candidate6.build.stderr'))
receipt=root/'build/candidate6/receipt.json'
if receipt.exists():launch['build_receipt_sha256']=sha(receipt)
(root/'candidate6.execution.public.json').write_text(json.dumps(launch,sort_keys=True,indent=2)+chr(10))
print(json.dumps(launch,sort_keys=True))
raise SystemExit(result.returncode)
