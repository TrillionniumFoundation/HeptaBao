# Linux broker shared-deadline qualification

The final three-file candidate built with Rust 1.98.0 and passed 19 of 19 actual Linux tests on ai395. This archive binds the c447 baseline, exact replacement files, Cargo lock, private offline cache inputs, build arguments, executable hashes, test inventories, original output, and Runtime request/launch/terminal records. All Cargo commands finished before qualified executables were copied and tested. The preserved old source and three qualified artifacts remained unchanged.

The first controller stopped before Cargo because it incorrectly required an absent historical target/debug binary. Its source, failure, receipt, and Runtime records remain under r1; the second controller uses a new directory and records the absence without guessing why it occurred. No product or test change was made between those Linux controller revisions.

The 19 tests comprise six real Unix-pair framing/deadline cases, two algorithm rejection controls, and eleven unchanged process/CLI/API/Git/revocation/recovery cases. This is a synthetic scope, not whole-workspace or production qualification and not an external security audit. The ten absent cache archives were not needed by this exact build; no complete workspace offline claim is made.

All included source and logs were explicitly selected. No credentials, vault contents, signing private keys, or global Cargo configuration are included. The baseline source tar itself remains remotely at its original receipt-bound output path; its complete source manifest and SHA are retained here. Copied tool-response structures preserve original embedded text, but are not described as raw wire captures or attestation.
