import gzip, hashlib, io, json, os, pathlib, stat, tarfile, time
B=pathlib.Path("/home/qq")
R1=B/"heptabao-broker-poll-fix-20261106-r1"
R2=B/"heptabao-broker-poll-fix-20261106-r2"
OUT=B/"heptabao-broker-poll-fix-linux-public-20261106-r1"
ARCHIVE=B/"heptabao-broker-poll-fix-linux-public-20261106-r1.tar.gz"
EXTRA=B/"heptabao-broker-poll-fix-linux-public-extras-20261106-r1.json"
def req(v,c):
 if not v: raise RuntimeError(c)
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p,cap=16*1024*1024):
 fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  s=os.fstat(fd);req(stat.S_ISREG(s.st_mode) and s.st_size<=cap,"regular_file")
  with os.fdopen(fd,"rb",closefd=False) as f:b=f.read(cap+1)
  a=os.fstat(fd);req(len(b)==s.st_size and (s.st_ino,s.st_dev,s.st_mtime_ns,s.st_size)==(a.st_ino,a.st_dev,a.st_mtime_ns,a.st_size),"stable_read")
  return b
 finally:os.close(fd)
def syncdir(p):
 fd=os.open(p,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
 try:os.fsync(fd)
 finally:os.close(fd)
files=[]
def put(name,data,origin):
 p=pathlib.PurePosixPath(name);req(not p.is_absolute() and ".." not in p.parts and all(x["path"]!=name for x in files),"safe_unique_path")
 target=OUT.joinpath(*p.parts);target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
 try:
  with os.fdopen(fd,"wb",closefd=False) as f:f.write(data);f.flush();os.fsync(f.fileno())
 finally:os.close(fd)
 syncdir(target.parent);req(read(target)==data,"write_readback")
 files.append({"path":name,"bytes":len(data),"sha256":sha(data),"origin":origin})
def cp(name,p,pin=None):
 b=read(p)
 if pin: req(sha(b)==pin,"source_hash_mismatch")
 put(name,b,"exact_original_file")
def toolbody(obj):
 if obj.get("status")=="fulfilled":obj=obj["value"]
 if obj.get("structuredContent") is not None:return obj["structuredContent"]
 return json.loads(next(x["text"] for x in obj["content"] if x["type"]=="text"))
os.umask(0o077);req(not OUT.exists() and not ARCHIVE.exists(),"new_output_only")
extra=read(EXTRA);req(sha(extra)=="f92e4772f81213fbd45bb16c43b36aca6fa7852c3a4c7445d3490d2c7b5cfaa1","extra_pin")
supp=json.loads(extra);req(all(isinstance(k,str) and isinstance(v,str) for k,v in supp.items()),"supplement_shape")
r1b=read(R1/"receipt.public.json");req(sha(r1b)=="914162dad229d2b0f2c967d0f66398bba020c8302a02eb08677a54be1efea8cd","r1_pin")
r2b=read(R2/"receipt.public.json");req(sha(r2b)=="e787df00bcc3d39cab8679463adacf147359e893541d3f9f3a36460c1ac58424","r2_pin")
r1=json.loads(r1b);r2=json.loads(r2b)
req(r1["result"]=="failed" and r1["executed"]==0 and not r1["commands"],"r1_scope")
req(r2["result"]=="passed" and (r2["expected"],r2["executed"],r2["passed"],r2["failed"],r2["missing"])==(19,19,19,0,0),"r2_counts")
req(r2["old_baseline_unchanged"] and r2["candidate_source_unchanged_after_tests"] and r2["cargo_writes_complete_before_freezing"],"r2_identity")
OUT.mkdir(mode=0o700);syncdir(B)
for name,text in supp.items():put(name,text.encode(),"copied_structured_record_or_new_review_as_named")
put("packet-assembler.actual.py",PACKAGER_SOURCE.encode(),"actual_assembler_source")
for label,root,receipt in (("r1",R1,r1),("r2",R2,r2)):
 for leaf in ("receipt.public.json","runner.actual.py","payload.original.json"):cp(label+"/"+leaf,root/leaf)
 if label=="r1":cp("r1/failure.private.txt",root/"failure.private.txt","e3720e88d93bf626ddd6b09a6ebb6e1be0b94e62b4f1c5597c4920ddfa5e6135")
for leaf,pin in (
 ("baseline-source.manifest.public.json",r2["baseline_source_manifest"]["sha256"]),
 ("candidate-source.manifest.public.json",r2["candidate_source_manifest"]["sha256"]),
 ("private-cache.manifest.public.json",r2["cache"]["manifest"]["sha256"])):
 cp("r2/"+leaf,R2/leaf,pin)
excluded=[]
for c in r2["commands"]:
 for kind in ("stdout","stderr"):
  row=c[kind];p=pathlib.PurePosixPath(row["path"]);req(p.parts[0]=="logs" and len(p.parts)==2,"log_path")
  if row["path"]=="logs/archive-baseline.stdout.original":
   excluded.append({"path":str(R2/row["path"]),"bytes":row["bytes"],"sha256":row["sha256"],"reason":"full repository source tar retained in place; fixed Git tree and complete source manifest included"})
   continue
  b=read(R2/row["path"]);req(len(b)==row["bytes"] and sha(b)==row["sha256"],"command_log_pin")
  put("r2/"+row["path"],b,"exact_original_command_output")
src=R2/"source"
selected=["Cargo.lock","Cargo.toml","crates/heptabao-credential-broker/Cargo.toml",
 "crates/heptabao-credential-broker/src/lib.rs","crates/heptabao-credential-broker/src/main.rs",
 "crates/heptabao-credential-broker/src/frame_read_tests.rs",
 "crates/heptabao-credential-broker/tests/algorithm_policy.rs",
 "crates/heptabao-credential-broker/tests/process_e2e.rs","tools/heptabao_git_signer.py"]
source_rows={x["path"]:x for x in json.loads(read(R2/"candidate-source.manifest.public.json"))["files"]}
for p in selected:cp("source/"+p,src/p,source_rows[p]["sha256"])
for version,job in (("r1","1a1b1dd5085-fc05-7b34"),("r2","1a1b1dfbcc2-fc05-7b44")):
 terminal=toolbody(json.loads(supp["runtime/"+version+"-terminal.tool-response.json"]))
 req(terminal["job_id"]==job and terminal["output_complete"] and terminal["output_durable"],"terminal_binding")
 logs=toolbody(json.loads(supp["runtime/"+version+"-process-read.tool-response.json"]))
 req(logs["job_id"]==job,"runtime_log_binding")
 for k in ("stdout","stderr"):
  row=logs[k];raw=bytes.fromhex(row["bytes_hex"]);req(row["offset"]==0 and row["eof"] and len(raw)==row["size"]==row["next_offset"] and raw.decode()==row["text"],"runtime_original_complete")
  put("runtime/"+version+"."+k+".original",raw,"exact_original_Runtime_process_read_bytes")
manifest={"schema":1,"scope":"linux_broker_poll_fix_exact_candidate_synthetic_original_evidence","external_security_review":False,"production_qualified":False,
 "files":sorted(files,key=lambda x:x["path"]),"excluded_large_originals_retained_remote":excluded,
 "expected_test_count":19,"actual_test_count":19,"actual_passed":19,"actual_failed":0,"not_raw_wire_json":True}
mb=(json.dumps(manifest,sort_keys=True,indent=2)+"\n").encode()
put("manifest.public.json",mb,"new_archive_integrity_index")
with open(ARCHIVE,"xb") as af:
 with gzip.GzipFile(filename="",mode="wb",fileobj=af,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode="w") as tf:
   for row in sorted(files,key=lambda x:x["path"]):
    b=read(OUT/row["path"]);req(len(b)==row["bytes"] and sha(b)==row["sha256"],"archive_input_changed")
    info=tarfile.TarInfo(row["path"]);info.size=len(b);info.mode=0o600;info.mtime=0;info.uid=info.gid=0;tf.addfile(info,io.BytesIO(b))
 af.flush();os.fsync(af.fileno())
syncdir(B);ab=read(ARCHIVE)
with tarfile.open(fileobj=io.BytesIO(ab),mode="r:gz") as tf:
 members=tf.getmembers();req(len(members)==len(files) and all(x.isfile() for x in members),"tar_regular_count")
 rows={x["path"]:x for x in files};req({m.name for m in members}==set(rows),"tar_paths")
 for m in members:
  b=tf.extractfile(m).read();req(len(b)==rows[m.name]["bytes"] and sha(b)==rows[m.name]["sha256"],"tar_member_pin")
print(json.dumps({"result":"archived_originals_verified","scope":"archive_integrity_only_not_new_test","archive":str(ARCHIVE),"bytes":len(ab),"sha256":sha(ab),
 "regular_members":len(files),"indexed_originals":len(files)-1,"manifest_sha256":sha(mb),"r2_receipt_sha256":sha(r2b),"r1_failure_preserved":True},sort_keys=True),flush=True)
