#!/usr/bin/python3
"""One isolated, synthetic-only Linux qualification; no cache/network fallback."""
import base64, hashlib, json, os, pathlib, re, shutil, signal, stat, subprocess, sys, tarfile, time, tomllib, traceback

ROOT = pathlib.Path("/home/qq/heptabao-broker-poll-fix-20261106-r1")
BASE = pathlib.Path("/home/qq/heptabao-broker-ed25519-c447536")
OLD = pathlib.Path("/home/qq/heptabao-broker-ed25519-c447536-build")
TOOLBIN = pathlib.Path("/home/qq/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin")
COMMIT = "c447536ae0343731d84c18291d2dcd712b3bea08"
TREE = "50835fd4df6e7bdd2b551941a3fa012281c931c2"
LOCK = "ef3b19cf8b1b360f7888f11e3e5b1523e464762d6c24ce7e92b64d0d7d5c99a9"
REG = "index.crates.io-1949cf8c6b5b557f"
EXPECTED_OLD = {
 "bin-qualified/heptabao-credential-broker":"6fe0b6c78213e4bb1184ca4c4be7fc3e44dce4117f22097aab14efa567ac8a08",
 "target/debug/heptabao-credential-broker":"6fe0b6c78213e4bb1184ca4c4be7fc3e44dce4117f22097aab14efa567ac8a08",
 "test-qualified/algorithm_policy":"bdcfa6b8338ce16bfa1f7bbf4295d1e5b60edf14c4c5ca34d91592d2737360fe",
 "test-qualified/process_e2e":"af3a7b7f82acb262304989d0dc51e3fcc03b367d06e0bb78a744f37d2fd4eb43"}
EXPECTED_FILES = {
 "crates/heptabao-credential-broker/Cargo.toml":"0f281abd2fb8ee3d37250a5d7d93bba92aa9089b0e49732a7bdbee8ba5b17ad6",
 "crates/heptabao-credential-broker/src/lib.rs":"3617799f6de0368fa3b4b4c1343510fe9d202ee3a31fc0e067eb312c40732001",
 "crates/heptabao-credential-broker/src/frame_read_tests.rs":"2a203ee7ca0e4c8f9b878abb0727374a57e3f977dc3a09e1d8cad5ed3a5b9fc7"}
TEST_NAMES = {
 "frame_read_tests":[
  "frame_read_tests::an_open_silent_peer_cannot_hold_the_reader_past_the_deadline",
  "frame_read_tests::closed_partial_header_and_body_are_incomplete",
  "frame_read_tests::complete_frame_remains_readable_after_peer_close",
  "frame_read_tests::fragmented_live_frame_is_read_within_one_deadline",
  "frame_read_tests::header_progress_does_not_reset_the_body_deadline",
  "frame_read_tests::invalid_frame_sizes_are_refused_before_reading_a_body"],
 "algorithm_policy":["valid_ecdsa_key_is_rejected_by_sdk_and_cli","valid_rsa_key_is_rejected_by_sdk_and_cli"],
 "process_e2e":[
  "actual_cli_and_ed25519_git_sshsig_verify","actual_cli_denials_have_nonzero_exit_and_no_target_contact",
  "actual_git_commit_signing_and_verify_commit_bind_repository_and_payload",
  "cli_non_success_http_is_recorded_without_retry_and_queryable",
  "killed_after_target_contact_remains_unknown_without_second_dispatch",
  "owner_rejects_unscoped_targets_and_request_variants",
  "private_permissions_symlinks_and_competing_writer_are_rejected",
  "real_process_api_echo_is_not_released_and_result_survives_restart",
  "redirect_is_not_followed_and_conflicting_id_is_rejected",
  "revocation_survives_process_restart",
  "wrong_target_body_task_signature_and_expired_grants_do_not_contact_target"]}
READ_ENV={"PATH":str(TOOLBIN)+":/usr/local/bin:/usr/bin:/bin","LANG":"C.UTF-8","LC_ALL":"C.UTF-8",
 "GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_GLOBAL":"/dev/null","GIT_OPTIONAL_LOCKS":"0","GIT_TERMINAL_PROMPT":"0"}
report={"schema":1,"scope":"linux_broker_c447_plus_exact_poll_fix_synthetic_only","synthetic_only":True,
 "production_qualified":False,"external_security_review":False,"expected":19,"executed":0,"passed":0,
 "failed":0,"missing":19,"commands":[],"test_suites":{},"source_expected_commit":COMMIT,
 "source_expected_tree":TREE,"lock_sha256":LOCK,"overlays":EXPECTED_FILES,"started_unix_ns":time.time_ns(),
 "build_network_policy":"private Cargo home; --offline --locked and CARGO_NET_OFFLINE=true",
 "test_network_scope":"synthetic local Unix sockets and loopback HTTP only",
 "prior_results_inherited":False,"result":"running"}

def require(ok, code):
 if not ok: raise RuntimeError(code)
def digest(data): return hashlib.sha256(data).hexdigest()
def read(path, cap=256*1024*1024):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  s=os.fstat(fd);require(stat.S_ISREG(s.st_mode) and s.st_size<=cap,"unsafe_or_large_file")
  chunks=[];total=0
  while True:
   b=os.read(fd,min(1024*1024,cap+1-total))
   if not b:break
   chunks.append(b);total+=len(b);require(total<=cap,"read_cap")
  a=os.fstat(fd);require((s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns)==(a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns),"file_changed")
  require(total==s.st_size,"short_file")
  return b"".join(chunks)
 finally:os.close(fd)
def meta(path):
 b=read(path);return {"bytes":len(b),"sha256":digest(b)}
def syncdir(path):
 fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
 try:os.fsync(fd)
 finally:os.close(fd)
def create(path, data, mode=0o600):
 path=pathlib.Path(path);path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,mode)
 try:
  with os.fdopen(fd,"wb",closefd=False) as f:f.write(data);f.flush();os.fsync(f.fileno())
 finally:os.close(fd)
 syncdir(path.parent)
def public(path,obj): create(path,(json.dumps(obj,sort_keys=True,indent=2)+"\n").encode())
def checkpoint():
 path=ROOT/"receipt.public.json";tmp=ROOT/(".receipt-"+str(time.time_ns())+".tmp")
 create(tmp,(json.dumps(report,sort_keys=True,indent=2)+"\n").encode());os.replace(tmp,path);syncdir(ROOT)
def git_state():
 def one(args):
  r=subprocess.run(["/usr/bin/git","-C",str(BASE)]+args,env=READ_ENV,capture_output=True,timeout=30)
  require(r.returncode==0,"baseline_git_failed");return r.stdout.decode().strip()
 s={"commit":one(["rev-parse","HEAD"]),"tree":one(["rev-parse","HEAD^{tree}"]),
    "porcelain":one(["status","--porcelain=v1"]),"lock":meta(BASE/"Cargo.lock")}
 require(s["commit"]==COMMIT and s["tree"]==TREE and not s["porcelain"] and s["lock"]["sha256"]==LOCK,"baseline_identity_changed")
 return s
def old_hashes():
 h={name:meta(OLD/name) for name in EXPECTED_OLD}
 require(all(h[n]["sha256"]==v for n,v in EXPECTED_OLD.items()),"old_qualified_artifact_changed")
 return h
def command(label,argv,env,cwd,timeout,needed=True):
 out=ROOT/"logs"/(label+".stdout.original");err=ROOT/"logs"/(label+".stderr.original")
 t=time.monotonic_ns();item={"label":label,"argv":argv,"cwd":str(cwd),"environment":env,
 "deadline_seconds":timeout,"started_unix_ns":time.time_ns(),"timed_out":False}
 with open(out,"xb") as of,open(err,"xb") as ef:
  p=subprocess.Popen(argv,env=env,cwd=cwd,stdin=subprocess.DEVNULL,stdout=of,stderr=ef,start_new_session=True)
  item["owned_pid"]=p.pid
  try:item["exit_code"]=p.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   item["timed_out"]=True
   try:os.killpg(p.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   item["exit_code"]=p.wait()
  of.flush();ef.flush();os.fsync(of.fileno());os.fsync(ef.fileno())
 syncdir(out.parent);item.update({"elapsed_ns":time.monotonic_ns()-t,
 "stdout":{"path":str(out.relative_to(ROOT)),**meta(out)},
 "stderr":{"path":str(err.relative_to(ROOT)),**meta(err)}})
 report["commands"].append(item);checkpoint()
 if needed:require(item["exit_code"]==0 and not item["timed_out"],"command_failed_"+label)
 return item
def source_manifest(src):
 rows=[]
 for p in sorted(src.rglob("*")):
  if p.is_symlink():raise RuntimeError("source_symlink")
  if p.is_file():rows.append({"path":str(p.relative_to(src)),**meta(p)})
 return rows
def records(log):
 result=[]
 for line in read(log).splitlines():
  try:item=json.loads(line)
  except (ValueError,UnicodeDecodeError):continue
  if isinstance(item,dict) and item.get("reason")=="compiler-artifact" and item.get("executable"):result.append(item)
 return result
def copy_regular(src,dst,expected=None,mode=0o600):
 b=read(src)
 if expected:require(digest(b)==expected,"input_checksum_mismatch")
 create(dst,b,mode);require(meta(dst)=={"bytes":len(b),"sha256":digest(b)},"copy_readback")
 return {"bytes":len(b),"sha256":digest(b)}

def main():
 os.umask(0o077)
 require(len(sys.argv)==2,"payload_argument")
 payload_bytes=read(sys.argv[1],256*1024);payload=json.loads(payload_bytes)
 require(set(payload)=={"schema","files"} and payload["schema"]==1 and set(payload["files"])==set(EXPECTED_FILES),"payload_schema")
 for p,sha in EXPECTED_FILES.items():
  b=base64.b64decode(payload["files"][p],validate=True);require(digest(b)==sha,"overlay_checksum")
 require(not ROOT.exists(),"output_already_exists")
 ROOT.mkdir(mode=0o700);syncdir(ROOT.parent)
 for n in ("logs","bin-qualified","test-qualified","cargo-home","target","source"): (ROOT/n).mkdir(mode=0o700)
 copy_regular(pathlib.Path(__file__),ROOT/"runner.actual.py")
 create(ROOT/"payload.original.json",payload_bytes)
 report["runner"]=meta(ROOT/"runner.actual.py");report["payload"]=meta(ROOT/"payload.original.json")
 checkpoint()
 try:
  report["source_before"]=git_state();report["old_artifacts_before"]=old_hashes()
  report["tools"]={name:{"path":str(TOOLBIN/name),**meta(TOOLBIN/name)} for name in ("cargo","rustc")}
  command("rustc-version",[str(TOOLBIN/"rustc"),"-vV"],READ_ENV,ROOT,30)
  rv=read(ROOT/"logs/rustc-version.stdout.original").decode()
  require("rustc 1.98.0 " in rv and "commit-hash: 88d9e12ae178fab0fb5cc050a94da85685d449ea" in rv and "host: x86_64-unknown-linux-gnu" in rv,"toolchain_mismatch")
  report["rustc_vV"]=rv
  command("cargo-version",[str(TOOLBIN/"cargo"),"--version"],READ_ENV,ROOT,30)
  for name in ("git","ssh-keygen","cc"):
   path=shutil.which(name,path=READ_ENV["PATH"]);require(path is not None,"tool_missing")
   report["tools"][name]={"path":path,**meta(pathlib.Path(path).resolve())}
  command("archive-baseline",["/usr/bin/git","-C",str(BASE),"archive","--format=tar",COMMIT],READ_ENV,ROOT,60)
  archive=ROOT/"logs/archive-baseline.stdout.original";src=ROOT/"source"
  with tarfile.open(archive,"r:") as tf:
   members=tf.getmembers();require(len(members)<=20000 and sum(m.size for m in members)<=256*1024*1024,"source_archive_cap")
   seen=set()
   for m in members:
    p=pathlib.PurePosixPath(m.name);require(not p.is_absolute() and ".." not in p.parts and m.name not in seen,"archive_path");seen.add(m.name)
    target=src.joinpath(*p.parts)
    if m.isdir():target.mkdir(mode=0o700,parents=True,exist_ok=True)
    else:
     require(m.isfile(),"archive_nonregular")
     f=tf.extractfile(m);require(f is not None,"archive_member")
     create(target,f.read(),0o700 if m.mode&0o111 else 0o600)
  baseline=source_manifest(src);public(ROOT/"baseline-source.manifest.public.json",{"files":baseline})
  report["baseline_source_manifest"]=meta(ROOT/"baseline-source.manifest.public.json")
  for p in EXPECTED_FILES:
   target=src/p
   if target.exists():target.unlink()
   create(target,base64.b64decode(payload["files"][p],validate=True))
  require(meta(src/"Cargo.lock")["sha256"]==LOCK,"candidate_lock_changed")
  before=source_manifest(src);public(ROOT/"candidate-source.manifest.public.json",{"files":before})
  report["candidate_source_manifest"]=meta(ROOT/"candidate-source.manifest.public.json")
  lock=tomllib.loads(read(src/"Cargo.lock").decode())
  packages=[p for p in lock["package"] if p.get("source")]
  require(all(p["source"]=="registry+https://github.com/rust-lang/crates.io-index" for p in packages),"nonpublic_registry")
  cache=ROOT/"cargo-home/registry/cache"/REG;index=ROOT/"cargo-home/registry/index"/REG
  cache.mkdir(mode=0o700,parents=True);(index/".cache").mkdir(mode=0o700,parents=True)
  public(index/"config.json",{"dl":"https://static.crates.io/crates","api":"https://crates.io"})
  source_cache=pathlib.Path("/home/qq/.cargo/registry/cache")/REG
  source_index=pathlib.Path("/home/qq/.cargo/registry/index")/REG/".cache"
  cache_rows=[];index_rows=[];missing=[];byname={}
  for pkg in packages:
   name,ver,sha=pkg["name"],pkg["version"],pkg["checksum"]
   require(re.fullmatch(r"[a-zA-Z0-9_-]+",name) and re.fullmatch(r"[a-zA-Z0-9_.+-]+",ver) and re.fullmatch(r"[0-9a-f]{64}",sha),"lock_package_shape")
   byname.setdefault(name,[]).append(pkg)
   leaf=f"{name}-{ver}.crate";sp=source_cache/leaf
   if sp.exists():cache_rows.append({"name":leaf,**copy_regular(sp,cache/leaf,sha)})
   else:missing.append({"name":name,"version":ver,"checksum":sha})
  for name,versions in sorted(byname.items()):
   rel=name if len(name)==1 else ("2/"+name if len(name)==2 else ("3/"+name[0]+"/"+name if len(name)==3 else name[:2]+"/"+name[2:4]+"/"+name))
   if len(name)==1:rel="1/"+name
   ib=read(source_index/rel,16*1024*1024);rows={}
   for part in ib.split(b"\0"):
    if part.startswith(b"{"):
     obj=json.loads(part)
     if obj.get("name")==name:rows[obj["vers"]]=obj
   for pkg in versions:require(pkg["version"] in rows and rows[pkg["version"]].get("cksum")==pkg["checksum"],"index_lock_checksum_mismatch")
   create(index/".cache"/rel,ib);index_rows.append({"path":rel,"bytes":len(ib),"sha256":digest(ib)})
  public(ROOT/"private-cache.manifest.public.json",{"locked_versions":len(packages),"index":index_rows,"archives":cache_rows,"missing_archives":missing,
   "scope":"only public index/archive; no global config or credentials; absent archives not fetched"})
  report["cache"]={"locked_versions":len(packages),"index_files":len(index_rows),"copied_archives":len(cache_rows),"missing_archive_count":len(missing),
   "manifest":meta(ROOT/"private-cache.manifest.public.json")}
  env={**READ_ENV,"CARGO_HOME":str(ROOT/"cargo-home"),"CARGO_TARGET_DIR":str(ROOT/"target"),"CARGO_NET_OFFLINE":"true",
   "RUSTC":str(TOOLBIN/"rustc"),"RUSTDOC":str(TOOLBIN/"rustdoc"),"CARGO_BUILD_JOBS":"2","CARGO_INCREMENTAL":"0",
   "CARGO_PROFILE_DEV_DEBUG":"0","CARGO_PROFILE_TEST_DEBUG":"0","TMPDIR":"/tmp","RUST_BACKTRACE":"0"}
  command("build-cli",[str(TOOLBIN/"cargo"),"build","--locked","--offline","-p","heptabao-credential-broker","--bin","heptabao-credential-broker","--message-format=json"],env,src,1200)
  command("build-tests",[str(TOOLBIN/"cargo"),"test","--locked","--offline","-p","heptabao-credential-broker","--no-run","--message-format=json"],env,src,1200)
  require(source_manifest(src)==before,"candidate_mutated_during_build")
  report["cargo_writes_complete_before_freezing"]=True
  arts=records(ROOT/"logs/build-cli.stdout.original")+records(ROOT/"logs/build-tests.stdout.original")
  cli=ROOT/"target/debug/heptabao-credential-broker"
  ca=[a for a in arts if a["target"]["name"]=="heptabao-credential-broker" and a["target"]["kind"]==["bin"] and not a["profile"]["test"] and a["executable"]==str(cli)]
  require(bool(ca),"missing_cli_artifact")
  frozen=ROOT/"bin-qualified/heptabao-credential-broker";cli_meta=copy_regular(cli,frozen,mode=0o700)
  signer=ROOT/"bin-qualified/heptabao_git_signer.py";signer_meta=copy_regular(src/"tools/heptabao_git_signer.py",signer,mode=0o700)
  report["artifacts"]={"cli":{"compiler_artifact":ca[-1],"original":str(cli),"frozen":str(frozen),**cli_meta},"signer":{"path":str(signer),**signer_meta}}
  test_env={**env,"HEPTABAO_BROKER_TEST_BINARY":str(frozen),"HEPTABAO_GIT_SIGNER_TEST_SCRIPT":str(signer)}
  tests={}
  for suite,names in TEST_NAMES.items():
   selected=[a for a in arts if a["profile"]["test"] and
    ((suite=="frame_read_tests" and a["target"]["kind"]==["lib"] and a["target"]["name"]=="heptabao_credential_broker") or
     (suite!="frame_read_tests" and a["target"]["kind"]==["test"] and a["target"]["name"]==suite))]
   unique={a["executable"]:a for a in selected};require(len(unique)==1,"test_artifact_count_"+suite)
   art=next(iter(unique.values()));original=pathlib.Path(art["executable"])
   require(original.is_relative_to(ROOT/"target"),"artifact_outside_target")
   frozen_test=ROOT/"test-qualified"/suite;tm=copy_regular(original,frozen_test,mode=0o700)
   command("list-"+suite,[str(frozen_test),"--list"],test_env,src,30)
   listed=read(ROOT/"logs"/("list-"+suite+".stdout.original")).decode()
   actual=[line[:-6] for line in listed.splitlines() if line.endswith(": test")]
   require(sorted(actual)==sorted(names),"test_inventory_changed_"+suite)
   tests[suite]={"compiler_artifact":art,"original":str(original),"frozen":str(frozen_test),**tm,"expected_names":sorted(names)}
  report["frozen_test_artifacts"]=tests;checkpoint()
  for suite,info in tests.items():
   tracked={"cli":frozen,"original_cli":cli,"test":pathlib.Path(info["frozen"]),"original_test":pathlib.Path(info["original"]),"signer":signer}
   bef={k:meta(p) for k,p in tracked.items()};require(bef["cli"]==cli_meta and bef["original_cli"]==cli_meta,"cli_changed_before_test")
   item=command("test-"+suite,[info["frozen"],"--test-threads=1"],test_env,src,300,needed=False)
   aft={k:meta(p) for k,p in tracked.items()};require(bef==aft,"frozen_artifact_changed")
   text=read(ROOT/"logs"/("test-"+suite+".stdout.original")).decode()
   summary=re.findall(r"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;",text)
   require(len(summary)==1,"test_summary_missing_"+suite)
   passed,failed,ignored,measured,filtered=map(int,summary[0])
   require(ignored==measured==filtered==0 and passed+failed==len(TEST_NAMES[suite]),"test_denominator_changed")
   observed={name:status for name,status in re.findall(r"^test (\S+) \.\.\. (ok|FAILED)$",text,re.M)}
   require(set(observed)==set(TEST_NAMES[suite]),"test_name_results_changed")
   require((item["exit_code"]==0)==(failed==0) and not item["timed_out"],"test_exit_summary_mismatch")
   report["test_suites"][suite]={"expected":len(TEST_NAMES[suite]),"executed":passed+failed,"passed":passed,"failed":failed,
    "test_results":observed,"artifacts_before":bef,"artifacts_after":aft,"command_label":item["label"]}
   report["executed"]+=passed+failed;report["passed"]+=passed;report["failed"]+=failed;report["missing"]=19-report["executed"];checkpoint()
  require(source_manifest(src)==before,"candidate_mutated_during_tests")
  report["candidate_source_unchanged_after_tests"]=True
  report["result"]="passed" if report["passed"]==19 and report["failed"]==0 and report["missing"]==0 else "failed"
 except BaseException as error:
  report["result"]="failed";report["error_type"]=type(error).__name__;report["error_code"]=str(error) if isinstance(error,RuntimeError) else "unexpected_exception"
  create(ROOT/"failure.private.txt",traceback.format_exc().encode())
 finally:
  try:report["source_after"]=git_state();report["old_artifacts_after"]=old_hashes();report["old_baseline_unchanged"]=report.get("old_artifacts_before")==report["old_artifacts_after"]
  except BaseException as error:report["result"]="failed";report["final_baseline_check_error"]=type(error).__name__
  report["finished_unix_ns"]=time.time_ns();checkpoint()
 print(json.dumps({"scope":report["scope"],"result":report["result"],"expected":19,"executed":report["executed"],"passed":report["passed"],
  "failed":report["failed"],"missing":report["missing"],"receipt":str(ROOT/"receipt.public.json"),**meta(ROOT/"receipt.public.json")},sort_keys=True),flush=True)
 return 0 if report["result"]=="passed" else 1
if __name__=="__main__":sys.exit(main())

