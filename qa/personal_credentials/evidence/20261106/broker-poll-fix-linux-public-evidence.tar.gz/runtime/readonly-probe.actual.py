import pathlib,subprocess,json,hashlib,os,shutil
root=pathlib.Path("/home/qq/heptabao-broker-ed25519-c447536")
out=pathlib.Path("/home/qq/heptabao-broker-poll-fix-20261106-r1")
tool=pathlib.Path("/home/qq/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin")
def run(args):
 p=subprocess.run(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20)
 if p.returncode: raise RuntimeError("probe_command_failed")
 return p.stdout.decode()
lock=root/"Cargo.lock"
v={"scope":"readonly_build_input_probe","source":str(root),"head":run(["/usr/bin/git","-C",str(root),"rev-parse","HEAD"]).strip(),"tree":run(["/usr/bin/git","-C",str(root),"rev-parse","HEAD^{tree}"]).strip(),"clean":not run(["/usr/bin/git","-C",str(root),"status","--porcelain"]).strip(),"lock_sha256":hashlib.sha256(lock.read_bytes()).hexdigest(),"new_root_absent":not os.path.lexists(out),"rustc_vV":run([str(tool/"rustc"),"-vV"]),"cargo_version":run([str(tool/"cargo"),"-V"]),"registry_cache_directories":[p.name for p in pathlib.Path("/home/qq/.cargo/registry/cache").iterdir() if p.is_dir()],"registry_index_directories":[p.name for p in pathlib.Path("/home/qq/.cargo/registry/index").iterdir() if p.is_dir()],"free_bytes":shutil.disk_usage("/home/qq").free}
print(json.dumps(v,sort_keys=True))
