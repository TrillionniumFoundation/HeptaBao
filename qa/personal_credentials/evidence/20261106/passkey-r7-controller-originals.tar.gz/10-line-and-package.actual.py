import os,pathlib,subprocess,json,hashlib,re,tarfile,zipfile,time
os.umask(0o077);base=pathlib.Path("/Users/qianqi/HeptaBaoPasskey-20261106-r1");build=base/"build-r7";source=base/"snapshot-r7-final/source";jdk=pathlib.Path("/Library/Java/JavaVirtualMachines/temurin-17.jdk/Contents/Home");bt=pathlib.Path("/Users/qianqi/Library/Android/sdk/build-tools/34.0.0")
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(build/"receipt.json")=="e12bd68de3c606e03ce22a7a688ebb90c7b6ec4a951d15e5be233339e698042b"
assert sha(base/"host-r7/result.public.json")=="173a3777dd928acb8b3a18f1e7bb81e995c74fd501c48cd35cdb702a2ade7c57"
assert sha(base/"source-r7-final.tar.gz")=="e2e79c7e35a507c11ba2a52a67c5a4882528d2447fa1c489977a64ad992f91b6"
out=base/"line-and-transport-r7";out.mkdir(mode=0o700,exist_ok=False)
owners={"org.heptabao.passkey.preview.VaultFiles","org.heptabao.passkey.preview.VaultFiles$Guard","org.heptabao.passkey.preview.VaultFiles$Descriptor","org.heptabao.passkey.preview.DocumentIO"}
classes=build/"provider/classes";javap={}
for owner in sorted(owners):
 r=subprocess.run([str(jdk/"bin/javap"),"-p","-l","-classpath",str(classes),owner],capture_output=True,timeout=30)
 assert r.returncode==0 and b"LineNumberTable:" in r.stdout
 f=out/(owner.rsplit(".",1)[1]+".javap.public.txt");f.write_bytes(r.stdout)
 javap[owner]={"sha256":sha(f),"line_numbers":sorted(set(map(int,re.findall(rb"line ([0-9]+):",r.stdout))))}
dex={};positions={}
with zipfile.ZipFile(build/"apks/provider.apk") as apk:
 for path in sorted((build/"provider/dex").glob("classes*.dex")):
  assert hashlib.sha256(apk.read(path.name)).hexdigest()==sha(path)
  selected=[];active=False;owner=None;method=None
  err=out/(path.name+".dexdump.stderr")
  with err.open("wb") as log:
   child=subprocess.Popen([str(bt/"dexdump"),"-d",str(path)],stdout=subprocess.PIPE,stderr=log)
   for raw in child.stdout:
    line=raw.decode("utf-8","replace")
    if re.match(r"Class #[0-9]+",line):active=False;owner=None;method=None
    match=re.search(r"Class descriptor\s*:\s*'L([^;]+);'",line)
    if match:owner=match.group(1).replace("/",".");active=owner in owners
    if active:
     selected.append(line)
     name=re.match(r"\s+name\s*:\s*'([^']+)'",line)
     if name:method=name.group(1)
     position=re.search(r"\bline=([0-9]+)",line)
     if position and method:positions.setdefault(owner+"#"+method,set()).add(int(position.group(1)))
   assert child.wait(timeout=180)==0
  data="".join(selected).encode();f=out/(path.name+".selected-dexdump.public.txt");f.write_bytes(data)
  dex[path.name]={"dex_sha256":sha(path),"selected_dump_sha256":sha(f),"selected_bytes":len(data),"selected_positions":len(re.findall(rb"line=([0-9]+)",data)),"apk_embedded_bytes_identical":True}
  assert data and b"positions" in data
mapping=(source/"provider/java/org/heptabao/passkey/preview/StageDiagnostics.java").read_text()
refs=re.findall(r'bind\((DOCUMENT|VAULT|GUARD|DESCRIPTOR), "([^"]+)", ([0-9]+), Site\.([A-Z_]+)\)',mapping)
assert len(refs)==39
lookup={"VAULT":"org.heptabao.passkey.preview.VaultFiles","GUARD":"org.heptabao.passkey.preview.VaultFiles$Guard","DESCRIPTOR":"org.heptabao.passkey.preview.VaultFiles$Descriptor","DOCUMENT":"org.heptabao.passkey.preview.DocumentIO"}
coverage=[]
for symbolic,method,line,site in refs:
 owner=lookup[symbolic];number=int(line)
 coverage.append({"owner":owner,"method":method,"line":number,"site":site,"javap_line_present":number in javap[owner]["line_numbers"],"dex_method_position_present":number in positions.get(owner+"#"+method,set())})
assert 169 in positions.get(lookup["VAULT"]+"#publish",set())
assert 40 in positions.get(lookup["DESCRIPTOR"]+"#close",set())
report={"schema":1,"candidate":"r7","scope":"actual_sdk_javac_d8_line_table_inspection_no_phone","build_receipt_sha256":sha(build/"receipt.json"),"source_archive_sha256":sha(base/"source-r7-final.tar.gz"),"vault_source_sha256":sha(source/"provider/java/org/heptabao/passkey/preview/VaultFiles.java"),"diagnostic_source_sha256":sha(source/"provider/java/org/heptabao/passkey/preview/StageDiagnostics.java"),"javap":javap,"dex":dex,"dexdump_sha256":sha(bt/"dexdump"),"source_bindings":coverage,"present_dex_binding_positions":sum(x["dex_method_position_present"] for x in coverage),"missing_dex_binding_positions":sum(not x["dex_method_position_present"] for x in coverage),"critical_publish_rename_and_raw_close_positions_present":True,"diagnostic_missing_or_unknown_position_policy":"UNKNOWN","phone_qualified":False,"production_qualified":False,"created_unix_ns":time.time_ns()}
line_receipt=out/"line-check.public.json";line_receipt.write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
receipt=json.loads((build/"receipt.json").read_bytes());assert all(sha(pathlib.Path(a["path"]))==a["sha256"] for a in receipt["artifacts"].values())
archive=base/"phone-r7-artifacts-full.tar.gz"
members=[(build/"receipt.json","build.receipt.json"),(base/"host-r7/result.public.json","host.result.public.json"),(line_receipt,"line-check.public.json"),(base/"source-r7-final.tar.gz","source-r7-final.tar.gz"),(base/"fixture-r5/seed.hbv","seed.hbv"),(base/"seed-transfer-r5/producer.public.json","seed.producer.public.json"),(base/"seed-transfer-r5/seed.receipt.public.json","seed.receipt.public.json"),(base/"snapshot-r7-final/qa/passkey_rp.py","passkey_rp.py")]
members += [(pathlib.Path(a["path"]),"apks/"+name+".apk") for name,a in sorted(receipt["artifacts"].items())]
with tarfile.open(archive,"x:gz",format=tarfile.PAX_FORMAT) as t:
 for p,name in members:t.add(p,arcname=name,recursive=False)
for p in [archive,line_receipt]:
 with p.open("rb") as f:os.fsync(f.fileno())
for p in [out,base]:
 fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({"ok":True,"line_check":str(line_receipt),"line_check_sha256":sha(line_receipt),"bindings":39,"present_dex_binding_positions":report["present_dex_binding_positions"],"missing_dex_binding_positions":report["missing_dex_binding_positions"],"critical_positions_present":True,"archive":str(archive),"archive_sha256":sha(archive),"archive_bytes":archive.stat().st_size,"phone_exercised":False},sort_keys=True))
