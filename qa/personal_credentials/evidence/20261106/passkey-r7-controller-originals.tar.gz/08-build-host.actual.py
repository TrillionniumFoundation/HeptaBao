import pathlib,tarfile,hashlib,os,json,time,subprocess
os.umask(0o077);base=pathlib.Path("/Users/qianqi/HeptaBaoPasskey-20261106-r1");archive=base/"source-r7-final.tar.gz"
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(archive)=="e2e79c7e35a507c11ba2a52a67c5a4882528d2447fa1c489977a64ad992f91b6"
root=base/"snapshot-r7-final";root.mkdir(mode=0o700,exist_ok=False)
with tarfile.open(archive,"r:gz") as t:
 members=t.getmembers();assert len(members)==33 and len({m.name for m in members})==33
 assert all(m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and ".." not in pathlib.PurePosixPath(m.name).parts for m in members)
 assert sum(m.size for m in members)<2*1024*1024
 for m in members:
  path=root/m.name;path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
  with path.open("xb") as f:f.write(t.extractfile(m).read());f.flush();os.fsync(f.fileno())
source=root/"source";qa=root/"qa";inventory={str(p.relative_to(source)):sha(p) for p in sorted(source.rglob("*")) if p.is_file()}
assert len(inventory)==29 and inventory["provider/java/org/heptabao/passkey/preview/VaultFiles.java"]=="f19b24a8091bac11c92354922d5fe0db1d2d2d59d1afbc511387f2a9d19c2012"
assert inventory["provider/java/org/heptabao/passkey/preview/StageDiagnostics.java"]=="1791431a579b62c66c31ae64e7749b5074ff1a3cc57f723acd708fb43c15b389"
assert inventory["README.md"]=="be3053a9db7b53e5d01132337823d898b179b2fcb9618fe46b0233584d3659cc"
jdk="/Library/Java/JavaVirtualMachines/temurin-17.jdk/Contents/Home";sdk="/Users/qianqi/Library/Android/sdk";bc="/Users/qianqi/HeptaBaoAndroid-20261106-r1/deps/bcprov-jdk15to18-1.86.jar"
build=base/"build-r7";host=base/"host-r7";assert not build.exists() and not host.exists()
subprocess.run(["/usr/bin/python3",str(qa/"passkey_build.py"),"--source",str(source),"--sdk",sdk,"--java-home",jdk,"--bc-jar",bc,"--output",str(build)],check=True)
receipt=json.loads((build/"receipt.json").read_bytes());assert receipt["source_files_before"]==inventory and receipt["source_files_after"]==inventory
assert len(receipt["commands"])==48 and all(x["exit_code"]==0 for x in receipt["commands"])
subprocess.run(["/usr/bin/python3",str(qa/"passkey_host.py"),"--source",str(source),"--rp-script",str(qa/"passkey_rp.py"),"--java-home",jdk,"--bc-jar",bc,"--fixture",str(base/"fixture-r5"),"--build-receipt",str(build/"receipt.json"),"--output",str(host)],check=True)
host_report=json.loads((host/"result.public.json").read_bytes());assert host_report["result"]=="PASS" and host_report["passed_checks"]==10 and host_report["android_device_exercised"] is False and host_report["credential_manager_exercised"] is False
for p in [build/"receipt.json",host/"result.public.json"]+[pathlib.Path(x["path"]) for x in receipt["artifacts"].values()]:
 fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
for p in [build,host,root,base]:
 fd=os.open(p,os.O_RDONLY);os.fsync(fd);os.close(fd)
print(json.dumps({"ok":True,"candidate":"r7","source_archive_sha256":sha(archive),"build_receipt":str(build/"receipt.json"),"build_receipt_sha256":sha(build/"receipt.json"),"host_receipt":str(host/"result.public.json"),"host_receipt_sha256":sha(host/"result.public.json"),"host_checks":10,"sdk_commands":48,"source_files":29,"phone_exercised":False,"credential_manager_exercised":False},sort_keys=True))
