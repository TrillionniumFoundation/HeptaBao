#!/usr/bin/env python3
"""Mac-only fixed-source build and real process tests, using synthetic fixtures."""
import ast
import fcntl
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import signal
import stat
import subprocess
import sys
import time

ROOT = Path('/Users/qianqi/HeptaBaoBrokerMac-c447536-20261106-r1')
SOURCE = ROOT / 'offline-source'
OUT = ROOT / 'qualification-r3'
TARGET = ROOT / 'target-r3'
BIN = OUT / 'bin-qualified'
TESTS = OUT / 'test-qualified'
CACHE = ROOT / 'cargo-home-r3'
CACHE_RECEIPT = ROOT / 'offline-cache-r3.receipt.public.json'
CACHE_RECEIPT_SHA = 'b783b03a0476c8dda76329d79fb971252eebd1fe1d44027a2f223234329ef7ab'
CACHE_PREPARER_SHA = '0035ee5411332871ee2eec482955c60e4e4cffa7e88c734170fc315415227151'
CACHE_MANIFEST_SHA = '3687a2eded83ef5e06af770c546dcff6358f696c0c90eebc558b874393ef8771'
CACHE_PACKET_SHA = 'a8521bc557bfb7f4bf13acd4453a97f5ca25f07aca341101f9871dd3821bbea9'
RUSTUP = '/opt/homebrew/bin/rustup'
GIT = '/usr/bin/git'
HEAD = 'c447536ae0343731d84c18291d2dcd712b3bea08'
TREE = '50835fd4df6e7bdd2b551941a3fa012281c931c2'
LOCK = 'ef3b19cf8b1b360f7888f11e3e5b1523e464762d6c24ce7e92b64d0d7d5c99a9'
PACKAGES = ['heptabao-credential-broker', 'heptabao-personal-vault', 'heptabao-personal-edge']
BINARIES = ['heptabao-credential-broker', 'heptabao-vault', 'heptabao-browser', 'heptabao-sync']
EXPECTED_RUST = {'heptabao-credential-broker': 13, 'heptabao-personal-vault': 14,
                 'heptabao-personal-edge': 1}

def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while True:
            block = stream.read(1024 * 1024)
            if not block: break
            value.update(block)
    return value.hexdigest()

def describe(path):
    value = path.lstat()
    if not stat.S_ISREG(value.st_mode) or value.st_uid != os.getuid():
        raise RuntimeError('unsafe_owned_artifact')
    return {'path': str(path), 'sha256': digest(path), 'size': value.st_size,
            'mode': stat.S_IMODE(value.st_mode), 'mtime_ns': value.st_mtime_ns}

def publish(path, value):
    temporary = path.with_name(path.name + '.new')
    with temporary.open('xb') as stream:
        stream.write((json.dumps(value, sort_keys=True, indent=2) + chr(10)).encode())
        stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)
    descriptor = os.open(path.parent, os.O_RDONLY)
    try: os.fsync(descriptor)
    finally: os.close(descriptor)

def prepared_cache_state():
    described = describe(CACHE_RECEIPT)
    if described['sha256'] != CACHE_RECEIPT_SHA:
        raise RuntimeError('offline_cache_receipt_changed')
    proof = json.loads(CACHE_RECEIPT.read_bytes())
    identity = {'commit': HEAD, 'tree': TREE, 'status': ''}
    if (proof.get('status') != 'public_offline_cache_prepared'
            or proof.get('destination') != str(CACHE)
            or proof.get('source_before') != identity or proof.get('source_after') != identity
            or proof.get('cargo_lock', {}).get('sha256') != LOCK
            or proof.get('actual_script', {}).get('sha256') != CACHE_PREPARER_SHA
            or proof.get('packet', {}).get('sha256') != CACHE_PACKET_SHA
            or proof.get('manifest_sha256') != CACHE_MANIFEST_SHA
            or proof.get('selected_archive_count') != 50
            or proof.get('registry_locked_package_versions') != 387
            or proof.get('index_file_count') != 356):
        raise RuntimeError('offline_cache_scope_mismatch')
    files = [row['copy'] for row in proof['indices']] + [row['copy'] for row in proof['archives']]
    files.append(proof['private_sparse_registry_metadata'])
    if len(files) != 407 or len({row['path'] for row in files}) != 407:
        raise RuntimeError('offline_cache_file_inventory_mismatch')
    verified = []
    for expected in files:
        path = Path(expected['path'])
        if not path.is_relative_to(CACHE / 'registry'):
            raise RuntimeError('offline_cache_path_escape')
        parent = path.parent
        while True:
            info = parent.lstat()
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
                raise RuntimeError('unsafe_private_cache_parent')
            if parent == CACHE: break
            parent = parent.parent
        actual = describe(path)
        if (actual['size'] != expected['size'] or actual['sha256'] != expected['sha256']
                or actual['mode'] != 0o600):
            raise RuntimeError('offline_cache_file_changed')
        verified.append({'path': str(path), 'size': actual['size'], 'sha256': actual['sha256']})
    encoded = json.dumps(sorted(verified, key=lambda row: row['path']), sort_keys=True, separators=(',', ':')).encode()
    return {'receipt': described, 'verified_file_count': len(verified),
            'canonical_file_identity_sha256': hashlib.sha256(encoded).hexdigest(),
            'selected_archives': 50, 'locked_index_versions': 387, 'index_files': 356}

def main():
    os.umask(0o077)
    root_info = ROOT.lstat()
    if not stat.S_ISDIR(root_info.st_mode) or root_info.st_uid != os.getuid() or root_info.st_mode & 0o077:
        raise RuntimeError('unsafe_task_root')
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise RuntimeError('unexpected_platform')
    OUT.mkdir(mode=0o700)
    LOG = OUT / 'logs'; LOG.mkdir(mode=0o700)
    cache = CACHE
    cache_info = cache.lstat()
    if not stat.S_ISDIR(cache_info.st_mode) or cache_info.st_uid != os.getuid() or cache_info.st_mode & 0o077:
        raise RuntimeError('unsafe_prepared_private_cache')
    overrides = {'PATH': '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
                 'CARGO_HOME': str(cache), 'CARGO_TARGET_DIR': str(TARGET),
                 'CARGO_BUILD_JOBS': '2', 'CARGO_PROFILE_DEV_DEBUG': '0',
                 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_INCREMENTAL': '0',
                 'CARGO_TERM_COLOR': 'never', 'CARGO_NET_OFFLINE': 'true',
                 'CARGO_REGISTRIES_CRATES_IO_PROTOCOL': 'sparse', 'GIT_CONFIG_NOSYSTEM': '1',
                 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_TERMINAL_PROMPT': '0',
                 'TMPDIR': '/private/tmp', 'PYTHONDONTWRITEBYTECODE': '1'}
    environment = dict(os.environ); environment.update(overrides)
    receipt = {'schema': 1, 'status': 'running', 'platform': platform.platform(),
               'machine': platform.machine(), 'scope': PACKAGES,
               'source_commit': HEAD, 'source_tree': TREE, 'expected_cargo_lock_sha256': LOCK,
               'actual_argv': sys.argv, 'actual_script': describe(Path(__file__).resolve()),
               'environment_overrides': overrides, 'started_unix': time.time(),
               'synthetic_only': True, 'production_qualified': False,
               'real_browser_tested': False, 'heptaruntime_task_attestation_tested': False,
               'other_platform_results_inherited': False, 'commands': [], 'tests': [],
               'expected_rust_tests_by_package': EXPECTED_RUST, 'expected_edge_process_tests': 4,
               'cargo_writes_complete_before_freezing': False}

    def command(label, argv, cwd=SOURCE, extra_env=None, timeout=1200, require=True):
        local_env = dict(environment)
        if extra_env: local_env.update(extra_env)
        stdout = LOG / (label + '.stdout'); stderr = LOG / (label + '.stderr')
        started = time.time(); timed_out = False
        with stdout.open('xb') as out_stream, stderr.open('xb') as error_stream:
            child = subprocess.Popen(argv, cwd=cwd, env=local_env, stdout=out_stream,
                                     stderr=error_stream, start_new_session=True)
            try: code = child.wait(timeout=timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                try: os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError: pass
                try: code = child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    try: os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError: pass
                    code = child.wait(timeout=5)
        record = {'label': label, 'argv': list(map(str, argv)), 'cwd': str(cwd),
                  'environment_overrides': dict(overrides),
                  'environment_extra': extra_env or {}, 'started_unix': started,
                  'finished_unix': time.time(), 'exit_code': code, 'timed_out': timed_out,
                  'stdout': describe(stdout), 'stderr': describe(stderr)}
        receipt['commands'].append(record)
        print(json.dumps({'phase': label, 'exit_code': code, 'timed_out': timed_out}), flush=True)
        if require and (code != 0 or timed_out): raise RuntimeError('command_failed:' + label)
        return record, stdout.read_text(errors='strict'), stderr.read_text(errors='strict')

    def source_state(label):
        _, head, _ = command(label + '-head', [GIT, 'rev-parse', 'HEAD'], timeout=30)
        _, tree, _ = command(label + '-tree', [GIT, 'rev-parse', 'HEAD^{tree}'], timeout=30)
        _, status, _ = command(label + '-status', [GIT, 'status', '--porcelain=v1', '--untracked-files=all'], timeout=30)
        current = {'head': head.strip(), 'tree': tree.strip(), 'clean': status == '',
                   'cargo_lock_sha256': digest(SOURCE / 'Cargo.lock')}
        if current != {'head': HEAD, 'tree': TREE, 'clean': True, 'cargo_lock_sha256': LOCK}:
            raise RuntimeError('source_changed:' + label)
        return current

    def original_binaries():
        return {name: describe(TARGET / 'debug' / name) for name in BINARIES}

    def all_frozen_bindings():
        return {'original_clis': original_binaries(),
                'qualified_clis': {name: describe(BIN / name) for name in BINARIES},
                'original_tests': {row['key']: describe(Path(row['original']['path'])) for row in receipt['test_executables']},
                'qualified_tests': {row['key']: describe(Path(row['qualified']['path'])) for row in receipt['test_executables']}}

    def identity_map(bindings):
        return {section: {name: (value['path'], value['sha256'], value['size'])
                          for name, value in values.items()} for section, values in bindings.items()}

    try:
        receipt['source_before_build'] = source_state('01-before-build')
        receipt['offline_cache_before_cargo'] = prepared_cache_state()
        receipt['offline_cargo_policy'] = 'private prepared cache; CARGO_NET_OFFLINE=true and explicit --offline on dependency-resolving commands'
        resolved_tools = {}
        for tool in ('cargo', 'rustc', 'cargo-fmt', 'rustfmt', 'cargo-clippy', 'clippy-driver'):
            _, output, _ = command('01-which-' + tool, [RUSTUP, 'which', '--toolchain', '1.98.0', tool], timeout=30)
            path = Path(output.strip())
            if not path.is_absolute() or not path.is_file() or not os.access(path, os.X_OK):
                raise RuntimeError('existing_toolchain_executable_unavailable')
            resolved_tools[tool] = describe(path)
        parents = {str(Path(value['path']).parent) for value in resolved_tools.values()}
        if len(parents) != 1: raise RuntimeError('unexpected_toolchain_directory_layout')
        toolchain_bin = next(iter(parents))
        overrides['PATH'] = toolchain_bin + ':' + overrides['PATH']
        environment.update(overrides)
        receipt['existing_toolchain_executables'] = resolved_tools
        receipt['path_resolution_scope'] = 'existing exact toolchain bin prepended only to this job environment; no installation/global configuration'
        receipt['prior_failed_attempts'] = [
            {'receipt_sha256': '1999c0fd49de8b9d751907561eb7921d9c5d46e14ee56d8847d0cacd3f495312',
             'phase': 'cargo fmt subcommand discovery; no product build/test occurred'},
            {'receipt_sha256': '90ece4f6e7687279cac346afc1a31eded53965a51ef2239a9908b4f5bf4101aa',
             'phase': 'private empty cache registry wait reached owned command timeout; no product build/test occurred',
             'job': '1a1b0b6a7fc-fc05-7250', 'terminal_state': 'failed', 'exit_code': 1,
             'output_durable': True, 'output_complete': True}]
        _, rustc, _ = command('02-rustc-version', [RUSTUP, 'run', '1.98.0', 'rustc', '-vV'], timeout=30)
        if 'release: 1.98.0' not in rustc or 'host: aarch64-apple-darwin' not in rustc:
            raise RuntimeError('rust_toolchain_mismatch')
        receipt['rustc_vv'] = rustc
        command('03-cargo-version', [RUSTUP, 'run', '1.98.0', 'cargo', '-vV'], timeout=30)
        command('04-git-version', [GIT, '--version'], timeout=30)
        command('05-ssh-version', ['/usr/bin/ssh', '-V'], timeout=30)
        command('06-clang-version', ['/usr/bin/clang', '--version'], timeout=30)
        receipt['external_tools'] = {name: {'invocation': shutil.which(name, path=environment['PATH']),
                                           'resolved': str(Path(shutil.which(name, path=environment['PATH'])).resolve())}
                                     for name in ('git', 'ssh-keygen', 'python3')}
        cargo = [RUSTUP, 'run', '1.98.0', 'cargo']
        packages = [part for name in PACKAGES for part in ('-p', name)]
        command('07-fmt', cargo + ['fmt', *packages, '--', '--check'], timeout=300)
        command('08-clippy', cargo + ['clippy', '--locked', '--offline', *packages, '--all-targets', '--', '-D', 'warnings'], timeout=2400)
        command('09-build-binaries', cargo + ['build', '--locked', '--offline', *packages, '--bins', '--message-format=json'], timeout=1800)
        receipt['binaries_after_build_command'] = original_binaries()
        _, test_json, _ = command('10-compile-all-tests', cargo + ['test', '--locked', '--offline', *packages, '--no-run', '--message-format=json'], timeout=1800)
        receipt['binaries_after_test_compilation'] = original_binaries()
        _, graph, _ = command('11-normal-feature-graph', cargo + ['tree', '--locked', '--offline', *packages,
                                '--target', 'aarch64-apple-darwin', '-e', 'normal', '--prefix', 'none', '--format', '{p}'], timeout=300)
        selected_affected = sorted({line for line in graph.splitlines() if re.match(r'^(?:rsa|crypto-bigint) v', line)})
        receipt['selected_normal_graph'] = {'target': 'aarch64-apple-darwin', 'affected_package_rows': selected_affected,
                                            'workspace_server_crypto_scope_not_claimed_clean': True}
        if selected_affected: raise RuntimeError('unexpected_selected_crypto_dependency')
        receipt['source_after_all_cargo'] = source_state('12-after-cargo')
        receipt['offline_cache_after_cargo'] = prepared_cache_state()
        if receipt['offline_cache_before_cargo'] != receipt['offline_cache_after_cargo']:
            raise RuntimeError('offline_cache_inputs_changed_during_cargo')
        receipt['cargo_writes_complete_before_freezing'] = True
        BIN.mkdir(mode=0o700); TESTS.mkdir(mode=0o700)
        test_records = []
        seen = set()
        for line in test_json.splitlines():
            if not line.strip(): continue
            entry = json.loads(line)
            if entry.get('reason') != 'compiler-artifact' or not entry.get('profile', {}).get('test') or not entry.get('executable'):
                continue
            source_path = Path(entry['target']['src_path'])
            package = next((name for name in PACKAGES if source_path.is_relative_to(SOURCE / 'crates' / name)), None)
            if package is None: continue
            executable = Path(entry['executable'])
            if not executable.is_relative_to(TARGET / 'debug/deps'): raise RuntimeError('unexpected_test_executable_path')
            if str(executable) in seen: continue
            seen.add(str(executable))
            key = package + '__' + entry['target']['name']
            destination = TESTS / (key + '__' + executable.name)
            shutil.copy2(executable, destination); os.chmod(destination, 0o500)
            original = describe(executable); qualified = describe(destination)
            if original['sha256'] != qualified['sha256']: raise RuntimeError('test_copy_mismatch')
            test_records.append({'key': key, 'package': package, 'target': entry['target'],
                                 'original': original, 'qualified': qualified,
                                 'producer_command': '10-compile-all-tests'})
        if len({row['key'] for row in test_records}) != len(test_records) or not test_records:
            raise RuntimeError('ambiguous_test_inventory')
        receipt['test_executables'] = sorted(test_records, key=lambda row: row['key'])
        for name in BINARIES:
            shutil.copy2(TARGET / 'debug' / name, BIN / name); os.chmod(BIN / name, 0o500)
            if digest(TARGET / 'debug' / name) != digest(BIN / name): raise RuntimeError('binary_copy_mismatch')
        receipt['frozen_bindings'] = all_frozen_bindings()
        receipt['binary_producer_boundary'] = 'after all selected CLI and test compilation; every subsequent test runs without Cargo'
        receipt['vault_embedded_cli_binding'] = {'actual_path': str(TARGET / 'debug/heptabao-vault'),
                                                'qualified_copy_used_by_rust_vault_test': False,
                                                'original_path_frozen_and_rehashed_each_command': True}
        receipt['frozen_unix'] = time.time()
        build_receipt = dict(receipt); build_receipt['status'] = 'build_and_freeze_passed_functional_tests_pending'
        publish(OUT / 'receipt.build.public.json', build_receipt)
        print(json.dumps({'phase': 'binaries_ready', 'bin_dir': str(BIN),
                          'receipt': describe(OUT / 'receipt.build.public.json'),
                          'binaries': {name: digest(BIN / name) for name in BINARIES}}), flush=True)
        fixed = identity_map(receipt['frozen_bindings'])
        tested_counts = {name: 0 for name in PACKAGES}
        listed_counts = {name: 0 for name in PACKAGES}
        all_success = True
        special = {'HEPTABAO_BROKER_TEST_BINARY': str(BIN / 'heptabao-credential-broker'),
                   'HEPTABAO_GIT_SIGNER_TEST_SCRIPT': str(SOURCE / 'tools/heptabao_git_signer.py')}
        for index, row in enumerate(receipt['test_executables']):
            executable = row['qualified']['path']
            listing_record, listing, _ = command(f'20-{index:02d}-list', [executable, '--list', '--format', 'terse'], extra_env=special, timeout=60)
            names = [line[:-6] for line in listing.splitlines() if line.endswith(': test')]
            listed_counts[row['package']] += len(names)
            before = all_frozen_bindings()
            if identity_map(before) != fixed: raise RuntimeError('artifact_changed_before_test')
            executed, stdout, _ = command(f'21-{index:02d}-test', [executable, '--test-threads=1', '--format', 'pretty'], extra_env=special, timeout=1200, require=False)
            after = all_frozen_bindings()
            matches = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', stdout)
            if len(matches) == 1:
                state, passed, failed, ignored, measured, filtered = matches[0]
                count = {'state': state, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored),
                         'measured': int(measured), 'filtered': int(filtered), 'listed': len(names)}
            else: count = {'state': 'unparseable', 'passed': 0, 'listed': len(names)}
            passed = (executed['exit_code'] == 0 and not executed['timed_out'] and count.get('state') == 'ok'
                      and count['passed'] == len(names) and all(count.get(key, -1) == 0 for key in ('failed', 'ignored', 'measured', 'filtered'))
                      and identity_map(before) == identity_map(after) == fixed)
            tested_counts[row['package']] += count['passed']
            receipt['tests'].append({'kind': 'rust_actual_executable', 'key': row['key'], 'names': names,
                                     'command': executed, 'listing_command': listing_record, 'counts': count,
                                     'bindings_before': before, 'bindings_after': after, 'passed': passed})
            all_success = all_success and passed
            if identity_map(after) != fixed: raise RuntimeError('artifact_changed_during_test')
        receipt['rust_listed_counts'] = listed_counts
        receipt['rust_passed_counts'] = tested_counts
        receipt['rust_expected_counts_match'] = listed_counts == EXPECTED_RUST and tested_counts == EXPECTED_RUST
        all_success = all_success and receipt['rust_expected_counts_match']
        before = all_frozen_bindings()
        edge_command, edge_stdout, edge_stderr = command('30-personal-edge-live', ['/usr/bin/python3',
                       str(SOURCE / 'qa/personal_credentials/personal_edge_live.py'), '--bin-dir', str(BIN), '-v'],
                       timeout=1200, require=False)
        after = all_frozen_bindings()
        combined = edge_stdout + edge_stderr
        matches = re.findall(r'^Ran (\d+) tests? in ', combined, re.MULTILINE)
        edge_passed = (edge_command['exit_code'] == 0 and not edge_command['timed_out'] and matches == ['4']
                       and re.search(r'^OK\s*$', combined, re.MULTILINE) is not None
                       and identity_map(before) == identity_map(after) == fixed)
        receipt['tests'].append({'kind': 'edge_independent_processes', 'expected': 4,
                                 'passed_count': 4 if edge_passed else None, 'passed': edge_passed,
                                 'command': edge_command, 'bindings_before': before, 'bindings_after': after})
        all_success = all_success and edge_passed
        if identity_map(after) != fixed: raise RuntimeError('artifact_changed_during_edge_test')
        profile = SOURCE / 'qa/personal_credentials/native_backpressure.py'
        expected_backpressure = None
        for statement in ast.parse(profile.read_text()).body:
            if isinstance(statement, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'EXPECTED' for target in statement.targets):
                value = statement.value
                if not (isinstance(value, ast.Call) and isinstance(value.func, ast.Name)
                        and value.func.id == 'frozenset' and len(value.args) == 1 and not value.keywords):
                    raise RuntimeError('native_profile_inventory_shape_changed')
                expected_backpressure = sorted(ast.literal_eval(value.args[0]))
        if expected_backpressure is None or len(expected_backpressure) != 8:
            raise RuntimeError('native_profile_inventory_changed')
        cap = {'F_SETPIPE_SZ': hasattr(fcntl, 'F_SETPIPE_SZ'), 'F_GETPIPE_SZ': hasattr(fcntl, 'F_GETPIPE_SZ')}
        native_command, native_stdout, native_stderr = command('31-linux-native-profile-capability',
                    ['/usr/bin/python3', str(profile), '--bin-dir', str(BIN), '--report', str(OUT / 'native-backpressure.public.json')],
                    timeout=60, require=False)
        refused = native_command['exit_code'] != 0 and 'this pipe-capacity regression requires Linux' in native_stderr
        receipt['linux_native_backpressure_profile'] = {'status': 'unsupported' if refused and not all(cap.values()) else 'unexpected',
                   'expected_cases': expected_backpressure, 'expected_count': 8, 'passed_count': 0,
                   'case_execution_claimed': False, 'capabilities': cap, 'command': native_command,
                   'actual_profile_refusal_observed': refused, 'script': describe(profile)}
        all_success = all_success and receipt['linux_native_backpressure_profile']['status'] == 'unsupported'
        receipt['source_after_tests'] = source_state('40-after-tests')
        receipt['bindings_after_all_tests'] = all_frozen_bindings()
        if identity_map(receipt['bindings_after_all_tests']) != fixed: raise RuntimeError('final_artifact_identity_changed')
        receipt['status'] = 'passed_supported_scope_with_linux_profile_unsupported' if all_success else 'failed'
    except Exception as error:
        receipt['status'] = 'failed'
        receipt['failure_class'] = type(error).__name__
        receipt['failure'] = str(error)
        try: receipt['source_after_failure'] = source_state('99-after-failure')
        except Exception as state_error: receipt['source_after_failure_error'] = type(state_error).__name__
    finally:
        receipt['finished_unix'] = time.time()
        publish(OUT / 'receipt.final.public.json', receipt)
        print(json.dumps({'phase': 'finished', 'status': receipt['status'],
                          'receipt': describe(OUT / 'receipt.final.public.json'),
                          'rust_passed_counts': receipt.get('rust_passed_counts'),
                          'failure': receipt.get('failure')}), flush=True)
    return 0 if receipt['status'] == 'passed_supported_scope_with_linux_profile_unsupported' else 1

if __name__ == '__main__':
    raise SystemExit(main())
