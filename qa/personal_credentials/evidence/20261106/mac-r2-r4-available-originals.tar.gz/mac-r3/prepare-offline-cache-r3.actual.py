#!/usr/bin/env python3
"""Copy checksum-verified public registry inputs into one new private cache."""
import hashlib
import io
import json
import os
from pathlib import Path
import platform
import re
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path('/Users/qianqi/HeptaBaoBrokerMac-c447536-20261106-r1')
SOURCE = ROOT / 'offline-source'
DESTINATION = ROOT / 'cargo-home-r3'
PUBLIC_REGISTRY = Path('/Users/qianqi/.cargo/registry')
REGISTRY = 'index.crates.io-1949cf8c6b5b557f'
PACKET = ROOT / 'offline-missing-archives-r3.tar.gz'
PACKET_SHA = 'a8521bc557bfb7f4bf13acd4453a97f5ca25f07aca341101f9871dd3821bbea9'
MANIFEST_SHA = '3687a2eded83ef5e06af770c546dcff6358f696c0c90eebc558b874393ef8771'
GRAPH_SHA = '1034ce7cbacbefce2e69164b9655db878888fd9a95b516d17851b70316332f97'
LOCK_SHA = 'ef3b19cf8b1b360f7888f11e3e5b1523e464762d6c24ce7e92b64d0d7d5c99a9'
COMMIT = 'c447536ae0343731d84c18291d2dcd712b3bea08'
TREE = '50835fd4df6e7bdd2b551941a3fa012281c931c2'
RECEIPT = ROOT / 'offline-cache-r3.receipt.public.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def private_directory(path):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise RuntimeError('unsafe_private_directory')


def owned_directory(path):
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
        raise RuntimeError('unsafe_public_registry_directory')


def read_owned(path, maximum=32 * 1024 * 1024):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(descriptor)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_nlink != 1 or before.st_size > maximum):
            raise RuntimeError('unsafe_public_input')
        with os.fdopen(descriptor, 'rb', closefd=False) as stream:
            data = stream.read(maximum + 1)
        after = os.fstat(descriptor)
        current = path.lstat()
        identity = lambda value: (value.st_dev, value.st_ino, value.st_size,
                                  value.st_mtime_ns, value.st_ctime_ns)
        if len(data) != before.st_size or identity(before) != identity(after) or identity(after) != identity(current):
            raise RuntimeError('public_input_changed_during_read')
        return data, {'path': str(path), 'size': len(data), 'sha256': sha(data),
                      'mode': stat.S_IMODE(before.st_mode), 'snapshot_stable': True}
    finally:
        os.close(descriptor)


def durable_parent(path):
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def create_directory(path):
    if path == DESTINATION:
        path.mkdir(mode=0o700)
        durable_parent(path.parent)
        return
    if not path.is_relative_to(DESTINATION):
        raise RuntimeError('destination_escape')
    if not path.parent.exists():
        create_directory(path.parent)
    try:
        path.mkdir(mode=0o700)
        durable_parent(path.parent)
    except FileExistsError:
        private_directory(path)


def write_new(path, data):
    if not path.is_relative_to(DESTINATION):
        raise RuntimeError('destination_escape')
    if not path.parent.exists():
        create_directory(path.parent)
    private_directory(path.parent)
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    durable_parent(path.parent)
    copied, record = read_owned(path)
    if copied != data:
        raise RuntimeError('cache_copy_mismatch')
    return record


def parse_lock(raw):
    if sha(raw) != LOCK_SHA:
        raise RuntimeError('fixed_lock_mismatch')
    packages = {}
    for block in raw.decode('utf-8').split('[[package]]')[1:]:
        values = {}
        for key in ('name', 'version', 'source', 'checksum'):
            found = re.findall(r'^' + key + r' = "([^"\\]+)"$', block, re.M)
            if len(found) > 1:
                raise RuntimeError('ambiguous_fixed_lock')
            if found:
                values[key] = found[0]
        if values.get('source') != 'registry+https://github.com/rust-lang/crates.io-index':
            continue
        if (not re.fullmatch(r'[a-zA-Z0-9_-]+', values.get('name', ''))
                or not re.fullmatch(r'[a-zA-Z0-9.+_-]+', values.get('version', ''))
                or not re.fullmatch(r'[a-f0-9]{64}', values.get('checksum', ''))):
            raise RuntimeError('invalid_fixed_lock_package')
        identity = (values['name'], values['version'])
        if identity in packages:
            raise RuntimeError('duplicate_fixed_lock_package')
        packages[identity] = values['checksum']
    if len(packages) != 387:
        raise RuntimeError('unexpected_registry_lock_count')
    return packages


def index_relative(name):
    name = name.lower()
    if len(name) == 1:
        return Path('1') / name
    if len(name) == 2:
        return Path('2') / name
    if len(name) == 3:
        return Path('3') / name[0] / name
    return Path(name[:2]) / name[2:4] / name


def unique_json(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise RuntimeError('duplicate_public_index_field')
        result[key] = value
    return result


def validate_index(data, name, versions):
    records = {}
    for chunk in data.split(bytes([0])):
        if not chunk.startswith(b'{'):
            continue
        record = json.loads(chunk, object_pairs_hook=unique_json)
        if record.get('name') != name or not isinstance(record.get('vers'), str):
            raise RuntimeError('public_index_identity_mismatch')
        version = record['vers']
        if version in records:
            raise RuntimeError('duplicate_public_index_version')
        records[version] = record.get('cksum')
    if any(records.get(version) != checksum for version, checksum in versions.items()):
        raise RuntimeError('locked_index_checksum_mismatch')


def source_identity():
    environment = dict(os.environ)
    environment.update({'PATH': '/usr/bin:/bin', 'GIT_CONFIG_NOSYSTEM': '1',
                        'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_TERMINAL_PROMPT': '0'})
    result = {}
    for label, arguments in (('commit', ['rev-parse', 'HEAD']),
                             ('tree', ['rev-parse', 'HEAD^{tree}']),
                             ('status', ['status', '--porcelain=v1', '--untracked-files=all'])):
        completed = subprocess.run(['/usr/bin/git', *arguments], cwd=SOURCE, env=environment,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=30, check=False)
        if completed.returncode != 0 or completed.stderr:
            raise RuntimeError('fixed_source_query_failed')
        result[label] = completed.stdout.decode('utf-8').strip()
    if result != {'commit': COMMIT, 'tree': TREE, 'status': ''}:
        raise RuntimeError('fixed_source_identity_mismatch')
    return result


def main():
    os.umask(0o077)
    if platform.system() != 'Darwin' or platform.machine() != 'arm64':
        raise RuntimeError('unexpected_platform')
    private_directory(ROOT)
    if DESTINATION.exists() or DESTINATION.is_symlink() or RECEIPT.exists() or RECEIPT.is_symlink():
        raise RuntimeError('fresh_cache_or_receipt_required')
    source_before = source_identity()
    lock, lock_record = read_owned(SOURCE / 'Cargo.lock')
    locked = parse_lock(lock)
    packet, packet_record = read_owned(PACKET, 1024 * 1024)
    if len(packet) != 532489 or sha(packet) != PACKET_SHA:
        raise RuntimeError('offline_packet_mismatch')
    members = {}
    with tarfile.open(fileobj=io.BytesIO(packet), mode='r:gz') as archive:
        entries = archive.getmembers()
        if len(entries) != 14:
            raise RuntimeError('offline_packet_inventory_mismatch')
        for entry in entries:
            if not entry.isfile() or entry.name in members or entry.size > 2 * 1024 * 1024:
                raise RuntimeError('unsafe_offline_packet_member')
            handle = archive.extractfile(entry)
            if handle is None:
                raise RuntimeError('offline_packet_read_failed')
            with handle:
                data = handle.read(entry.size + 1)
            if len(data) != entry.size:
                raise RuntimeError('offline_packet_member_length_mismatch')
            members[entry.name] = data
    manifest_bytes = members.pop('darwin-offline-inputs.public.json')
    graph_bytes = members.pop('darwin-all-edges.stdout')
    if sha(manifest_bytes) != MANIFEST_SHA or sha(graph_bytes) != GRAPH_SHA:
        raise RuntimeError('offline_input_manifest_mismatch')
    manifest = json.loads(manifest_bytes)
    if (manifest.get('registry_package_count') != 50 or manifest.get('lock_sha256') != LOCK_SHA
            or manifest.get('graph_sha256') != GRAPH_SHA or manifest.get('platform') != 'aarch64-apple-darwin'):
        raise RuntimeError('offline_input_scope_mismatch')
    selected = {}
    for item in manifest['registry_archives']:
        key = (item['name'], item['version'])
        if (key in selected or locked.get(key) != item['sha256']
                or not isinstance(item['size'], int) or not 0 < item['size'] <= 4 * 1024 * 1024):
            raise RuntimeError('selected_archive_not_exact_locked_input')
        selected[key] = item
    if len(selected) != 50 or len(members) != 12:
        raise RuntimeError('offline_archive_inventory_mismatch')
    packet_archives = {}
    for name, data in members.items():
        matches = [(key, item) for key, item in selected.items()
                   if name == 'archives/' + key[0] + '-' + key[1] + '.crate']
        if len(matches) != 1:
            raise RuntimeError('unexpected_offline_archive_member')
        key, item = matches[0]
        if len(data) != item['size'] or sha(data) != item['sha256']:
            raise RuntimeError('packet_archive_checksum_mismatch')
        packet_archives[key] = data
    for directory in (PUBLIC_REGISTRY.parent, PUBLIC_REGISTRY, PUBLIC_REGISTRY / 'index',
                      PUBLIC_REGISTRY / 'index' / REGISTRY,
                      PUBLIC_REGISTRY / 'index' / REGISTRY / '.cache',
                      PUBLIC_REGISTRY / 'cache', PUBLIC_REGISTRY / 'cache' / REGISTRY):
        owned_directory(directory)
    create_directory(DESTINATION)
    indices = []
    names = {}
    for (name, version), checksum in locked.items():
        names.setdefault(name, {})[version] = checksum
    for name, versions in sorted(names.items()):
        relative = index_relative(name)
        public_path = PUBLIC_REGISTRY / 'index' / REGISTRY / '.cache' / relative
        for parent in (public_path.parent, *public_path.parents):
            if parent == PUBLIC_REGISTRY / 'index' / REGISTRY / '.cache':
                break
            if not parent.is_relative_to(PUBLIC_REGISTRY / 'index' / REGISTRY / '.cache'):
                raise RuntimeError('public_index_path_escape')
            owned_directory(parent)
        data, origin = read_owned(public_path)
        validate_index(data, name, versions)
        copied = write_new(DESTINATION / 'registry/index' / REGISTRY / '.cache' / relative, data)
        indices.append({'name': name, 'locked_versions': sorted(versions), 'origin': origin,
                        'copy': copied, 'locked_checksums_verified': True})
    archives = []
    for key, item in sorted(selected.items()):
        filename = key[0] + '-' + key[1] + '.crate'
        public_path = PUBLIC_REGISTRY / 'cache' / REGISTRY / filename
        try:
            data, origin = read_owned(public_path, 4 * 1024 * 1024)
            origin_kind = 'existing_public_mac_registry_archive'
        except FileNotFoundError:
            if key not in packet_archives:
                raise RuntimeError('selected_archive_unavailable_offline')
            data = packet_archives[key]
            origin = {'packet_path': str(PACKET), 'packet_sha256': PACKET_SHA,
                      'member': 'archives/' + filename, 'size': len(data), 'sha256': sha(data)}
            origin_kind = 'checksum_bound_public_archive_packet'
        if len(data) != item['size'] or sha(data) != item['sha256']:
            raise RuntimeError('public_archive_checksum_mismatch')
        copied = write_new(DESTINATION / 'registry/cache' / REGISTRY / filename, data)
        archives.append({'name': key[0], 'version': key[1], 'locked_checksum': item['sha256'],
                         'origin_kind': origin_kind, 'origin': origin, 'copy': copied})
    registry_configuration = (json.dumps({'dl': 'https://static.crates.io/crates',
                                          'api': 'https://crates.io'}, sort_keys=True) + '\n').encode('ascii')
    configuration = write_new(DESTINATION / 'registry/index' / REGISTRY / 'config.json', registry_configuration)
    source_after = source_identity()
    lock_after, _ = read_owned(SOURCE / 'Cargo.lock')
    if lock_after != lock:
        raise RuntimeError('fixed_lock_changed')
    _, script = read_owned(Path(__file__).resolve(), 128 * 1024)
    result = {'schema': 1, 'status': 'public_offline_cache_prepared',
              'actual_argv': sys.argv, 'actual_script': script, 'finished_unix': time.time(),
              'source_before': source_before, 'source_after': source_after,
              'cargo_lock': lock_record, 'destination': str(DESTINATION),
              'packet': packet_record, 'manifest_sha256': MANIFEST_SHA, 'graph_sha256': GRAPH_SHA,
              'registry_locked_package_versions': len(locked), 'selected_archive_count': len(archives),
              'index_file_count': len(indices), 'indices': indices, 'archives': archives,
              'private_sparse_registry_metadata': configuration,
              'global_cache_modified': False, 'global_configuration_or_credentials_read': False,
              'network': False, 'cargo_executed': False, 'product_build_or_test_claimed': False,
              'other_platform_results_inherited': False, 'device_actions': 0}
    temporary = RECEIPT.with_name(RECEIPT.name + '.new')
    with temporary.open('xb') as stream:
        stream.write((json.dumps(result, sort_keys=True, indent=2) + '\n').encode('utf-8'))
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, RECEIPT)
    durable_parent(RECEIPT.parent)
    _, described = read_owned(RECEIPT)
    print(json.dumps({'status': result['status'], 'receipt': described,
                      'selected_archive_count': len(archives), 'index_file_count': len(indices),
                      'network': False, 'cargo_executed': False, 'device_actions': 0}, sort_keys=True))


if __name__ == '__main__':
    main()
