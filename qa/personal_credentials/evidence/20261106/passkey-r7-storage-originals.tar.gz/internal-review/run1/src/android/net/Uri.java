package android.net;
public final class Uri {public String getScheme(){return "content";}}
