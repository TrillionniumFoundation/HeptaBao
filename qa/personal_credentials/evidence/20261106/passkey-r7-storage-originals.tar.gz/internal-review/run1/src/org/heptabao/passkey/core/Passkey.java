package org.heptabao.passkey.core;
import java.util.*;
public final class Passkey {
  public static final class Record {public Map<String,Object> data=new HashMap<>();public void save(){throw new AssertionError("crypto_out_of_scope");}}
  public static List<Record> records(Hbv.Unlocked vault,String cert){throw new AssertionError("crypto_out_of_scope");}
}
