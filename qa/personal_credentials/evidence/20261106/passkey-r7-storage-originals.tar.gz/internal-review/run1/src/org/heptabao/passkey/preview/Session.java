package org.heptabao.passkey.preview;
import java.util.*;
import org.heptabao.passkey.core.Hbv;
final class Session {
  static final class Entry {}
  static List<Entry> labels(Hbv.Unlocked vault){throw new AssertionError("session_out_of_scope");}
}
