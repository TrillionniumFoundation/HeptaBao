package org.heptabao.passkey.core;
// Compile dependency only: no password, encryption, or real vault qualification.
public final class Hbv {
  public static final class Unlocked implements AutoCloseable {
    public byte[] expectedFileSha256,next;
    public Unlocked(byte[] expected,byte[] next){this.expectedFileSha256=expected;this.next=next;}
    public byte[] encryptNext(){return next.clone();}
    public long revision(){return 1;}
    public void close(){}
  }
  public static Unlocked unlock(byte[] encrypted,byte[] password){throw new AssertionError("crypto_out_of_scope");}
}
