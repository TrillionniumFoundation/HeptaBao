package org.heptabao.passkey.preview;
import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
final class DocumentIO {
  void check(){}
  ParcelFileDescriptor open(Context context,Uri uri,String mode){throw new AssertionError("SAF_out_of_scope");}
  void released(ParcelFileDescriptor pfd){}
}
