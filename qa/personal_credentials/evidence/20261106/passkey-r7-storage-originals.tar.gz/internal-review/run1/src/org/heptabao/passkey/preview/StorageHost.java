package org.heptabao.passkey.preview;

import android.content.Context;
import android.os.ParcelFileDescriptor;
import android.system.*;
import java.io.*;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.channels.FileLock;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import org.heptabao.passkey.core.*;

/** Calls the unchanged frozen product class; dependencies are explicit host mocks. */
public final class StorageHost {
  private static final Class<?> GUARD;
  private static final Constructor<?> CONSTRUCTOR;
  private static final Method PUBLISH,READ;
  static {
    try {
      GUARD=Class.forName("org.heptabao.passkey.preview.VaultFiles$Guard");
      CONSTRUCTOR=GUARD.getDeclaredConstructor(Context.class);CONSTRUCTOR.setAccessible(true);
      PUBLISH=VaultFiles.class.getDeclaredMethod("publish",GUARD,File.class,byte[].class,byte[].class,int.class);PUBLISH.setAccessible(true);
      READ=VaultFiles.class.getDeclaredMethod("read",File.class,int.class);READ.setAccessible(true);
    }catch(Exception e){throw new ExceptionInInitializerError(e);}
  }
  interface Action {void run() throws Exception;}
  static Context context;
  static Path root,files,target;
  static final byte[] OLD="synthetic-old-bytes".getBytes(StandardCharsets.US_ASCII);
  static final byte[] NEXT="synthetic-new-whole-value".getBytes(StandardCharsets.US_ASCII);
  static final byte[] RACE="synthetic-conflicting-writer".getBytes(StandardCharsets.US_ASCII);
  static void check(boolean value,String code){if(!value)throw new AssertionError(code);}
  static Exception unwrap(InvocationTargetException e) throws Exception {
    Throwable t=e.getCause();if(t instanceof Error)throw (Error)t;if(t instanceof Exception)return (Exception)t;throw new AssertionError("unexpected_reflection_cause");
  }
  static Object guard() throws Exception {try{return CONSTRUCTOR.newInstance(context);}catch(InvocationTargetException e){throw unwrap(e);}}
  static void close(Object g) throws Exception {((AutoCloseable)g).close();}
  static Object field(Object g,String name) throws Exception {Field f=GUARD.getDeclaredField(name);f.setAccessible(true);return f.get(g);}
  static FileDescriptor descriptor(Object g) throws Exception {return ((ParcelFileDescriptor)field(g,"descriptor")).getFileDescriptor();}
  static void publish(Object g,byte[] value,byte[] expected) throws Exception {
    try{PUBLISH.invoke(null,g,target.toFile(),value,expected,65536);}catch(InvocationTargetException e){throw unwrap(e);}
  }
  static byte[] read(Path p) throws Exception {try{return (byte[])READ.invoke(null,p.toFile(),65536);}catch(InvocationTargetException e){throw unwrap(e);}}
  static Exception failure(Action action) throws Exception {try{action.run();}catch(Exception e){return e;}throw new AssertionError("expected_failure_missing");}
  static void failureCode(String code,Action action) throws Exception {Exception e=failure(action);check(e instanceof Failure&&((Failure)e).code.equals(code),"wrong_failure_code");}
  static void errno(int code,Action action) throws Exception {Exception e=failure(action);check(e instanceof ErrnoException&&((ErrnoException)e).errno==code,"wrong_errno");}
  static void plain(Path p,byte[] value) throws Exception {Files.write(p,value);Files.setAttribute(p,"unix:mode",0600);}
  static void same(Path p,byte[] value) throws Exception {check(Arrays.equals(Files.readAllBytes(p),value),"file_bytes_changed");}
  static void clean(){check(Os.openCount()==0,"mock_descriptor_leak");}
  static long pending() throws Exception {try(java.util.stream.Stream<Path> s=Files.list(files)){return s.filter(p->p.getFileName().toString().startsWith(".pending-")).count();}}
  static void clearHook(){Os.hook=(op,p,fd)->{};}
  static void fenced() throws Exception {
    int before=Os.openCalls;failureCode("busy",()->guard());check(Os.openCalls==before,"fenced_guard_opened_descriptor");
  }
  static void reusable() throws Exception {clearHook();Os.tryLockMode=0;ParcelFileDescriptor.failStreamConstructor=false;Object g=guard();close(g);clean();}
  static ErrnoException injected(){return new ErrnoException("fixed_injected_site",OsConstants.EIO);}
  static boolean lock(Path p){return p.getFileName().toString().equals("store.lock");}
  static void initialize(Path work) throws Exception {
    root=work;Files.createDirectories(root);Files.setAttribute(root,"unix:mode",0700);
    files=root.resolve("files");Files.createDirectory(files);Files.setAttribute(files,"unix:mode",0700);
    target=files.resolve("test-ciphertext.hbv");context=new Context(root.toFile());Os.initialize(root);
  }
  static void run(String name) throws Exception {
    switch(name){
      case "create_and_reopen": {
        Object g=guard();publish(g,NEXT,null);same(target,NEXT);
        int rename=Os.events.indexOf("rename:test-ciphertext.hbv");
        check(rename>0&&Os.events.subList(0,rename).stream().anyMatch(s->s.startsWith("fsync:.pending-")),"temporary_not_synced_before_rename");
        check(Os.events.subList(rename+1,Os.events.size()).contains("fsync:files"),"parent_not_synced_after_rename");
        close(g);g=guard();check(Arrays.equals(read(target),NEXT),"reopen_wrong_bytes");close(g);clean();break;
      }
      case "admission_before_open": {
        Object g=guard();int opened=Os.openCalls;FileDescriptor fd=descriptor(g);AtomicReference<Throwable> result=new AtomicReference<>();
        Thread other=new Thread(()->{try{failureCode("busy",()->guard());}catch(Throwable e){result.set(e);}});other.start();other.join(2000);
        check(!other.isAlive()&&result.get()==null,"concurrent_busy_not_observed");check(Os.openCalls==opened,"busy_attempt_opened_file");
        check(Os.nativeLockHeld(fd)&&((FileLock)field(g,"lock")).isValid(),"busy_attempt_released_prior_lock");close(g);clean();break;
      }
      case "cross_thread_close_and_old_close": {
        Object a=guard();AtomicReference<Throwable> result=new AtomicReference<>();Thread t=new Thread(()->{try{close(a);}catch(Throwable e){result.set(e);}});
        t.start();t.join(2000);check(!t.isAlive()&&result.get()==null,"cross_thread_close_failed");Object b=guard();int before=Os.openCalls;close(a);
        check(Os.nativeLockHeld(descriptor(b)),"old_close_released_successor_lock");failureCode("busy",()->guard());check(Os.openCalls==before,"old_close_released_admission");
        failureCode("storage_lock_lost",()->publish(a,NEXT,null));check(Os.openCalls==before,"closed_publish_opened_target");close(b);clean();break;
      }
      case "short_reads": {plain(target,NEXT);Os.maxRead=2;check(Arrays.equals(read(target),NEXT)&&Os.readCalls>2,"short_read_not_completed");clean();break;}
      case "invalid_read_progress": {plain(target,NEXT);Os.negativeRead=true;failureCode("read_incomplete",()->read(target));clean();break;}
      case "short_writes": {Object g=guard();Os.maxWrite=2;publish(g,NEXT,null);same(target,NEXT);check(Os.writeCalls>2,"short_write_not_retried");close(g);clean();break;}
      case "zero_write_preserves_old": {
        plain(target,OLD);Object g=guard();Os.zeroWrite=true;failureCode("write_incomplete",()->publish(g,NEXT,Codec.sha(OLD)));
        same(target,OLD);check(Os.renameCalls==0&&pending()==0,"zero_write_published_or_orphaned");close(g);clean();break;
      }
      case "second_cas_conflict": {
        plain(target,OLD);Object g=guard();Os.hook=(op,p,fd)->{if(op.equals("fsync")&&p.getFileName().toString().startsWith(".pending-")){try{plain(target,RACE);}catch(Exception e){throw injected();}}};
        failureCode("conflict",()->publish(g,NEXT,Codec.sha(OLD)));same(target,RACE);check(Os.renameCalls==0&&pending()==0,"conflict_published");clearHook();close(g);clean();break;
      }
      case "initial_absence_conflict": {plain(target,OLD);Object g=guard();failureCode("conflict",()->publish(g,NEXT,null));same(target,OLD);check(Os.renameCalls==0&&pending()==0,"absence_conflict_published");close(g);clean();break;}
      case "rename_failure_preserves_old": {
        plain(target,OLD);Object g=guard();Os.hook=(op,p,fd)->{if(op.equals("rename"))throw new ErrnoException("fixed",OsConstants.EACCES);};
        errno(OsConstants.EACCES,()->publish(g,NEXT,Codec.sha(OLD)));same(target,OLD);check(pending()==0,"failed_rename_temp_left");clearHook();close(g);clean();break;
      }
      case "postrename_directory_sync_unknown":
      case "postrename_read_unknown":
      case "postrename_read_close_unknown":
      case "postrename_directory_close_unknown": {
        plain(target,OLD);Object g=guard();Os.hook=(op,p,fd)->{
          if(Os.renameCalls==0)return;
          if(name.equals("postrename_directory_sync_unknown")&&op.equals("fsync")&&p.equals(files))throw injected();
          if(name.equals("postrename_read_unknown")&&op.equals("read")&&p.equals(target))throw injected();
          if(name.equals("postrename_read_close_unknown")&&op.equals("close")&&p.equals(target))throw injected();
          if(name.equals("postrename_directory_close_unknown")&&op.equals("close")&&p.equals(files))throw injected();
        };
        failureCode("save_outcome_unknown",()->publish(g,NEXT,Codec.sha(OLD)));same(target,NEXT);clearHook();close(g);
        if(!name.contains("close"))clean();
        else check(Os.openCount()==1,"unknown_nonlock_close_not_accounted");
        Object next=guard();check(Arrays.equals(read(target),NEXT),"uncertain_result_reopen_wrong");close(next);break;
      }
      case "constructor_files_open_failure":
      case "constructor_lock_open_failure":
      case "constructor_lock_stat_failure":
      case "constructor_dup_failure": {
        Os.hook=(op,p,fd)->{
          if(name.equals("constructor_files_open_failure")&&op.equals("open")&&p.equals(files))throw injected();
          if(name.equals("constructor_lock_open_failure")&&op.equals("open")&&lock(p))throw injected();
          if(name.equals("constructor_lock_stat_failure")&&op.equals("fstat")&&lock(p))throw injected();
          if(name.equals("constructor_dup_failure")&&op.equals("dup"))throw injected();
        };
        failure(()->guard());clean();reusable();break;
      }
      case "raw_lock_close_unknown_fences": {
        Os.hook=(op,p,fd)->{if(op.equals("close")&&lock(p)&&!Os.wasDuplicate(fd))throw injected();};
        failure(()->guard());check(Os.openCount()==1,"raw_unknown_cleanup_count");clearHook();fenced();break;
      }
      case "stream_constructor_failure_cleans": {ParcelFileDescriptor.failStreamConstructor=true;failure(()->guard());clean();reusable();break;}
      case "trylock_null_cleans": {Os.tryLockMode=1;failureCode("busy",()->guard());clean();reusable();break;}
      case "trylock_io_cleans": {Os.tryLockMode=2;failure(()->guard());clean();reusable();break;}
      case "trylock_overlap_cleans": {Os.tryLockMode=3;failureCode("busy",()->guard());clean();reusable();break;}
      case "constructor_cleanup_unknown_fences": {
        Os.tryLockMode=1;Os.hook=(op,p,fd)->{if(op.equals("pfd-close")&&lock(p))throw injected();};
        failureCode("busy",()->guard());check(Os.openCount()==1,"constructor_unknown_cleanup_count");clearHook();Os.tryLockMode=0;fenced();break;
      }
      case "lock_release_unknown_fences":
      case "pfd_close_unknown_fences":
      case "published_lock_release_unknown":
      case "published_pfd_close_unknown": {
        Object g=guard();boolean published=name.startsWith("published_");if(published)publish(g,NEXT,null);
        boolean pfd=name.contains("pfd_close");Os.hook=(op,p,fd)->{if(lock(p)&&op.equals(pfd?"pfd-close":"release-lock"))throw injected();};
        if(published)failureCode("save_outcome_unknown",()->close(g));else failure(()->close(g));
        int calls=Os.closeCalls;clearHook();close(g);check(Os.closeCalls==calls,"unknown_close_retried");fenced();if(published)same(target,NEXT);break;
      }
      case "primary_failure_survives_close_failure": {
        plain(target,NEXT);Files.setAttribute(target,"unix:mode",0644);
        Os.hook=(op,p,fd)->{if(op.equals("close")&&p.equals(target))throw injected();};
        Exception error=failure(()->read(target));check(error instanceof Failure&&((Failure)error).code.equals("unsafe_file"),"primary_guard_masked");
        check(error.getSuppressed().length==1&&Os.closeCalls==1,"close_not_once_or_not_suppressed");break;
      }
      case "lost_guard_refuses_before_io": {
        Object g=guard();((FileLock)field(g,"lock")).release();int before=Os.openCalls;
        failureCode("storage_lock_lost",()->publish(g,NEXT,null));check(Os.openCalls==before&&!Files.exists(target),"lost_lock_published");close(g);clean();break;
      }
      case "unowned_temp_collision_preserved": {
        Object g=guard();Os.hook=(op,p,fd)->{if(op.equals("open")&&p.getFileName().toString().startsWith(".pending-")){try{plain(p,RACE);}catch(Exception e){throw injected();}}};
        errno(OsConstants.EEXIST,()->publish(g,NEXT,null));check(pending()==1&&!Files.exists(target),"unowned_collision_removed");clearHook();close(g);clean();break;
      }
      case "temporary_cleanup_error_keeps_primary": {
        plain(target,OLD);Object g=guard();Os.zeroWrite=true;Os.hook=(op,p,fd)->{if(op.equals("remove")&&p.getFileName().toString().startsWith(".pending-"))throw injected();};
        Exception e=failure(()->publish(g,NEXT,Codec.sha(OLD)));check(e instanceof Failure&&((Failure)e).code.equals("write_incomplete")&&e.getSuppressed().length==1,"cleanup_masked_primary");
        same(target,OLD);check(pending()==1,"uncertain_temp_not_preserved");clearHook();close(g);clean();break;
      }
      case "transaction_unknown_requires_reopen": {
        Object setup=guard();Path storage=((File)field(setup,"root")).toPath();String store="store-00000000000000000000000000000001";
        Files.createDirectory(storage.resolve(store));Files.setAttribute(storage.resolve(store),"unix:mode",0700);
        plain(storage.resolve("current"),store.getBytes(StandardCharsets.US_ASCII));Path cipher=storage.resolve(store).resolve("vault.hbv");plain(cipher,OLD);close(setup);
        VaultFiles.Transaction transaction=VaultFiles.begin(context,store);Os.hook=(op,p,fd)->{if(op.equals("fsync")&&Os.renameCalls>0&&p.equals(cipher.getParent()))throw injected();};
        Hbv.Unlocked next=new Hbv.Unlocked(Codec.sha(OLD),NEXT);
        failureCode("save_outcome_unknown",()->transaction.commit(next));int before=Os.openCalls;
        failureCode("outcome_requires_reopen",()->transaction.commit(next));check(Os.openCalls==before,"unknown_transaction_retried_io");clearHook();transaction.close();same(cipher,NEXT);
        VaultFiles.Transaction reopened=VaultFiles.begin(context,store);check(Arrays.equals(reopened.ciphertext,NEXT),"transaction_reopen_missed_committed_bytes");
        reopened.commit(new Hbv.Unlocked(Codec.sha(NEXT),RACE));reopened.close();same(cipher,RACE);clean();break;
      }
      default:throw new AssertionError("unknown_case");
    }
  }
  public static void main(String[] args) {
    String name=args[0];
    try {
      initialize(Paths.get(args[1]));run(name);
      System.out.println("{\"case\":\""+name+"\",\"passed\":true,\"open_descriptors_at_end\":"+Os.openCount()+",\"mock_open_calls\":"+Os.openCalls+",\"mock_close_calls\":"+Os.closeCalls+",\"rename_calls\":"+Os.renameCalls+"}");
    }catch(Throwable error){
      String kind=error instanceof AssertionError?"assertion":error instanceof Failure?((Failure)error).code:error instanceof ErrnoException?"errno":error.getClass().getSimpleName();
      String assertion=error instanceof AssertionError?String.valueOf(error.getMessage()):"none";
      if(!kind.matches("[A-Za-z0-9_]+"))kind="unknown";if(!assertion.matches("[A-Za-z0-9_]+"))assertion="unknown";
      System.out.println("{\"case\":\""+name+"\",\"passed\":false,\"kind\":\""+kind+"\",\"assertion\":\""+assertion+"\"}");
      System.exit(2);
    }
  }
}
