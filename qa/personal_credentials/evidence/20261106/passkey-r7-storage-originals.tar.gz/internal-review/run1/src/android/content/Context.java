package android.content;
import java.io.File;
public final class Context {
  private final File root;
  public Context(File root){this.root=root;}
  public File getDataDir(){return root;}
  public File getFilesDir(){return new File(root,"files");}
}
