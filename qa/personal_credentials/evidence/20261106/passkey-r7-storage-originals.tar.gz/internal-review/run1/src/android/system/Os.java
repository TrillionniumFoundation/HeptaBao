package android.system;

import java.io.FileDescriptor;
import java.io.IOException;
import java.nio.file.*;
import java.nio.channels.FileChannel;
import java.nio.file.attribute.*;
import java.util.*;

/** Explicit Android/POSIX fault model, with real private host file bytes.
 * Descriptor identity, ownership, and lock bookkeeping are mocks, not ART evidence.
 */
public final class Os {
  public interface Hook {void at(String operation,Path path,FileDescriptor fd) throws ErrnoException;}
  public static Hook hook=(op,path,fd)->{};
  public static int maxWrite=Integer.MAX_VALUE,maxRead=Integer.MAX_VALUE;
  public static boolean zeroWrite,negativeRead;
  public static int openCalls,closeCalls,duplicateCalls,renameCalls,writeCalls,readCalls;
  public static int tryLockMode; // 1=null, 2=IOException, 3=overlap; zero succeeds.
  public static final List<String> events=new ArrayList<>();
  private static final Map<FileDescriptor,Handle> handles=new IdentityHashMap<>();
  private static final Map<Path,Node> nodes=new HashMap<>();
  private static final Set<Node> nativeLocks=new HashSet<>();
  private static Path root;
  private static final class Node {Path path;Node(Path p){path=p;}}
  private static final class Position {int value;}
  private static final class Handle {
    final Node node;final Position position;final boolean duplicate;
    Handle(Node n,Position p,boolean d){node=n;position=p;duplicate=d;}
  }
  public static void initialize(Path allowedRoot){root=allowedRoot.toAbsolutePath().normalize();}
  private static Path path(String name) throws ErrnoException {
    Path result=Paths.get(name).toAbsolutePath().normalize();
    if(root==null||!result.startsWith(root))throw new AssertionError("host_path_outside_private_root");
    return result;
  }
  private static ErrnoException errno(int code){return new ErrnoException("closed_host_site",code);}
  private static void event(String op,Path p,FileDescriptor fd) throws ErrnoException {
    events.add(op+":"+p.getFileName());hook.at(op,p,fd);
  }
  private static Handle handle(FileDescriptor fd) throws ErrnoException {
    Handle result=handles.get(fd);if(result==null)throw errno(OsConstants.EBADF);return result;
  }
  public static int openCount(){return handles.size();}
  public static long openCountFor(String leaf){return handles.values().stream().filter(h->h.node.path.getFileName().toString().equals(leaf)).count();}
  public static boolean nativeLockHeld(FileDescriptor fd) throws ErrnoException{return nativeLocks.contains(handle(fd).node);}
  public static Path pathOf(FileDescriptor fd) throws ErrnoException{return handle(fd).node.path;}
  public static boolean wasDuplicate(FileDescriptor fd) throws ErrnoException{return handle(fd).duplicate;}
  public static void invoke(String op,FileDescriptor fd) throws ErrnoException {event(op,handle(fd).node.path,fd);}
  public static FileDescriptor open(String text,int flags,int mode) throws ErrnoException {
    Path p=path(text);openCalls++;event("open",p,null);
    try {
      boolean exists=Files.exists(p,LinkOption.NOFOLLOW_LINKS);
      if((flags&OsConstants.O_NOFOLLOW)!=0&&Files.isSymbolicLink(p))throw errno(OsConstants.EACCES);
      if((flags&OsConstants.O_CREAT)!=0){
        if(exists&&(flags&OsConstants.O_EXCL)!=0)throw errno(OsConstants.EEXIST);
        if(!exists){Files.createFile(p);chmod(p,mode);}
      }else if(!exists)throw errno(OsConstants.ENOENT);
      Node n=nodes.computeIfAbsent(p,Node::new);
      FileDescriptor fd=new FileDescriptor();handles.put(fd,new Handle(n,new Position(),false));
      return fd;
    }catch(ErrnoException e){throw e;}catch(IOException e){throw errno(OsConstants.EIO);}
  }
  public static FileDescriptor duplicate(FileDescriptor fd) throws ErrnoException {
    Handle h=handle(fd);duplicateCalls++;event("dup",h.node.path,fd);
    FileDescriptor copy=new FileDescriptor();handles.put(copy,new Handle(h.node,h.position,true));return copy;
  }
  public static void close(FileDescriptor fd) throws ErrnoException {
    Handle h=handle(fd);closeCalls++;event("close",h.node.path,fd);
    handles.remove(fd);
    // POSIX process-associated fcntl locks: any close of this inode releases them.
    nativeLocks.remove(h.node);
    event("closed",h.node.path,fd);
  }
  public static StructStat lstat(String text) throws ErrnoException {
    Path p=path(text);event("lstat",p,null);return stat(p);
  }
  public static StructStat fstat(FileDescriptor fd) throws ErrnoException {
    Path p=handle(fd).node.path;event("fstat",p,fd);return stat(p);
  }
  private static StructStat stat(Path p) throws ErrnoException {
    try {
      if(!Files.exists(p,LinkOption.NOFOLLOW_LINKS))throw errno(OsConstants.ENOENT);
      StructStat s=new StructStat();s.st_uid=android.os.Process.myUid();
      s.st_mode=((Number)Files.getAttribute(p,"unix:mode",LinkOption.NOFOLLOW_LINKS)).intValue();
      s.st_dev=((Number)Files.getAttribute(p,"unix:dev",LinkOption.NOFOLLOW_LINKS)).longValue();
      s.st_ino=((Number)Files.getAttribute(p,"unix:ino",LinkOption.NOFOLLOW_LINKS)).longValue();
      s.st_nlink=((Number)Files.getAttribute(p,"unix:nlink",LinkOption.NOFOLLOW_LINKS)).longValue();
      s.st_size=Files.size(p);s.st_mtime=Files.getLastModifiedTime(p).toMillis();
      s.st_ctime=((FileTime)Files.getAttribute(p,"unix:ctime",LinkOption.NOFOLLOW_LINKS)).toMillis();
      return s;
    }catch(ErrnoException e){throw e;}catch(IOException e){throw errno(OsConstants.EIO);}
  }
  private static void chmod(Path p,int mode) throws IOException {Files.setAttribute(p,"unix:mode",mode,LinkOption.NOFOLLOW_LINKS);}
  public static void fchmod(FileDescriptor fd,int mode) throws ErrnoException {
    Path p=handle(fd).node.path;event("fchmod",p,fd);try{chmod(p,mode);}catch(IOException e){throw errno(OsConstants.EIO);}
  }
  public static void mkdir(String text,int mode) throws ErrnoException {
    Path p=path(text);event("mkdir",p,null);
    try{Files.createDirectory(p);chmod(p,mode);}catch(FileAlreadyExistsException e){throw errno(OsConstants.EEXIST);}catch(IOException e){throw errno(OsConstants.EIO);}
  }
  public static int read(FileDescriptor fd,byte[] bytes,int offset,int count) throws ErrnoException {
    Handle h=handle(fd);readCalls++;event("read",h.node.path,fd);
    if(negativeRead)return -1;
    try{
      byte[] source=Files.readAllBytes(h.node.path);
      int n=Math.min(Math.min(count,maxRead),Math.max(0,source.length-h.position.value));
      System.arraycopy(source,h.position.value,bytes,offset,n);h.position.value+=n;return n;
    }catch(IOException e){throw errno(OsConstants.EIO);}
  }
  public static int write(FileDescriptor fd,byte[] bytes,int offset,int count) throws ErrnoException {
    Handle h=handle(fd);writeCalls++;event("write",h.node.path,fd);if(zeroWrite)return 0;
    try{
      int n=Math.min(count,maxWrite);byte[] old=Files.readAllBytes(h.node.path);
      byte[] next=Arrays.copyOf(old,Math.max(old.length,h.position.value+n));
      System.arraycopy(bytes,offset,next,h.position.value,n);Files.write(h.node.path,next,StandardOpenOption.TRUNCATE_EXISTING);
      h.position.value+=n;return n;
    }catch(IOException e){throw errno(OsConstants.EIO);}
  }
  public static void fsync(FileDescriptor fd) throws ErrnoException {
    Path p=handle(fd).node.path;event("fsync",p,fd);
    try(FileChannel c=FileChannel.open(p,Files.isDirectory(p)?StandardOpenOption.READ:StandardOpenOption.WRITE)){c.force(true);}
    catch(IOException e){throw errno(OsConstants.EIO);}
  }
  public static void rename(String source,String target) throws ErrnoException {
    Path a=path(source),b=path(target);event("rename",b,null);
    try{
      Files.move(a,b,StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);
      Node n=nodes.remove(a);nodes.remove(b);if(n!=null){n.path=b;nodes.put(b,n);}
      renameCalls++;
    }catch(IOException e){throw errno(OsConstants.EIO);}
  }
  public static void remove(String text) throws ErrnoException {
    Path p=path(text);event("remove",p,null);
    try{Files.delete(p);nodes.remove(p);}catch(NoSuchFileException e){throw errno(OsConstants.ENOENT);}catch(IOException e){throw errno(OsConstants.EIO);}
  }
  public static boolean acquire(FileDescriptor fd) throws ErrnoException {
    Handle h=handle(fd);event("try-lock",h.node.path,fd);
    if(tryLockMode==1)return false;if(tryLockMode==2)throw errno(OsConstants.EIO);
    if(tryLockMode==3||nativeLocks.contains(h.node))throw new java.nio.channels.OverlappingFileLockException();
    nativeLocks.add(h.node);return true;
  }
  public static void release(FileDescriptor fd) throws ErrnoException {
    Handle h=handle(fd);event("release-lock",h.node.path,fd);nativeLocks.remove(h.node);
  }
  private Os(){}
}
