package android.os;
public final class OperationCanceledException extends RuntimeException {public OperationCanceledException(){super("synthetic_cancel");}}
