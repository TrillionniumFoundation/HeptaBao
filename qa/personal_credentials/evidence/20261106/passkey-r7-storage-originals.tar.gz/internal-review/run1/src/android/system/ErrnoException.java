package android.system;
public final class ErrnoException extends Exception {
  public final int errno;
  public ErrnoException(String site,int code){super("synthetic_host_errno");errno=code;}
  public java.io.IOException rethrowAsIOException(){return new java.io.IOException("synthetic_host_io",this);}
}
