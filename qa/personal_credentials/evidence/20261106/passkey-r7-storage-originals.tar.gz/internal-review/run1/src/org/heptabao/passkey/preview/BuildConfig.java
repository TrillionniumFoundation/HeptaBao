package org.heptabao.passkey.preview;
final class BuildConfig {static final String FIXTURE_CERT_SHA256="0000000000000000000000000000000000000000000000000000000000000000";}
