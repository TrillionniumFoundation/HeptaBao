package android.system;
public final class OsConstants {
  public static final int O_RDONLY=0,O_WRONLY=1,O_RDWR=2,O_CREAT=64,O_EXCL=128,
    O_NONBLOCK=2048,O_CLOEXEC=524288,O_NOFOLLOW=131072;
  public static final int EPERM=1,ENOENT=2,EINTR=4,EIO=5,EBADF=9,EACCES=13,
    EEXIST=17,EINVAL=22,ENFILE=23,EMFILE=24,ENOSPC=28,EROFS=30,EOPNOTSUPP=95,ECANCELED=125;
  public static boolean S_ISDIR(int mode){return (mode & 0170000)==0040000;}
  public static boolean S_ISREG(int mode){return (mode & 0170000)==0100000;}
}
