package android.os;
public final class Process {public static int myUid(){return 10432;}}
