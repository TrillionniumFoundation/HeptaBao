package android.os;

import android.system.*;
import java.io.*;
import java.nio.*;
import java.nio.channels.*;

/** Owning PFD/stream mock. Never uses the host JDK's File*(fd) close ownership. */
public final class ParcelFileDescriptor implements AutoCloseable {
  public static boolean failStreamConstructor;
  private final FileDescriptor fd;
  private boolean closed;
  private ParcelFileDescriptor(FileDescriptor fd){this.fd=fd;}
  public static ParcelFileDescriptor dup(FileDescriptor source) throws IOException {
    try{return new ParcelFileDescriptor(Os.duplicate(source));}catch(ErrnoException e){throw e.rethrowAsIOException();}
  }
  public FileDescriptor getFileDescriptor(){return fd;}
  public void close() throws IOException {
    if(closed)return;closed=true;
    try{Os.invoke("pfd-close",fd);Os.close(fd);}catch(ErrnoException e){throw e.rethrowAsIOException();}
  }
  public static final class AutoCloseOutputStream extends FileOutputStream {
    private final ParcelFileDescriptor pfd;
    private final FakeChannel channel;
    private boolean closed;
    public AutoCloseOutputStream(ParcelFileDescriptor pfd){
      super(pfd.getFileDescriptor());
      if(failStreamConstructor)throw new IllegalStateException("synthetic_stream_constructor");
      this.pfd=pfd;this.channel=new FakeChannel(pfd.fd);
    }
    @Override public FileChannel getChannel(){return channel;}
    @Override public void close() throws IOException {
      if(closed)return;closed=true;
      try{channel.close();}finally{pfd.close();}
    }
    @Override public void write(byte[] value,int offset,int length) throws IOException {
      try{while(length>0){int n=Os.write(pfd.fd,value,offset,length);if(n<=0)throw new IOException("synthetic_zero_write");offset+=n;length-=n;}}
      catch(ErrnoException e){throw e.rethrowAsIOException();}
    }
    @Override public void flush(){}
  }
  public static final class AutoCloseInputStream extends FileInputStream {
    private final ParcelFileDescriptor pfd;
    public AutoCloseInputStream(ParcelFileDescriptor pfd){super(pfd.getFileDescriptor());this.pfd=pfd;}
    @Override public int read(byte[] b,int off,int len) throws IOException {
      try{int n=Os.read(pfd.fd,b,off,len);return n==0?-1:n;}catch(ErrnoException e){throw e.rethrowAsIOException();}
    }
    @Override public int read(byte[] b) throws IOException{return read(b,0,b.length);}
    @Override public void close() throws IOException{pfd.close();}
  }
  private static final class FakeChannel extends FileChannel {
    final FileDescriptor fd;
    FakeLock current;
    FakeChannel(FileDescriptor fd){this.fd=fd;}
    @Override public FileLock tryLock(long pos,long size,boolean shared) throws IOException {
      try{if(!Os.acquire(fd))return null;return current=new FakeLock(this,pos,size,shared);}
      catch(ErrnoException e){throw e.rethrowAsIOException();}
    }
    @Override public FileLock lock(long pos,long size,boolean shared) throws IOException{return tryLock(pos,size,shared);}
    @Override protected void implCloseChannel() throws IOException{if(current!=null&&current.isValid())current.release();}
    @Override public int read(ByteBuffer dst){throw new AssertionError("channel_read_out_of_scope");}
    @Override public long read(ByteBuffer[] dst,int offset,int length){throw new AssertionError("channel_read_out_of_scope");}
    @Override public int read(ByteBuffer dst,long position){throw new AssertionError("channel_read_out_of_scope");}
    @Override public int write(ByteBuffer src){throw new AssertionError("channel_write_out_of_scope");}
    @Override public long write(ByteBuffer[] src,int offset,int length){throw new AssertionError("channel_write_out_of_scope");}
    @Override public int write(ByteBuffer src,long position){throw new AssertionError("channel_write_out_of_scope");}
    @Override public long position(){throw new AssertionError("channel_position_out_of_scope");}
    @Override public FileChannel position(long p){throw new AssertionError("channel_position_out_of_scope");}
    @Override public long size(){throw new AssertionError("channel_size_out_of_scope");}
    @Override public FileChannel truncate(long size){throw new AssertionError("channel_truncate_out_of_scope");}
    @Override public void force(boolean metadata){throw new AssertionError("channel_force_out_of_scope");}
    @Override public long transferTo(long pos,long count,WritableByteChannel dst){throw new AssertionError("channel_transfer_out_of_scope");}
    @Override public long transferFrom(ReadableByteChannel src,long pos,long count){throw new AssertionError("channel_transfer_out_of_scope");}
    @Override public MappedByteBuffer map(MapMode mode,long position,long size){throw new AssertionError("channel_map_out_of_scope");}
  }
  private static final class FakeLock extends FileLock {
    private final FakeChannel channel;
    private boolean valid=true;
    FakeLock(FakeChannel channel,long pos,long size,boolean shared){super(channel,pos,size,shared);this.channel=channel;}
    @Override public boolean isValid(){return valid;}
    @Override public void release() throws IOException {
      if(!valid)return;
      try{Os.release(channel.fd);valid=false;}catch(ErrnoException e){throw e.rethrowAsIOException();}
    }
  }
}
