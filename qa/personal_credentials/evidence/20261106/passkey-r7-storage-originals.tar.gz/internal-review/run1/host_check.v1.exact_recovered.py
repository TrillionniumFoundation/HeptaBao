#!/usr/bin/env python3
"""Execute frozen VaultFiles control flow with explicit Android API mocks.

This is not an Android runtime, SDK/APK build, crypto check, or phone qualification.
Each failure case gets a fresh JVM; unknown-admission cases never reset product
statics through reflection. Files are synthetic and stay under the new run root.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/848006513f75/HeptaBao')
FROZEN = Path('/workspace/scratch/848006513f75/passkey_r7_storage_qualification/source')
PROVIDER = Path('clients/android-passkey/provider/java/org/heptabao/passkey/preview')
CORE = Path('clients/android-passkey/common/java/org/heptabao/passkey/core')
PINS = {'VaultFiles.java': 'f19b24a8091bac11c92354922d5fe0db1d2d2d59d1afbc511387f2a9d19c2012',
        'StageDiagnostics.java': '1791431a579b62c66c31ae64e7749b5074ff1a3cc57f723acd708fb43c15b389'}

def sha(value):
    return hashlib.sha256(value).hexdigest()

def save(path, value):
    path.parent.mkdir(parents=True, mode=0o700, exist_ok=True)
    with path.open('xb') as stream:
        os.chmod(path, 0o600)
        stream.write(value)
        stream.flush()
        os.fsync(stream.fileno())

def run(argv, output, timeout):
    start = time.time_ns()
    result = subprocess.run(argv, capture_output=True, timeout=timeout, check=False)
    end = time.time_ns()
    save(output.with_suffix('.stdout.original'), result.stdout)
    save(output.with_suffix('.stderr.original'), result.stderr)
    return result, {'argv': argv, 'exit_code': result.returncode, 'started_unix_ns': start,
                    'finished_unix_ns': end, 'stdout_sha256': sha(result.stdout),
                    'stderr_sha256': sha(result.stderr)}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--work', required=True, type=Path)
    parser.add_argument('--case', action='append')
    args = parser.parse_args()
    assert args.work.is_absolute() and not args.work.exists(), 'fresh_absolute_work_required'
    os.umask(0o077)
    args.work.mkdir(mode=0o700)
    src = args.work / 'src'
    classes = args.work / 'classes'
    classes.mkdir(mode=0o700)
    product = {}
    for name, expected in PINS.items():
        blob = (FROZEN / PROVIDER / name).read_bytes()
        assert sha(blob) == expected, 'frozen_source_pin_mismatch'
        assert (REPO / PROVIDER / name).read_bytes() == blob, 'current_source_differs_from_frozen'
        product[name] = blob
        save(src / 'org/heptabao/passkey/preview' / name, blob)
    for name in ['Failure.java', 'Codec.java', 'Json.java']:
        blob = (REPO / CORE / name).read_bytes()
        product[name] = blob
        save(src / 'org/heptabao/passkey/core' / name, blob)
    mapping = product['StageDiagnostics.java'].decode()
    assert f'VAULT_SOURCE_SHA256 = "{PINS["VaultFiles.java"]}"' in mapping
    document = (REPO / PROVIDER / 'DocumentIO.java').read_bytes()
    assert sha(document) == '8a08b26986febb451a0416559ce43949e537e1649cd6d536754c45fddb49fa2f'
    entries = re.findall(r'bind\((DOCUMENT|VAULT|GUARD|DESCRIPTOR), "([^"]+)", ([0-9]+), Site\.([A-Z_]+)\), // (.+)', mapping)
    assert len(entries) == 39 and len({(a, b, c) for a, b, c, _, _ in entries}) == 39
    for owner, method, number, site, fragment in entries:
        blob = document if owner == 'DOCUMENT' else product['VaultFiles.java']
        assert fragment in blob.decode().splitlines()[int(number) - 1], 'diagnostic_mapping_line_changed'
    stub_hashes = {}
    for file in sorted((HERE / 'stubsrc').rglob('*.java')):
        relative = file.relative_to(HERE / 'stubsrc')
        blob = file.read_bytes()
        stub_hashes[str(relative)] = sha(blob)
        save(src / relative, blob)
    java = '/usr/bin/java'
    version, version_row = run([java, '-version'], args.work / 'java-version', 10)
    assert version.returncode == 0
    commands = [version_row]
    compile_argv = [java, '-m', 'jdk.compiler/com.sun.tools.javac.Main', '-g', '-d', str(classes)]
    compile_argv += [str(path) for path in sorted(src.rglob('*.java'))]
    compilation, row = run(compile_argv, args.work / 'compile', 60)
    commands.append(row)
    all_cases = re.findall(r'case "([a-z0-9_]+)":', (HERE / 'stubsrc/org/heptabao/passkey/preview/StorageHost.java').read_text())
    assert len(set(all_cases)) == len(all_cases)
    cases = args.case or all_cases
    assert all(case in all_cases for case in cases)
    results = []
    if compilation.returncode == 0:
        for case in cases:
            argv = [java, '-cp', str(classes), 'org.heptabao.passkey.preview.StorageHost', case,
                    str(args.work / 'cases' / case)]
            executed, row = run(argv, args.work / 'outputs' / case, 12)
            commands.append(row)
            try:
                result = json.loads(executed.stdout)
            except (ValueError, UnicodeError):
                result = {'case': case, 'passed': False, 'reason': 'closed_host_result_unavailable'}
            result['exit_code'] = executed.returncode
            result['stderr_empty'] = executed.stderr == b''
            result['passed'] = result.get('passed') is True and executed.returncode == 0 and executed.stderr == b''
            results.append(result)
    source_unchanged = all((FROZEN / PROVIDER / name).read_bytes() == product[name] and
                           (REPO / PROVIDER / name).read_bytes() == product[name] for name in PINS)
    report = {'schema': 1, 'scope': 'frozen_storage_class_control_flow_with_android_api_mocks',
              'product_source_sha256': {name: sha(blob) for name, blob in product.items()},
              'source_unchanged_before_after': source_unchanged,
              'diagnostic_mapping_entries_checked': len(entries),
              'harness_sha256': sha(Path(__file__).read_bytes()), 'stub_source_sha256': stub_hashes,
              'java_binary_sha256': sha(Path(java).resolve().read_bytes()), 'commands': commands,
              'compile_succeeded': compilation.returncode == 0, 'expected': len(cases),
              'executed': len(results), 'passed': sum(result['passed'] for result in results),
              'failed': [result['case'] for result in results if not result['passed']],
              'missing': [case for case in cases if case not in {row['case'] for row in results}],
              'results': results, 'adb_calls': 0, 'network_calls': 0, 'sdk_or_apk_builds': 0,
              'external_review': False, 'production_qualified': False, 'android_runtime_exercised': False,
              'phone_qualified': False, 'limits': [
                  'Actual frozen VaultFiles and StageDiagnostics classes are compiled unchanged.',
                  'Android Os, descriptor identity, PFD ownership and FileChannel behavior are explicit fault mocks.',
                  'Host file bytes, rename and force operations use private real Linux files; this is not ART/OEM durability evidence.',
                  'Hbv, Passkey, Session and DocumentIO are compile-only or sentinel dependencies; encryption, credentials and SAF are not qualified.',
                  'Normal data/directory descriptor close uncertainty is distinguished from the process-wide lock-cleanup admission fence.',
                  'Cases with deliberately uncertain descriptor close retain their mock descriptor and report it; no leak-free claim is inferred for failed closes.',
                  'Each case starts a new JVM and never edits the product admission static to clear a fence.'
              ]}
    blob = (json.dumps(report, sort_keys=True, indent=2) + '\n').encode()
    save(args.work / 'receipt.public.json', blob)
    fd = os.open(args.work, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    assert (args.work / 'receipt.public.json').read_bytes() == blob
    print(json.dumps({'receipt': str(args.work / 'receipt.public.json'), 'sha256': sha(blob),
                      'compile_succeeded': report['compile_succeeded'], 'expected': len(cases),
                      'executed': len(results), 'passed': report['passed'], 'failed': report['failed'],
                      'missing': report['missing'], 'source_unchanged': source_unchanged}, sort_keys=True))
    return 0 if compilation.returncode == 0 and source_unchanged and report['passed'] == len(cases) else 1

if __name__ == '__main__':
    raise SystemExit(main())
