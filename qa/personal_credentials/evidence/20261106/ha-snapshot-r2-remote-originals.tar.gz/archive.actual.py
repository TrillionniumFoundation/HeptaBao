#!/usr/bin/python3
"""Archive fixed public ROG r2 originals. No service execution or private work reads."""
import gzip, hashlib, io, json, os, stat, sys, tarfile
from pathlib import Path
SRC = Path("/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2")
OUT = Path('/home/qian-qi/heptabao-ha-snapshot-r2-archive-20261106-r1')
TRANSCRIPT = Path('/home/qian-qi/heptabao-ha-snapshot-r2-runtime-transcript.public.json')
TRANSCRIPT_SHA = 'c629febcca3e814a544ef9eec93967bfcbc18f152f4b2176d38bf0784c306e20'
SPECS = json.loads("[{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run_profiles.py\",\"member\":\"original-source/run_profiles.py\",\"size\":11473,\"sha256\":\"5a0c089e4f373fbd1b6cb587aa616497a1b552d437318605e79692b5fe946738\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/prepare_remote.py\",\"member\":\"original-source/prepare_remote.py\",\"size\":7621,\"sha256\":\"aac9f7f472f320911b9b48563d3d77ab1d5e11a9b51c8b064e00b15f1277fcdb\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/source/ha_destructive.py\",\"member\":\"original-source/source/ha_destructive.py\",\"size\":29388,\"sha256\":\"171b1d284424bed53e72e8cc29a892a2eb2d3b4baa56245280a9c964927bfe33\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/source/owned_process.py\",\"member\":\"original-source/source/owned_process.py\",\"size\":28442,\"sha256\":\"0ee96c9f43b50ebd57ee8f0ef95f2431c441ec02c1799992588dbf50768745d0\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/source/fixture_mounts.py\",\"member\":\"original-source/source/fixture_mounts.py\",\"size\":1560,\"sha256\":\"55075ee436c22816a176dfb06cec387df37fdadd581c16acc07dabc837ba85b5\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/source/ha_network_partition.py\",\"member\":\"original-source/source/ha_network_partition.py\",\"size\":19101,\"sha256\":\"73bac79cc8c373c147896b43ef69119e5538c9b97c66a039c392f5b8decb88b0\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/source/replay_epoch_ha.py\",\"member\":\"original-source/source/replay_epoch_ha.py\",\"size\":15838,\"sha256\":\"093c03308b2f9e2bd134ae5ddcece08da8e06e8b9efa213aa0db1e0c84b9d387\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/source/tests/test_ha_destructive.py\",\"member\":\"original-source/source/tests/test_ha_destructive.py\",\"size\":15318,\"sha256\":\"022122a9203af21f9e03e49fb38d2487f762d82508f753cd19b7073e655993b1\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/admission.public.json\",\"member\":\"remote-results/admission.public.json\",\"size\":1037,\"sha256\":\"0f2a23bf777ae86fde6074dcdef57931286714cb9f9d4f660792517f9c824e85\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/deployment.manifest.json\",\"member\":\"remote-results/deployment.manifest.json\",\"size\":1849,\"sha256\":\"cbcb0b22a9dc14387baf03a2e9f294d6b58e684b94b316d6f7371fceb7b9475b\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/original-build.public.json\",\"member\":\"remote-results/original-build.public.json\",\"size\":5048,\"sha256\":\"96bad2644072717e73e08440afe65470ff542d159a2d85340951581a4c17ead5\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-ha_destructive/stdout.original.json\",\"member\":\"remote-results/run-ha_destructive/stdout.original.json\",\"size\":1964,\"sha256\":\"3873c82088cd08c9eeb8bb3a4b20bb1dcbf7f3c113bf089aaa5e076c2c3d5e78\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-ha_destructive/stderr.original.txt\",\"member\":\"remote-results/run-ha_destructive/stderr.original.txt\",\"size\":0,\"sha256\":\"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-ha_destructive/execution.public.json\",\"member\":\"remote-results/run-ha_destructive/execution.public.json\",\"size\":9916,\"sha256\":\"b74a6f6169c9897ab007705f11a6bfcfd03d87006329d7119d4cdf07de3bdefb\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-ha_destructive/intent.public.json\",\"member\":\"remote-results/run-ha_destructive/intent.public.json\",\"size\":2961,\"sha256\":\"4776bcd87d66552cf8c42d98698618a4d1d0669adea743a9ec1700c4360fc6d5\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-ha_network_partition/stdout.original.json\",\"member\":\"remote-results/run-ha_network_partition/stdout.original.json\",\"size\":4739,\"sha256\":\"ea1a38d759ac2823047f075d0a75527385edfb11c42cc2a27c7e365d392748ba\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-ha_network_partition/stderr.original.txt\",\"member\":\"remote-results/run-ha_network_partition/stderr.original.txt\",\"size\":0,\"sha256\":\"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-ha_network_partition/execution.public.json\",\"member\":\"remote-results/run-ha_network_partition/execution.public.json\",\"size\":10042,\"sha256\":\"d0728a3e354c3836411d1a9aa7bd72ac87a13b99a75e444b9eaab6b9d983eb9c\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-ha_network_partition/intent.public.json\",\"member\":\"remote-results/run-ha_network_partition/intent.public.json\",\"size\":2991,\"sha256\":\"1577d60fa5c1483a2c807b64e83f64ed7c9914c6b7c24158ffdd59c35de77e8c\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-replay_epoch_ha/stdout.original.json\",\"member\":\"remote-results/run-replay_epoch_ha/stdout.original.json\",\"size\":4005,\"sha256\":\"5fcf8cf392d64877f0bb1f75b3aadbbc6114e16ee75020d22d6cf311a7dab4e9\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-replay_epoch_ha/stderr.original.txt\",\"member\":\"remote-results/run-replay_epoch_ha/stderr.original.txt\",\"size\":0,\"sha256\":\"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-replay_epoch_ha/execution.public.json\",\"member\":\"remote-results/run-replay_epoch_ha/execution.public.json\",\"size\":11669,\"sha256\":\"ae1a0c8fbc88afb3c0456a4a64d1c5ca23368176a01f95570914655c704f8698\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2/run-replay_epoch_ha/intent.public.json\",\"member\":\"remote-results/run-replay_epoch_ha/intent.public.json\",\"size\":2966,\"sha256\":\"43d2288ccfcf2196723ad8d15f9b41e3bdd12f852b7e5ebdf503141ee8f9c11d\"},{\"path\":\"/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2.input.tar.gz\",\"member\":\"original-input.tar.gz\",\"size\":32782,\"sha256\":\"e790233f5268d0c4345a106360645f278f767bda76885613b872c1daab08da58\"}]")
def sha(data): return hashlib.sha256(data).hexdigest()
def read(path, expected=None, size=None):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid() or before.st_nlink != 1:
        raise RuntimeError('unsafe_public_original')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        opened = os.fstat(fd)
        if (opened.st_dev,opened.st_ino) != (before.st_dev,before.st_ino):
            raise RuntimeError('original_replaced')
        if opened.st_size > 1048576: raise RuntimeError('original_too_large')
        parts = []
        while True:
            chunk=os.read(fd,65536)
            if not chunk: break
            parts.append(chunk)
        data=b''.join(parts)
        after=os.fstat(fd)
        final=path.lstat()
        attrs=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
        if attrs(opened)!=attrs(after) or attrs(opened)!=attrs(final) or len(data)!=opened.st_size:
            raise RuntimeError('original_changed')
        if expected is not None and sha(data)!=expected: raise RuntimeError('original_sha_mismatch')
        if size is not None and len(data)!=size: raise RuntimeError('original_length_mismatch')
        return data
    finally: os.close(fd)
def js(value): return (json.dumps(value,sort_keys=True,indent=2)+'\n').encode()
def syncdir(path):
    fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
    try: os.fsync(fd)
    finally: os.close(fd)
def write(path,data):
    path.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
    try:
        view=memoryview(data)
        while view:
            count=os.write(fd,view)
            if count<=0: raise RuntimeError('short_archive_write')
            view=view[count:]
        os.fsync(fd)
    finally: os.close(fd)
    syncdir(path.parent)
    if read(path,sha(data),len(data))!=data: raise RuntimeError('archive_copy_failed')
def text_result(value):
    texts=[x['text'] for x in value.get('content',[]) if x.get('type')=='text']
    if len(texts)!=1: raise RuntimeError('unexpected_tool_content')
    return texts[0]
def main():
    os.umask(0o077)
    if len(sys.argv)!=2 or len(sys.argv[1])!=64: raise RuntimeError('missing_script_pin')
    script=read(Path(__file__),sys.argv[1])
    transcript=read(TRANSCRIPT,TRANSCRIPT_SHA,114770)
    container=json.loads(transcript)
    records={row['key']:row['value'] for row in container['records']}
    if len(records)!=len(container['records']): raise RuntimeError('duplicate_runtime_record')
    objects={}
    origin={}
    for item in SPECS:
        if item['member'] in objects: raise RuntimeError('duplicate_archive_member')
        objects[item['member']]=read(Path(item['path']),item['sha256'],item['size'])
        origin[item['member']]={'source_path':item['path'],'role':'exact_original_bytes'}
    objects['archive.actual.py']=script
    origin['archive.actual.py']={'source_path':str(Path(__file__)),'role':'new_archiver_source'}
    objects['runtime/stored-tool-records.container.json']=transcript
    origin['runtime/stored-tool-records.container.json']={'source_path':str(TRANSCRIPT),'role':'new_container_preserving_original_returned_text_and_hex'}
    for key,value in records.items():
        if key.endswith('_request'):
            objects['runtime/'+key+'.record.json']=js(value)
            origin['runtime/'+key+'.record.json']={'role':'new_serialization_of_retained_actual_request_object'}
        else:
            raw=text_result(value)
            name='runtime/'+key+'.tool-response.original.json'
            objects[name]=raw.encode()
            origin[name]={'role':'original_mcp_text_content_bytes_utf8'}
            if key.endswith('_read'):
                parsed=json.loads(raw)
                for stream in ('stdout','stderr'):
                    row=parsed[stream]
                    data=bytes.fromhex(row['bytes_hex'])
                    if not(row['offset']==0 and row['eof'] is True and row['next_offset']==row['size']==len(data)):
                        raise RuntimeError('incomplete_original_process_stream')
                    name='runtime/'+key.removesuffix('_read')+'.'+stream+'.original.txt'
                    objects[name]=data
                    origin[name]={'role':'exact_original_process_stream_decoded_from_tool_bytes_hex'}
    profiles=[]
    jobs={'ha_destructive':('destructive','1a1b0fa35bf-fc05-748c',0,22),
          'ha_network_partition':('partition','1a1b0fbd715-fc05-749b',0,66),
          'replay_epoch_ha':('replay','1a1b0fd8c62-fc05-74ac',1,46)}
    for name,(short,job_id,exit_code,count) in jobs.items():
        base='remote-results/run-'+name+'/'
        report=json.loads(objects[base+'stdout.original.json'])
        execution=json.loads(objects[base+'execution.public.json'])
        status=json.loads(text_result(records[short+'_status']))
        if status['job_id']!=job_id or status['exit_code']!=exit_code or status['output_durable'] is not True or status['output_complete'] is not True:
            raise RuntimeError('runtime_terminal_mismatch')
        if execution['profile_exit_code']!=exit_code or execution['observed_scenario_count']!=count or report['scenario_count']!=count:
            raise RuntimeError('profile_result_mismatch')
        if execution['deadline_fired'] or execution['fallback_cleanup_used'] or not execution['all_registered_originals_reaped']:
            raise RuntimeError('unexpected_cleanup_state')
        profiles.append({'profile':name,'job_id':job_id,'terminal_state':status['state'],'exit_code':exit_code,
            'runtime_output_durable':status['output_durable'],'runtime_output_complete':status['output_complete'],
            'observed_scenarios':count,'original_budget_seconds':execution['original_budget_seconds'],
            'failure_class':report.get('failure_class'),'deadline_fired':False,'fallback_cleanup_used':False,
            'all_registered_originals_reaped':True,
            'report_sha256':sha(objects[base+'stdout.original.json']),
            'execution_sha256':sha(objects[base+'execution.public.json'])})
    scope={'schema_version':1,'scope':'fixed_c27_binary_and_frozen_r2_native_snapshot_qa_private_loopback_profiles',
       'synthetic_only':True,'complete_profiles_passed':2,'complete_profiles_failed':1,'missing_profiles':0,
       'observed_scenario_counts_are_not_an_independent_test_suite_denominator':True,
       'server_sha256':'c27a0c223d227d3b2b5292e1e3ab6cf0230562baee36b6465b22a7ddf17be172',
       'server_build_commit':'a1b6ff4506f52082a0893b7167fafb4ff95610be','profiles':profiles,
       'new_source_tree_qualified':False,'ci_suite_qualified':False,'canonical_owner_qualified':False,
       'production_qualified':False,'external_independent_security_review':False,
       'archive_includes_private_service_work':False,'cryptographic_runtime_attestation_claimed':False,
       'later_revision_results_inherited':False,
       'local_reviewer_packet_available_to_this_archiver':False,
       'local_reviewer_packet_gap':'local executor disconnected; no reconstruction of unavailable local originals',
       'notes':['Native gzip download framing passed but does not itself prove Raft log purge or restore.',
                'Replay failure is preserved; no earlier scenarios are promoted to whole-profile success.',
                'Archive wrappers and summary are newly generated; original byte sources are identified per member.']}
    objects['review/summary.public.json']=js(scope)
    origin['review/summary.public.json']={'role':'new_summary_derived_from_exact_original_results'}
    file_rows=[{'path':name,'bytes':len(data),'sha256':sha(data),**origin[name]} for name,data in sorted(objects.items())]
    archive_manifest=js({'schema_version':1,'scope':'public_original_archive_integrity_only','files':file_rows,'includes_self':False})
    objects['archive.manifest.public.json']=archive_manifest
    OUT.mkdir(mode=0o700)
    syncdir(OUT.parent)
    for name,data in sorted(objects.items()): write(OUT/name,data)
    archive=OUT/'public-review.tar.gz'
    partial=OUT/'public-review.tar.gz.partial'
    with partial.open('xb') as stream:
        with gzip.GzipFile(filename='',mode='wb',fileobj=stream,mtime=0) as gz:
            with tarfile.open(mode='w',fileobj=gz,format=tarfile.PAX_FORMAT) as tar:
                for name,data in sorted(objects.items()):
                    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o600;info.mtime=0
                    tar.addfile(info,io.BytesIO(data))
        stream.flush();os.fsync(stream.fileno())
    os.rename(partial,archive);syncdir(OUT)
    archive_bytes=read(archive)
    with tarfile.open(fileobj=io.BytesIO(archive_bytes),mode='r:gz') as tar:
        members=tar.getmembers()
        if len(members)!=len(objects) or {m.name for m in members}!=set(objects):raise RuntimeError('archive_inventory_mismatch')
        for member in members:
            if not member.isfile() or tar.extractfile(member).read()!=objects[member.name]:raise RuntimeError('archive_readback_mismatch')
    result={'schema_version':1,'status':'public_archive_verified','archive_path':str(archive),'archive_sha256':sha(archive_bytes),
       'archive_bytes':len(archive_bytes),'regular_members':len(objects),'manifest_sha256':sha(archive_manifest),
       'summary_sha256':sha(objects['review/summary.public.json']),'archiver_sha256':sha(script),
       'runtime_container_sha256':sha(transcript),'complete_profiles_passed':2,'complete_profiles_failed':1,
       'private_service_work_included':False,'qualification_granted':False}
    write(OUT/'archive.receipt.public.json',js(result))
    print(json.dumps(result,sort_keys=True))
if __name__=='__main__': main()
