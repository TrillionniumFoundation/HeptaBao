#!/usr/bin/env python3
"""Run one frozen synthetic HA main with its original deadline and Popen objects.

This observer preserves owned_process._CURRENT=None. It grants no canonical
Owner receipt or qualification to the server source tree or another build.
"""
import argparse
import contextlib
import hashlib
import importlib
import json
import os
from pathlib import Path
import signal
import stat
import subprocess
import sys
import time

ROOT = Path('/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2')
ORIGINAL_BINARY = Path('/home/qian-qi/heptabao-personal-build-evidence-20261106-a1b6ff-r1/server-build-r1/bin/heptabao-server')
BINARY_SHA = 'c27a0c223d227d3b2b5292e1e3ab6cf0230562baee36b6465b22a7ddf17be172'
BUILD_SHA = '96bad2644072717e73e08440afe65470ff542d159a2d85340951581a4c17ead5'
PROFILES = {
    'ha_destructive': (240, 'heptabao.destructive-ha.v2'),
    'ha_network_partition': (360, 'heptabao.loopback-network-partition.v1'),
    'replay_epoch_ha': (600, 'heptabao.replay-epoch-ha.v1'),
}


def digest(path):
    before = path.lstat()
    if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1 or before.st_uid != os.getuid():
        raise RuntimeError('unsafe_regular_input')
    with path.open('rb') as stream:
        result = hashlib.file_digest(stream, 'sha256').hexdigest()
    after = path.lstat()
    keys = ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
    if any(getattr(before, key) != getattr(after, key) for key in keys):
        raise RuntimeError('input_changed_during_hash')
    return {'sha256': result, 'bytes': before.st_size}


def unique_json(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate_json_key')
        result[key] = value
    return result


def write_new(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, sort_keys=True, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    directory = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--profile', choices=tuple(PROFILES), required=True)
    parser.add_argument('--expected-deployment-sha256', required=True)
    args = parser.parse_args()
    os.umask(0o077)
    actual_argv = sys.argv[:]
    if Path(__file__).resolve() != ROOT / 'run_profiles.py' or ROOT.resolve() != ROOT:
        raise RuntimeError('unexpected_controller_root')
    info = ROOT.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o700:
        raise RuntimeError('unsafe_controller_root')
    manifest_bytes = (ROOT / 'deployment.manifest.json').read_bytes()
    if hashlib.sha256(manifest_bytes).hexdigest() != args.expected_deployment_sha256:
        raise RuntimeError('deployment_manifest_changed')
    manifest = json.loads(manifest_bytes, object_pairs_hook=unique_json)
    binary = ROOT / 'bin/heptabao-server'
    def bindings():
        observed = {}
        for item in manifest['files']:
            path = ROOT / item['path']
            got = digest(path)
            if got != {'sha256': item['sha256'], 'bytes': item['bytes']}:
                raise RuntimeError('frozen_controller_or_source_changed')
            observed[item['path']] = got
        for label, path in (('frozen_binary', binary), ('original_binary', ORIGINAL_BINARY)):
            got = digest(path)
            if got != {'sha256': BINARY_SHA, 'bytes': 133550368}:
                raise RuntimeError('frozen_binary_changed')
            observed[label] = got
        got = digest(ROOT / 'original-build.public.json')
        if got['sha256'] != BUILD_SHA:
            raise RuntimeError('original_build_receipt_changed')
        observed['original_build_receipt'] = got
        return observed
    before = bindings()
    attempt = ROOT / ('run-' + args.profile)
    attempt.mkdir(mode=0o700)
    temporary = attempt / 'tmp'
    temporary.mkdir(mode=0o700)
    process_env = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
                   'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONNOUSERSITE': '1', 'TMPDIR': str(temporary)}
    os.environ.clear()
    os.environ.update(process_env)
    budget, schema = PROFILES[args.profile]
    profile_argv = [str(ROOT / 'source' / (args.profile + '.py')), '--binary', str(binary),
                    '--expected-binary-sha256', BINARY_SHA, '--work-dir', str(attempt / 'work')]
    write_new(attempt / 'intent.public.json', {
        'schema': 1, 'profile': args.profile, 'actual_controller_argv': actual_argv,
        'profile_main_argv': profile_argv, 'dispatch': 'frozen_module_original_main',
        'profile_budget_seconds': budget, 'subprocess_environment': process_env,
        'python_version': sys.version, 'deployment_manifest_sha256': args.expected_deployment_sha256,
        'bindings_before': before, 'synthetic_only': True,
        'canonical_owner_receipt_claimed': False, 'whole_tree_qualification': False,
    })
    sys.path.insert(0, str(ROOT / 'source'))
    import owned_process
    module = importlib.import_module(args.profile)
    if owned_process._CURRENT is not None:
        raise RuntimeError('standalone_path_required')
    original_popen = owned_process.popen
    children = []
    def observed_popen(arguments, *positional, **keywords):
        if positional or not isinstance(arguments, list) or not arguments or arguments[0] != str(binary):
            raise RuntimeError('unexpected_registered_command')
        child = original_popen(arguments, **keywords)
        # Keep this exact returned object before any optional observation.
        children.append((child, list(arguments)))
        return child
    owned_process.popen = observed_popen
    timed_out = False
    def deadline(signum, frame):
        nonlocal timed_out
        timed_out = True
        raise TimeoutError('original_profile_deadline')
    previous_alarm = signal.signal(signal.SIGALRM, deadline)
    profile_exit = None
    failure_class = None
    recovery_cleanup = False
    original_children = []
    started_ns = time.monotonic_ns()
    started_unix_ns = time.time_ns()
    previous_argv = sys.argv
    stdout_path = attempt / 'stdout.original.json'
    stderr_path = attempt / 'stderr.original.txt'
    try:
        with stdout_path.open('x') as stdout, stderr_path.open('x') as stderr:
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                sys.argv = profile_argv
                signal.setitimer(signal.ITIMER_REAL, budget)
                try:
                    profile_exit = module.main()
                except BaseException as error:
                    failure_class = type(error).__name__
                finally:
                    signal.setitimer(signal.ITIMER_REAL, 0)
                    sys.argv = previous_argv
            for stream in (stdout, stderr):
                stream.flush()
                os.fsync(stream.fileno())
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_alarm)
        owned_process.popen = original_popen
        for child, arguments in children:
            row = {'original_pid': child.pid, 'argv': arguments,
                   'cleanup_recovery_needed': False, 'same_original_popen': True}
            try:
                row['returncode_before_observer_wait'] = child.poll()
                if child.returncode is None:
                    recovery_cleanup = row['cleanup_recovery_needed'] = True
                    child.kill()
                row['original_popen_wait_returncode'] = child.wait(timeout=10)
            except BaseException as error:
                recovery_cleanup = True
                row['cleanup_recovery_needed'] = True
                row['cleanup_exception_class'] = type(error).__name__
                try:
                    child.kill()
                except BaseException:
                    pass
                try:
                    row['original_popen_wait_returncode'] = child.wait(timeout=10)
                except BaseException as wait_error:
                    row['final_wait_exception_class'] = type(wait_error).__name__
            original_children.append(row)
    elapsed = (time.monotonic_ns() - started_ns) / 1e9
    after = bindings()
    report = None
    try:
        report = json.loads(stdout_path.read_text(), object_pairs_hook=unique_json)
    except (OSError, ValueError):
        pass
    report_valid = (isinstance(report, dict) and report.get('schema') == schema
                    and report.get('status') == 'pass_scoped_repository_fixture'
                    and report.get('binary_sha256') == BINARY_SHA
                    and report.get('node_count') == 3
                    and type(report.get('scenario_count')) is int
                    and isinstance(report.get('scenarios'), list)
                    and report['scenario_count'] == len(report['scenarios'])
                    and report.get('qualification') is False)
    all_reaped = bool(original_children) and all('original_popen_wait_returncode' in row for row in original_children)
    passed = (profile_exit == 0 and report_valid and not timed_out and not recovery_cleanup
              and failure_class is None and elapsed <= budget and all_reaped and before == after)
    result = {'schema': 1, 'profile': args.profile, 'status': 'passed_scoped_observation' if passed else 'failed',
              'actual_controller_argv': actual_argv, 'profile_main_argv': profile_argv,
              'dispatch': 'frozen_module_original_main', 'profile_exit_code': profile_exit,
              'failure_class': failure_class, 'original_budget_seconds': budget,
              'started_unix_ns': started_unix_ns, 'finished_unix_ns': time.time_ns(),
              'elapsed_including_observer_cleanup_seconds': elapsed,
              'deadline_fired': timed_out, 'fallback_cleanup_used': recovery_cleanup,
              'all_registered_originals_reaped': all_reaped, 'original_children': original_children,
              'bindings_before': before, 'bindings_after': after,
              'stdout': digest(stdout_path), 'stderr': digest(stderr_path),
              'profile_report_shape_valid': report_valid,
              'observed_scenario_count': report.get('scenario_count') if isinstance(report, dict) else None,
              'profile_failure': report.get('failure_class') if isinstance(report, dict) else None,
              'synthetic_only': True, 'canonical_owner_receipt_claimed': False,
              'new_source_tree_qualified': False, 'ci_suite_qualified': False,
              'production_qualified': False, 'independent_security_review': False}
    write_new(attempt / 'execution.public.json', result)
    print(json.dumps({'status': result['status'], 'profile': args.profile,
                      'profile_exit_code': profile_exit,
                      'observed_scenario_count': result['observed_scenario_count'],
                      'profile_failure': result['profile_failure'],
                      'receipt': digest(attempt / 'execution.public.json'),
                      'all_registered_originals_reaped': all_reaped}, sort_keys=True))
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
