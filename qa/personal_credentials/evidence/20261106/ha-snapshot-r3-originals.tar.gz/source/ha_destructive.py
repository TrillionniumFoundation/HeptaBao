#!/usr/bin/env python3
"""Run bounded three-process HA faults against private, synthetic loopback state.

Never attach to a real service. A passing result is NOT independent qualification,
full linearizability proof, power-cut evidence, or rolling-version-upgrade evidence.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
from fixture_mounts import completed_kv2_mount_metadata, provision_secret_kv2
import hashlib
import json
import os
from pathlib import Path
import secrets
import shutil
import socket
import ssl
import owned_process
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zlib


class FixtureError(RuntimeError):
    """A safe fixed classification; never include credential-bearing responses."""


MISBOUND_BOOTSTRAP_ERROR = (
    "heptabao-server: HA bootstrap admission marker binding is invalid"
)
SNAPSHOT_WIRE_LIMIT = 32 * 1024 * 1024
SNAPSHOT_EXPANDED_LIMIT = 64 * 1024 * 1024


def exact_startup_rejection(returncode: int | None, log_delta: bytes,
                            expected_line: str) -> bool:
    """Admit only one exact, terminal fail-closed process rejection."""
    try:
        lines = [line.strip() for line in log_delta.decode("utf-8").splitlines()
                 if line.strip()]
    except UnicodeDecodeError:
        return False
    return returncode == 1 and bool(lines) and lines[-1] == expected_line


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        return None


def private_write(path: Path, value: str | bytes) -> None:
    data = value.encode() if isinstance(value, str) else value
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def openssl(*arguments: str) -> None:
    owned_process.run(["openssl", *arguments], check=True, timeout=30,
                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                   stderr=subprocess.DEVNULL, label="ha_destructive.62")


def free_ports(count: int) -> tuple[int, ...]:
    """Select one bounded loopback batch while all selected sockets stay bound.

    This prevents reuse within our own batch, not another process taking a port
    after release. Actual bind/start failures still fail the campaign; no node
    initialization or business request is retried.
    """
    if type(count) is not int or not 1 <= count <= 64:
        raise FixtureError("invalid_ephemeral_port_count")
    with ExitStack() as handles:
        ports = []
        for _ in range(count):
            sock = handles.enter_context(socket.socket())
            sock.bind(("127.0.0.1", 0))
            ports.append(int(sock.getsockname()[1]))
        if len(set(ports)) != count:
            raise FixtureError("ephemeral_port_collision")
        return tuple(ports)


def free_port() -> int:
    return free_ports(1)[0]


def checked_binary(path: Path, expected: str) -> str:
    if not path.is_absolute() or path.resolve() != path or not path.is_file() or not os.access(path, os.X_OK):
        raise FixtureError("binary_not_an_absolute_regular_executable")
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    if len(expected) != 64 or actual != expected:
        raise FixtureError("binary_digest_mismatch")
    return actual


class Node:
    def __init__(self, node_id: int, binary: Path, root: Path, context: ssl.SSLContext,
                 *, ports: tuple[int, int] | None = None):
        self.node_id, self.binary, self.root = node_id, binary, root
        self.context = context
        self.ha_config = root / "ha.json"
        selected = free_ports(2) if ports is None else ports
        if (len(selected) != 2 or len(set(selected)) != 2
                or any(type(port) is not int or not 1 <= port <= 65535 for port in selected)):
            raise FixtureError("invalid_node_port_pair")
        self.http_port, self.raft_port = selected
        self.process = None
        self.log = None
        self.started_pids: list[int] = []

    @property
    def data_dir(self) -> Path:
        return self.root / "data"

    def call(self, method: str, path: str, body=None, *, token: str = "", timeout: float = 8.0, wrap_ttl: str | None = None):
        if not path or path.startswith("/") or "://" in path or ".." in path.split("/"):
            raise FixtureError("invalid_fixture_request_path")
        headers = {"Accept": "application/json", "Content-Type": "application/json"}
        if token:
            headers["X-Vault-Token"] = token
        if wrap_ttl is not None:
            if not isinstance(wrap_ttl, str) or not 1 <= len(wrap_ttl) <= 64 or any(
                    ord(c) < 33 or ord(c) > 126 for c in wrap_ttl):
                raise FixtureError("invalid_fixture_wrapping_ttl")
            headers["X-Vault-Wrap-TTL"] = wrap_ttl
        request = urllib.request.Request(
            f"https://127.0.0.1:{self.http_port}/v1/{path}",
            data=None if body is None else json.dumps(body).encode(), headers=headers, method=method)
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
                                             urllib.request.HTTPSHandler(context=self.context))
        try:
            response = opener.open(request, timeout=timeout)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            raw = response.read(32 * 1024 * 1024 + 1)
            if len(raw) > 32 * 1024 * 1024:
                raise FixtureError("response_exceeds_fixture_bound")
            parsed = json.loads(raw) if raw else {}
            if not isinstance(parsed, dict):
                raise FixtureError("non_object_response")
            return int(response.status), parsed

    def download_snapshot(self, *, token: str, timeout: float) -> dict[str, object]:
        """Validate one bounded native gzip download; never parse it as JSON.

        This checks transport and gzip framing only. It does not authenticate
        archive contents or qualify restore. A failed or ambiguous GET is not
        retried: snapshot creation is itself a server-side operation.
        """
        request = urllib.request.Request(
            f"https://127.0.0.1:{self.http_port}/v1/sys/storage/raft/snapshot",
            headers={"Accept": "application/gzip", "X-Vault-Token": token},
            method="GET")
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
                                             urllib.request.HTTPSHandler(context=self.context))
        try:
            response = opener.open(request, timeout=timeout)
        except urllib.error.HTTPError as error:
            response = error
        with response:
            if response.status != 200:
                raise FixtureError("snapshot_download_http_status")
            if (response.headers.get_all("Content-Type") != ["application/gzip"]
                    or response.headers.get_all("Transfer-Encoding")
                    or response.headers.get_all("Content-Encoding")):
                raise FixtureError("snapshot_download_framing")
            lengths = response.headers.get_all("Content-Length")
            if (not lengths or len(lengths) != 1 or not 1 <= len(lengths[0]) <= 8
                    or any(c not in "0123456789" for c in lengths[0])
                    or lengths[0].startswith("0")):
                raise FixtureError("snapshot_download_length")
            length = int(lengths[0])
            if not 0 < length <= SNAPSHOT_WIRE_LIMIT:
                raise FixtureError("snapshot_download_wire_bound")
            raw = response.read(SNAPSHOT_WIRE_LIMIT + 1)
            if len(raw) != length:
                raise FixtureError("snapshot_download_length_mismatch")
        decoder = zlib.decompressobj(31)
        try:
            # max_length bounds allocation even for a highly compressed input.
            expanded = len(decoder.decompress(raw, SNAPSHOT_EXPANDED_LIMIT + 1))
        except zlib.error as error:
            raise FixtureError("snapshot_download_invalid_gzip") from error
        if expanded > SNAPSHOT_EXPANDED_LIMIT:
            raise FixtureError("snapshot_download_expanded_bound")
        if (expanded == 0 or not decoder.eof or decoder.unused_data
                or decoder.unconsumed_tail):
            raise FixtureError("snapshot_download_incomplete_or_trailing_gzip")
        return {"http_status": 200, "content_type": "application/gzip",
                "archive_bytes": len(raw), "archive_sha256": hashlib.sha256(raw).hexdigest(),
                "expanded_bytes": expanded, "gzip_framing_verified": True,
                "archive_authenticity_verified": False, "restore_verified": False}

    def snapshot_after_compaction(self, *, token: str, timeout: float) -> dict[str, object]:
        """Request Raft maintenance explicitly before the separate backup GET.

        HTTP native export does not run the legacy JSON snapshot trigger. All
        three requests share the caller's original budget; none is replayed.
        A successful maintenance response is not proof that log purge finished.
        """
        deadline = time.monotonic() + timeout

        def remaining() -> float:
            value = deadline - time.monotonic()
            if value <= 0:
                raise FixtureError("snapshot_operation_deadline")
            return value

        status, body = self.call("GET", "sys/storage/raft/snapshot-status",
                                 token=token, timeout=remaining())
        data = body.get("data") if isinstance(body, dict) else None
        if (status != 200 or not isinstance(data, dict)
                or type(data.get("applied_index")) is not int
                or not 0 < data["applied_index"] < 2 ** 64):
            raise FixtureError("snapshot_pre_compaction_frontier_unavailable")
        applied_index = data["applied_index"]
        status, body = self.call("POST", "sys/storage/raft/compact", {},
                                 token=token, timeout=remaining())
        data = body.get("data") if isinstance(body, dict) else None
        fields = ("generation", "retained_requests", "journal_bytes_before", "journal_bytes_after")
        if (status != 200 or not isinstance(data, dict)
                or any(type(data.get(key)) is not int or not 0 <= data[key] < 2 ** 64
                       for key in fields)
                or data["journal_bytes_after"] > data["journal_bytes_before"]):
            raise FixtureError("snapshot_compaction_not_acknowledged")
        compaction = {key: data[key] for key in fields}
        snapshot = self.download_snapshot(token=token, timeout=remaining())
        remaining()
        return {**snapshot, "raft_compaction": {
            "http_status": 200, "target_applied_index": applied_index,
            **compaction, "purge_completion_verified": False}}

    def start(self, ha: bool = True, *, wait: bool = True) -> None:
        if self.process is not None:
            raise FixtureError("node_already_running")
        # Created inside a fresh owner-only synthetic directory, never an existing log.
        fd = os.open(self.root / "process.log", os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        self.log = os.fdopen(fd, "ab")
        command = [str(self.binary), "--config", str(self.root / "server.json")]
        if ha:
            command.extend(["--ha-config", str(self.ha_config)])
        self.process = owned_process.popen(command, stdin=subprocess.DEVNULL,
                                        stdout=self.log, stderr=self.log, start_new_session=True, label="ha_destructive.157", action="KILL", stop_timeout=10)
        try:
            self.started_pids.append(self.process.pid)
            if not wait:
                return
            self.wait_ready()
        except BaseException as error:
            owned_process.abort(error, [self.stop])

    def wait_ready(self) -> None:
        """Wait for the HTTPS listener after all peers have had a chance to bind.

        HA bootstrap can need a peer listener while the bootstrap process is
        starting.  Starting every process first avoids making node 1's startup
        depend on an incidental process scheduling order.
        """
        if self.process is None:
            raise FixtureError("node_not_running")
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            if self.process.poll() is not None:
                raise FixtureError("node_exited_during_startup")
            try:
                if self.call("GET", "sys/health", timeout=1)[0] in (200, 429, 501, 503):
                    return
            except (OSError, urllib.error.URLError, TimeoutError):
                pass
            time.sleep(0.05)
        raise FixtureError("node_listener_timeout")

    def expect_startup_rejection(self, expected_line: str) -> None:
        """Require an exact nonzero process rejection before API admission."""
        if self.process is not None:
            raise FixtureError("node_already_running")
        log_path = self.root / "process.log"
        before = log_path.stat().st_size if log_path.exists() else 0
        self.start(wait=False)
        try:
            try:
                returncode = owned_process.wait(self.process, timeout=10)
            except subprocess.TimeoutExpired as error:
                raise FixtureError("misbound_cluster_process_did_not_exit") from error
            if self.log is None:
                raise FixtureError("startup_rejection_log_unavailable")
            self.log.flush()
            with log_path.open("rb") as stream:
                stream.seek(before)
                delta = stream.read(64 * 1024 + 1)
            if len(delta) > 64 * 1024 or not exact_startup_rejection(
                    returncode, delta, expected_line):
                raise FixtureError("unexpected_startup_rejection")
        except BaseException as error:
            # Reap the owned child while retaining the actual rejection or
            # timeout failure if cleanup also reports an unexpected exit.
            owned_process.abort(error, [self.stop])
        else:
            # The exact diagnostic and exit 1 have already been observed.
            # This child exited itself; cleanup must not require SIGKILL.
            self.stop(expected_codes=(1,))

    def stop(self, *, expected_codes: tuple[int, ...] = (-9,)) -> None:
        process, log = self.process, self.log
        try:
            owned_process.close_all([
                lambda: owned_process.stop(process, action="KILL", timeout=10, expected_codes=expected_codes),
                lambda: log.close() if log is not None and not log.closed else None,
            ])
        finally:
            self.process = None
            self.log = None


class Cluster:
    NODE_IDS = (1, 2, 3)
    def __init__(self, binary: Path, root: Path):
        if not root.is_absolute() or root.resolve() != root or root.exists() or not root.parent.is_dir():
            raise FixtureError("work_directory_must_be_new_absolute_non_symlink")
        root.mkdir(mode=0o700)
        self.root, self.binary = root, binary
        self.nodes: list[Node] = []
        self.scenarios: list[str] = []
        self.fixture_mount_setup: list[dict] = []
        self.snapshot_downloads: list[dict[str, object]] = []
        self.root_token = ""
        self.unseal_key = ""
        self.cluster_id = ""
        self.replication_key = secrets.token_bytes(32)
        self.configure()

    def check(self, name: str, condition: bool) -> None:
        if not condition:
            raise FixtureError(name)
        self.scenarios.append(name)

    def configure(self) -> None:
        ca_key, ca_cert = self.root / "ca.key", self.root / "ca.crt"
        openssl("req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "2",
                "-keyout", str(ca_key), "-out", str(ca_cert), "-subj", "/CN=HeptaBao Synthetic HA CA",
                "-addext", "basicConstraints=critical,CA:TRUE",
                "-addext", "keyUsage=critical,keyCertSign,cRLSign")
        ca_key.chmod(0o600)
        context = ssl.create_default_context(cafile=str(ca_cert))
        peers = {}
        ports = iter(free_ports(2 * len(self.NODE_IDS)))
        for number in self.NODE_IDS:
            root = self.root / f"node-{number}"
            root.mkdir(mode=0o700)
            node = Node(number, self.binary, root, context, ports=(next(ports), next(ports)))
            self.nodes.append(node)
            key, cert, csr = root / "tls.key", root / "tls.crt", root / "tls.csr"
            openssl("req", "-new", "-newkey", "rsa:2048", "-nodes", "-keyout", str(key),
                    "-out", str(csr), "-subj", f"/CN=heptabao-synthetic-{number}")
            key.chmod(0o600)
            extension = root / "tls.ext"
            private_write(extension, "basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,keyEncipherment\nextendedKeyUsage=serverAuth,clientAuth\nsubjectAltName=DNS:localhost,IP:127.0.0.1\n")
            openssl("x509", "-req", "-in", str(csr), "-CA", str(ca_cert), "-CAkey", str(ca_key),
                    "-CAcreateserial", "-out", str(cert), "-days", "2", "-sha256", "-extfile", str(extension))
            fingerprint = hashlib.sha256(ssl.PEM_cert_to_DER_cert(cert.read_text())).hexdigest()
            peers[str(number)] = {"node_name": f"node-{number}", "address": f"127.0.0.1:{node.raft_port}",
                                  "server_name": "localhost", "certificate_sha256": fingerprint}
            private_write(root / "server.json", json.dumps({
                "listen": f"127.0.0.1:{node.http_port}", "data_dir": str(node.data_dir),
                "audit_file": str(root / "audit.jsonl"), "tls_cert_file": str(cert), "tls_key_file": str(key),
                "max_connections": 32, "timeout_seconds": 5,
                "rate_limit_per_second": 1000, "rate_limit_burst": 2000, "rate_limit_entries": 256}))
        ports = [port for node in self.nodes for port in (node.http_port, node.raft_port)]
        if len(set(ports)) != 2 * len(self.NODE_IDS):
            raise FixtureError("ephemeral_port_collision")
        self.peers = peers

    def configure_ha(self) -> None:
        if not self.cluster_id:
            raise FixtureError("unbound_seed_cluster_identity")
        ca_cert = self.root / "ca.crt"
        peers = self.peers
        for node in self.nodes:
            private_write(node.root / "replication.key", self.replication_key)
            private_write(node.root / "ha.json", json.dumps({
                "node_id": node.node_id, "cluster_id": self.cluster_id,
                "raft_dir": str(node.root / "raft"), "listen": f"127.0.0.1:{node.raft_port}",
                "ca_file": str(ca_cert), "cert_file": str(node.root / "tls.crt"),
                "key_file": str(node.root / "tls.key"), "replication_key_file": str(node.root / "replication.key"),
                "peers": peers, "bootstrap": node.node_id == 1, "peer_timeout_ms": 500, "max_inflight": 32}))

    def running(self) -> list[Node]:
        return [node for node in self.nodes if node.process is not None]

    def wait_quorum(self) -> None:
        """Read-only readiness: a sealed listener is not a committed quorum."""
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            active = 0
            for node in self.running():
                try:
                    _, health = node.call("GET", "sys/health", timeout=2)
                except (OSError, urllib.error.URLError, TimeoutError):
                    continue
                if health.get("ha_active") is True:
                    active += 1
            if active > 1:
                raise FixtureError("multiple_raft_leaders_during_readiness")
            if active == 1:
                return
            time.sleep(0.1)
        raise FixtureError("raft_quorum_readiness_timeout")

    def leader(self) -> Node:
        # Fault phases permit a bounded election settling period. Do not retry a
        # write after ambiguity: establish stable, read-only leadership first.
        deadline = time.monotonic() + 30
        previous, stable_since = None, None
        while time.monotonic() < deadline:
            active = []
            for node in self.running():
                try:
                    status, health = node.call("GET", "sys/health", timeout=2)
                except (OSError, urllib.error.URLError, TimeoutError):
                    continue
                if status == 200:
                    if (health.get("ha_active") is not True
                            or health.get("ha_application_ready") is not True
                            or health.get("standby") is not False):
                        raise FixtureError("health_success_without_active_authority")
                    active.append(node)
            if len(active) > 1:
                raise FixtureError("multiple_active_health_responses")
            if len(active) == 1:
                node = active[0]
                status, body = node.call("GET", "sys/leader", token=self.root_token)
                if status == 200 and body.get("is_self") is True:
                    observed = time.monotonic()
                    if previous is not node:
                        previous, stable_since = node, observed
                    elif observed - stable_since >= 2.2:
                        return node
                else:
                    previous, stable_since = None, None
            else:
                previous, stable_since = None, None
            time.sleep(0.1)
        raise FixtureError("unique_active_leader_not_observed")

    def write(self, node: Node, path: str, value: str) -> None:
        # Exactly one write attempt. Lost/ambiguous responses fail rather than replay.
        status, body = node.call("POST", f"secret/data/{path}", {"data": {"value": value}}, token=self.root_token)
        if status != 200 or type(body.get("data", {}).get("version")) is not int:
            raise FixtureError("write_not_acknowledged")

    def read(self, node: Node, path: str, value: str) -> None:
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline:
            try:
                status, body = node.call("GET", f"secret/data/{path}", token=self.root_token)
            except (OSError, urllib.error.URLError, TimeoutError):
                time.sleep(0.1)
                continue
            if status == 200:
                if body.get("data", {}).get("data", {}).get("value") != value:
                    raise FixtureError("successful_read_returned_stale_or_wrong_data")
                return
            if status not in (429, 503):
                raise FixtureError("acknowledged_write_not_visible")
            time.sleep(0.1)
        raise FixtureError("readback_timeout")

    def restart(self, node: Node) -> None:
        node.start()
        if node.call("POST", "sys/unseal", {"key": self.unseal_key})[0] != 200:
            raise FixtureError("restart_unseal_failed")

    def provision_seed_mounts(self, seed: Node) -> None:
        provision_secret_kv2(
            seed.call, token=self.root_token, error_type=FixtureError)
        self.fixture_mount_setup.append(completed_kv2_mount_metadata())

    def bootstrap(self) -> None:
        """Start the synthetic three-voter cluster without unrelated fault cases."""
        seed = self.nodes[0]
        seed.start(ha=False)
        self.check("fresh_seed_uninitialized", seed.call("GET", "sys/health")[0] == 501)
        status, body = seed.call("POST", "sys/init", {"secret_shares": 1, "secret_threshold": 1})
        self.check("fresh_seed_initialized", status == 200 and bool(body.get("root_token")) and bool(body.get("keys_base64")))
        self.root_token, self.unseal_key = body["root_token"], body["keys_base64"][0]
        self.check("seed_unsealed_before_ha", seed.call("POST", "sys/unseal", {"key": self.unseal_key})[0] == 200)
        self.provision_seed_mounts(seed)
        status, health = seed.call("GET", "sys/health")
        self.check("seed_cluster_identity_read_back", status == 200 and isinstance(health.get("cluster_id"), str) and bool(health["cluster_id"]))
        self.cluster_id = health["cluster_id"]
        seed.stop()
        self.configure_ha()
        for node in self.nodes[1:]:
            shutil.copytree(seed.data_dir, node.data_dir)
        # This intentionally tests a cold-cloned encrypted seed, NOT production enrollment.
        # Bootstrap every peer with the same cluster identity before exercising
        # the hostile misbinding case.  The bootstrap voter may contact its
        # peers during membership expansion, so bind every listener first.
        for node in [self.nodes[1], self.nodes[2], self.nodes[0]]:
            node.start(wait=False)
        for node in [self.nodes[1], self.nodes[2], self.nodes[0]]:
            node.wait_ready()
        self.check("three_distinct_service_processes", len({node.process.pid for node in self.nodes}) == 3)
        self.wait_quorum()
        for node in self.nodes:
            self.check(f"node_{node.node_id}_unsealed", node.call("POST", "sys/unseal", {"key": self.unseal_key})[0] == 200)

    def assert_misbound_rejection(self, wrong: Node) -> None:
        # Current candidates must reject the bound durable marker before API
        # admission. Historical rolling fixtures override only this assertion.
        wrong.expect_startup_rejection(MISBOUND_BOOTSTRAP_ERROR)
        self.check("misbound_cluster_startup_rejected", True)

    def run(self) -> None:
        self.bootstrap()
        # Test that a legitimate peer cannot unseal a different application
        # cluster after it has already joined the committed three-voter set.
        wrong = self.nodes[2]
        wrong.stop()
        wrong_config = json.loads((wrong.root / "ha.json").read_text())
        wrong_config["cluster_id"] = "deliberately-wrong-application-cluster"
        wrong.ha_config = wrong.root / "wrong-cluster.json"
        private_write(wrong.ha_config, json.dumps(wrong_config))
        self.assert_misbound_rejection(wrong)
        wrong.ha_config = wrong.root / "ha.json"
        wrong.start()
        self.wait_quorum()
        self.check("restored_peer_unsealed", wrong.call("POST", "sys/unseal", {"key": self.unseal_key})[0] == 200)
        leader = self.leader()
        marker = secrets.token_hex(16)
        self.write(leader, "ha-probe", marker)
        for node in self.nodes:
            self.read(node, "ha-probe", marker)
        self.check("acknowledged_value_readable_through_all_nodes", True)
        standby = next(node for node in self.nodes if node is not leader)
        forwarded = secrets.token_hex(16)
        self.write(standby, "forwarded-probe", forwarded)
        self.read(leader, "forwarded-probe", forwarded)
        self.check("standby_write_forwarded_to_leader", True)
        standby.stop()
        for index in range(8):
            self.write(leader, f"snapshot-probe-{index}", secrets.token_hex(12))
        self.snapshot_downloads.append(leader.snapshot_after_compaction(token=self.root_token, timeout=15))
        self.check("leader_snapshot_trigger", True)
        snapshot_value = secrets.token_hex(16)
        self.write(leader, "after-snapshot", snapshot_value)
        self.restart(standby)
        self.read(standby, "after-snapshot", snapshot_value)
        self.check("offline_follower_rejoined_after_snapshot_trigger", True)
        old_leader = self.leader()
        old_leader.stop()
        leader = self.leader()
        self.check("new_leader_after_sigkill", leader is not old_leader)
        failover_value = secrets.token_hex(16)
        self.write(leader, "after-failover", failover_value)
        for node in self.running():
            self.read(node, "after-failover", failover_value)
        self.check("acknowledged_post_failover_write", True)
        peer = next(node for node in self.running() if node is not leader)
        peer.stop()
        time.sleep(1.5)
        status, health = leader.call("GET", "sys/health", timeout=5)
        self.check("quorum_loss_health_denied", status == 503 and health.get("ha_active") is False)
        status, _ = leader.call("POST", "secret/data/quorum-denied", {"data": {"value": "must-not-commit"}}, token=self.root_token)
        self.check("quorum_loss_write_denied", status == 503)
        self.restart(peer)
        leader = self.leader()
        recovered_value = secrets.token_hex(16)
        self.write(leader, "quorum-recovered", recovered_value)
        self.restart(old_leader)
        self.leader()
        for node in self.nodes:
            self.read(node, "quorum-recovered", recovered_value)
            self.check(f"node_{node.node_id}_no_rejected_write_effect", node.call("GET", "secret/data/quorum-denied", token=self.root_token)[0] == 404)
        self.check("all_three_rejoined_after_quorum_recovery", True)

    def close(self) -> None:
        owned_process.close_all([node.stop for node in self.nodes])


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--expected-binary-sha256", required=True)
    parser.add_argument("--work-dir", required=True, type=Path)
    args = parser.parse_args()
    report = {"schema": "heptabao.destructive-ha.v2", "status": "not_run", "scenarios": [],
              "qualification": False, "compatibility_claim": False, "production_authority": False,
              "release_authority": False, "independent_attestation": False,
              "uncovered": ["network_partition", "power_loss", "disk_full", "forced_snapshot_install",
                            "rolling_version_upgrade", "membership_change", "longitudinal_linearizability"]}
    cluster = None
    started = time.monotonic()
    try:
        report["binary_sha256"] = checked_binary(args.binary, args.expected_binary_sha256)
        cluster = Cluster(args.binary, args.work_dir)
        report["status"] = "running"
        cluster.run()
        checked_binary(args.binary, args.expected_binary_sha256)
        report["status"] = "pass_scoped_repository_fixture"
        report["node_count"] = 3
        return_code = 0
    except (FixtureError, OSError, subprocess.SubprocessError, ValueError, KeyError, TypeError, IndexError) as error:
        report["status"] = "failed"
        report["failure_class"] = str(error) if isinstance(error, FixtureError) else type(error).__name__
        return_code = 1
    finally:
        if cluster is not None:
            report["scenarios"] = cluster.scenarios
            report["fixture_mount_setup"] = cluster.fixture_mount_setup
            report["snapshot_downloads"] = cluster.snapshot_downloads
            try:
                cluster.close()
            except (FixtureError, OSError, subprocess.SubprocessError):
                report["status"], report["failure_class"] = "failed", "cleanup_failed"
                return_code = 1
        report["elapsed_seconds"] = round(time.monotonic() - started, 3)
    report["scenario_count"] = len(report["scenarios"])
    print(json.dumps(report, sort_keys=True, indent=2))
    return return_code


if __name__ == "__main__":
    raise SystemExit(main())
