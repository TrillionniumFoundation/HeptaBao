import hashlib,json,os,pathlib,stat
P=json.loads(PAYLOAD)
BASE=pathlib.Path("/home/qian-qi/heptabao-ha-rejection-c27-20261106-r2")
OUT=pathlib.Path("/home/qian-qi/heptabao-ha-r3-source-c403d-20261106")
os.umask(0o077)
manifest=(BASE/"deployment.manifest.json").read_bytes()
assert hashlib.sha256(manifest).hexdigest()=="cbcb0b22a9dc14387baf03a2e9f294d6b58e684b94b316d6f7371fceb7b9475b"
blobs={}
for r in json.loads(manifest)["files"]:
    p=BASE/r["path"];s=p.lstat()
    assert stat.S_ISREG(s.st_mode) and s.st_uid==os.getuid() and s.st_nlink==1
    b=p.read_bytes();assert len(b)==r["bytes"] and hashlib.sha256(b).hexdigest()==r["sha256"]
    if r["path"].startswith("source/"):blobs[r["path"]]=b
def replace_once(s,a,b):
    assert s.count(a)==1
    return s.replace(a,b,1)
ha=blobs["source/ha_destructive.py"].decode()
ha=replace_once(ha,"    def start(self, ha: bool = True, *, wait: bool = True) -> None:",P["helper"]+"\n    def start(self, ha: bool = True, *, wait: bool = True) -> None:")
ha=replace_once(ha,"leader.download_snapshot(token=self.root_token, timeout=15)","leader.snapshot_after_compaction(token=self.root_token, timeout=15)")
replay=blobs["source/replay_epoch_ha.py"].decode()
replay=replace_once(replay,"class ReplayEpochCluster(Cluster):",P["predicate"]+"class ReplayEpochCluster(Cluster):")
old='        self.snapshot_downloads.append(final_leader.download_snapshot(\n            token=self.root_token,\n            timeout=20,\n        ))\n'
replay=replace_once(replay,old,P["snapshotBlock"])
start=replay.index("        deadline = time.monotonic() + 10\n")
end=replay.index("        self.restart(lagging)\n",start)
replay=replay[:start]+P["frontierBlock"]+replay[end:]
replay=replace_once(replay,'            report["snapshot_downloads"] = cluster.snapshot_downloads\n','            report["snapshot_downloads"] = cluster.snapshot_downloads\n            report["replay_snapshot_frontier"] = getattr(cluster, "replay_snapshot_frontier", None)\n')
blobs["source/ha_destructive.py"]=ha.encode()
blobs["source/replay_epoch_ha.py"]=replay.encode()
blobs["source/tests/test_ha_snapshot_maintenance.py"]=P["tests"].encode()
expected={"source/ha_destructive.py":"403d10c594952c9b30094f42b08eb9a67cb732202d5af45c6d8adf0fe866d524","source/replay_epoch_ha.py":"a9cfb31d1b5e0fa448118738b4fc7d6dec90b4b3134f169434b0716fd2bfe502","source/tests/test_ha_snapshot_maintenance.py":"dc41da8ff9372f4e2476beb75411857bc80a88e14e9a520d40fc6607ed74e807"}
for n,h in expected.items():
    actual=hashlib.sha256(blobs[n]).hexdigest()
    assert actual==h,(n,actual,len(blobs[n]))
OUT.mkdir(mode=0o700,exist_ok=False)
def put(n,b):
    p=OUT/n;p.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    with p.open("xb") as f:f.write(b);f.flush();os.fsync(f.fileno())
    fd=os.open(p.parent,os.O_RDONLY)
    try:os.fsync(fd)
    finally:os.close(fd)
rows=[]
for n,b in sorted(blobs.items()):
    put(n,b);rows.append({"path":n,"bytes":len(b),"sha256":hashlib.sha256(b).hexdigest()})
put("base.deployment.manifest.original.json",manifest)
put("materialization-payload.original.json",PAYLOAD.encode())
put("materialize.actual.py",SCRIPT.encode())
receipt={"schema":1,"scope":"byte_identical_source_materialization_from_frozen_r2_and_exact_r3_delta","all_known_local_r3_source_hashes_matched":True,"original_host_test_output_reconstructed":False,"tests_executed":False,"production_qualified":False,"base_manifest_sha256":hashlib.sha256(manifest).hexdigest(),"files":rows}
b=(json.dumps(receipt,sort_keys=True,indent=2)+"\n").encode();put("materialization.receipt.public.json",b)
print(json.dumps({"ok":True,"root":str(OUT),"files":rows,"receipt_sha256":hashlib.sha256(b).hexdigest(),"tests_executed":False},sort_keys=True))
