#!/usr/bin/env python3
"""Create one new private ROG run root from an exact source packet and old binary."""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile
import time

ROOT = Path('/home/qian-qi/heptabao-ha-rejection-c27-20261106-r3')
PACKET = Path('/home/qian-qi/heptabao-ha-rejection-c27-20261106-r3.input.tar.gz')
ORIGINAL = Path('/home/qian-qi/heptabao-personal-build-evidence-20261106-a1b6ff-r1/server-build-r1')
BINARY_SHA = 'c27a0c223d227d3b2b5292e1e3ab6cf0230562baee36b6465b22a7ddf17be172'
BUILD_SHA = '96bad2644072717e73e08440afe65470ff542d159a2d85340951581a4c17ead5'


def snapshot(info):
    return [getattr(info, key) for key in ('st_dev', 'st_ino', 'st_mode', 'st_uid', 'st_nlink',
                                         'st_size', 'st_mtime_ns', 'st_ctime_ns')]


def read_safe(path, maximum):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_nlink != 1 or before.st_size > maximum):
            raise RuntimeError('unsafe_fixed_input')
        with os.fdopen(fd, 'rb', closefd=False) as stream:
            data = stream.read(maximum + 1)
        if (len(data) != before.st_size or snapshot(before) != snapshot(os.fstat(fd))
                or snapshot(before) != snapshot(path.lstat())):
            raise RuntimeError('fixed_input_changed')
        return data
    finally:
        os.close(fd)


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def create_file(path, data, mode=0o400):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory(path.parent)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--packet-sha256', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    os.umask(0o077)
    if ROOT.parent.resolve() != ROOT.parent or ROOT.parent.stat().st_uid != os.getuid():
        raise RuntimeError('unexpected_owned_parent')
    packet = read_safe(PACKET, 1024 * 1024)
    if hashlib.sha256(packet).hexdigest() != args.packet_sha256:
        raise RuntimeError('packet_sha256_mismatch')
    contents = {}
    with tarfile.open(fileobj=io.BytesIO(packet), mode='r:gz') as archive:
        members = archive.getmembers()
        if not 1 <= len(members) <= 12:
            raise RuntimeError('packet_member_count')
        for item in members:
            path = PurePosixPath(item.name)
            if (not item.isfile() or path.is_absolute() or '..' in path.parts
                    or str(path) != item.name or item.name in contents or item.size > 100000):
                raise RuntimeError('unsafe_packet_member')
            stream = archive.extractfile(item)
            if stream is None:
                raise RuntimeError('packet_member_missing')
            with stream:
                data = stream.read(item.size + 1)
            if len(data) != item.size:
                raise RuntimeError('packet_member_length')
            contents[item.name] = data
    manifest_bytes = contents['deployment.manifest.json']
    if hashlib.sha256(manifest_bytes).hexdigest() != args.manifest_sha256:
        raise RuntimeError('manifest_sha256_mismatch')
    manifest = json.loads(manifest_bytes)
    files = manifest['files']
    if set(contents) != {'deployment.manifest.json'} | {item['path'] for item in files}:
        raise RuntimeError('manifest_inventory_mismatch')
    for item in files:
        data = contents[item['path']]
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            raise RuntimeError('manifest_member_sha256_mismatch')
    build = read_safe(ORIGINAL / 'build.public.json', 65536)
    if hashlib.sha256(build).hexdigest() != BUILD_SHA:
        raise RuntimeError('original_build_receipt_mismatch')
    proof = json.loads(build)
    expected = proof['binaries']['heptabao-server']
    if (expected['artifact_path'] != str(ORIGINAL / 'bin/heptabao-server')
            or expected['binary_sha256'] != BINARY_SHA or expected['binary_bytes'] != 133550368
            or proof['status'] != 'passed'):
        raise RuntimeError('original_build_binding_mismatch')
    ROOT.mkdir(mode=0o700)
    sync_directory(ROOT.parent)
    for directory in (ROOT / 'source', ROOT / 'source/tests', ROOT / 'bin'):
        directory.mkdir(mode=0o700)
        sync_directory(directory.parent)
    for name, data in contents.items():
        create_file(ROOT / name, data)
    create_file(ROOT / 'original-build.public.json', build)
    source_path = ORIGINAL / 'bin/heptabao-server'
    source_fd = os.open(source_path, os.O_RDONLY | os.O_NOFOLLOW)
    value = hashlib.sha256()
    copied = 0
    try:
        before = os.fstat(source_fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid != os.getuid()
                or before.st_nlink != 1 or before.st_size != 133550368):
            raise RuntimeError('unsafe_original_binary')
        destination = ROOT / 'bin/heptabao-server'
        fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o500)
        with os.fdopen(fd, 'wb') as output, os.fdopen(source_fd, 'rb', closefd=False) as source:
            while True:
                block = source.read(1024 * 1024)
                if not block:
                    break
                output.write(block)
                value.update(block)
                copied += len(block)
            output.flush()
            os.fsync(output.fileno())
        if (copied != 133550368 or value.hexdigest() != BINARY_SHA
                or snapshot(before) != snapshot(os.fstat(source_fd))
                or snapshot(before) != snapshot(source_path.lstat())):
            raise RuntimeError('original_binary_changed_or_digest_mismatch')
    finally:
        os.close(source_fd)
    sync_directory(ROOT / 'bin')
    with (ROOT / 'bin/heptabao-server').open('rb') as stream:
        if hashlib.file_digest(stream, 'sha256').hexdigest() != BINARY_SHA:
            raise RuntimeError('copied_binary_mismatch')
    admission = {'schema': 1, 'status': 'prepared', 'actual_argv': sys.argv,
                 'root': str(ROOT), 'packet_sha256': args.packet_sha256,
                 'manifest_sha256': args.manifest_sha256, 'original_build_sha256': BUILD_SHA,
                 'server_binary_sha256': BINARY_SHA, 'server_binary_bytes': copied,
                 'server_source_commit': proof['expected_source_commit'],
                 'server_source_tree': proof['expected_source_tree'],
                 'created_unix_ns': time.time_ns(), 'synthetic_only': True,
                 'existing_service_touched': False, 'profile_started': False,
                 'production_qualified': False}
    raw = (json.dumps(admission, sort_keys=True, indent=2) + '\n').encode()
    create_file(ROOT / 'admission.public.json', raw)
    print(json.dumps({'status': 'prepared', 'root': str(ROOT),
                      'admission_sha256': hashlib.sha256(raw).hexdigest(),
                      'packet_sha256': args.packet_sha256, 'manifest_sha256': args.manifest_sha256,
                      'server_binary_sha256': BINARY_SHA, 'profile_started': False}, sort_keys=True))


if __name__ == '__main__':
    main()
