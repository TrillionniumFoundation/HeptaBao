#!/usr/bin/python3
"""Fresh fixed-source unit controls. No HA or Android qualification."""
import argparse, hashlib, json, os, re, signal, stat, subprocess, sys, time
from pathlib import Path
ROOT=Path('/home/qian-qi/heptabao-ha-rejection-c27-20261106-r3')
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,data):
    with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
    fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)
def encoded(obj):return (json.dumps(obj,sort_keys=True,indent=2)+'\n').encode()
def snapshot(manifest):
    result={}
    for row in manifest['files']:
        path=ROOT/row['path'];st=path.lstat()
        if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.getuid() or st.st_nlink!=1:raise RuntimeError('unsafe_frozen_file')
        data=path.read_bytes()
        item={'bytes':len(data),'sha256':sha(data)}
        if item!={'bytes':row['bytes'],'sha256':row['sha256']}:raise RuntimeError('source_changed')
        result[row['path']]=item
    return result
BOOTSTRAP="""import json,os,runpy,sys
from pathlib import Path
source,test,auditpath=sys.argv[1:]
events=[]
def guard(event,args):
    if event.startswith('socket.') or event=='urllib.Request':
        events.append(event)
        raise RuntimeError('host_control_external_network_forbidden')
sys.addaudithook(guard)
sys.path.insert(0,source)
sys.argv=[test,'-v']
try:
    runpy.run_path(test,run_name='__main__')
finally:
    data=(json.dumps({'network_event_count':len(events),'events':events},sort_keys=True)+'\\n').encode()
    fd=os.open(auditpath,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    try:
        with os.fdopen(fd,'wb',closefd=False) as f:f.write(data);f.flush();os.fsync(f.fileno())
    finally:os.close(fd)
"""
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--expected-deployment-sha256',required=True)
    args=parser.parse_args();os.umask(0o077)
    if Path(__file__).resolve()!=ROOT/'run_host_controls.py':raise RuntimeError('wrong_root')
    raw=(ROOT/'deployment.manifest.json').read_bytes()
    if sha(raw)!=args.expected_deployment_sha256:raise RuntimeError('manifest_changed')
    manifest=json.loads(raw);before=snapshot(manifest)
    out=ROOT/'host-controls-r1';out.mkdir(mode=0o700)
    temp=out/'tmp';temp.mkdir(mode=0o700)
    env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TMPDIR':str(temp),'PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
    cases=[];passed=True
    for name,expected in [('test_ha_snapshot_maintenance.py',12),('test_ha_destructive.py',25)]:
        stem=name.removesuffix('.py')
        audit=out/(stem+'.network-audit.original.json')
        argv=['/usr/bin/python3','-I','-B','-c',BOOTSTRAP,str(ROOT/'source'),str(ROOT/'source/tests'/name),str(audit)]
        intent={'actual_argv':argv,'environment':env,'expected_test_count':expected,'timeout_seconds':90}
        write(out/(stem+'.intent.public.json'),encoded(intent))
        started=time.monotonic();timed_out=False
        p=subprocess.Popen(argv,cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        try:stdout,stderr=p.communicate(timeout=90)
        except subprocess.TimeoutExpired:
            timed_out=True
            os.killpg(p.pid,signal.SIGKILL)
            stdout,stderr=p.communicate(timeout=10)
        elapsed=time.monotonic()-started
        write(out/(stem+'.stdout.original.txt'),stdout);write(out/(stem+'.stderr.original.txt'),stderr)
        counts=re.findall(rb'^Ran ([0-9]+) tests? in [^\n]+$',stderr,re.M)
        observed=int(counts[0]) if len(counts)==1 else None
        audit_raw=audit.read_bytes() if audit.exists() else b''
        audit_obj=json.loads(audit_raw) if audit_raw else {}
        okay=p.returncode==0 and not timed_out and observed==expected and stderr.rstrip().endswith(b'OK') and audit_obj.get('network_event_count')==0
        row={'test_file':name,'exit_code':p.returncode,'timeout':timed_out,'elapsed_seconds':elapsed,
             'expected':expected,'observed':observed,'passed':okay,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr),
             'network_audit_sha256':sha(audit_raw),'network_event_count':audit_obj.get('network_event_count'),'actual_argv':argv}
        cases.append(row);passed=passed and okay
    after=snapshot(manifest);passed=passed and before==after
    receipt={'schema_version':1,'scope':'fresh_author_guard_suites_rerun_by_peer_with_substituted_http',
        'actual_controller_argv':sys.argv,'python_version':sys.version,'manifest_sha256':args.expected_deployment_sha256,
        'before':before,'after':after,'cases':cases,'passed':passed,'adb_operations':0,
        'actual_network_events':sum(row['network_event_count'] or 0 for row in cases),
        'test_design_independent':False,'external_security_review':False,'real_ha_qualified':False,'production_qualified':False}
    raw=encoded(receipt);write(out/'receipt.public.json',raw)
    print(json.dumps({'passed':passed,'counts':[row['observed'] for row in cases],
                      'receipt_sha256':sha(raw),'actual_network_events':receipt['actual_network_events'],'adb_operations':0},sort_keys=True))
    return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
