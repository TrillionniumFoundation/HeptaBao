import ast,gzip,hashlib,io,json,os,stat,sys,tarfile
from pathlib import Path
ROOT=Path('/home/qian-qi/heptabao-ha-rejection-c27-20261106-r3')
PAYLOAD=Path(str(ROOT)+'.controller-input.public.json')
PAYLOAD_SHA='0721e2e9564171cc1d812818e15272af0957ff11e36723b6059162af3b1bb0aa'
def sha(b):return hashlib.sha256(b).hexdigest()
def safe(path,expected):
 fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC)
 try:
  s=os.fstat(fd)
  if not stat.S_ISREG(s.st_mode) or s.st_uid!=os.getuid() or s.st_nlink!=1 or s.st_size>1048576:raise RuntimeError('unsafe_input')
  with os.fdopen(fd,'rb',closefd=False) as f:data=f.read()
  e=os.fstat(fd);l=path.lstat();key=lambda v:(v.st_dev,v.st_ino,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
  if key(s)!=key(e) or key(s)!=key(l) or len(data)!=s.st_size or sha(data)!=expected:raise RuntimeError('input_changed')
  return data
 finally:os.close(fd)
def syncdir(path):
 fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def save(path,data):
 with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.chmod(path,0o400);syncdir(path.parent)
 if path.read_bytes()!=data:raise RuntimeError('write_readback_mismatch')
os.umask(0o077)
if ROOT.exists():raise RuntimeError('run_root_already_exists')
data=safe(PAYLOAD,PAYLOAD_SHA);p=json.loads(data)
if p['root']!=str(ROOT) or set(p['generated_files'])!={'run_profiles.py','prepare_remote.py','run_host_controls.py'}:raise RuntimeError('payload_scope')
source=Path(p['source_root']);contents={}
for row in p['source_files']:
 if not row['path'].startswith('source/') or '..' in Path(row['path']).parts:raise RuntimeError('bad_path')
 content=safe(source/row['path'],row['sha256'])
 if len(content)!=row['bytes']:raise RuntimeError('length')
 contents[row['path']]=content
if len(contents)!=7:raise RuntimeError('source_inventory')
for name,text in p['generated_files'].items():
 content=text.encode();ast.parse(text,filename=name);contents[name]=content
material=p['materialization']
contents['source-materialization.public.json']=safe(Path(material['path']),material['sha256'])
if len(contents['source-materialization.public.json'])!=material['bytes']:raise RuntimeError('materialization_length')
manifest={'schema':1,'scope':'frozen_explicit_compaction_and_native_snapshot_qa_and_separate_existing_binary_synthetic_profiles',
 'files':[{'path':name,'bytes':len(blob),'sha256':sha(blob)} for name,blob in sorted(contents.items())],
 'profiles':{'ha_destructive':240,'ha_network_partition':360,'replay_epoch_ha':600},
 'server_sha256':'c27a0c223d227d3b2b5292e1e3ab6cf0230562baee36b6465b22a7ddf17be172',
 'server_source_commit':'a1b6ff4506f52082a0893b7167fafb4ff95610be','source_head_observed':None,
 'source_materialization_sha256':material['sha256'],'source_bytes_match_frozen_r3':True,
 'same_source_tree_build_claimed':False,'canonical_owner_claimed':False,'production_qualified':False}
manifest_bytes=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
contents['deployment.manifest.json']=manifest_bytes
if len(contents)!=12:raise RuntimeError('packet_inventory')
raw=io.BytesIO()
with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
  for name,blob in sorted(contents.items()):
   ti=tarfile.TarInfo(name);ti.size=len(blob);ti.mode=0o400;ti.mtime=0;tar.addfile(ti,io.BytesIO(blob))
packet=raw.getvalue()
save(Path(str(ROOT)+'.input.tar.gz'),packet)
save(Path(str(ROOT)+'.deployment.manifest.json'),manifest_bytes)
save(Path(str(ROOT)+'.prepare.actual.py'),contents['prepare_remote.py'])
actual_source=sys.orig_argv[sys.orig_argv.index('-c')+1].encode()
save(Path(str(ROOT)+'.packet-builder.actual.py'),actual_source)
review=dict(p['review'],manifest_sha256=sha(manifest_bytes),packet_sha256=sha(packet),actual_source_materialization=material)
save(Path(str(ROOT)+'.static-review.public.json'),(json.dumps(review,sort_keys=True,indent=2)+'\n').encode())
receipt={'schema':1,'status':'fixed_r3_input_packet_created','packet_sha256':sha(packet),'packet_bytes':len(packet),
 'manifest_sha256':sha(manifest_bytes),'controller_sha256':sha(contents['run_profiles.py']),
 'prepare_sha256':sha(contents['prepare_remote.py']),'host_controller_sha256':sha(contents['run_host_controls.py']),
 'packet_builder_sha256':sha(actual_source),'source_materialization_sha256':material['sha256'],
 'member_count':len(contents),'profile_executed':False,'host_controls_executed':False}
save(Path(str(ROOT)+'.packet-receipt.public.json'),(json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps(receipt,sort_keys=True))
