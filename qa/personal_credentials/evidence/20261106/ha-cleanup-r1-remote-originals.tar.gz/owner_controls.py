#!/usr/bin/env python3
"""Actual local Owner/Popen control; no server, socket, or device action."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    os.umask(0o077)
    root = args.output
    root.mkdir(mode=0o700)
    source = Path(__file__).resolve().parent / 'source'
    expected = {
        'ha_destructive.py': '6219624c135d4de428af8376dff5bad8d923585725fcefa7bee2878803eca676',
        'owned_process.py': '0ee96c9f43b50ebd57ee8f0ef95f2431c441ec02c1799992588dbf50768745d0',
        'fixture_mounts.py': '55075ee436c22816a176dfb06cec387df37fdadd581c16acc07dabc837ba85b5',
    }
    def check_sources():
        for name, digest in expected.items():
            assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest
    check_sources()
    sys.path.insert(0, str(source))
    import ha_destructive as ha
    import owned_process as owned
    cases = (
        ('exact_exit_one', ha.MISBOUND_BOOTSTRAP_ERROR, 1, None),
        ('wrong_diagnostic', 'different synthetic failure', 1, 'unexpected_startup_rejection'),
        ('exit_zero', ha.MISBOUND_BOOTSTRAP_ERROR, 0, 'unexpected_startup_rejection'),
    )
    observations = []
    for name, line, code, expected_error in cases:
        case = root / name
        case.mkdir(mode=0o700)
        private_owner = case / 'owner'
        private_owner.mkdir(mode=0o700)
        program = case / 'synthetic-server'
        program.write_text('#!' + sys.executable + '\nimport sys\n'
                           + 'print(' + repr(line) + ', file=sys.stderr, flush=True)\n'
                           + 'raise SystemExit(' + str(code) + ')\n')
        program.chmod(0o700)
        node = ha.Node(1, program, case, None, ports=(19001, 19002))
        owner = owned.Owner(private_owner, deadline_ns=time.monotonic_ns() + 30_000_000_000,
                            profile='startup_rejection_internal_control')
        observed_error = None
        try:
            with owned.activated(owner):
                node.expect_startup_rejection(ha.MISBOUND_BOOTSTRAP_ERROR)
        except ha.FixtureError as error:
            observed_error = str(error)
        assert observed_error == expected_error
        assert node.process is None and node.log is None
        assert len(owner.children) == 1
        child = owner.children[0]
        assert isinstance(child, owned._OwnedPopen) and child._done
        assert child.returncode == code
        row = owner.receipt['children'][0]
        assert row['completed_original_wait_count'] == 1
        assert row['same_original_Popen_wait'] is True
        assert row['signals'] == []
        assert row['original_SID_retired_observed'] is True
        assert owner.receipt['same_originals_closed'] is True
        assert owner.receipt['passed_process_method'] is (expected_error is None)
        receipt_path = owner.root / 'original-process-receipt.json'
        observations.append({
            'case': name, 'passed': True, 'actual_returncode': code,
            'observed_error': observed_error, 'owner_method_passed': owner.receipt['passed_process_method'],
            'original_wait_count': row['completed_original_wait_count'], 'signals_sent': 0,
            'node_handles_cleared': True, 'original_sid_retired': True,
            'original_owner_receipt': str(receipt_path.relative_to(root)),
            'original_owner_receipt_sha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
        })
    check_sources()
    report = {'schema': 1, 'scope': 'actual_owner_node_cleanup_local_controls_only',
              'actual_argv': sys.argv, 'expected': 3, 'passed': len(observations),
              'observations': observations, 'source_sha256': expected,
              'server_executed': False, 'socket_actions': 0, 'device_actions': 0,
              'production_qualified': False, 'external_security_review': False,
              'owner_close_expected_codes_after_saved_wait_tested': False,
              'owner_done_early_return_is_existing_behavior': True}
    print(json.dumps(report, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
