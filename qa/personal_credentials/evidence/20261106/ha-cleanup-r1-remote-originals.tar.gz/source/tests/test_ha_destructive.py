"""Fixture guard tests only; these do not execute or qualify a real HA cluster."""
from __future__ import annotations
import hashlib
import importlib.util
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

SPEC = importlib.util.spec_from_file_location("ha_destructive_under_test", Path(__file__).resolve().parents[1] / "ha_destructive.py")
assert SPEC and SPEC.loader
HA = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(HA)


class DestructiveFixtureGuards(unittest.TestCase):
    def cluster(self):
        value = HA.Cluster.__new__(HA.Cluster)
        value.root_token = "synthetic"
        value.scenarios = []
        return value

    def test_successful_stale_read_fails_without_retry(self):
        node = Mock()
        node.call.return_value = (200, {"data": {"data": {"value": "stale"}}})
        with self.assertRaisesRegex(HA.FixtureError, "stale_or_wrong"):
            self.cluster().read(node, "probe", "current")
        node.call.assert_called_once()

    def test_missing_acknowledged_value_fails_without_retry(self):
        node = Mock()
        node.call.return_value = (404, {})
        with self.assertRaisesRegex(HA.FixtureError, "not_visible"):
            self.cluster().read(node, "probe", "current")
        node.call.assert_called_once()

    def test_transient_unavailability_can_retry_read_only(self):
        node = Mock()
        node.call.side_effect = [(503, {}), (200, {"data": {"data": {"value": "current"}}})]
        with patch.object(HA.time, "sleep"):
            self.cluster().read(node, "probe", "current")
        self.assertEqual(2, node.call.call_count)

    def test_ambiguous_write_is_not_replayed(self):
        node = Mock()
        node.call.side_effect = TimeoutError("synthetic timeout")
        with self.assertRaises(TimeoutError):
            self.cluster().write(node, "probe", "new")
        node.call.assert_called_once()

    def test_boolean_version_is_not_a_committed_write_receipt(self):
        node = Mock()
        node.call.return_value = (200, {"data": {"version": True}})
        with self.assertRaises(HA.FixtureError):
            self.cluster().write(node, "probe", "new")

    def test_preexisting_root_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory).resolve()
            marker = root / "preserve.txt"
            marker.write_text("retain")
            with self.assertRaises(HA.FixtureError):
                HA.Cluster(Path("/not-used"), root)
            self.assertEqual("retain", marker.read_text())

    def test_redirects_are_not_followed(self):
        self.assertIsNone(HA.NoRedirect().redirect_request(None, None, 302, "", {}, "http://external.invalid"))

    def test_private_write_is_create_only(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "synthetic.json"
            HA.private_write(path, b"first")
            with self.assertRaises(FileExistsError):
                HA.private_write(path, b"second")
            self.assertEqual(b"first", path.read_bytes())

    def test_wrong_binary_digest_denied_before_execution(self):
        with tempfile.TemporaryDirectory() as directory:
            path = (Path(directory) / "program").resolve()
            path.write_bytes(b"synthetic executable bytes")
            path.chmod(0o700)
            with self.assertRaisesRegex(HA.FixtureError, "digest_mismatch"):
                HA.checked_binary(path, "0" * 64)
            expected = hashlib.sha256(path.read_bytes()).hexdigest()
            self.assertEqual(expected, HA.checked_binary(path, expected))

    def test_exact_startup_rejection_requires_one_terminal_diagnostic(self):
        expected = HA.MISBOUND_BOOTSTRAP_ERROR
        self.assertTrue(HA.exact_startup_rejection(
            1, ("listener ready\n" + expected + "\n").encode(), expected))
        for returncode, payload in [
            (None, expected.encode()),
            (0, expected.encode()),
            (-9, expected.encode()),
            (1, b"different failure\n"),
            (1, (expected + "\ntrailing output\n").encode()),
            (1, b"\xff"),
        ]:
            with self.subTest(returncode=returncode, payload=payload):
                self.assertFalse(HA.exact_startup_rejection(
                    returncode, payload, expected))

    def test_failed_scenario_is_not_recorded_as_success(self):
        cluster = self.cluster()
        with self.assertRaises(HA.FixtureError):
            cluster.check("unobserved", False)
        self.assertEqual([], cluster.scenarios)


@unittest.skipUnless(os.name == "posix", "actual Unix child-process cleanup")
class StartupRejectionProcessCleanup(unittest.TestCase):
    """Exercise the actual Node/Popen cleanup path, without a server or socket."""

    def run_child(self, root, line, code, operation):
        program = root / "synthetic-server"
        program.write_text(
            "#!" + sys.executable + "\nimport sys\n"
            + "print(" + repr(line) + ", file=sys.stderr, flush=True)\n"
            + "raise SystemExit(" + str(code) + ")\n")
        program.chmod(0o700)
        node = HA.Node(1, program, root, None, ports=(19001, 19002))
        children = []
        original = HA.owned_process.popen

        def capture(*args, **kwargs):
            child = original(*args, **kwargs)
            children.append(child)
            return child

        try:
            with patch.object(HA.owned_process, "popen", side_effect=capture):
                operation(node)
        finally:
            self.assertEqual(1, len(children))
            self.assertEqual(code, children[0].poll())
            self.assertIsNone(node.process)
            self.assertIsNone(node.log)

    def test_exact_exit_one_rejection_is_reaped_without_sigkill_claim(self):
        with tempfile.TemporaryDirectory() as directory:
            self.run_child(Path(directory), HA.MISBOUND_BOOTSTRAP_ERROR, 1,
                           lambda node: node.expect_startup_rejection(HA.MISBOUND_BOOTSTRAP_ERROR))

    def test_wrong_diagnostic_remains_original_rejection_failure(self):
        with tempfile.TemporaryDirectory() as directory:
            def attempt(node):
                with self.assertRaisesRegex(HA.FixtureError, "unexpected_startup_rejection"):
                    node.expect_startup_rejection(HA.MISBOUND_BOOTSTRAP_ERROR)
            self.run_child(Path(directory), "different synthetic failure", 1, attempt)

    def test_exit_zero_never_qualifies_a_startup_rejection(self):
        with tempfile.TemporaryDirectory() as directory:
            def attempt(node):
                with self.assertRaisesRegex(HA.FixtureError, "unexpected_startup_rejection"):
                    node.expect_startup_rejection(HA.MISBOUND_BOOTSTRAP_ERROR)
            self.run_child(Path(directory), HA.MISBOUND_BOOTSTRAP_ERROR, 0, attempt)

    def test_ordinary_stop_still_rejects_unexpected_exit_one(self):
        with tempfile.TemporaryDirectory() as directory:
            def attempt(node):
                node.start(wait=False)
                self.assertEqual(1, HA.owned_process.wait(node.process, timeout=5))
                with self.assertRaisesRegex(HA.owned_process.OwnedFailure,
                                           "owned_standalone_shutdown_code"):
                    node.stop()
            self.run_child(Path(directory), "unqualified synthetic exit", 1, attempt)


if __name__ == "__main__":
    unittest.main()
