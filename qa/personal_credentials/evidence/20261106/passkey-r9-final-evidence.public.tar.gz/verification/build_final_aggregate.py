#!/usr/bin/env python3
"""Host-only, create-only aggregate of already observed public originals.

No ADB, device access, network, product execution, or evidence rewriting.
"""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import os
import stat
import tarfile

BASE = Path('/workspace/scratch/personal_vault_passkey_r9_20261106')
OUT = BASE / 'final-aggregate-r1'
EXPANDED = BASE / 'final-main-archive-r1/expanded'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()

def read_regular(path, expected=None):
    st = path.lstat()
    assert stat.S_ISREG(st.st_mode) and not path.is_symlink()
    data = path.read_bytes()
    assert len(data) == st.st_size
    if expected is not None:
        assert sha(data) == expected, str(path)
    return data

def create(path, data):
    with path.open('xb') as f:
        os.chmod(path, 0o600)
        f.write(data)
        f.flush()
        os.fsync(f.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)

def verify_inner(data):
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as t:
        members = t.getmembers()
        assert 1 <= len(members) <= 5000
        assert sum(m.size for m in members) <= 256 * 1024 * 1024
        names = [m.name for m in members]
        assert len(names) == len(set(names))
        for m in members:
            p = PurePosixPath(m.name)
            assert m.isfile() and not p.is_absolute() and '..' not in p.parts
            assert str(p) == m.name and '\\' not in m.name
        manifest_raw = t.extractfile('manifest.public.json').read()
        manifest = json.loads(manifest_raw)
        entries = manifest.get('files', manifest.get('entries', manifest.get('members')))
        if isinstance(entries, dict):
            entries = [dict(v, path=k) for k, v in entries.items()]
        assert isinstance(entries, list)
        assert len(entries) == len(members) - 1
        assert {e['path'] for e in entries} == set(names) - {'manifest.public.json'}
        for e in entries:
            actual = t.extractfile(e['path']).read()
            assert len(actual) == e['bytes'] and sha(actual) == e['sha256'], e['path']
        return {'regular_members': len(members), 'indexed_members': len(entries),
                'manifest_sha256': sha(manifest_raw), 'all_indexed_bytes_verified': True}

SOURCES = [
    ('phone/original-profile.public.tar.gz', BASE / 'passkey-r9-public-originals.tar.gz',
     '4d412e0ea2ebb38f24038919ff016f3dc574db2c775758f982392150cdd2bc2d',
     'Original r9 18-case ledger, 33 frozen sources, actual Runtime records and public observations; 17 passed, G07 blocked.'),
    ('phone/independent-G07-attempt2.public.tar.gz', BASE / 'G07-independent-public-originals-r1.tar.gz',
     'bf1fe5f22bfa628fe848909b8d94a56ad8f2aa6e0bd39a4664f9cd0e64f66c01',
     'Separate exact Home preparation and one-case attempt2, blocked before its cancellation negative began; original ledger unchanged.'),
    ('runtime/orchestration-originals.public.tar.gz', OUT / 'runtime-orchestration-originals.public.tar.gz',
     'c14bb76151e6a41857ad99fbeca678d6d5a25d198b19509effe1ffd2ddf5235f',
     'Actual request, launch, terminal and stream containers, host capture/materialization records, and read-only local verification.'),
    ('peer/G11-case-admission.public.tar.gz', Path('/workspace/scratch/heptabao-p0-recovery-20261106-r2/passkey-r9-G11-peer/passkey-r9-G11-peer-review.public.tar.gz'),
     'e85c111930c334899042e7253c5312da8e956afd19437b2452b3c62e09207456',
     'Internal case-specific source and observed-input review, before the single G11 reset. Not an external audit or outcome by itself.'),
    ('support/firefox-linux-feasibility.public.tar.gz', BASE / 'supporting-evidence-r1/firefox-linux-feasibility.public.tar.gz',
     '64f1faa2e45546426c4e74b29f8c97de75bb8619f7b4bbf378522230d48ccc29',
     'Separate Firefox inventory and feasibility; no Firefox browser login.'),
    ('support/firefox-native-r1-public-originals.tar.gz', BASE / 'supporting-evidence-r1/firefox-native-r1-public-originals.tar.gz',
     '8d83057d95e139b861cf9fff15870d16c5cabd9cb50c44cabc50c33429692415',
     'Separate native CLI/installer 13 checks and Chromium native pipe 8 checks; zero Firefox browser E2E.'),
    ('support/firefox-native-root-review.public.tar.gz', BASE / 'supporting-evidence-r1/firefox-native-root-review.public.tar.gz',
     '18108ff336f810c8676189b368e8b36032c2084d1be0ef22e2d1bd1ea76885ef',
     'Root source and index integrity review of native support.'),
    ('support/chrome-f191-26-public-originals.tar.gz', BASE / 'supporting-evidence-r1/chrome-f191-26-public-originals.tar.gz',
     '2b1444e509776b19f5d73d1cc6228dcb2a6d7edaa5dc9b43a9e0c67b9d2caaf2',
     'Separate actual Chrome regression 26/26; synthetic TLS exception and no-sandbox conditions remain.'),
    ('support/chrome-f191-root-readback.public.tar.gz', BASE / 'supporting-evidence-r1/chrome-f191-root-readback.public.tar.gz',
     'c2c23395a5032247c0c66b3e361ffe346578c40a02dae04ccf0f27d4e49eafff',
     'Root direct Runtime and original-byte readback of the Chrome regression.'),
    ('support/passkey-r9-root-integration.public.tar.gz', BASE / 'supporting-evidence-r1/passkey-r9-root-integration.public.tar.gz',
     '256d5aeb31f2c884cdf875582dd3999bd3dc241106ae30f323ec98124b4bbed1',
     'Exact 33-source repository integration and root execution of host checks 20+55+13+14; no additional phone denominator.'),
    ('support/passkey-r9-release-root.public.tar.gz', BASE / 'supporting-evidence-r1/passkey-r9-release-root.public.tar.gz',
     '2ba5eba05894f178f1a1c474252e4f2ee977391d2fd2b9bc618168a210d53f1e',
     'Root direct release bytes and Runtime terminal observations. Incidental rolling-build metadata is not a P4 case.'),
]

files = {}
components = []
for dest, path, expected, scope in SOURCES:
    data = read_regular(path, expected)
    check = verify_inner(data)
    files[dest] = data
    components.append({'path': dest, 'bytes': len(data), 'sha256': sha(data), 'scope': scope, **check})

verification_raw = read_regular(BASE / 'final-main-archive-r1/verification.public.json',
    'e94e243c31dc4ae3073dc44d2cce392ffc2d5099b637b5a0d0a0f853c3dbd21a')
verification = json.loads(verification_raw)
ledger_raw = read_regular(EXPANDED / 'case-results.public.json',
    '8e79eb6e521d9eafb59d85ec16514a3258ba4409dfcf6da4af61fa9b103accf0')
ledger = json.loads(ledger_raw)
assert verification['ok'] is True and verification['fixed_source_files_unchanged'] == 33
assert {k: ledger[k] for k in ['expected', 'executed', 'passed', 'failed', 'blocked', 'missing']} == {
    'expected':18, 'executed':17, 'passed':17, 'failed':0, 'blocked':1, 'missing':0}
assert len(verification['original_stages']) == 21 and len(verification['additional_terminal_jobs']) == 4
assert all(j['launch_audit_recorded'] for j in verification['original_stages'] + verification['additional_terminal_jobs'])

summary = {
    'schema': 1,
    'scope': 'r9 actual Android synthetic Passkey profile plus separately scoped support; final host-only aggregate',
    'original_profile': {
        'expected':18, 'executed':17, 'passed':17, 'failed':0, 'blocked':1, 'missing':0,
        'blocked_ids':['G07'], 'fixed_profile_all_passed':False,
        'ledger_sha256':sha(ledger_raw),
        'cases':[{k:c[k] for k in ['id','group','behavior','status','executed']} for c in ledger['cases']],
    },
    'independent_G07_attempt2': {
        'expected':1, 'executed':0, 'passed':0, 'failed':0, 'blocked':1,
        'merged_into_original_profile':False,
        'original_G07_result_sha256':'7e4aebf3a031b503e9d46767d1f475b88aaba2bf89824b413127ddd8a9de8992',
        'preparation_result_sha256':'bb5e4f3fecf5b4050fb374383b531fa0ad902c5ee32b253ca610704356ea3f8a',
        'attempt2_result_sha256':'b1ab658648716dcd754fbb8e18af1e3fcc2b0fc4a9d8e584d95652e792cd7219',
        'preparation_master_or_CM':False, 'positive_control_CM_request_issued':True,
        'positive_control_completed':False, 'cancellation_negative_started':False,
        'provider_Back_inputs':0, 'system_chooser_Back_inputs':0,
        'failed_tap_input_was_not_reached':True, 'attempt3_performed':False,
    },
    'runtime': {
        'original_pre_release_jobs':20, 'release_jobs':1, 'additional_jobs':4,
        'original_stage_terminals':verification['original_stages'],
        'additional_terminals':verification['additional_terminal_jobs'],
        'all_listed_launches_audit_recorded':True,
        'M05_reset_and_restore_launches_audit_recorded':True,
        'actual_execution_mode':'operator', 'workload_task_attestation_proved':False,
        'actual_request_launch_terminal_and_full_streams_preserved':True,
        'raw_tool_values_are_not_claimed_to_be_wire_protocol_JSON':True,
    },
    'source_freeze': {
        'original_files':33, 'before_after_unchanged':True,
        'archive_sha256':'b2a71dab6bc8490147c3189352967bffa7927c8239a66331fa89ee49674edb5b',
        'ingress_sha256':'44eaca542f1898520f1780d9499e0cb4d7d012ab8f82ba10f5314f55ce389abc',
        'profile_public_sha256':'b6b7754bad0e34cf55b0c2635683b03093555fa5d3f096533ee36b3e02eec55b',
        'provider_apk_sha256':'b16e82916330fac6909f82696089798c3ec76d7b4058fe9290e7e841b9e00459',
        'fixture_good_apk_sha256':'b0d266ce40939a74822a3bd285895063fb938b93fd1c007c31b2a309abd52f7f',
        'build_receipt_sha256':'97a6daec5bb7276b935498fb3c8501df9ecc57a118641cffb9f2df3ae6edd009',
        'new_product_build_for_r9':False, 'extra_G07_QA_sources_are_separate':True,
    },
    'observed_boundaries': {
        'M05':'Real owned-provider pm clear after witnessed backup and case-specific review, then ordinary SAF restore in a new process on the same phone.',
        'M06':'Real CredentialManager get accepted for the original public key, sign_count 2 and authenticator flags 29.',
        'G08':'Fresh selected valid URI remained unconsumed before new picker; starting that picker clears the prior target; cancel then Write refused with choose_backup_destination_first and nonempty QA baseline unchanged.',
        'G10':'A distinct fresh unconsumed target reached wrong_key_or_corrupt with a wrong password; its nonempty QA baseline was unchanged. The attempted Write consumed the URI.',
        'G11':'Actual stale backup and natural CM/RP counters produced counter_rollback_or_replay with the same key/count2; no hand-edited counters or third reset.',
        'synthetic_destination_baseline':'615-byte fixed encrypted seed copied once for QA; not a product backup export.',
    },
    'cleanup': {
        'result_sha256':'8655e79f866128bcf23d953e59a9bd614540d88d43aef54e8c1213477477bfbf',
        'release_sha256':'51d1d95ba90c416487d38d504291421b6e319df0e8a4251b56a220ae193368c4',
        'release_bytes':16734, 'release_job':'1a1b2b2f271-fc05-7f5d',
        'all_three_settings_restored':True, 'three_owned_packages_installed_and_retained_absent':True,
        'owned_reverse_mapping_absent':True, 'tracked_files':8, 'tracked_directories':4,
        'tracked_documents_and_media_rows_absent':True,
        'RP_original_job':'1a1b25a72f2-fc05-7da8', 'RP_terminal_state':'cancelled', 'RP_exit_code':0,
        'RP_ready_and_stopped_stdout_bytes':104, 'phone_lease_released':True,
    },
    'host_and_browser_support': {
        'r9_host_check_groups':[20,55,13,14], 'r9_host_checks':102,
        'author_and_root_repeat_are_not_added_as_distinct_tests':True,
        'extra_G07_candidate_host_controls':13,
        'firefox_native_CLI_installer_checks':13, 'chromium_native_pipe_checks':8,
        'new_f191_real_Chrome_regression':{'expected':26,'passed':26},
        'firefox_browser_E2E_executed':0,
        'Chrome_synthetic_TLS_exception_and_no_sandbox_conditions_retained':True,
        'native_origin_argv_is_not_OS_caller_attestation':True,
        'phone_denominator_contribution':0,
    },
    'limitations': {
        'p4_qualified':False, 'production_qualified':False, 'external_security_audit_completed':False,
        'same_physical_device_recovery_only':True, 'physical_cross_device_passkey_migration_proved':False,
        'general_web_RP_and_platform_exchange_and_sharing_qualified':False,
        'credential_entry':'synthetic_only_adb_input_text_child_argv',
        'production_end_to_end_no_argv_proved':False,
        'old_r8_results_unchanged':'Original 16/18 and independent 3/3 remain separate, including their audit and evidence limitations.',
        'no_phone_or_product_actions_by_final_packager':True,
    },
    'components':components,
    'local_verification_sha256':sha(verification_raw),
}

text = '''# Android Passkey r9 — final evidence scope

The original fixed r9 profile finished with **17 passed, 1 blocked (G07), 0 failed, and 0 missing out of 18**. A separately admitted G07 attempt2 finished **blocked, with its cancellation negative unexecuted**, under its own one-case denominator. This aggregate does not claim 18/18 or P4 qualification. The earlier r8 16/18 result and its three independent successful retests retain their original, separate scope.

## What actually completed

Ordinary Android SAF imported the fixed synthetic encrypted vault. The native CredentialManager completed create and get against the fixed fixture application, certificate and synthetic RP, with independent RP verification. After a verified external encrypted backup, a case-specific admitted reset cleared only the initially absent, owned provider's data. A new process restored through ordinary SAF, and a real get verified against the original public key with `sign_count=2` and authenticator flags `29` (UP, UV, BE and BS). Both M05 reset and restore Runtime launches recorded `audit_recorded=true` in this run.

The stale-backup test then used the earlier real SAF backup and naturally advanced CM/RP counters. The RP recorded `counter_rollback_or_replay` while keeping the same public key and accepted counter 2. No counter was manually edited and no third reset occurred. This is recovery on the same physical Android phone; it is not evidence of physical cross-device Passkey migration.

The four SAF guards completed with separate causal observations. In G08 a new, valid, selected URI was still unconsumed before a new picker was opened and cancelled; Write then returned `choose_backup_destination_first`, and the nonempty target digest stayed unchanged. The new picker clears the old URI: the result is not attributed exclusively to the cancel callback. G10 used a distinct, newly selected, unconsumed target; a wrong-password Write reached `wrong_key_or_corrupt` without changing its nonempty contents. That attempted Write consumed the URI. Both destination baselines were the fixed 615-byte encrypted seed prepared once for synthetic QA, not product backup exports.

## The two G07 boundaries remain visible

| Record | Observed boundary | Case outcome |
| --- | --- | --- |
| Original fixed-source G07 | G06 had ended in the exact owned decoy fixture with `TYPE_NO_CREDENTIAL`. The Home/good-only entry predicate blocked before master entry, unlock, a new CM request, either time-budget origin or any Back action. | Original G07 remains blocked and unexecuted. Its original exit-1 job and result are unchanged. |
| Separate Home preparation | Exact decoy component, APK, settled G06 result, old blocked result, ledger and RP state were checked. One ordinary provider launch reached Home and the original evidence/RP remained unchanged. No master or CM request was used. | Setup only; not a cancellation test. |
| Independent attempt2 | The same six UI/timing functions and final CM block were retained in a distinct output scope. Its real positive-control CM request reached the chooser, but the next Continue tap failed with `unexpected_foreground_no_ui_read` before the actual input tap. | Expected 1, executed cancellation negatives 0, blocked 1. The positive control did not complete; no cancellation Back was sent. |

There was no attempt3. A subsequent read-only observation reported an unknown foreground without reading that unknown UI or injecting input. A separately recorded, exact-owned-package cleanup terminated the outstanding fixture request. That cleanup is not a successful cancellation guard. The two original 180-second ceremony and 300-second index budgets were not reset to turn either blocked attempt into a pass.

## Runtime, source and cleanup custody

The original flow has 20 pre-release stage jobs plus its independent RELEASE job. All 21 have observed terminal state, complete saved stdout/stderr and actual request/launch containers. The four additional G07 jobs—preparation, attempt2, read-only observation and owned-request cleanup—are recorded separately. All these launches recorded audit success and ran in `operator` mode; this does not establish a trusted workload task identity or attestation. Original G07 and independent attempt2 exit-1 terminal states are preserved. The RP ended as cancelled with exit code 0 and its original 104-byte ready/stopped output, rather than being inferred stopped merely from an unreachable port.

The original 33-source freeze, initial ingress, final archived files and local copies match exactly. The provider APK is the frozen r7 `b16e8291…` artifact, with the permissioned r8 fixtures and their original build receipt; r9 did not rebuild the product. The separately reviewed G07 preparation and attempt2 sources are explicitly additional QA components. Their records cannot be used to claim that the original 33-source profile passed all 18 cases.

Final cleanup restored all three recorded settings, confirmed all three owned packages absent in both installed and retained-package queries, removed the owned reverse mapping, and verified the eight tracked files, four directories and corresponding MediaStore rows absent. The release original is 16,734 bytes with SHA-256 `51d1d95ba90c416487d38d504291421b6e319df0e8a4251b56a220ae193368c4`. Root independently read those exact bytes and checked Runtime terminal states; the phone lease has ended. The final packager performed no ADB, phone query or product execution.

## Included support stays outside the 18 cases

| Evidence group | Actual scope |
| --- | --- |
| r9 host checks | Four groups of 20, 55, 13 and 14 checks: 102 total. Author originals and root's repeat at the exact integrated 33-source paths are both preserved; they are not added into 204 distinct tests. |
| Additional G07 source controls | 13 host controls for the independent preparation/attempt2 candidate; not phone passes. |
| Firefox native support | 13 CLI/installer checks and 8 real Chromium native-pipe checks. There is no Firefox browser E2E login. Native origin argv validation does not attest the OS caller. |
| New native binary Chrome regression | 26/26 actual Chrome cases, under the recorded synthetic TLS exception and `--no-sandbox` conditions. These do not contribute to the Android Passkey denominator. |
| Internal and root reviews | Original source/input reviews, M05/G11 case-specific admissions, repository integration and direct release/readback records. They are internal reviews, not an independent external security audit. |

The browser support packets retain their own omission and custody declarations, including the large public baseline source archive retained on its host rather than embedded. A rolling-build metadata observation inside root's release packet is incidental support, not a P4 test.

## Archive map and limits

`phone/original-profile.public.tar.gz` is the unchanged 1,295-member original packet. It includes the exact host-preparation packet, M05/G11 input packets, M05 internal admission, final ledger, source freeze, public phase observations and main Runtime records. `phone/independent-G07-attempt2.public.tar.gz` preserves its separate observations plus its original nested Runtime/source/control packet. `runtime/orchestration-originals.public.tar.gz` retains the actual local tool-value containers, capture/materialization calls and read-only verification. `peer/` adds the unchanged G11 admission packet; `support/` preserves all seven unchanged browser, integration and release packets. `manifest.public.json` binds every outer member and every inner archive's verified index. `summary.public.json` lists all original case statuses and all 25 principal job terminal records.

The public aggregate intentionally omits master passwords, private keys, encrypted vault/backup bytes, APK bytes, private journals and raw private UI. Fixed artifact hashes and original build/source/public observations remain. The synthetic password was entered through the actual EditText using the explicitly scoped child `adb/input` argv QA path; end-to-end production no-argv handling is not established. General websites, platform credential exchange, sharing, broad device/browser compatibility and production security are outside this result. **P4 qualified=false; production qualified=false; external security audit completed=false.**
'''

files['SUMMARY.md'] = text.encode()
files['summary.public.json'] = encoded(summary)
files['verification/original-archive-relationship-check.public.json'] = verification_raw
files['verification/build_final_aggregate.py'] = read_regular(Path(__file__))
manifest = {
    'schema':1,
    'scope':'single repository evidence entry; unchanged inner originals plus explicit derived scope',
    'inner_components':components,
    'original_phone_expected':18, 'original_phone_passed':17, 'original_phone_blocked':1,
    'independent_G07_expected':1, 'independent_G07_executed':0, 'independent_G07_blocked':1,
    'supplemental_results_merged_into_original':False,
    'p4_qualified':False, 'production_qualified':False,
    'files':[{'path':n,'bytes':len(d),'sha256':sha(d)} for n,d in sorted(files.items())],
}
files['manifest.public.json'] = encoded(manifest)
for name in ['SUMMARY.md','summary.public.json','manifest.public.json']:
    create(OUT / name, files[name])

archive_path = OUT / 'passkey-r9-final-evidence.public.tar.gz'
with archive_path.open('xb') as raw:
    os.chmod(archive_path,0o600)
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for name,data in sorted(files.items()):
                ti=tarfile.TarInfo(name)
                ti.size=len(data);ti.mode=0o600;ti.mtime=0;ti.uid=0;ti.gid=0
                tar.addfile(ti,io.BytesIO(data))
    raw.flush();os.fsync(raw.fileno())
fd=os.open(OUT,os.O_RDONLY|os.O_DIRECTORY)
try:os.fsync(fd)
finally:os.close(fd)
outer_bytes=read_regular(archive_path)
outer_check=verify_inner(outer_bytes)
receipt={
    'schema':1,'scope':'host-only aggregate construction and exact index verification',
    'archive_path':str(archive_path),'bytes':len(outer_bytes),'sha256':sha(outer_bytes),
    **outer_check,
    'inner_archives':len(components),
    'inner_regular_members':sum(c['regular_members'] for c in components),
    'inner_indexed_members_verified':sum(c['indexed_members'] for c in components),
    'summary_sha256':sha(files['summary.public.json']),
    'summary_markdown_sha256':sha(files['SUMMARY.md']),
    'build_source_sha256':sha(files['verification/build_final_aggregate.py']),
    'phone_actions':0,'network_actions':0,'new_product_executions':0,
    'old_packets_modified':False,'p4_qualified':False,
}
create(OUT/'aggregate-verification.public.json',encoded(receipt))
print(json.dumps(receipt,sort_keys=True))
