# Android Passkey r9 — final evidence scope

The original fixed r9 profile finished with **17 passed, 1 blocked (G07), 0 failed, and 0 missing out of 18**. A separately admitted G07 attempt2 finished **blocked, with its cancellation negative unexecuted**, under its own one-case denominator. This aggregate does not claim 18/18 or P4 qualification. The earlier r8 16/18 result and its three independent successful retests retain their original, separate scope.

## What actually completed

Ordinary Android SAF imported the fixed synthetic encrypted vault. The native CredentialManager completed create and get against the fixed fixture application, certificate and synthetic RP, with independent RP verification. After a verified external encrypted backup, a case-specific admitted reset cleared only the initially absent, owned provider's data. A new process restored through ordinary SAF, and a real get verified against the original public key with `sign_count=2` and authenticator flags `29` (UP, UV, BE and BS). Both M05 reset and restore Runtime launches recorded `audit_recorded=true` in this run.

The stale-backup test then used the earlier real SAF backup and naturally advanced CM/RP counters. The RP recorded `counter_rollback_or_replay` while keeping the same public key and accepted counter 2. No counter was manually edited and no third reset occurred. This is recovery on the same physical Android phone; it is not evidence of physical cross-device Passkey migration.

The four SAF guards completed with separate causal observations. In G08 a new, valid, selected URI was still unconsumed before a new picker was opened and cancelled; Write then returned `choose_backup_destination_first`, and the nonempty target digest stayed unchanged. The new picker clears the old URI: the result is not attributed exclusively to the cancel callback. G10 used a distinct, newly selected, unconsumed target; a wrong-password Write reached `wrong_key_or_corrupt` without changing its nonempty contents. That attempted Write consumed the URI. Both destination baselines were the fixed 615-byte encrypted seed prepared once for synthetic QA, not product backup exports.

## The two G07 boundaries remain visible

| Record | Observed boundary | Case outcome |
| --- | --- | --- |
| Original fixed-source G07 | G06 had ended in the exact owned decoy fixture with `TYPE_NO_CREDENTIAL`. The Home/good-only entry predicate blocked before master entry, unlock, a new CM request, either time-budget origin or any Back action. | Original G07 remains blocked and unexecuted. Its original exit-1 job and result are unchanged. |
| Separate Home preparation | Exact decoy component, APK, settled G06 result, old blocked result, ledger and RP state were checked. One ordinary provider launch reached Home and the original evidence/RP remained unchanged. No master or CM request was used. | Setup only; not a cancellation test. |
| Independent attempt2 | The same six UI/timing functions and final CM block were retained in a distinct output scope. Its real positive-control CM request reached the chooser, but the next Continue tap failed with `unexpected_foreground_no_ui_read` before the actual input tap. | Expected 1, executed cancellation negatives 0, blocked 1. The positive control did not complete; no cancellation Back was sent. |

There was no attempt3. A subsequent read-only observation reported an unknown foreground without reading that unknown UI or injecting input. A separately recorded, exact-owned-package cleanup terminated the outstanding fixture request. That cleanup is not a successful cancellation guard. The two original 180-second ceremony and 300-second index budgets were not reset to turn either blocked attempt into a pass.

## Runtime, source and cleanup custody

The original flow has 20 pre-release stage jobs plus its independent RELEASE job. All 21 have observed terminal state, complete saved stdout/stderr and actual request/launch containers. The four additional G07 jobs—preparation, attempt2, read-only observation and owned-request cleanup—are recorded separately. All these launches recorded audit success and ran in `operator` mode; this does not establish a trusted workload task identity or attestation. Original G07 and independent attempt2 exit-1 terminal states are preserved. The RP ended as cancelled with exit code 0 and its original 104-byte ready/stopped output, rather than being inferred stopped merely from an unreachable port.

The original 33-source freeze, initial ingress, final archived files and local copies match exactly. The provider APK is the frozen r7 `b16e8291…` artifact, with the permissioned r8 fixtures and their original build receipt; r9 did not rebuild the product. The separately reviewed G07 preparation and attempt2 sources are explicitly additional QA components. Their records cannot be used to claim that the original 33-source profile passed all 18 cases.

Final cleanup restored all three recorded settings, confirmed all three owned packages absent in both installed and retained-package queries, removed the owned reverse mapping, and verified the eight tracked files, four directories and corresponding MediaStore rows absent. The release original is 16,734 bytes with SHA-256 `51d1d95ba90c416487d38d504291421b6e319df0e8a4251b56a220ae193368c4`. Root independently read those exact bytes and checked Runtime terminal states; the phone lease has ended. The final packager performed no ADB, phone query or product execution.

## Included support stays outside the 18 cases

| Evidence group | Actual scope |
| --- | --- |
| r9 host checks | Four groups of 20, 55, 13 and 14 checks: 102 total. Author originals and root's repeat at the exact integrated 33-source paths are both preserved; they are not added into 204 distinct tests. |
| Additional G07 source controls | 13 host controls for the independent preparation/attempt2 candidate; not phone passes. |
| Firefox native support | 13 CLI/installer checks and 8 real Chromium native-pipe checks. There is no Firefox browser E2E login. Native origin argv validation does not attest the OS caller. |
| New native binary Chrome regression | 26/26 actual Chrome cases, under the recorded synthetic TLS exception and `--no-sandbox` conditions. These do not contribute to the Android Passkey denominator. |
| Internal and root reviews | Original source/input reviews, M05/G11 case-specific admissions, repository integration and direct release/readback records. They are internal reviews, not an independent external security audit. |

The browser support packets retain their own omission and custody declarations, including the large public baseline source archive retained on its host rather than embedded. A rolling-build metadata observation inside root's release packet is incidental support, not a P4 test.

## Archive map and limits

`phone/original-profile.public.tar.gz` is the unchanged 1,295-member original packet. It includes the exact host-preparation packet, M05/G11 input packets, M05 internal admission, final ledger, source freeze, public phase observations and main Runtime records. `phone/independent-G07-attempt2.public.tar.gz` preserves its separate observations plus its original nested Runtime/source/control packet. `runtime/orchestration-originals.public.tar.gz` retains the actual local tool-value containers, capture/materialization calls and read-only verification. `peer/` adds the unchanged G11 admission packet; `support/` preserves all seven unchanged browser, integration and release packets. `manifest.public.json` binds every outer member and every inner archive's verified index. `summary.public.json` lists all original case statuses and all 25 principal job terminal records.

The public aggregate intentionally omits master passwords, private keys, encrypted vault/backup bytes, APK bytes, private journals and raw private UI. Fixed artifact hashes and original build/source/public observations remain. The synthetic password was entered through the actual EditText using the explicitly scoped child `adb/input` argv QA path; end-to-end production no-argv handling is not established. General websites, platform credential exchange, sharing, broad device/browser compatibility and production security are outside this result. **P4 qualified=false; production qualified=false; external security audit completed=false.**
