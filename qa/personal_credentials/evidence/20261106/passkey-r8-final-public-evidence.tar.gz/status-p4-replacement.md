# Proposed STATUS.md P4 update

This draft follows the existing English document. It changes no repository
file. Apply the adjacent patch only after checking the named P4 anchors against
the then-current STATUS.md, because other phases are being edited concurrently.

The new evidence filename proposed for the top-level index is
`passkey-r8-final-public-evidence.tar.gz`. The old `55facc...` archive remains
byte-identical inside that grouping container.

## 中文核对说明

原 r8 的 18 项仍为 **16 passed / 2 failed**；G07、G10 的原失败不改写。
3 项独立补测各有独立分母，合计 **3/3**，不并入原 18 项。
原 G08 的“passed”保留，但明确其目标已由前一次 Write 消费，原观察不足以
证明清除“新选中且尚未消费”的目标；新的独立 G08 补测补足这个前置条件。

M05 恢复启动时的 `audit_recorded=false` 保留为控制平面审计缺口。
仅主机证据物化作业 `1a1b1b76f32-fc05-7a72` 的终态仍未观察；
已有文件的原字节校验不替代该作业终态。后续另一个归包作业确实成功。
恢复实测是同一设备的 OS 应用数据清空、新进程、普通 SAF 恢复后真实认证，
没有声称物理双机 Passkey 迁移。**P4 和生产资格仍为 false**。

## Proposed acceptance-matrix row

| P4: extended vault | The fixed Android native fixture completed real CredentialManager create/get, ordinary encrypted SAF backup, same-device app-data reset/new-process restore, and independent RP stale-backup rejection. The r8 original ledger remains **16 passed, 2 failed**; three separately declared supplements passed **3/3**. | Original G07/G10 failures and G08's causal limit remain recorded; M05 has a launch-audit gap. This is one synthetic native fixture and same-device recovery, not physical two-device Passkey migration. Credential exchange, sharing, device revocation and additional platforms remain unsupported. **P4 remains unqualified.** |

## Proposed replacement for the existing r8 paragraph

The r8 product delta is the fixture's normal
`CREDENTIAL_MANAGER_SET_ALLOWED_PROVIDERS` permission. All other product
source bytes and the `b16e8291` provider APK are unchanged. Build receipt
`97a6daec...` records 33 successful SDK commands and separately verifies all
three new fixture APK manifests and certificates. The r7 provider's host/DEX
evidence is reused with its original identity; it is not a new r8 host
execution. The r8 declaration retains all eighteen cases and pins the new
input/reset helpers, artifact identities and backup roles. The
[ingress packet](../../qa/personal_credentials/evidence/20261106/passkey-r8-ingress-originals.tar.gz)
preserves the new build and author host controls.

The completed r8 original ledger records **16 passed and 2 failed**, with all
eighteen cases executed and none blocked or missing. Actual Android
CredentialManager create and get responses were accepted by the independent
RP. Ordinary SAF exported and read back an encrypted backup. M05 then cleared
only the initially absent, exact-owned provider's app data under its reviewed
checkpoint, observed a new process, and restored through ordinary SAF. M06
authenticated the same credential and SPKI public key with the RP counter
advancing from 1 to 2 and restored backup flags 29. This is same-device OS
app-data reset/new-process recovery; it does not establish physical two-device
Passkey migration or direct inspection of a private store's inode.

G11 used a separately observed current recovery backup and retained the actual
older M04 ciphertext as stale input. Its separately admitted single reset and
ordinary SAF restoration produced a real CredentialManager assertion that the
RP rejected with `counter_rollback_or_replay`; the accepted key and counter
stayed unchanged. Counters advanced only through ordinary create/get operations
and RP validation. Neither side's counter was manually altered to obtain the
result. Both M05 and G11 retain their individual intent, result and completion
witness; no third reset or uncertain reset replay was performed.

Original G07 and G10 remain failed. G07's one-Back controller did not establish
the final cancellation callback within the admitted original request window.
G10 reached `choose_backup_destination_first`, because an earlier Write had
already consumed the destination, and did not test wrong-key rejection.
The original G08 report remains present with an explicit causal limitation:
its refusal also followed a previously consumed destination, so that result
alone did not prove clearing a newly selected, unconsumed destination.

Three separate one-case supplements then passed **3/3**, without changing the
original eighteen-case denominator. Fresh G07 observed the same request's
Operation Back followed by the system chooser Back, the exact cancellation
callback, unchanged RP acceptance and the original 180/300-second timing
bounds. Fresh G08 selected an unconsumed target before beginning a new picker
and cancelling; Write was refused and the nonempty target digest stayed
unchanged. Fresh G10 used a newly selected target, reached
`wrong_key_or_corrupt` and preserved that target. The 615-byte ciphertext used
to make these two targets nonempty was explicit QA fixture preparation, not a
product export. The unconsumed-target statement is their precondition; G10's
attempted Write consumes the selected URI when it begins.

G02's original Runtime job remains failed with exit 1: after the actual
wrong-password rejection and timing assertions, its create-only report writer
collided with an existing control-result filename. An independently reviewed,
read-only reconciliation supplies the case's behavior result; no phone action
was repeated. G11's auxiliary export also retains its original mistaken summary
reference and the distinct correction pointing to the actual new backup
receipt. Neither original result was rewritten.

M05's ordinary-restore launch reported `audit_recorded=false`. Later product
success and a durable terminal outcome do not repair that control-plane audit
gap. The host-only output-materialization job
`1a1b1b76f32-fc05-7a72` has no observed terminal status; its files were separately
read and hashed. The later final packet job `1a1b1c54169-fc05-7abe` completed
successfully with exit zero and durable, complete output. That separate
success does not supply the earlier job's missing terminal observation.

The [r8 final public packet](../../qa/personal_credentials/evidence/20261106/passkey-r8-final-public-evidence.tar.gz)
groups the unchanged original phone archive, its manifest/receipt/assessment,
the local integrity verification and the actual archive Runtime binding.
The original inner archive has 1,744 regular members, including originals and
explicit derived summaries. It retains all 34 tracked run invocations and
terminal observations, exact stdout/stderr bytes, 1,195 public phase records,
frozen sources, original failures and supplements. Canonical structured
metadata copies are distinguished from original source and log bytes.
The internal peer reviews remain separate from an external security review.

Final cleanup and an independent release observation verified all three
original settings, installed/retained absence of all three owned packages,
the absent owned reverse mapping and all twelve owned synthetic files, six
directories and corresponding MediaStore rows absent. The original RP emitted
its stopped message and reached terminal state before document cleanup.
All tracked phone jobs were terminal before handoff. This qualifies only the
stated synthetic native-fixture observations on the current device:
`p4_qualified=false` and `production_qualified=false` remain explicit.

## Proposed mobile-artifact row

| Passkey r7/r8 provider APK | `b16e82916330fac6909f82696089798c3ec76d7b4058fe9290e7e841b9e00459` | The unchanged r7 provider retains its separate storage build, 10 host checks and DEX evidence. Original r7 phone: 8 passed, 1 failed, 9 blocked. With the newly permissioned r8 fixtures: original 18-case ledger 16 passed/2 failed, plus three independent supplements 3/3; original G08's causal limit, M05 audit gap and unqualified P4 scope remain explicit. |
