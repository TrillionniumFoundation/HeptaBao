# P4 r8 final public evidence

This is a new grouping container. The original phone archive is retained
byte-for-byte as `original-phone-packet.tar.gz`, SHA-256
`55facc1663090f0577e75624b78c460233d2275cf1c8901f1b6be2500122e346`.
The original member manifest, build of that archive, derived assessment,
independent local download verification and actual archive Runtime binding
are separate members with their own exact SHA-256 values.

## Results and scope

The original fixed eighteen-case ledger remains 16 passed and 2 failed
(G07 and G10), with every case executed and no blocked or missing rows.
Three separately declared one-case supplements passed 3/3. They do not
replace the original failures or form a new merged denominator.

The fixed native fixture exercised actual Android CredentialManager create/get
with independent RP validation, ordinary SAF encrypted import/export, an actual
OS app-data reset followed by a new-process ordinary SAF restoration and
authentication with the same credential/public key, and rejection of a stale
backup's signature as counter_rollback_or_replay. Each of the two reset cases
had its own observed checkpoint and was executed once.

The original G08 report observed refusal after an earlier Write had already
consumed the destination. It did not isolate clearing a newly selected,
unconsumed destination. The new G08 supplement establishes that narrower
precondition and refusal without rewriting the original report.
The G07 supplement uses two ordinary Back actions in the same fresh request.
The G10 supplement reaches wrong_key_or_corrupt with a fresh, selected,
unconsumed nonempty target.

G02's original Runtime job remains failed/exit1 because the report writer
collided after the actual rejection assertions. A separate read-only
reconciliation supplies the behavior conclusion without another phone action.
G11's original auxiliary summary reference and its distinct correction remain.

The M05 restore launch reported audit_recorded=false. The successful product
outcome does not repair that audit gap. Terminal status for host-only output
materialization job 1a1b1b76f32-fc05-7a72 remains unobserved; its existing files
were independently read and hashed. The later, separate final packet job
1a1b1c54169-fc05-7abe has observed succeeded/exit0 with durable, complete output.
Neither fact relabels the former job.

## Preservation and release

The inner archive has 1,744 regular members, including original evidence and
explicit derived summaries. It retains all 34 tracked run invocations and
terminal observations, exact stdout/stderr bytes, 1,195 sanitized public phase
records, fixed sources, failed attempts, two reset inputs/results/witnesses,
independent supplements, cleanup and release. Structured metadata containers
are canonical copies of returned values, not original wire serializations.
Source strings and stdout/stderr bytes remain separately preserved.

The device release checked all three original settings; installed and retained
absence of the three owned packages; absence of the owned reverse mapping; and
absence of all twelve owned synthetic files, six directories and corresponding
MediaStore rows. The original RP emitted its stopped output and was terminal
before final document cleanup. The phone was handed back; this grouping and
local verification performed no ADB/UI/phone action.

This evidence is limited to the fixed synthetic native fixture on the observed
Android device. Same-device app-data reset/new-process recovery is not physical
two-device Passkey migration. General website support, platform credential
exchange, sharing, device revocation, additional platforms, external security
review and production qualification remain unsupported or unqualified.
P4 remains unqualified. The real-EditText QA input temporarily places only the
synthetic master in the innermost adb/input argv; this does not qualify a
production end-to-end argv-free credential path.

The wrapper manifest verifies container integrity, not independent authenticity,
platform coverage, security review, or a passing P4 phase.
