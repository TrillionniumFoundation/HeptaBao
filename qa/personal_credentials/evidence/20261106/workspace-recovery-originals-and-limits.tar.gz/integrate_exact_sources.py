from pathlib import Path
import hashlib
import json

REPO = Path('/workspace/scratch/heptabao-recovery-20261106')
ROOT = Path(__file__).resolve().parent
EXTRACTED = ROOT / 'extracted'
SOURCES = [
    (EXTRACTED/'passkey-r7-guard-backup/00-passkey_reset_provider_r7.py', 'qa/personal_credentials/passkey_reset_provider_r7.py', 'f321cb6033ac3245291805dd72123e7f732c571b785ad74b2b14307a8054f6db'),
    (EXTRACTED/'passkey-r7-guard-backup/01-passkey_input_r7.py', 'qa/personal_credentials/passkey_input_r7.py', '0ba29978acd83d7cccad6ff4d25d4ee32304c2c2584a02b74fee28be8db87f56'),
    (EXTRACTED/'passkey-r7-guard-backup/02-passkey_phases_r7_input.py', 'qa/personal_credentials/passkey_phases_r7_input.py', '3b50d89e0688e640453025c8994aa787f4f527a880062e3e1cf8538429dd8eff'),
    (EXTRACTED/'passkey-r8-ingress/passkey_input_r8.py', 'qa/personal_credentials/passkey_input_r8.py', '6107824e7021d6d3c5c8741ad93922dc750595ce4bc4942f5a30b1d20230e146'),
    (EXTRACTED/'passkey-r8-ingress/run_phases.input-r8.public.py', 'qa/personal_credentials/passkey_phases_r8_input.py', '45547627264563b447072222f7bf0371d6c00a7e99bd6480dbf926c85f236af3'),
    (EXTRACTED/'passkey-r8-ingress/passkey_phone_profile.r8.py', 'qa/personal_credentials/passkey_phone_profile_r8.py', '4b6a478f84d16c563ce25fa75bd663a0c084c5c25314529b3f1f6ef3d8d64385'),
    (EXTRACTED/'passkey-r8-ingress/passkey_reset_provider_r8.py', 'qa/personal_credentials/passkey_reset_provider_r8.py', '413a17831a115b3c9688933dfba17835ccee9323be659b58c7810fcb5d986115'),
    (EXTRACTED/'passkey-r8-source/qa/passkey_fixture_rebuild.py', 'qa/personal_credentials/passkey_fixture_rebuild.py', '9944bef782ef80575be947c2b4347fa3f14b75a75097bebf7b0897e6213bf4bc'),
    (EXTRACTED/'passkey-r8-source/source/fixture/AndroidManifest.xml', 'clients/android-passkey/fixture/AndroidManifest.xml', '280f1318abd1e2cf14bc83fda266dc75bf9058bce53e65c37d77a7041b524673'),
    (EXTRACTED/'broker-upgrade-r1-public/controller/broker_upgrade_live.49a9.py', 'qa/personal_credentials/broker_upgrade_live.py', '49a9cb4a263e0620ba5488580094e1dd9e72cad02cf445a146b822fd59673501'),
]
HA = Path('/workspace/scratch/heptabao-p0-recovery-20261106/r3/source')
for name, digest in {
    'ha_destructive.py': '403d10c594952c9b30094f42b08eb9a67cb732202d5af45c6d8adf0fe866d524',
    'ha_network_partition.py': '73bac79cc8c373c147896b43ef69119e5538c9b97c66a039c392f5b8decb88b0',
    'replay_epoch_ha.py': 'a9cfb31d1b5e0fa448118738b4fc7d6dec90b4b3134f169434b0716fd2bfe502',
    'tests/test_ha_destructive.py': '022122a9203af21f9e03e49fb38d2487f762d82508f753cd19b7073e655993b1',
    'tests/test_ha_snapshot_maintenance.py': 'dc41da8ff9372f4e2476beb75411857bc80a88e14e9a520d40fc6607ed74e807',
}.items():
    SOURCES.append((HA/name, 'qa/openbao-acceptance/'+name, digest))
prepared=[]
for source,target,digest in SOURCES:
    b=source.read_bytes()
    assert hashlib.sha256(b).hexdigest()==digest, str(source)
    prepared.append((source,target,digest,b))
rows=[]
for source,target,digest,b in prepared:
    dest=REPO/target
    if dest.exists():
        before=hashlib.sha256(dest.read_bytes()).hexdigest()
    else:
        before=None
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(b)
    assert hashlib.sha256(dest.read_bytes()).hexdigest()==digest
    rows.append({'path':target,'bytes':len(b),'sha256':digest,'source_path':str(source),'prior_sha256':before})
report={'schema':1,'scope':'byte_identical_source_recovery','base_commit':'7e77aa3f4319e9e6c8fbc6e0d200dc2cde8af7c6','files':rows}
out=ROOT/'source-recovery.public.json'
data=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode()
assert not out.exists()
out.write_bytes(data)
print(json.dumps({'restored_files':len(rows),'receipt_sha256':hashlib.sha256(data).hexdigest()}))
