from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/heptabao-recovery-20261106')
ARCHIVE = REPO/'qa/personal_credentials/evidence/20261106'
index_path = ARCHIVE/'manifest.json'
index = json.loads(index_path.read_text())

def digest(b):
    return hashlib.sha256(b).hexdigest()

def add(name, data, description):
    assert '/' not in name and len(description) <= 512
    row = {'file':name,'bytes':len(data),'sha256':digest(data),'transformation':description}
    existing = [x for x in index['entries'] if x['file']==name]
    if existing:
        assert len(existing)==1 and existing[0]==row and (ARCHIVE/name).read_bytes()==data
        return
    assert not (ARCHIVE/name).exists()
    with (ARCHIVE/name).open('xb') as f:
        f.write(data)
    index['entries'].append(row)
    print(json.dumps(row))

def bundle(files, metadata):
    assert len(files)==len(set(files))
    rows=[{'path':n,'bytes':len(b),'sha256':digest(b)} for n,b in sorted(files.items())]
    manifest=dict(metadata,files=rows)
    files=dict(files,**{'manifest.public.json':(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode()})
    out=io.BytesIO()
    with gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for n,b in sorted(files.items()):
                info=tarfile.TarInfo(n);info.size=len(b);info.mode=0o600;info.mtime=0;info.uid=0;info.gid=0
                tar.addfile(info,io.BytesIO(b))
    raw=out.getvalue()
    with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
        for m in tar.getmembers():
            assert m.isfile() and tar.extractfile(m).read()==files[m.name]
    return raw

for source,name in {
    'ha-r1-public':'ha-cleanup-r1-remote-originals.tar.gz',
    'ha-r2-public':'ha-snapshot-r2-remote-originals.tar.gz',
    'passkey-r7-phone':'passkey-r7-phone-originals.tar.gz',
    'passkey-r8-ingress':'passkey-r8-ingress-originals.tar.gz',
    'passkey-r7-guard-backup':'passkey-r7-controller-originals.tar.gz',
    'passkey-r7-review-originals':'passkey-r7-peer-review-originals.tar.gz',
    'passkey-r7-review-supplement':'passkey-r7-review-supplement-originals.tar.gz',
    'broker-upgrade-r1-public':'broker-upgrade-r1-remote-originals.tar.gz',
}.items():
    add(name,(ROOT/'packets'/(source+'.tar.gz')).read_bytes(),
        'Byte-identical original remote public packet, recovered with pinned versions, EOF, exact length and SHA-256; retained failures are not converted to passing results.')

for source,name in {
    'passkey-r7-phone/case-results.public.json':'passkey-r7-phone-cases.public.json',
    'broker-upgrade-r1-public/public/receipt.public.json':'broker-upgrade-r1.public.json',
    'ha-r2-public/review/summary.public.json':'ha-snapshot-r2-real-profiles.public.json',
}.items():
    add(name,(ROOT/'extracted'/source).read_bytes(),'Byte-identical original public result also present in the corresponding recovered remote packet; qualification scope remains as recorded.')

ci_files={p.name:p.read_bytes() for p in (ROOT/'ci').iterdir() if p.is_file()}
add('ci-2280-terminal-7e77-core-recovered-originals.tar.gz',bundle(ci_files,{
    'schema':1,'scope':'new_container_for_preserved_original_ci_records',
    'old_local_archive_recreated':False,'decoded_log_tool_strings_not_raw_github_zip':True,
    'core_receipt_original_hashes_verified':True,'full_replacement_qualified':False,
    'production_qualified':False}),
    'New container assembled after executor replacement from preserved decoded GitHub log strings and original receipt envelopes; all three 7e77 core receipt hashes match. Full 2280 failures and in-progress 7e77 observations remain distinct.')
add('ci-7e77-result.public.json',(ROOT/'ci/result.public.json').read_bytes(),
    'Reconstructed from the original GitHub job-log JSON envelope using Python JSON number parsing and original formatting; exact original SHA-256 verified.',)

loss = {
    'schema':1,'scope':'workspace_recovery_and_provenance_limits',
    'old_workspace_available':False,'restored_public_head':'7e77aa3f4319e9e6c8fbc6e0d200dc2cde8af7c6',
    'restored_public_tree':'44b5f1ae9f0c7ff1994d096c26f2456bc4a75c06',
    'restored_tree_clean_before_integration':True,'old_local_unpublished_head':'58c864340693fcf34c55a1dc5b2220a74a8028a4',
    'same_published_tree_as_old_local_head':True,'old_stdout_reconstructed':False,
    'missing_originals_are_not_replaced_by_new_test_runs':True,
    'unavailable_originals':[
        {'area':'root r7 reset-helper 49-check separate rerun','receipt_sha256':'9e6feb94d7b30019608ce895dd645307c8d03e58e5654c5af5d006a540cee7d7','indirect_reference':'passkey-r7-review-supplement-originals.tar.gz/p0_r7_review_authorship_scope.public.json','full_original_output_available':False},
        {'area':'root local HA r1/r2/r3 host-test stdout and stderr','observed_in_prior_session':True,'full_original_output_available':False},
        {'area':'p0 local independent r8 input/reset 20/55 host-test outputs','observed_in_prior_session':True,'full_original_output_available':False,'author_original_20_55_outputs_recovered':True},
        {'area':'local r9 22-member manifest and local-only supplementary review files','full_original_packet_available':False,'remote_original_report_and_release_preserved':True},
        {'area':'unpublished root-created grouping archives and 236-entry index','full_original_container_available':False,'new_containers_identified_separately':True},
    ],
    'product_or_source_qualification_granted_by_recovery':False,'production_qualified':False,
}
(ROOT/'recovery-limitations.public.json').write_text(json.dumps(loss,indent=2,sort_keys=True)+'\n')
recovery_files={p.name:p.read_bytes() for p in [ROOT/'remote-packets-recovery.public.json',ROOT/'packet-member-integrity.public.json',ROOT/'source-recovery.public.json',ROOT/'recovery-limitations.public.json',ROOT/'assemble_original_packets.py',ROOT/'integrate_exact_sources.py',Path(__file__)]}
for p in ROOT.glob('recovery_*.tool-original.json'):
    recovery_files['original-binary-read-records/'+p.name]=p.read_bytes()
add('workspace-recovery-originals-and-limits.tar.gz',bundle(recovery_files,{
    'schema':1,'scope':'new_read_only_original_recovery_validation',
    'new_source_or_product_tests_executed':False,'production_qualified':False}),
    'New recovery report with original pinned binary-read envelopes, restored source hashes, complete remote-packet member verification and explicit unavailable local-only originals. Recovery is not product qualification.')

assert len(index['entries'])<=256
index_path.write_text(json.dumps(index,indent=2)+'\n')
print(json.dumps({'indexed_files':len(index['entries']),'new_index_sha256':digest(index_path.read_bytes())}))
