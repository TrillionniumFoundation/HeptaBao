import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

ROOT = Path(__file__).resolve().parent
PACKETS = {
    'ha-r1-original': (['packet_initial_2'], '', 0),
    'ha-r1-public': (['ha_r1_first', 'ha_r1_tail'], '346e7cbd1e65149e1ae6a18c66e60653988c362d5a556c06c2cb5c41776b5de6', 88964),
    'ha-r2-public': (['packet_initial_3', 'ha_r2_tail'], '7eedfc768abe52b4f5f849a6ead1e8477e2c1a8b0b2d2d507c4749917129c9c7', 105047),
    'passkey-r7-phone': (['packet_initial_4', 'r7_65536', 'r7_131072', 'r7_196608'], '27847e9bf8d72245eaac9255fcd4703f6dec87b421f22b741bafd641d32a96dd', 203579),
    'passkey-r8-ingress': (['r8_first', 'r8_65536', 'r8_131072', 'r8_196608'], '15f917a77be26b249984b18177532eb2ee5767ba06eff8e3a8c17a71b10a7ca2', 197320),
    'passkey-r7-guard-backup': (['r7_guard_backup'], 'b5ec268c28c473abc4be2c69c36b1bb97ba0ac901f5258660e2ba539a30e8fbe', 46216),
    'passkey-r7-review-originals': (['r7_p0_review_first', 'r7_p0_review_tail'], '92839240da30becc16818011764dc2040e3932df8d63b498a4a4b7028d610cc0', 87298),
    'passkey-r7-review-supplement': (['r7_p0_supplement'], '138fb164fa9107be52afa8ffd3dab66691d82e351b9a3240fd0c92f9fbf7ff06', 3985),
    'broker-upgrade-r1-public': (['upgrade_first'], '45573d50fa424c8b79990b648c354702dffcdd5198f96ad258040af12868802e', 13803),
}
del PACKETS['ha-r1-original']

def put(path, data):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    if path.exists():
        assert path.is_file() and not path.is_symlink() and path.read_bytes() == data
    else:
        with path.open('xb') as f:
            f.write(data)

report = {'schema': 1, 'scope': 'original_remote_bytes_recovery_only',
          'product_tests_executed': False, 'production_qualified': False, 'packets': []}
for name, (keys, expected_sha, expected_size) in PACKETS.items():
    chunks = []
    offset = 0
    version = remote_path = None
    for key in keys:
        raw = json.loads((ROOT / ('recovery_' + key + '.tool-original.json')).read_text())
        item = json.loads(next(c['text'] for c in raw['content'] if c['type'] == 'text'))
        chunk = (ROOT / ('recovery_' + key + '.chunk')).read_bytes()
        assert item['offset'] == offset and item['next_offset'] == offset + len(chunk)
        assert item['size'] == expected_size
        assert hashlib.sha256(chunk).hexdigest() == item['chunk_sha256']
        if version is None:
            version, remote_path = item['version'], item['path']
        assert item['version'] == version and item['path'] == remote_path
        offset += len(chunk)
        assert item['eof'] == (offset == expected_size)
        chunks.append(chunk)
    data = b''.join(chunks)
    assert len(data) == expected_size and hashlib.sha256(data).hexdigest() == expected_sha
    put(ROOT / 'packets' / (name + '.tar.gz'), data)
    dest = ROOT / 'extracted' / name
    rows = []
    seen = set()
    total = 0
    with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as archive:
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert str(path) == member.name and member.name not in seen and len(seen) < 1024
            assert 0 <= member.size <= 16 * 1024 * 1024
            total += member.size
            assert total <= 64 * 1024 * 1024
            seen.add(member.name)
            body = archive.extractfile(member).read()
            assert len(body) == member.size
            put(dest / member.name, body)
            rows.append({'path': member.name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    report['packets'].append({'name': name, 'bytes': len(data), 'sha256': expected_sha,
                              'remote_path': remote_path, 'regular_members': len(rows), 'files': rows})
    print(json.dumps({'name': name, 'bytes': len(data), 'sha256': expected_sha,
                      'regular_members': len(rows), 'manifest_candidates': [r['path'] for r in rows if 'manifest' in r['path']]}))
put(ROOT / 'remote-packets-recovery.public.json', (json.dumps(report, indent=2, sort_keys=True) + '\n').encode())
