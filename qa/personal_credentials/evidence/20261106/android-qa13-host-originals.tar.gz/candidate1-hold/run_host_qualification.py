#!/usr/bin/env python3
"""Capture exact QA13 host controls; no phone, product build, or pass inheritance."""
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
BASELINE = ROOT / "android_live.qa12.baseline.py"
CANDIDATE = ROOT / "android_live.revision13.py"
OLD_TESTS = Path("/workspace/scratch/heptabao-recovery-20261106/qa/personal_credentials")
OUT = ROOT / sys.argv[1]
OUT.mkdir(mode=0o700)
inventory = [(ROOT / "android_return_guard_tests.py", 34),
             (OLD_TESTS / "android_popup_guard_tests.py", 46),
             (OLD_TESTS / "android_driver_guard_tests.py", 8),
             (OLD_TESTS / "android_diagnostic_guard_tests.py", 12)]


def digest(path):
    data = path.read_bytes()
    return {"path": str(path), "size": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def nodes(tree):
    return {node.name: node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))}


def write_json(path, value):
    data = (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "wb") as output:
        output.write(data); output.flush(); os.fsync(output.fileno())


paths = [BASELINE, CANDIDATE, ROOT / "qa13.changes.patch", Path(__file__).resolve(), *[row[0] for row in inventory]]
receipt = {"schema": 1, "scope": "qa13_offline_return_guards", "phone_operations": 0,
           "device_qualification": False, "product_binary_changed": False,
           "prior_phone_results_reclassified": False, "expected_test_count": 100,
           "source_before": [digest(path) for path in paths], "commands": [], "started_unix_ns": time.time_ns()}
old_tree, new_tree = ast.parse(BASELINE.read_bytes()), ast.parse(CANDIDATE.read_bytes())
old, new = nodes(old_tree), nodes(new_tree)
unchanged = ["pending_intent_metadata", "_activity_id_supported", "_activity_identity", "_activity_shape",
             "_activity_relation", "_focus_snapshot", "_window_details", "_popup_parent", "_bound_parent",
             "_top_resumed_bound", "autofill_popup_metadata", "command", "shell", "foreground", "ui", "find", "wait", "tap",
             "assert_fixture", "authentication", "authorization_status", "package_present", "package_hash",
             "restore", "validate_journal"]
unchanged += sorted(name for name in old if name in {"locked", "wrong_master", "cached", "explicit_lock", "expired", "cancelled", "background", "restarted", "wrong_package", "wrong_certificate"})
receipt["unchanged_ast_nodes"] = {name: ast.dump(old[name], include_attributes=False) == ast.dump(new[name], include_attributes=False) for name in unchanged}
old_cases = next(ast.literal_eval(node.value) for node in old_tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "EXPECTED_CASES" for target in node.targets))
new_cases = next(ast.literal_eval(node.value) for node in new_tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "EXPECTED_CASES" for target in node.targets))
receipt["case_inventory"] = {"unchanged": old_cases == new_cases, "count": len(new_cases), "unique": len(set(new_cases)) == 12}
old_compares = [ast.dump(node, include_attributes=False) for node in ast.walk(old["cancel_authentication"]) if isinstance(node, ast.Compare)]
new_compares = [ast.dump(node, include_attributes=False) for node in ast.walk(new["cancel_authentication"]) if isinstance(node, ast.Compare)]
receipt["cancel_deadline_comparisons_unchanged"] = old_compares == new_compares
receipt["back_command_source_sites"] = CANDIDATE.read_text().count('self.shell("input", "keyevent", "KEYCODE_BACK")')
receipt["new_helper_contains_no_activity_launch"] = not any(isinstance(node, ast.Constant) and node.value == "am" for name in ("_return_snapshot", "_wait_return_surface", "return_to_fixture") for node in ast.walk(new[name]))
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
for index, (test, count) in enumerate(inventory, 1):
    argv = [sys.executable, str(test), "--driver", str(CANDIDATE), "-v"]
    started = time.time_ns()
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, check=False, timeout=45)
    stdout = OUT / (str(index).zfill(2) + ".stdout")
    stderr = OUT / (str(index).zfill(2) + ".stderr")
    stdout.write_bytes(result.stdout); stderr.write_bytes(result.stderr)
    combined = (result.stdout + result.stderr).decode("utf-8", "strict")
    summaries = re.findall(r"^Ran ([0-9]+) tests? in [0-9.]+s$", combined, re.MULTILINE)
    passed = result.returncode == 0 and summaries == [str(count)] and len(re.findall(r"^OK$", combined, re.MULTILINE)) == 1
    row = {"argv": argv, "started_unix_ns": started, "finished_unix_ns": time.time_ns(),
           "exit_code": result.returncode, "expected_tests": count, "observed_summaries": summaries,
           "passed": passed, "stdout": digest(stdout), "stderr": digest(stderr)}
    receipt["commands"].append(row)
    print(json.dumps({"suite": test.name, "exit_code": result.returncode, "expected": count, "observed": summaries, "passed": passed}), flush=True)
receipt["source_after"] = [digest(path) for path in paths]
receipt["source_unchanged"] = receipt["source_before"] == receipt["source_after"]
receipt["passed"] = all(row["passed"] for row in receipt["commands"]) and receipt["source_unchanged"] and all(receipt["unchanged_ast_nodes"].values()) and receipt["case_inventory"] == {"unchanged": True, "count": 12, "unique": True} and receipt["cancel_deadline_comparisons_unchanged"] and receipt["back_command_source_sites"] == 1 and receipt["new_helper_contains_no_activity_launch"]
receipt["finished_unix_ns"] = time.time_ns()
write_json(OUT / "receipt.public.json", receipt)
print(json.dumps({"passed": receipt["passed"], "receipt": digest(OUT / "receipt.public.json")}), flush=True)
sys.exit(0 if receipt["passed"] else 1)
