#!/usr/bin/env python3
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
os.umask(0o077)
base=Path('/home/alex/heptabao-android-autofill-20261106-r1')
qa=base/'android_live.revision16.py'
build=base/'candidate9/build-receipt.json'
release=base/'release-r13.json'
output=base/'run-r14'
adb=Path('/home/alex/.local/bin/adb')
expected={
 str(qa):'195600cde56e9f3d3d62ca1d174f30300e20ffb5171ac13032bd13491f8382b1',
 str(build):'7251a0373bb364639b854cc25062c394f1e3e8297d77e4dee95d0a1affb8d281',
 str(release):'2a82dd97a1ed7e602c627d3b5fad9242f5ce8bad8131d62ad54320ba399ab654',
 str(base/'candidate9/artifact-review.json'):'a9bcacc60ebd13e1498a7ba06082db83a43b1dc44ebc2701fe48a1d2a840999e',
 str(base/'candidate9/stage.public.json'):'37a9d8d172c4188fe789109e020f8baa690fbf4964c1058c3ff1c181a395112f',
 str(base/'candidate9/source.manifest.public.json'):'6ceef7b402f8b6b6aad0cb66ef5eb220801c28a43c127e5fc449db57834f050b',
 str(base/'candidate9/public-transport/source.tar.gz'):'95cdbbd1b6a7f473fac796fdc88cb494d9b42f6e9b35fe5679584a2a2c8ebe83',
 str(base/'candidate9/apks/provider.apk'):'45bc67b20fe7dbadc61710681feaf12d65f619befe85fde801d4cb7f6ffcde9f',
 str(base/'candidate9/apks/fixture-good.apk'):'fe06a99b6b70f12e63d09a69e89030df2aff9f92d5e01be9b7d857f91abaaf51',
 str(base/'candidate9/apks/fixture-wrong-certificate.apk'):'2f49f63789ef11cf4d204b07c53f6965c353246b889c36d518987765d309fa16',
 str(base/'candidate9/apks/fixture-wrong-package.apk'):'a7de3e26169fddce148e7ad8eb2c130e1691c8961a25a558d54616033ec9d5b4'}
def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write_once(path,obj):
 data=(json.dumps(obj,sort_keys=True,indent=2)+chr(10)).encode()
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as stream: stream.write(data);stream.flush();os.fsync(stream.fileno())
 parent=os.open(Path(path).parent,os.O_RDONLY|os.O_DIRECTORY)
 try: os.fsync(parent)
 finally: os.close(parent)
 return hashlib.sha256(data).hexdigest()
try:
 if output.exists() or output.is_symlink(): raise ValueError()
 before={path:digest(path) for path in expected}
 if before!=expected: raise ValueError()
 adb_before=digest(adb)
 argv=['/usr/bin/python3','-u',str(qa),'--adb',str(adb),'--apks',str(base/'candidate9/apks'),'--build-receipt',str(build),'--master-file',str(base/'master.private'),'--output',str(output)]
 binding={'schema':1,'candidate':'android-autofill-candidate9','run':'r14','qa_revision':16,'build_source_qa_revision':15,'expected_case_count':12,'synthetic_only':True,'production_qualified':False,'credential_entry':'synthetic_only_adb_input_text_argv','device_exclusive_handoff':'autofill-r13-release-sha256-bound','argv':argv,'input_sha256':before,'adb_sha256':adb_before,'wrapper_sha256':digest(__file__),'created_unix_ns':time.time_ns()}
 binding_sha=write_once(base/'run-r14.launch.public.json',binding)
 print(json.dumps({'phase':'launch_bound','run':'r14','qa_sha256':expected[str(qa)],'binding_sha256':binding_sha}),flush=True)
 started=time.time_ns()
 proc=subprocess.run(argv,check=False)
 after={path:digest(path) for path in expected};adb_after=digest(adb)
 execution={'schema':1,'run':'r14','launch_binding_sha256':binding_sha,'started_unix_ns':started,'finished_unix_ns':time.time_ns(),'exit_code':proc.returncode,'input_sha256_before':before,'input_sha256_after':after,'inputs_unchanged':before==after,'adb_sha256_before':adb_before,'adb_sha256_after':adb_after,'adb_unchanged':adb_before==adb_after,'wrapper_sha256':digest(__file__)}
 if (output/'report.json').is_file(): execution['phone_report_sha256']=digest(output/'report.json')
 execution_sha=write_once(base/'run-r14.execution.public.json',execution)
 print(json.dumps({'phase':'execution_finished','run':'r14','exit_code':proc.returncode,'inputs_unchanged':before==after,'adb_unchanged':adb_before==adb_after,'execution_sha256':execution_sha}),flush=True)
 sys.exit(proc.returncode if before==after and adb_before==adb_after else 1)
except Exception:
 print(json.dumps({'ok':False,'error':'launch_or_execution_binding_failed','run':'r14'}),flush=True)
 sys.exit(1)
