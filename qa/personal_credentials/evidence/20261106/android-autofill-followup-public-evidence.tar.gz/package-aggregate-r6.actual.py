from pathlib import Path,PurePosixPath
import gzip,hashlib,io,json,os,re,stat,tarfile
os.umask(0o077)
c=Path(__file__).resolve().parent
r=c.parent
out=c/'aggregate-r6-public'
out.mkdir(mode=0o700)
sha=lambda b:hashlib.sha256(b).hexdigest()
def encode(v):return (json.dumps(v,sort_keys=True,indent=2)+'\n').encode()
def write(path,b):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def read(path,pin):
 s=path.lstat();assert stat.S_ISREG(s.st_mode) and s.st_nlink==1
 b=path.read_bytes();assert len(b)==s.st_size and sha(b)==pin
 return b
def pairs(values):
 result={}
 for k,v in values:assert k not in result;result[k]=v
 return result
def json_value(b):return json.loads(b.decode(),object_pairs_hook=pairs)
def safe(name):
 path=PurePosixPath(name)
 return bool(name) and not path.is_absolute() and '..' not in path.parts and str(path)==name
def recursive_verify(data,label,rows,external=None,depth=0):
 assert depth<24 and len(data)<=16*1024*1024
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tf:
  members=tf.getmembers();assert len(members)<=5000
  files={};total=0
  for item in members:
   assert item.isfile() and safe(item.name) and item.name not in files and 0<=item.size<=32*1024*1024
   total+=item.size;assert total<=128*1024*1024
   b=tf.extractfile(item).read();assert len(b)==item.size;files[item.name]=b
  assert len({x.casefold() for x in files})==len(files)
 selected=next((name for name in ['manifest.json','manifest.public.json','MANIFEST.public.json','freeze.public.json'] if name in files),None)
 if selected is not None:
  manifest=json_value(files[selected]);entries=manifest.get('entries',manifest.get('files'))
  assert isinstance(entries,list) and entries
  expected=set()
  for entry in entries:
   assert isinstance(entry,dict) and {'path','bytes','sha256'}<=set(entry)
   name=entry['path'];assert isinstance(name,str) and safe(name) and name not in expected and name in files
   assert type(entry['bytes']) is int and entry['bytes']==len(files[name]) and sha(files[name])==entry['sha256']
   assert re.fullmatch('[0-9a-f]{64}',entry['sha256'])
   expected.add(name)
  assert expected==set(files)-{selected}
  mode='complete_inline_manifest';manifest_sha=sha(files[selected]);indexed=len(entries)
 else:
  assert external is not None
  mapping=json_value(external)['files'];assert isinstance(mapping,dict) and set(mapping)==set(files)
  for name,pin in mapping.items():assert isinstance(pin,str) and re.fullmatch('[0-9a-f]{64}',pin) and sha(files[name])==pin
  mode='complete_parent_sidecar_source_manifest';manifest_sha=sha(external);indexed=len(mapping)
 rows.append({'archive':label,'depth':depth,'archive_bytes':len(data),'archive_sha256':sha(data),'regular_members':len(files),'indexed_members':indexed,'manifest_mode':mode,'manifest_sha256':manifest_sha,'verified_member_bytes':total})
 assert len(rows)<=128
 for name,b in files.items():
  if name.endswith(('.tar.gz','.tgz')):
   sidecar=name[:-7]+'.manifest.public.json' if name.endswith('.tar.gz') else name[:-4]+'.manifest.public.json'
   recursive_verify(b,label+'!'+name,rows,files.get(sidecar),depth+1)

old=read(r/'android-followup-aggregate-r5.public.tar.gz','0d520688d9aecaa2ef203842bc88527d0708a7a7f59193209fd0adc93ca2af1e')
assert (r/'android-followup.public.tar.gz').read_bytes()==old
phone=read(c/'phone-r17-public/c10-qa19-r17-phone.public.tar.gz','9a2cfc0c7b2784ae29a7f762106afd9d96825272127e2556f3a36ad4d560fa7d')
root=read(Path('/workspace/scratch/heptabao-root-recovery-20261106-r2/android-r17-root-evidence-r1.public.tar.gz'),'a0f399e160dd64fc37f445f34aedcf264f72651311895f9890874f1762050c72')
write(out/'root-evidence.original.tar.gz',root)
rows=[]
for label,data in [('history/aggregate-r5.original.tar.gz',old),('candidate10/phone-r17.original.tar.gz',phone),('root/qa19-and-r17-independent-originals.tar.gz',root)]:recursive_verify(data,label,rows)
audit={'schema':1,'scope':'archive_byte_integrity_only_not_qualification_or_external_security_review','passed':True,'archives':len(rows),'regular_member_occurrences':sum(v['regular_members'] for v in rows),'indexed_member_occurrences':sum(v['indexed_members'] for v in rows),'complete_manifest_or_parent_sidecar_for_every_archive':True,'rows':rows}
audit_raw=encode(audit);write(out/'input-layers-integrity.public.json',audit_raw)
phone_summary=json_value((c/'phone-r17-public/summary.public.json').read_bytes())
summary={'schema':1,'profile':'android-autofill-followup-history-with-c10-qa19-r17','aggregate_revision':6,'current_phone':phone_summary,'prior_r5_bytes':len(old),'prior_r5_sha256':sha(old),'phone_packet_bytes':len(phone),'phone_packet_sha256':sha(phone),'root_packet_bytes':len(root),'root_packet_sha256':sha(root),'root_observations_are_not_additional_device_runs':True,'all_prior_failed_profiles_preserved_as_exact_nested_bytes':True,'r16_remains':{'result':'failed','passed':6,'expected':12,'exact_subcondition':'unknown'},'current_phone_qualification_only':'fixed_c10_QA19_Android16_Motorola_native_synthetic_fixture_12_case_profile','production_qualified':False,'new_prebinding_popup_device_events':0,'new_prebinding_path_host_controls_only':True,'device_lease_released':True,'no_additional_device_operations':True}
payload={'history/aggregate-r5.original.tar.gz':old,'candidate10/phone-r17.original.tar.gz':phone,'root/qa19-and-r17-independent-originals.tar.gz':root,'root/input-layers-integrity.public.json':audit_raw,'candidate10/r17-offsite-write.original.json':(c/'phone-r17-public/offsite-write.tool-original.json').read_bytes(),'package-aggregate-r6.actual.py':Path(__file__).read_bytes(),'summary.public.json':encode(summary)}
manifest={'schema':1,'scope':'android-followup-aggregate-r6','entries':[{'path':name,'bytes':len(b),'sha256':sha(b)} for name,b in sorted(payload.items())]}
manifest_raw=encode(manifest);allfiles={**payload,'manifest.json':manifest_raw}
target=r/'android-followup-aggregate-r6.public.tar.gz'
with target.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for name,b in sorted(allfiles.items()):
    assert safe(name)
    item=tarfile.TarInfo(name);item.size=len(b);item.mode=0o600;tf.addfile(item,io.BytesIO(b))
 f.flush();os.fsync(f.fileno())
final_data=target.read_bytes();final_rows=[];recursive_verify(final_data,target.name,final_rows)
assert len(final_rows)==len(rows)+1
final_audit={'schema':1,'scope':'recursive_archive_integrity_only','passed':True,'archive_sha256':sha(final_data),'archives':len(final_rows),'regular_member_occurrences':sum(x['regular_members'] for x in final_rows),'indexed_member_occurrences':sum(x['indexed_members'] for x in final_rows),'rows':final_rows}
write(out/'final-recursive-integrity.public.json',encode(final_audit))
record={'schema':1,'path':str(target),'bytes':len(final_data),'sha256':sha(final_data),'regular_members':len(allfiles),'indexed_originals':len(payload),'manifest_sha256':sha(manifest_raw),'recursive_archives':len(final_rows),'recursive_regular_occurrences':sum(x['regular_members'] for x in final_rows),'recursive_indexed_occurrences':sum(x['indexed_members'] for x in final_rows)}
write(r/'android-followup-aggregate-r6.summary.public.json',encode(summary));write(r/'android-followup-aggregate-r6.packet.public.json',encode(record))
temp=r/'android-followup.public.tar.gz.new-r6';write(temp,final_data);os.replace(temp,r/'android-followup.public.tar.gz')
fd=os.open(r,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
print(json.dumps(record,sort_keys=True))
