#!/usr/bin/env python3
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
c9 = root / "android-c9-candidate"
qa16 = root / "android-qa16-candidate"
records = {}
sha = lambda data: hashlib.sha256(data).hexdigest()
def add(name, source, expected=None):
    data = source.read_bytes()
    if expected is not None: assert sha(data) == expected
    assert name not in records
    records[name] = data

add("candidate-c9-and-r13.public-originals.tar.gz", c9 / "android-c9-r13.public-originals.tar.gz",
    "d3b7cd2285ab1baf81824e223d8cb6c64686cd5a3590188c7b5f359ef6ab2ea2")
add("qa16/qa16.public-originals.tar.gz", qa16 / "qa16.public-originals.tar.gz",
    "42053a50999055acf97e5a62c4dad23ddcaa2f7ba4bca2e32eaace238c401f66")
add("qa16/peer-review.original.json", qa16 / "peer/REVIEW.original.json",
    "680c95910fb156ff1330ba05781ea1d850af7bbb3f56ceb7522483e8e9e3d96c")
add("qa16/integration-source-manifest.public.json", qa16 / "integration-source-manifest.public.json",
    "6f0e49e6295fa2c64b1c5d23d66911602f31d1d63a77d4833ed24d13be9fd453")
for path in sorted((qa16 / "phone-r14").iterdir()):
    if path.is_file(): add("phone-r14/" + path.name, path)
root_observations = Path("/workspace/scratch/heptabao-root-recovery-20261106-r2/android-qa16-integration")
for name in ['c9-r13-packet-integrity.public.json', 'ci-command.stderr.original', 'ci-command.stdout.original', 'ci-wiring.public.json', 'integration-source-manifest.public.json', 'integration.public.json', 'peer-review.original.json', 'r14-read-first.original.json', 'r14-release-binary-read.original.json', 'r14-release-read.original.json', 'r14-release-status.original.json', 'r14-release.original.json', 'r14-release.stderr.original', 'r14-release.stdout.original', 'r14-report-read-first.original.json', 'r14-report.original.json', 'r14-root-readback-review.public.json', 'r14-status-first.original.json', 'r14.stderr.original', 'r14.stdout.original']:
    add("root-observations/" + name, root_observations / name)
add("packer.actual.py", Path(__file__))
profiles = []
for name, directory in [("r13", c9 / "phone-r13"), ("r14", qa16 / "phone-r14")]:
    report_raw = (directory / "report.original.json").read_bytes()
    release_raw = (directory / "release.original.json").read_bytes()
    report, release = json.loads(report_raw), json.loads(release_raw)
    assert report["restoration"] == release["restoration"] == "restored_original"
    assert release["current_setting_sha256"] == release["original_setting_sha256"]
    assert len(release["packages"]) == 3 and all(v == {"installed_absent": True, "retained_record_absent": True, "query_succeeded": True} for v in release["packages"].values())
    profiles.append({"run": name, "qa_revision": 15 if name == "r13" else 16,
        "passed": report["passed"], "checks_passed": report["checks_passed"], "expected_count": report["expected_count"],
        "current_case": report["current_case"], "error": report["error"], "missing_cases": report["missing_cases"],
        "report_sha256": sha(report_raw), "release_sha256": sha(release_raw), "restoration": release["restoration"],
        "device_settings_and_owned_packages_restored": True})
summary = {"schema": 1, "aggregate_revision": 2, "scope": "Android Autofill c9 request ownership and QA16 follow-up originals",
    "c9_author_host_checks": 24, "c9_paired_peer_controls": {"c8_passed": 4, "c8_failed": 4, "c9_passed": 8},
    "c9_sdk_commands": 50, "c9_rust_java_interop_checks": 12, "c9_static_artifact_checks": 12,
    "qa16_author_host_checks": {"new_cache": 24, "existing_return": 38, "existing_diagnostic": 14, "total": 76},
    "phone_profiles": profiles, "phone_results_are_not_merged": True, "full_twelve_case_phone_qualified": False,
    "synthetic_only": True, "production_qualified": False,
    "next_work": "QA17 will address the separately observed delayed locked popup in the existing fixture-return observer; no next run is included here.",
    "exclusions": ["Private master/recovery credentials, keystores, generated fixture config, APK payloads, and raw UI/log buffers are not included.",
                   "c8/r12 history is already archived separately by root and is not duplicated.",
                   "Host stubs, source reviews, APK metadata and transfer hashes do not confer phone or production qualification."]}
records["summary.public.json"] = (json.dumps(summary, sort_keys=True, indent=2) + "\n").encode()
manifest = {"schema": 1, "entries": [{"path": name, "bytes": len(data), "sha256": sha(data)} for name, data in sorted(records.items())]}
records["manifest.public.json"] = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
output = root / "android-followup.pending-r2.public.tar.gz"
with output.open("xb") as raw:
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as compressed:
        with tarfile.open(mode="w", fileobj=compressed) as archive:
            for name, data in sorted(records.items()):
                info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o600; info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
data = output.read_bytes()
current = root / "android-followup.public.tar.gz"
assert sha(current.read_bytes()) == "729e2b81172e7105a714ff66c3bf4f2b884f84409851bbc6e713848a971b9076"
output.replace(current)
output = current
history = root / "android-followup-aggregate-r2.public.tar.gz"
with history.open("xb") as stream: stream.write(data)
(root / "android-followup-summary.public.json").write_bytes(records["summary.public.json"])
(root / "android-followup-manifest.public.json").write_bytes(records["manifest.public.json"])
print(json.dumps({"path": str(output), "bytes": len(data), "sha256": sha(data), "members": len(records),
                  "manifest_sha256": sha(records["manifest.public.json"]), "summary_sha256": sha(records["summary.public.json"])}))
