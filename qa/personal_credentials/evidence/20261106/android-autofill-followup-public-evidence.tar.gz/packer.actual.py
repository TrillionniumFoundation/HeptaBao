#!/usr/bin/env python3
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent
qa = root / "android-qa17-candidate2"
sha = lambda b: hashlib.sha256(b).hexdigest()
records = {}
def add(name, path, expected=None):
    b = path.read_bytes()
    if expected is not None: assert sha(b) == expected
    assert name not in records
    records[name] = b

prior = root / "android-followup-aggregate-r2.public.tar.gz"
add("prior-aggregate-r2.public.tar.gz", prior, "55d4ae9e35db36e834c0f9aad7f3d73ca709f8698bd8d82ba688a8b70fe8b07d")
with tarfile.open(fileobj=io.BytesIO(prior.read_bytes()), mode="r:gz") as archive:
    members = archive.getmembers()
    assert all(m.isfile() for m in members) and len({m.name for m in members}) == len(members)
    manifest = json.loads(archive.extractfile("manifest.public.json").read())
    assert len(members) == len(manifest["entries"]) + 1
    for row in manifest["entries"]:
        b = archive.extractfile(row["path"]).read()
        assert len(b) == row["bytes"] and sha(b) == row["sha256"]
    prior_summary = json.loads(archive.extractfile("summary.public.json").read())
add("qa17/qa17-candidate2.public-originals.tar.gz", qa / "qa17-candidate2.public-originals.tar.gz",
    "4b8d694f19abd7740184ebe15236af6683086739398b18294eaccaaca7f6ab24")
add("qa17/peer-review.original.json", qa / "peer/REVIEW.original.json",
    "04c573f845f1c6e5fc74d9b2e9bdacaf8da6b2527b8bbc6580ac08c0d7a8e274")
add("qa17/integration-source-manifest.public.json", qa / "integration-source-manifest.public.json",
    "e978d0e582e84f549975d4f20dfc9e34f8733c4cb7069188db89f7d8bc55eea8")
for name in ["offsite-write.request.json", "offsite-write.tool-original.json"]:
    add("qa17/" + name, qa / name)
for path in sorted((qa / "phone-r15").iterdir()):
    if path.is_file(): add("phone-r15/" + path.name, path)
observations = Path("/workspace/scratch/heptabao-root-recovery-20261106-r2/android-qa17-integration")
for path in sorted(observations.iterdir()):
    assert path.is_file() and not path.is_symlink()
    add("root-qa17-observations/" + path.name, path)
add("packer.actual.py", Path(__file__))
report = json.loads(records["phone-r15/report.original.json"])
release = json.loads(records["phone-r15/release.original.json"])
execution = json.loads(records["phone-r15/execution.original.json"])
assert sha(records["phone-r15/report.original.json"]) == "50c5f796a474721437b058457dc8247fe760f30f9bf55e6677a92f8e046570dc"
assert sha(records["phone-r15/release.original.json"]) == "6c313c0ae8aa36d4ed063ee1780166878d0a16c1a8c66b8e70ed7aa5e0817bca"
assert report["checks_passed"] == 7 and report["expected_count"] == 12 and not report["passed"]
assert execution["inputs_unchanged"] and execution["adb_unchanged"] and execution["exit_code"] == 1
assert release["restoration"] == "restored_original" and release["current_setting_sha256"] == release["original_setting_sha256"]
assert len(release["packages"]) == 3 and all(v == {"installed_absent": True, "retained_record_absent": True, "query_succeeded": True} for v in release["packages"].values())
profiles = prior_summary["phone_profiles"] + [{"run": "r15", "qa_revision": 17, "passed": False,
    "checks_passed": 7, "expected_count": 12, "passed_case_names": [c["name"] for c in report["cases"] if c["passed"]],
    "current_case": report["current_case"], "error": report["error"], "missing_cases": report["missing_cases"],
    "report_sha256": sha(records["phone-r15/report.original.json"]), "release_sha256": sha(records["phone-r15/release.original.json"]),
    "restoration": release["restoration"], "device_settings_and_owned_packages_restored": True}]
summary = {"schema": 1, "aggregate_revision": 3,
    "scope": "Android Autofill c9 with QA15/r13, QA16/r14 and QA17/r15 originals; all phone profiles retain failures",
    "prior_aggregate_bytes_preserved": True, "prior_aggregate_sha256": sha(prior.read_bytes()),
    "qa17_author_host_checks": {"new_late_popup": 16, "existing_cache": 24, "existing_return": 38, "existing_diagnostic": 14, "total": 92},
    "qa17_peer_review_is_readonly_not_test_rerun": True, "phone_profiles": profiles,
    "phone_results_are_not_merged": True, "full_twelve_case_phone_qualified": False,
    "cancelled_authorization_case_qualified": False, "r15_global_diagnostic_decision": report["failure_context"]["provider_decision"],
    "synthetic_only": True, "production_qualified": False,
    "next_work": "Host-only design of bounded request/action-linked cancellation observation; no c10 build or phone result is included.",
    "exclusions": ["No private master/recovery, keystore, generated fixture secrets, APK payloads, raw UI trees or unrestricted logs.",
                   "The r15 fixed-code buffer and global prior decision are diagnostic, not retroactive proof of the failed cancellation case.",
                   "The physical phone was fully restored and transferred by root to the separate Passkey task after r15."]}
records["summary.public.json"] = (json.dumps(summary, sort_keys=True, indent=2) + "\n").encode()
manifest = {"schema": 1, "entries": [{"path": n, "bytes": len(b), "sha256": sha(b)} for n, b in sorted(records.items())]}
records["manifest.public.json"] = (json.dumps(manifest, sort_keys=True, indent=2) + "\n").encode()
current = root / "android-followup.public.tar.gz"
assert sha(current.read_bytes()) == "55d4ae9e35db36e834c0f9aad7f3d73ca709f8698bd8d82ba688a8b70fe8b07d"
pending = root / "android-followup.pending-r3.public.tar.gz"
with pending.open("xb") as raw:
    with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0) as gz:
        with tarfile.open(mode="w", fileobj=gz) as archive:
            for name, b in sorted(records.items()):
                info = tarfile.TarInfo(name); info.size = len(b); info.mode = 0o600; info.mtime = 0
                archive.addfile(info, io.BytesIO(b))
data = pending.read_bytes()
with (root / "android-followup-aggregate-r3.public.tar.gz").open("xb") as stream: stream.write(data)
pending.replace(current)
(root / "android-followup-summary.public.json").write_bytes(records["summary.public.json"])
(root / "android-followup-manifest.public.json").write_bytes(records["manifest.public.json"])
print(json.dumps({"path": str(current), "bytes": len(data), "sha256": sha(data), "members": len(records),
                  "manifest_sha256": sha(records["manifest.public.json"]), "summary_sha256": sha(records["summary.public.json"])}))
