# Mac broker bounded-read repair

The original frozen c447536 Mac broker passed 4 of its 13 tests. Per-stage
Rust diagnostics observed EINVAL at a timeout update after a successful header
read; Python could consume the queued reply. A controlled TCP comparison also
observed EINVAL with an unread request body at peer close, while draining the
body allowed the original read loop to finish. These are diagnostic observations,
not added product acceptance tests. The first r2 diagnostic supplied issue
arguments in the wrong order and remains diagnostic_incomplete/invalid_ttl.

The first IPC-only patch passed 16/19, retaining three failed HTTP cases.
The final patch uses nonblocking recv plus poll under the original shared
deadline for IPC and the existing five-second HTTP status-line budget. It
preserves EOF refusal, bounded frames/status lines, exact authorization,
revocation and unknown-outcome fencing, without changing socket blocking mode
or ignoring EINVAL. The original thirteen tests and six real Unix-socket
regressions passed 19/19 on macOS arm64 with Rust 1.98.0. Formatting, strict
Clippy, offline locked builds and the normal dependency graph passed.

The final source overlay is exactly three files over unchanged c447536 source:
Cargo.toml 0f281abd2fb8ee3d37250a5d7d93bba92aa9089b0e49732a7bdbee8ba5b17ad6;
lib.rs 3617799f6de0368fa3b4b4c1343510fe9d202ee3a31fc0e067eb312c40732001;
frame_read_tests.rs 2a203ee7ca0e4c8f9b878abb0727374a57e3f977dc3a09e1d8cad5ed3a5b9fc7.
Final Mac CLI SHA-256: efa4b1f9394f3a2afc8d63d3812e9e8997b6809c16feb34dc168519d58e5b466.

The unchanged 135-member inner packet preserves fixed original sources,
receipts and allowlisted complete textual command outputs. It explicitly
excludes compiled executables, private owner state and duplicate git archive
stdout source tar files. This outer packet adds actual requests, exact stdin
and original tool response text for eight jobs, plus root integrity/binding
checks. No test is rerun by packaging. Request objects are structured copies;
original launch/status/read JSON strings are retained separately.

Linux 19/19 is recorded in its own independent packet. This Mac result does not
qualify Mac browser integration, Linux-only native backpressure, attested
Runtime identities, arbitrary external APIs or production deployment. Earlier
4/13 and 16/19 failed profiles remain unchanged.
