import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tarfile
import time

os.umask(0o077)
base = Path('/home/alex/heptabao-android-autofill-20261106-r1')
archive = base / 'candidate6-public-transport.tar.gz'
output = base / 'candidate6'
sha = lambda data: hashlib.sha256(data).hexdigest()
expected_packet = '0eef5193b12b8cae9716b21f4050fb40801a10abfb7a603089f49b5dba0331cd'
expected_manifest = '345d86b55ba90e2085881fe9449a03b2e58f24f5d4b5c431ced81c5ab81f67e7'


def read_file(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        st = os.fstat(stream.fileno())
        assert stat.S_ISREG(st.st_mode) and st.st_nlink == 1
        return stream.read()


def write_file(path, data):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data); stream.flush(); os.fsync(stream.fileno())


try:
    st = base.lstat()
    assert stat.S_ISDIR(st.st_mode) and st.st_uid == os.getuid() and stat.S_IMODE(st.st_mode) == 0o700
    packet = read_file(archive); assert sha(packet) == expected_packet
    output.mkdir(mode=0o700, exist_ok=False)
    payload = output / 'public-transport'; payload.mkdir(mode=0o700)
    with tarfile.open(archive, 'r:gz') as stream:
        members = stream.getmembers()
        assert len(members) == 23 and len({member.name for member in members}) == 23
        raw_manifest = stream.extractfile('transport.manifest.public.json').read()
        assert sha(raw_manifest) == expected_manifest
        manifest = json.loads(raw_manifest)
        assert set(manifest['members']) | {'transport.manifest.public.json'} == {member.name for member in members}
        for member in members:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            data = stream.extractfile(member).read()
            if member.name != 'transport.manifest.public.json':
                assert sha(data) == manifest['members'][member.name]['sha256'] and len(data) == manifest['members'][member.name]['bytes']
            write_file(payload / path, data)
    build = json.loads(read_file(payload / 'build-receipt.json'))
    assert sha(read_file(payload / 'build-receipt.json')) == '327060e7d1a5bb5edd3634307a448d9e87c3cb578a3a2b5e09cc1b256760a33e'
    assert sha(read_file(payload / 'artifact-review.json')) == '9ef1698dfe6deafb77cd495fa48039652e61303968232da90b899c4170d4a148'
    apks = output / 'apks'; apks.mkdir(mode=0o700)
    for name in ('fixture-good', 'fixture-wrong-certificate', 'fixture-wrong-package'):
        write_file(apks / (name + '.apk'), read_file(payload / 'apks' / (name + '.apk')))
    old_path = base / 'candidate5/apks/provider.apk'
    old = read_file(old_path)
    assert sha(old) == manifest['provider_base_sha256']
    write_file(apks / 'provider.apk', old)
    commands = []
    patch = payload / 'provider-c5-to-c6.patch'
    for check in (True, False):
        argv = ['/usr/bin/git', 'apply', '--binary', '-p2'] + (['--check'] if check else []) + [str(patch)]
        started = time.time_ns()
        proc = subprocess.run(argv, cwd=apks, capture_output=True, check=False, timeout=90)
        commands.append({'argv': argv, 'cwd': str(apks), 'exit_code': proc.returncode, 'started_unix_ns': started, 'finished_unix_ns': time.time_ns(), 'stdout_sha256': sha(proc.stdout), 'stderr_sha256': sha(proc.stderr)})
        assert proc.returncode == 0
    hashes = {name: sha(read_file(apks / (name + '.apk'))) for name in build['artifacts']}
    assert hashes == {name: row['sha256'] for name, row in build['artifacts'].items()}
    assert hashes['provider'] == manifest['provider_target_sha256']
    assert sha(read_file(old_path)) == manifest['provider_base_sha256']
    for name in ('build-receipt.json', 'artifact-review.json', 'source.manifest.public.json'):
        write_file(output / name, read_file(payload / name))
    result = {'schema': 1, 'purpose': 'candidate6_private_host_staging_no_device_operations', 'wrapper_sha256': sha(read_file(Path(__file__))), 'packet_sha256': sha(packet), 'transport_manifest_sha256': sha(raw_manifest), 'public_members_verified': 23, 'commands': commands, 'apk_sha256': hashes, 'base_apk_unchanged': True, 'source_archive_sha256': manifest['members']['source.tar.gz']['sha256'], 'build_receipt_sha256': sha(read_file(output / 'build-receipt.json')), 'artifact_review_sha256': sha(read_file(output / 'artifact-review.json')), 'adb_calls': 0, 'production_qualified': False, 'finished_unix_ns': time.time_ns()}
    data = (json.dumps(result, sort_keys=True, indent=2) + chr(10)).encode()
    write_file(output / 'stage.public.json', data)
    for directory in (apks, output, base):
        fd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(fd)
        finally: os.close(fd)
    print(json.dumps({'ok': True, 'stage_receipt_sha256': sha(data), 'apk_sha256': hashes, 'adb_calls': 0}, sort_keys=True))
except Exception:
    print(json.dumps({'ok': False, 'error': 'candidate6_host_staging_failed', 'adb_calls': 0}, sort_keys=True))
    raise SystemExit(1)
