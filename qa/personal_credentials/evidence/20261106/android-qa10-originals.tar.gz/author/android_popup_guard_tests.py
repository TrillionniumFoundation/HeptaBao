#!/usr/bin/env python3
"""Offline falsification tests for QA10's narrow system Autofill window contract.

Inputs below are synthetic upstream-format metadata, not device observations.
These tests never invoke ADB, install packages, or confer phone qualification.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import time
import unittest
import xml.etree.ElementTree as ET


parser = argparse.ArgumentParser()
parser.add_argument("--driver", type=Path, default=Path(__file__).with_name("android_live.py"))
args, remaining = parser.parse_known_args()
spec = importlib.util.spec_from_file_location("android_popup_candidate", args.driver)
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
PACKAGE = driver.GOOD
COMPONENT = PACKAGE + "/" + driver.ACTIVITY
ACTIVITY = "ActivityRecord{ca123 u0 " + COMPONENT + " t42}"


def focus_text(title="Autofill UI", window="abc12", activity=ACTIVITY, top=0):
    return ("WINDOW MANAGER DISPLAY CONTENTS (dumpsys window displays)\n"
            "  Display: mDisplayId=0\n"
            f"    mCurrentFocus=Window{{{window} u0 {title}}}\n"
            f"    mFocusedApp={activity}\n"
            "WINDOW MANAGER WINDOWS (dumpsys window windows)\n"
            f"  mTopFocusedDisplayId={top}\n")


def window_text(window, title, owner, package, kind, parent=None):
    lines = ["WINDOW MANAGER WINDOWS (dumpsys window windows)",
             f"  Window #0 Window{{{window} u0 {title}}}:",
             "    mDisplayId=0 taskId=42 mSession=Session{ignored} mClient=android.os.BinderProxy@ignored",
             f"    mOwnerUid={owner} showForAllUsers=false package={package} appop=NONE",
             f"    mAttrs={{(0,0)(matchxwrap) ty={kind} fmt=TRANSLUCENT}}",
             f"    mToken={ACTIVITY}", f"    mActivityRecord={ACTIVITY}",
             "    isOnScreen=true", "    isVisible=true"]
    if parent:
        lines.append(f"    mParentWindow=Window{{{parent} u0 {COMPONENT}}} mLayoutAttached=true")
    lines += ["  mGlobalConfiguration=unrelated_omitted", "  mTopFocusedDisplayId=0"]
    return "\n".join(lines) + "\n"


POPUP = window_text("abc12", "Autofill UI", 1000, "android", "APPLICATION_ABOVE_SUB_PANEL", "def34")
PARENT = window_text("def34", COMPONENT, 10432, PACKAGE, "BASE_APPLICATION")
ACTIVITIES = ("ACTIVITY MANAGER ACTIVITIES (dumpsys activity activities)\n"
              "Display #0 (activities from top to bottom):\n"
              "      CLIENT: synthetic_client_data_must_not_survive\n"
              f"  ResumedActivity: {ACTIVITY}\n")


class PopupGuards(unittest.TestCase):
    def setUp(self):
        self.focus = driver._focus_snapshot(focus_text())
        self.popup = driver._window_details(POPUP, "abc12")
        self.parent = driver._window_details(PARENT, "def34")

    def evaluate(self, focus=None, popup=None, parent=None, activities=None, final=None):
        return driver.autofill_popup_metadata(focus or self.focus, popup or self.popup,
                                             parent or self.parent, activities or ACTIVITIES,
                                             final or self.focus, PACKAGE)

    def rejected(self, **values):
        with self.assertRaises(driver.FocusUnavailable):
            self.evaluate(**values)

    def test_complete_system_parent_resumed_chain(self):
        result = self.evaluate()
        self.assertTrue(result["available"])
        self.assertEqual(result["classification"], "bound_system_autofill_popup")

    def test_title_alone_never_authorizes(self):
        with self.assertRaises(driver.FocusUnavailable):
            driver._window_details("Window{abc12 u0 Autofill UI}", "abc12")

    def test_non_system_uid_rejected(self):
        self.rejected(popup={**self.popup, "owner": 10432})

    def test_non_android_package_rejected(self):
        self.rejected(popup={**self.popup, "package": PACKAGE})

    def test_fullscreen_or_overlay_type_rejected(self):
        for kind in ("SYSTEM_DIALOG", "2008", "APPLICATION_OVERLAY", "2038", "1000"):
            with self.subTest(kind=kind):
                self.rejected(popup={**self.popup, "type": kind})

    def test_nondefault_or_invisible_popup_rejected(self):
        for field, value in (("display", 1), ("visible", False), ("onscreen", False)):
            with self.subTest(field=field):
                self.rejected(popup={**self.popup, field: value})

    def test_parent_component_or_attachment_rejected(self):
        for parent in (None, ("def34", "1", COMPONENT, "true"),
                       ("def34", "0", driver.DECOY + "/" + driver.ACTIVITY, "true"),
                       ("def34", "0", COMPONENT, "false")):
            with self.subTest(parent=parent):
                self.rejected(popup={**self.popup, "parent": parent})

    def test_popup_activity_token_must_match_focused_app(self):
        for field in ("token", "activity"):
            with self.subTest(field=field):
                self.rejected(popup={**self.popup, field: ACTIVITY.replace("ca123", "ca124")})

    def test_parent_activity_token_must_match_popup(self):
        for field in ("token", "activity"):
            with self.subTest(field=field):
                self.rejected(parent={**self.parent, field: ACTIVITY.replace("ca123", "ca124")})

    def test_parent_window_identity_and_owner(self):
        for field, value in (("window", "def35"), ("package", driver.DECOY),
                             ("title", "unrelated"), ("owner", 1000), ("type", "APPLICATION_OVERLAY")):
            with self.subTest(field=field):
                self.rejected(parent={**self.parent, field: value})

    def test_parent_task_display_and_visibility(self):
        for field, value in (("task", 43), ("display", 1), ("visible", False), ("onscreen", False)):
            with self.subTest(field=field):
                self.rejected(parent={**self.parent, field: value})

    def test_nondefault_top_display(self):
        with self.assertRaises(driver.FocusUnavailable):
            driver._focus_snapshot(focus_text(top=1))

    def test_multiple_focus_or_display_sections(self):
        samples = [focus_text().replace("    mFocusedApp=", "    mCurrentFocus=null\n    mFocusedApp="),
                   focus_text().replace("    mFocusedApp=", "  Display: mDisplayId=0\n    mFocusedApp=")]
        for raw in samples:
            with self.subTest(raw=raw), self.assertRaises(driver.FocusUnavailable):
                driver._focus_snapshot(raw)

    def test_wrong_focused_activity(self):
        self.rejected(focus={**self.focus, "activity": ACTIVITY.replace(PACKAGE, driver.DECOY)})

    def test_not_resumed_or_wrong_resumed_record(self):
        self.rejected(activities=ACTIVITIES.replace("ResumedActivity:", "PausedActivity:"))
        self.rejected(activities=ACTIVITIES.replace("ca123", "ca124"))

    def test_duplicate_and_client_nested_resumed_labels(self):
        self.rejected(activities=ACTIVITIES + f"  ResumedActivity: {ACTIVITY}\n")
        self.rejected(activities=ACTIVITIES.replace("  ResumedActivity:", "      ResumedActivity:"))

    def test_focus_change_after_ams_rejected(self):
        self.rejected(final={**self.focus, "window": "abc13"})

    def test_scoped_window_must_be_unique_and_exact(self):
        for raw, identity in ((POPUP, "abc13"), (POPUP + POPUP, "abc12")):
            with self.subTest(identity=identity), self.assertRaises(driver.FocusUnavailable):
                driver._window_details(raw, identity)

    def test_unknown_or_duplicate_owner_metadata_rejected(self):
        raws = [POPUP.replace("mOwnerUid=1000", "unrecognizedOwner=1000"),
                POPUP.replace("    mAttrs=", "    mOwnerUid=1000 showForAllUsers=false package=android appop=NONE\n    mAttrs=")]
        for raw in raws:
            with self.subTest(raw=raw), self.assertRaises(driver.FocusUnavailable):
                driver._window_details(raw, "abc12")

    def test_public_metadata_discards_ids_uid_title_and_client_data(self):
        encoded = json.dumps(self.evaluate())
        for private in ("abc12", "def34", "ca123", "10432", "1000", "Autofill UI", "synthetic_client_data"):
            self.assertNotIn(private, encoded)

    def device(self, popup=POPUP):
        device = driver.Device.__new__(driver.Device)
        device.expected_fixture = PACKAGE
        calls = []
        def shell(*args):
            calls.append(args)
            if args == ("dumpsys", "window"): return focus_text()
            if args == ("dumpsys", "window", "-a", "abc12"): return popup
            if args == ("dumpsys", "window", "-a", "def34"): return PARENT
            if args == ("dumpsys", "activity", "-p", PACKAGE, "activities"): return ACTIVITIES
            if args[:2] == ("input", "tap"): return ""
            raise AssertionError("unexpected synthetic shell command")
        device.shell = shell
        return device, calls

    def test_device_queries_exact_window_ids_and_package_only(self):
        device, calls = self.device()
        self.assertEqual(device.foreground(), driver.AUTOFILL_POPUP)
        self.assertEqual(calls, [("dumpsys", "window"), ("dumpsys", "window", "-a", "abc12"),
                                 ("dumpsys", "window", "-a", "def34"),
                                 ("dumpsys", "activity", "-p", PACKAGE, "activities"),
                                 ("dumpsys", "window")])

    def test_bad_owner_stops_before_parent_or_activity_reads(self):
        device, calls = self.device(POPUP.replace("mOwnerUid=1000", "mOwnerUid=10432"))
        self.assertIsNone(device.foreground())
        self.assertEqual(len(calls), 2)
        self.assertEqual(device.last_focus_metadata["reason"], "popup_not_system_owned")

    def test_ordinary_activity_branch_stays_direct(self):
        device, calls = self.device()
        device.shell = lambda *args: focus_text(title=COMPONENT)
        self.assertEqual(device.foreground(), (PACKAGE, driver.ACTIVITY))

    def test_authorized_popup_causes_exactly_one_normal_touch(self):
        device, calls = self.device()
        node = ET.Element("node", {"bounds": "[72,425][694,585]", "enabled": "true", "clickable": "true", "package": driver.PROVIDER, "class": "android.widget.TextView"})
        device.wait = lambda *args, **kwargs: node
        device.node_geometry = lambda value: []
        device.pending_intents = lambda: {"available": True, "own_record_count": 1}
        device.current_case = "locked_fill_refused"
        device.tap_diagnostics = []
        device._ui_started_ns = device._ui_finished_ns = time.monotonic_ns()
        device.tap(text="Unlock HeptaBao locally")
        self.assertEqual([c for c in calls if c[:2] == ("input", "tap")], [("input", "tap", "383", "505")])


if __name__ == "__main__":
    unittest.main(argv=[__file__, *remaining])
