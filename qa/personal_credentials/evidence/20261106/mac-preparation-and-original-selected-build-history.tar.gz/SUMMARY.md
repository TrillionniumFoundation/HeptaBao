# Available macOS history: three original public packages

This is a new grouping container. The three original archives are copied
byte-for-byte and retain their original manifests, summaries, failures and
limitations. The separate original 157-version r5 package identified by the
known SHA-256 prefix 037225 was unavailable to this handoff after workspace
replacement. It was not fetched again, reconstructed, or replaced by later
records. Its absence is a custody limit of this grouping.

## Recorded outcomes

| Original scope | Recorded result | Boundary |
| --- | --- | --- |
| Separate r5b 27-request HTTP/1.1 prefetch profile | 145 of 157 fixed versions verified: 130 reused and reverified, 15 newly verified, 12 failed | No Cargo build ran in this preparation profile. Partial timed-out downloads are not verified artifacts. |
| Bounded LAN transfer for 12 missing versions | Zero accepted connections and zero new verified versions; client and server exited 1; listener and workers closed | Client records did not distinguish connect failure from response-header failure. No stronger network cause is claimed. Individual client record files were not separately archived. |
| Actual selected-three-crate Darwin build with 375 cache archives | Fixed c447536 source stayed clean; Rust 1.98.0 selected offline locked build gates passed | The remaining 12 uncached archives were not required by that actual selected build. This does not establish a complete workspace cache or whole-workspace build. |
| Original selected Mac functional results | Broker 4/13; vault 14/14; edge library 1/1; separate edge Python process profile 4/4 | Broker scope remains failed. Linux-native backpressure has eight expected checks marked unsupported, with no passes. These are separate denominators. |

The selected build scope consists only of heptabao-credential-broker,
heptabao-personal-vault and heptabao-personal-edge, for aarch64-apple-darwin.
Recorded artifact digests and before/after identities remain in the original
receipts. No broader platform, real-browser, task attestation, production,
installer or migration qualification is added.

Later Mac/Linux nineteen-case broker-fix results belong to a separate source
and evidence packet. They are not included here and do not rewrite the old
4/13 result.

## Contents and custody

The three nested archives contain 219, 31 and 102 regular members respectively.
Their 218, 30 and 101 listed entries were checked against the original member
lengths and SHA-256 values. Embedded archives inside those originals remain
opaque here; this grouping does not claim a deeper reconstruction.

The metadata/ files are byte-identical copies of each original manifest and
summary for convenient review. The new scope summary and verification receipt
are explicitly derived. Existing controlled network metadata already present
in the public LAN package is retained; no additional private route files were
read or added. No missing individual record was fabricated.

This grouping performed no network request, dependency download, Cargo build,
test execution, ADB/UI action, device query or repository modification.
Archive-integrity success does not convert a recorded failed or unsupported
profile into a passing platform result.
