#!/usr/bin/python3
"""Independent static delta check and fresh execution of author QA13 host guards."""
import ast,difflib,hashlib,json,os,re,subprocess,sys
from pathlib import Path
BASE=Path('/workspace/scratch/heptabao-agent-broker-recovery-20261106-r1/qa13')
OUT=Path('/workspace/scratch/heptabao-p0-recovery-20261106/qa13-review-r1')
PINS={'android_live.revision13.py':'5e6ba13ba006517531a6058078d5529c811a06bb0bc2728ed72422d1bcdb7348',
 'android_return_guard_tests.py':'7383d789370dd8d010921c255f9331e641b5580ac23806bc9e2c0c60ca42180f',
 'qa13.changes.patch':'f8b89165b2a3cbf089f51ed097defd8f19a918a8b7a10aa1dbbf3bab4a54d471',
 'android_live.qa12.baseline.py':'7443b8115260ac08feb23dbdd8c9e14ed448933380642b0c53d5f4d60cf10c9c'}
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(o):return (json.dumps(o,sort_keys=True,indent=2)+'\n').encode()
def write(p,b):
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def members(tree):
 d={}
 for n in tree.body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):d[n.name]=n
  if isinstance(n,ast.ClassDef):
   for m in n.body:
    if isinstance(m,(ast.FunctionDef,ast.AsyncFunctionDef)):d[n.name+'.'+m.name]=m
 return d
def main():
 os.umask(0o077);OUT.mkdir(mode=0o700)
 sources={}
 for name,pin in PINS.items():
  raw=(BASE/name).read_bytes()
  if sha(raw)!=pin:raise RuntimeError('input_hash_mismatch')
  write(OUT/name,raw);sources[name]=raw
 old=sources['android_live.qa12.baseline.py'].decode();new=sources['android_live.revision13.py'].decode()
 exact=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='android_live.qa12.baseline.py',tofile='android_live.revision13.py'))
 if exact.encode()!=sources['qa13.changes.patch']:raise RuntimeError('patch_not_exact')
 ot,nt=ast.parse(old),ast.parse(new);om,nm=members(ot),members(nt)
 common=set(om)&set(nm);same=lambda k:ast.dump(om[k],include_attributes=False)==ast.dump(nm[k],include_attributes=False)
 changed=sorted(k for k in common if not same(k))
 required=['_focus_snapshot','_window_details','_top_resumed_bound','_popup_parent','_bound_parent','autofill_popup_metadata',
           'Device.shell','Device.foreground','Device.ui','Device.tap','Device.authentication','Device.unlock','Device.package_hash']
 if any(k not in common or not same(k) for k in required):raise RuntimeError('existing_safety_boundary_changed')
 def cases(t):
  return [n.args[0].value for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='case' and n.args and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str)]
 oc,nc=cases(ot),cases(nt)
 if oc!=nc or len(oc)!=12 or len(set(oc))!=12:raise RuntimeError('case_inventory_changed')
 audit=OUT/'external-attempts.original.json'
 bootstrap="""import json,os,runpy,sys
events=[]
def guard(event,args):
 if event.startswith('socket.') or event in {'subprocess.Popen','os.system','os.exec','os.posix_spawn'}:
  events.append(event)
  raise RuntimeError('external_calls_forbidden')
sys.addaudithook(guard)
test,driver,audit=sys.argv[1:]
sys.argv=[test,'--driver',driver,'-v']
try:runpy.run_path(test,run_name='__main__')
finally:
 with open(audit,'x') as f:json.dump({'external_attempt_count':len(events),'events':events},f,sort_keys=True);f.write('\\n');f.flush();os.fsync(f.fileno())
"""
 argv=['/usr/bin/python3','-I','-B','-c',bootstrap,str(OUT/'android_return_guard_tests.py'),str(OUT/'android_live.revision13.py'),str(audit)]
 env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'}
 write(OUT/'intent.public.json',enc({'argv':argv,'env':env,'timeout_seconds':60,'driver_sha256':PINS['android_live.revision13.py'],'tests_sha256':PINS['android_return_guard_tests.py']}))
 p=subprocess.run(argv,cwd=OUT,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=60)
 write(OUT/'stdout.original.txt',p.stdout);write(OUT/'stderr.original.txt',p.stderr)
 counts=re.findall(rb'^Ran ([0-9]+) tests? in [^\n]+$',p.stderr,re.M);observed=int(counts[0]) if len(counts)==1 else None
 audit_raw=audit.read_bytes();attempts=json.loads(audit_raw)['external_attempt_count']
 unchanged=all(sha((BASE/n).read_bytes())==v and sha((OUT/n).read_bytes())==v for n,v in PINS.items())
 passed=p.returncode==0 and observed==38 and p.stderr.rstrip().endswith(b'OK') and attempts==0 and unchanged
 receipt={'schema':1,'scope':'internal_static_delta_review_and_fresh_author_guard_suite_rerun',
 'source_pins':PINS,'patch_exact':True,'changed_common_methods':changed,'unchanged_existing_safety_methods':required,
 'original_12_case_ids_unchanged':oc,'author_guard_expected':38,'author_guard_observed':observed,'exit_code':p.returncode,'passed':passed,
 'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'external_audit_sha256':sha(audit_raw),'external_attempt_count':attempts,
 'source_before_after_unchanged':unchanged,'actual_argv':argv,'adb_operations':0,'phone_qualification':False,
 'c6_product_changed':False,'autofill_internal_session_id_observed':False,'same_wms_window_record_task_owner_only':True,
 'external_independent_security_review':False,'test_design_independent':False,
 'static_findings':['No new blocking issue in the frozen delta.',
  'Display 0 is supplied by the unchanged Device.shell adapter and asserted in the actual-command host control.',
  'All foreground query outcomes are checked against the original three-second observation deadline.',
  'Original WMS identity is revalidated after the title wait; this is not an internal Autofill session ID.',
  'Plaintext and unknown popup presentations refuse before one ordinary Back; uncertain Back is not retried.']}
 raw=enc(receipt);write(OUT/'receipt.public.json',raw)
 print(json.dumps({'passed':passed,'expected':38,'observed':observed,'external_attempts':attempts,'receipt_sha256':sha(raw),'changed_common_methods':changed,'path':str(OUT)},sort_keys=True))
 return 0 if passed else 1
if __name__=='__main__':raise SystemExit(main())
