#!/usr/bin/env python3
"""Actual Android system Autofill qualification for one previously authorized device.

Only synthetic, newly installed packages are touched. No raw serial, password,
UI hierarchy, or original password-provider component is emitted in the report.
The private restore journal makes an interrupted run reviewable and recoverable.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import signal
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

DEVICE_SHA256 = "41ad305f8562a6c47710afe71fabf30cb8692a71d3de1a47ca9949b669bcc6c1"
PROVIDER = "org.heptabao.personal.preview"
GOOD = "org.heptabao.synthetic.fixture"
DECOY = "org.heptabao.synthetic.decoy"
SERVICE = PROVIDER + "/org.heptabao.preview.VaultAutofillService"
ACTIVITY = "org.heptabao.fixture.FixtureActivity"
PACKAGES = {PROVIDER, GOOD, DECOY}


class Failed(Exception):
    pass


def sha(data):
    return hashlib.sha256(data).hexdigest()


def atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".new." + str(os.getpid()) + "." + str(time.monotonic_ns()))
    with temporary.open("x", encoding="utf-8") as output:
        json.dump(value, output, sort_keys=True, indent=2)
        output.write("\n"); output.flush(); os.fsync(output.fileno())
    os.replace(temporary, path)


class Device:
    def __init__(self, adb):
        self.adb = str(adb)
        raw = self.command([self.adb, "devices"], 15)
        devices = [row.split()[0] for row in raw.decode().splitlines()[1:] if len(row.split()) == 2 and row.split()[1] == "device"]
        if len(devices) != 1 or sha(devices[0].encode()) != DEVICE_SHA256:
            raise Failed("authorized_device_not_unique")
        self.serial = devices[0]

    @staticmethod
    def command(argv, timeout=25, allow_failure=False):
        try:
            result = subprocess.run(argv, capture_output=True, timeout=timeout, check=False)
        except (OSError, subprocess.TimeoutExpired):
            raise Failed("device_command_unavailable") from None
        if result.returncode and not allow_failure:
            raise Failed("device_command_failed")
        return result.stdout

    def adb_command(self, *args, timeout=25, allow_failure=False):
        return self.command([self.adb, "-s", self.serial, *map(str, args)], timeout, allow_failure)

    def shell(self, *args, timeout=25, allow_failure=False):
        # adb shell joins arguments. Quote each token for the remote shell, including synthetic input.
        return self.adb_command("shell", " ".join(shlex.quote(str(arg)) for arg in args), timeout=timeout, allow_failure=allow_failure).decode("utf-8", "replace").strip()

    def setting(self):
        value = self.shell("settings", "--user", "0", "get", "secure", "autofill_service")
        if value != "null" and not re.fullmatch(r"[A-Za-z0-9_.$]+/[A-Za-z0-9_.$]+", value):
            raise Failed("unexpected_autofill_setting")
        return value

    def package_hash(self, package):
        rows = self.shell("pm", "path", "--user", "0", package, allow_failure=True).splitlines()
        if not rows:
            return None
        if len(rows) != 1 or not rows[0].startswith("package:/data/app/"):
            raise Failed("unexpected_package_layout")
        path = rows[0][8:]
        value = self.shell("sha256sum", path).split()[0]
        if not re.fullmatch(r"[0-9a-f]{64}", value):
            raise Failed("installed_digest_unavailable")
        return value

    def foreground(self):
        raw = self.shell("dumpsys", "window", "windows")
        match = re.search(r"mCurrentFocus=Window\{[^\n]*? ([A-Za-z0-9_.$]+)/([A-Za-z0-9_.$]+)\}", raw)
        if not match:
            return None
        return match.group(1), match.group(2)

    def ui(self):
        current = self.foreground()
        if current is None or current[0] not in PACKAGES | {"android"}:
            raise Failed("unexpected_foreground_no_ui_read")
        # No hierarchy file is created on the device or host. Parse only in memory.
        raw = self.adb_command("exec-out", "uiautomator", "dump", "--compressed", "/dev/tty", timeout=20)
        start, end = raw.find(b"<hierarchy"), raw.find(b"</hierarchy>")
        if start < 0 or end < start:
            raise Failed("ui_hierarchy_unavailable")
        try:
            return list(ET.fromstring(raw[start:end + len(b"</hierarchy>")]).iter("node"))
        except ET.ParseError:
            raise Failed("ui_hierarchy_invalid") from None

    def find(self, text=None, description=None):
        for node in self.ui():
            if (text is not None and node.get("text", "").casefold() == text.casefold()) or (description is not None and node.get("content-desc") == description):
                return node
        return None

    def wait(self, text=None, description=None, seconds=25):
        deadline = time.monotonic() + seconds
        while time.monotonic() < deadline:
            node = self.find(text, description)
            if node is not None:
                return node
            time.sleep(0.25)
        raise Failed("expected_ui_missing")

    def tap(self, text=None, description=None):
        node = self.wait(text, description)
        match = re.fullmatch(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", node.get("bounds", ""))
        if not match or node.get("enabled") != "true":
            raise Failed("ui_target_unavailable")
        left, top, right, bottom = map(int, match.groups())
        if right <= left or bottom <= top:
            raise Failed("ui_target_bounds_invalid")
        self.shell("input", "tap", str((left + right) // 2), str((top + bottom) // 2))

    def fixture(self, package=GOOD):
        self.shell("am", "force-stop", "--user", "0", package)
        self.shell("am", "start", "--user", "0", "-W", "-n", package + "/" + ACTIVITY)
        self.wait(text="HeptaBao synthetic native login")

    def empty(self):
        self.verify("Empty fields")

    def verify(self, expected):
        # Dismiss a suggestion overlay; require an incremented counter, not a stale status label.
        self.tap(text="HeptaBao synthetic native login")
        before = self.wait(description="Fixture verification")
        match = re.fullmatch(r"Verification (\d+): .+", before.get("text", ""))
        if not match: raise Failed("fixture_verification_counter_missing")
        count = int(match.group(1)) + 1
        self.tap(text="Verify synthetic login")
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            after = self.wait(description="Fixture verification")
            prefix = "Verification " + str(count) + ": "
            if after.get("text", "").startswith(prefix):
                if after.get("text") != prefix + expected: raise Failed("actual_fixture_values_rejected")
                return
            time.sleep(0.25)
        raise Failed("fixture_verification_not_executed")

    def authentication(self):
        self.fixture()
        self.tap(text="Request Autofill")
        self.tap(text="Unlock HeptaBao locally")
        self.wait(text="HeptaBao · local authorization")
        self.wait(text="Locked")

    def unlock(self, master, expect_success=True):
        self.tap(description="Master password")
        node = self.find(description="Master password")
        current = self.foreground()
        if node is None or node.get("package") != PROVIDER or node.get("password") != "true" or node.get("focused") != "true" or current != (PROVIDER, "org.heptabao.preview.AuthActivity"):
            raise Failed("password_input_target_changed")
        self.shell("input", "text", master)
        self.tap(text="Unlock locally")
        self.wait(text="Unlocked; confirm within 20 seconds" if expect_success else "Unlock failed", seconds=40)

    def cancel_authentication(self):
        self.tap(text="Cancel")
        self.wait(text="HeptaBao synthetic native login")
        self.empty()

    def decision(self):
        self.shell("am", "start", "--user", "0", "-W", "-n", PROVIDER + "/org.heptabao.preview.MainActivity")
        node = self.wait(description="Provider status")
        match = re.search(r"Decision: ([a-z_]+)$", node.get("text", ""))
        if not match:
            raise Failed("provider_decision_unavailable")
        return match.group(1)


def restore(device, journal, journal_path):
    if journal.get("setting_write_attempted"):
        current = device.setting()
        previous = journal["previous_autofill_service"]
        if current == SERVICE:
            if previous == "null":
                device.shell("settings", "--user", "0", "delete", "secure", "autofill_service")
            else:
                device.shell("settings", "--user", "0", "put", "secure", "autofill_service", previous)
            if device.setting() != previous:
                raise Failed("autofill_restore_verification_failed")
            journal["restoration"] = "restored_original"
        elif current == previous:
            journal["restoration"] = "already_original"
        else:
            journal["restoration"] = "external_change_preserved"
    else:
        journal["restoration"] = "not_changed"
    atomic_json(journal_path, journal)
    cleanup = {}
    for package, hashes in journal.get("owned_packages", {}).items():
        current_hash = device.package_hash(package)
        if current_hash is None:
            cleanup[package] = "absent"
        elif current_hash in hashes:
            device.adb_command("uninstall", package, timeout=60)
            if device.package_hash(package) is not None:
                raise Failed("owned_package_cleanup_failed")
            cleanup[package] = "removed_owned_package"
        else:
            cleanup[package] = "unknown_artifact_preserved"
    journal["package_cleanup"] = cleanup
    atomic_json(journal_path, journal)
    return journal["restoration"], cleanup


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--adb", required=True, type=Path)
    parser.add_argument("--apks", type=Path)
    parser.add_argument("--build-receipt", type=Path)
    parser.add_argument("--master-file", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--restore", type=Path)
    args = parser.parse_args()
    os.umask(0o077)
    device = Device(args.adb)
    if device.shell("am", "get-current-user") != "0" or device.shell("getprop", "ro.build.version.sdk") != "36":
        raise Failed("unsupported_device_user_or_api")
    if args.restore:
        journal = json.loads(args.restore.read_text())
        if journal.get("device_serial_sha256") != DEVICE_SHA256 or journal.get("service_written") != SERVICE or set(journal.get("owned_packages", {})) - PACKAGES:
            raise Failed("invalid_restore_journal")
        restored, cleanup = restore(device, journal, args.restore)
        print(json.dumps({"ok": True, "restoration": restored, "package_cleanup": cleanup}, sort_keys=True))
        return
    if any(value is None for value in (args.apks, args.build_receipt, args.master_file, args.output)):
        raise Failed("missing_run_input")
    if args.master_file.is_symlink() or args.master_file.stat().st_uid != os.getuid() or args.master_file.stat().st_mode & 0o077:
        raise Failed("unsafe_master_file")
    master = args.master_file.read_text()
    if not re.fullmatch(r"[A-Za-z0-9_-]{43}", master):
        raise Failed("unexpected_synthetic_master")
    build = json.loads(args.build_receipt.read_text())
    variants = {"provider": PROVIDER, "fixture-good": GOOD, "fixture-wrong-certificate": GOOD, "fixture-wrong-package": DECOY}
    for variant, package in variants.items():
        artifact = build["artifacts"][variant]
        if artifact["package"] != package or artifact["sha256"] != sha((args.apks / (variant + ".apk")).read_bytes()):
            raise Failed("apk_build_binding_mismatch")
    if build["crypto_interop"].get("ok") is not True or build["crypto_interop"].get("checks") != 12:
        raise Failed("host_interop_not_qualified")
    if build["artifacts"]["fixture-good"]["signer_sha256"] != build["artifacts"]["fixture-wrong-package"]["signer_sha256"] or build["artifacts"]["fixture-good"]["signer_sha256"] == build["artifacts"]["fixture-wrong-certificate"]["signer_sha256"]:
        raise Failed("negative_certificate_fixtures_invalid")
    args.output.mkdir(mode=0o700, exist_ok=False)
    journal_path = args.output / "restore.private.json"
    journal = {"schema": 1, "device_serial_sha256": DEVICE_SHA256, "service_written": SERVICE, "previous_autofill_service": device.setting(), "setting_write_attempted": False, "owned_packages": {}, "created_unix_ns": time.time_ns()}
    atomic_json(journal_path, journal)
    report = {"schema": 1, "scope": "native_synthetic_autofill_only", "device_serial_sha256": DEVICE_SHA256, "api": 36, "release": device.shell("getprop", "ro.build.version.release"), "model": device.shell("getprop", "ro.product.model"), "hardware_sku": device.shell("getprop", "ro.boot.hardware.sku"), "build_fingerprint_sha256": sha(device.shell("getprop", "ro.build.fingerprint").encode()), "build_receipt_sha256": sha(args.build_receipt.read_bytes()), "qa_script_sha256": sha(Path(__file__).read_bytes()), "started_unix_ns": time.time_ns(), "cases": [], "installed_apk_sha256": {}, "previous_setting_sha256": sha(journal["previous_autofill_service"].encode()), "unsupported": ["browser", "WebView filling", "arbitrary applications", "passkeys", "sharing"]}
    def case(name, action):
        print(json.dumps({"case": name, "state": "running"}), flush=True)
        started = time.monotonic(); action()
        report["cases"].append({"name": name, "passed": True, "elapsed_ms": round((time.monotonic() - started) * 1000)})
        atomic_json(args.output / "progress.json", report)
        print(json.dumps({"case": name, "passed": True}), flush=True)
    def install(variant):
        artifact = build["artifacts"][variant]; package = artifact["package"]
        allowed = journal["owned_packages"].setdefault(package, [])
        if artifact["sha256"] not in allowed: allowed.append(artifact["sha256"])
        atomic_json(journal_path, journal)
        device.adb_command("install", "--user", "0", "--no-streaming", args.apks / (variant + ".apk"), timeout=90)
        if device.package_hash(package) != artifact["sha256"]:
            raise Failed("installed_apk_digest_mismatch")
        report["installed_apk_sha256"][variant] = artifact["sha256"]
    interrupted = False
    def stop(signum, frame):
        nonlocal interrupted
        if interrupted: return
        interrupted = True
        raise Failed("run_interrupted")
    signal.signal(signal.SIGTERM, stop); signal.signal(signal.SIGINT, stop)
    failure = None
    try:
        for package in PACKAGES:
            # Include uninstalled retained package records: never overwrite an unknown prior preview.
            if device.package_hash(package) is not None or device.shell("pm", "list", "packages", "-u", package):
                raise Failed("target_package_preexists")
        install("provider"); install("fixture-good"); install("fixture-wrong-package")
        if device.setting() != journal["previous_autofill_service"]:
            raise Failed("autofill_setting_changed_before_write")
        journal["setting_write_attempted"] = True; atomic_json(journal_path, journal)
        device.shell("settings", "--user", "0", "put", "secure", "autofill_service", SERVICE)
        if device.setting() != SERVICE: raise Failed("autofill_enable_not_applied")
        def imported():
            device.fixture(); device.tap(text="Import synthetic encrypted vault"); device.tap(text="Import")
            status = device.wait(description="Provider status")
            deadline = time.monotonic() + 20
            while "Encrypted vault imported; locked" not in status.get("text", "") and time.monotonic() < deadline:
                time.sleep(0.25); status = device.wait(description="Provider status")
            if "Encrypted vault imported; locked" not in status.get("text", ""): raise Failed("ciphertext_import_failed")
        case("rust_ciphertext_import", imported)
        def locked():
            device.authentication(); device.tap(text="Fill once"); device.wait(text="Locked or expired"); device.cancel_authentication()
        case("locked_fill_refused", locked)
        def wrong_master():
            device.authentication(); device.unlock(("A" if master[0] != "A" else "B") + master[1:], False)
            device.tap(text="Fill once"); device.wait(text="Locked or expired"); device.cancel_authentication()
        case("wrong_master_refused", wrong_master)
        def login():
            device.authentication(); device.unlock(master); device.tap(text="Fill once")
            device.wait(text="HeptaBao synthetic native login"); device.verify("Synthetic login accepted")
        case("actual_system_fill_and_login", login)
        def cached():
            device.tap(text="Clear fields"); device.tap(description="Synthetic username")
            time.sleep(1)
            node = device.find(text="Unlock HeptaBao locally")
            if node is not None:
                device.tap(text="Unlock HeptaBao locally"); time.sleep(0.5)
                if device.foreground() == (PROVIDER, "org.heptabao.preview.AuthActivity"):
                    device.wait(text="Locked"); device.tap(text="Fill once"); device.wait(text="Locked or expired"); device.cancel_authentication()
            device.empty()
            if device.find(text="Fill synthetic login once") is not None: raise Failed("cached_plaintext_dataset_visible")
        case("system_cached_plaintext_not_reusable", cached)
        def explicit_lock():
            device.authentication(); device.unlock(master); device.tap(text="Lock"); device.tap(text="Fill once"); device.wait(text="Locked or expired"); device.cancel_authentication()
        case("explicit_lock_refused", explicit_lock)
        def expired():
            device.authentication(); device.unlock(master); time.sleep(21)
            device.tap(text="Fill once"); device.wait(text="Locked or expired"); device.cancel_authentication()
        case("expired_authorization_refused", expired)
        def cancelled():
            device.authentication(); device.unlock(master); device.cancel_authentication()
            device.authentication(); device.tap(text="Fill once"); device.wait(text="Locked or expired"); device.cancel_authentication()
        case("cancelled_authorization_refused", cancelled)
        def background():
            device.authentication(); device.unlock(master); device.shell("input", "keyevent", "KEYCODE_HOME")
            device.authentication(); device.tap(text="Fill once"); device.wait(text="Locked or expired"); device.cancel_authentication()
        case("background_authorization_refused", background)
        def restarted():
            device.shell("am", "force-stop", "--user", "0", PROVIDER)
            device.shell("am", "start", "--user", "0", "-W", "-n", PROVIDER + "/org.heptabao.preview.MainActivity")
            node = device.wait(description="Provider status")
            if "Encrypted vault imported; locked" not in node.get("text", ""): raise Failed("restart_ciphertext_missing")
            device.authentication(); device.tap(text="Fill once"); device.wait(text="Locked or expired"); device.cancel_authentication()
            login()
        case("independent_process_restart_locked_and_recovered", restarted)
        def rejected_package():
            device.fixture(DECOY); device.tap(text="Request Autofill"); time.sleep(1); device.empty()
            if device.decision() != "wrong_package": raise Failed("wrong_package_cause_not_observed")
        case("wrong_package_same_certificate_refused", rejected_package)
        def rejected_certificate():
            if device.package_hash(GOOD) != build["artifacts"]["fixture-good"]["sha256"]: raise Failed("fixture_ownership_changed")
            device.adb_command("uninstall", GOOD, timeout=60)
            install("fixture-wrong-certificate")
            device.fixture(); device.tap(text="Request Autofill"); time.sleep(1); device.empty()
            if device.decision() != "wrong_certificate": raise Failed("wrong_certificate_cause_not_observed")
        case("same_package_wrong_certificate_refused", rejected_certificate)
    except Failed as error:
        failure = str(error)
    except Exception:
        failure = "unexpected_driver_failure"
    finally:
        # No raw exception, argv, serial, hierarchy, or secret is printed, including failures.
        try:
            restored, cleanup = restore(device, journal, journal_path)
            report["restoration"] = restored; report["package_cleanup"] = cleanup
            if any(value == "unknown_artifact_preserved" for value in cleanup.values()): failure = failure or "cleanup_external_change_preserved"
        except Exception:
            report["restoration"] = "verification_required"
            failure = failure or "restoration_failed"
        report["finished_unix_ns"] = time.time_ns(); report["passed"] = failure is None
        report["error"] = failure; report["checks_passed"] = len(report["cases"])
        atomic_json(args.output / "report.json", report)
    print(json.dumps({"ok": report["passed"], "checks_passed": report["checks_passed"], "error": failure, "restoration": report["restoration"], "report": str(args.output / "report.json"), "report_sha256": sha((args.output / "report.json").read_bytes())}, sort_keys=True), flush=True)
    if failure: raise SystemExit(1)


if __name__ == "__main__":
    try:
        main()
    except Failed as error:
        print(json.dumps({"ok": False, "error": str(error)}), flush=True)
        raise SystemExit(1)
