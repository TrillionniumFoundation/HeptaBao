#!/usr/bin/env python3
"""One real Linux non-waitable adopted leader transition; no Cargo invocation."""
from pathlib import Path
import ctypes
import hashlib
import importlib.util
import json
import os
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
OUT = Path('/home/qian-qi/heptabao-ci-r3-nonwaitable-control-20261106-r1')
OLD = Path('/home/qian-qi/heptabao-ci-diagnostics-inputs-20261106-r2/packet/controller_common.py')
OLD_SHA = 'fdcb49c11924a696c0563cb70c4e8890f3ce16ac701fe0fe4925665f8a167444'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    os.umask(0o077)
    assert OLD.is_file() and not OLD.is_symlink() and hashlib.sha256(OLD.read_bytes()).hexdigest() == OLD_SHA
    C = load('current_common', HERE / 'controller_common.py')
    previous = load('previous_common', OLD)
    C.install_cancellation()
    C.enable_child_subreaper()
    OUT.mkdir(mode=0o700, exist_ok=False)
    source_before = {'current': C.pin(HERE / 'controller_common.py'), 'previous': C.pin(OLD),
                     'control': C.pin(Path(__file__).resolve())}
    row = {'schema': 'heptabao.r3-one-nonwaitable-control.v1', 'status': 'running',
           'case_count': 1, 'rust_tests_executed': False,
           'r2_four_controls_are_a_separate_prior_source_result': True,
           'source_before': source_before, 'original_leader_reaped': False}
    child = None
    identity = None
    cleanup = {}
    close_attempted = False
    result = 1
    started = time.monotonic()
    try:
        # Only this child's main pthread exits. Its worker stays alive until our
        # private release marker, with an independent eight-second escape bound.
        worker = """from pathlib import Path
import ctypes, os, signal, threading, time
root=Path(__import__('sys').argv[1])
signal.signal(signal.SIGTERM,signal.SIG_IGN)
def remain_alive():
 deadline=time.monotonic()+8
 while not (root/'release').exists() and time.monotonic()<deadline:time.sleep(.01)
threading.Thread(target=remain_alive,daemon=False).start()
(root/'thread-ready').write_text(str(os.getpid()))
libc=ctypes.CDLL(None);libc.pthread_exit.argtypes=[ctypes.c_void_p];libc.pthread_exit.restype=None
libc.pthread_exit(None)
"""
        leader = """from pathlib import Path
import subprocess,sys,time
root=Path(sys.argv[1])
subprocess.Popen([sys.executable,'-I','-B','-c',sys.argv[2],str(root)])
deadline=time.monotonic()+3
while not (root/'thread-ready').exists():
 assert time.monotonic()<deadline
 time.sleep(.01)
raise SystemExit(7)
"""
        with (OUT / 'children.stdout.private').open('xb') as stdout, (OUT / 'children.stderr.private').open('xb') as stderr:
            child = subprocess.Popen([sys.executable, '-I', '-B', '-c', leader, str(OUT), worker],
                                     cwd=OUT, env=C.base_env(OUT), stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, start_new_session=True)
            identity = C.original_child_identity(child, pgid=child.pid, sid=child.pid)
            cleanup['child_identity'] = identity
            C.publish(OUT / 'original-leader.started.public.json', identity)
            deadline = time.monotonic() + 3
            while True:
                event = C.observe_original_unreaped(child, identity)
                descendants = C.own_group_children(child, identity)
                if event is not None and len(descendants) == 1 and descendants[0]['state'] == 'Z':
                    descendant = descendants[0]
                    break
                C.require(time.monotonic() < deadline, 'controlled_nonwaitable_state_not_observed')
                time.sleep(.01)
            C.require(os.waitid(os.P_PID, descendant['pid'], os.WEXITED | os.WNOHANG | os.WNOWAIT) is None,
                      'controlled_descendant_was_already_waitable')
            row['actual_nonwaitable_descendant'] = descendant
            old_row = {}
            try:
                previous.reap_owned_adopted_zombies(child, old_row, identity)
            except previous.Blocked as error:
                C.require(str(error) == 'owned_adopted_zombie_not_reaped', 'old_guard_other_failure')
                row['prior_guard_rejected_actual_nonwaitable_child'] = True
            else:
                raise C.Blocked('prior_guard_counterexample_not_observed')
            C.reap_owned_adopted_zombies(child, cleanup, identity)
            C.require(cleanup.get('adopted_waitpid_not_ready_count') == 1
                      and not cleanup.get('adopted_descendants_reaped'), 'new_guard_did_not_defer_without_claiming_reap')
            row['new_guard_deferred_without_claiming_reaped'] = True
            C.publish(OUT / 'nonwaitable.observation.public.json', {
                'descendant': descendant, 'old_guard_rejected': True,
                'new_guard_deferred': True, 'new_guard_reaped_count_before_release': 0})
            C.durable(OUT / 'release', b'release one owned worker\n')
            close_attempted = True
            C.close_owned_group(child, cleanup)
            row['cleanup'] = cleanup
            C.require(cleanup.get('exit_code') == 7 and cleanup.get('reaped') is True
                      and cleanup.get('descendant_group_absent') is True
                      and any(item['pid'] == descendant['pid'] for item in cleanup.get('adopted_descendants_reaped', [])),
                      'owned_nonwaitable_transition_not_fully_reaped')
            row['original_leader_reaped'] = True
            row['status'] = 'passed_one_actual_nonwaitable_to_reaped_transition'
            result = 0
    except BaseException as error:
        row['status'] = 'failed'
        row['failure_class'] = type(error).__name__
        row['failure_code'] = str(error) if isinstance(error, C.Blocked) else 'unexpected_control_exception'
    finally:
        # Only the original still-held Popen/group may be closed. No old job PID
        # or reusable numeric PGID is ever signalled by this controller.
        if child is not None and child.returncode is None and identity is not None and not close_attempted:
            try:
                close_attempted = True
                C.close_owned_group(child, cleanup)
            except BaseException as error:
                row['cleanup_failure_class'] = type(error).__name__
                row['status'] = 'failed'
                result = 1
        row['cleanup'] = cleanup
        row['original_leader_reaped'] = child is not None and child.returncode is not None
        row['duration_seconds'] = round(time.monotonic() - started, 3)
        row['source_after'] = {'current': C.pin(HERE / 'controller_common.py'), 'previous': C.pin(OLD),
                               'control': C.pin(Path(__file__).resolve())}
        if row['source_after'] != source_before:
            row['status'] = 'failed'; row['failure_code'] = 'control_source_changed'; result = 1
        row['streams'] = {name: C.pin(OUT / name) for name in ('children.stdout.private', 'children.stderr.private')
                          if (OUT / name).exists()}
        C.publish(OUT / 'result.public.json', row)
        print(json.dumps({'status': row['status'], 'case_count': 1, 'rust_tests_executed': False,
                          'receipt': C.pin(OUT / 'result.public.json')}, sort_keys=True))
    return result


if __name__ == '__main__':
    raise SystemExit(main())
