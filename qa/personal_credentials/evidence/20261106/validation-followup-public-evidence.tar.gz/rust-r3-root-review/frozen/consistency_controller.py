#!/usr/bin/env python3
"""Reconstruct the already formatted sources; run one isolated four-test red/green attempt."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import os
import re
import resource
import shutil
import sys
import time
import tomllib

HERE = Path(__file__).resolve().parent
ROOT = Path('/home/qian-qi/heptabao-consistency-audit-red-green-20261106-r3')
SOURCE_INPUTS = Path('/home/qian-qi/heptabao-ci-diagnostics-inputs-20261106-r1/packet')
ARCHIVE = Path('/home/qian-qi/heptabao-rolling-inputs-8f3-3ada-20261106-r1/candidate-source.tar.gz')
P0 = Path('/home/qian-qi/heptabao-rolling-exact-8f3-3ada-20261106-r1')
TOOL = Path('/home/qian-qi/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin')
FILES = ('crates/heptabao-server/src/http.rs',
         'crates/heptabao-server/src/http_consistency_tests.rs',
         'crates/heptabao-server/src/service_consistency.rs')


def common(expected):
    path = HERE / 'controller_common.py'
    if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise RuntimeError('controller_common_pin_mismatch')
    spec = importlib.util.spec_from_file_location('frozen_controller_common', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def environment(C, temporary):
    env = C.base_env(temporary)
    env.update({'PATH': str(TOOL) + ':/usr/local/bin:/usr/bin:/bin',
                'CARGO_HOME': str(ROOT / 'cargo-home'), 'CARGO_NET_OFFLINE': 'true',
                'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0',
                'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
                'RUSTC': str(TOOL / 'rustc'),
                'BINDGEN_EXTRA_CLANG_ARGS': '-isystem /usr/lib/gcc/x86_64-linux-gnu/15/include'})
    return env


def phase_rows(C, source):
    return [dict(path=path, **C.pin(source / path)) for path in FILES]


def manifest_overlays(C, source, manifest):
    original = {row['path']: row for row in manifest['files']}
    return [dict(path=path, git_mode=original[path]['git_mode'], **C.pin(source / path)) for path in FILES]


def check_phase_input(C, source, state, manifest, env):
    overlays = [dict(row, git_mode=next(item['git_mode'] for item in manifest['files'] if item['path'] == row['path']))
                for row in state]
    return C.verify_source(source, manifest, C.expected_rows(manifest, overlays), env, FILES)



def prepare(C, binding, binding_sha):
    """No format mutation: recreate and check the exact r1 actual formatted bytes."""
    ROOT.mkdir(mode=0o700, exist_ok=False)
    logs = ROOT / 'prepare-private-logs'; logs.mkdir(mode=0o700)
    temporary = ROOT / 'private-tmp'; temporary.mkdir(mode=0o700)
    env = environment(C, temporary)
    report = {'schema': 'heptabao.consistency-format-preparation.v1', 'status': 'running',
              'bindings_sha256': binding_sha, 'controller_sha256': C.sha(Path(__file__).resolve()),
              'rust_tests_executed': False, 'cargo_build_executed': False,
              'P0_source_target_and_cache_modified': False,
              'r1_source_target_and_cache_modified': False, 'rustfmt_mutation_executed': False,
              'source_representation': 'genuine original commit with one disclosed shallow boundary',
              'prior_actual_rustfmt_receipt': binding['prior_prepare_receipt']}
    result = 1
    try:
        C.pin(SOURCE_INPUTS / '3ada.manifest.json', binding['source']['manifest'])
        manifest = json.loads((SOURCE_INPUTS / '3ada.manifest.json').read_bytes())
        C.require(manifest['commit'] == binding['source']['commit'] and manifest['tree'] == binding['source']['tree'], 'source_manifest_identity_mismatch')
        for row in binding['formatted_inputs']:
            C.pin(HERE / row['path'], row)
        C.pin(HERE / 'prior-prepare.public.json', binding['prior_prepare_receipt'])
        previous = json.loads((HERE / 'prior-prepare.public.json').read_bytes())
        C.require(previous['status'] == 'prepared_only_no_rust_execution'
                  and previous['bindings_sha256'] == binding['prior_prepare_bindings_sha256'], 'prior_format_receipt_invalid')
        old = json.loads((HERE / 'source-bindings.json').read_bytes())
        C.require(old['base_commit'] == manifest['commit'], 'patch_base_identity_mismatch')
        C.pin(HERE / 'source-bindings.json', previous['formatted_bindings'])
        tools = {name: C.pin(TOOL / name, expected) for name, expected in previous['toolchain'].items()}
        report['toolchain'] = tools
        report['rustc_version'] = previous['rustc_version']
        phases = {}
        for phase, state in (('red', 'tests-only'), ('green', 'candidate')):
            source = ROOT / ('source' if phase == 'red' else 'formatted-green-source')
            C.reconstruct(ARCHIVE, SOURCE_INPUTS / '3ada.commit.raw', manifest, source, env)
            patch = HERE / (phase + '.formatted.patch')
            C.git(source, env, 'apply', '--check', str(patch))
            C.git(source, env, 'apply', str(patch))
            check_phase_input(C, source, old['states'][state], manifest, env)
            argv = [str(TOOL / 'rustfmt'), '--check', '--edition', '2024', '--config', 'skip_children=true', *[str(source / path) for path in FILES]]
            command = C.run_owned(phase + '-rustfmt-check', argv, cwd=source, env=env, log_dir=logs, timeout=60)
            identity = check_phase_input(C, source, old['states'][state], manifest, env)
            C.require(identity['source_content_sha256'] == previous['phases'][phase]['full_source_rows_sha256'], 'r1_formatted_full_source_pin_mismatch')
            phases[phase] = {'command': command, 'files': phase_rows(C, source),
                             'full_source_rows_sha256': identity['source_content_sha256'],
                             'changed_by_rustfmt': [], 'prior_actual_format_source_unchanged': True}
        C.require(all((ROOT / 'source' / path).read_bytes() == (ROOT / 'formatted-green-source' / path).read_bytes()
                      for path in FILES[1:]), 'formatted_test_sources_differ_between_phases')
        runner = ROOT / 'runner'; runner.mkdir(mode=0o700)
        for name, expected in (('run_targeted.py', binding['targeted_runner']),
                               ('controller_common.py', binding['controller_common'])):
            C.pin(HERE / name, expected)
            C.durable(runner / name, (HERE / name).read_bytes())
        C.durable(runner / 'source-bindings.json', (HERE / 'source-bindings.json').read_bytes())
        C.publish(runner / 'runtime-bindings.json', {'controller_common': binding['controller_common']})
        report['phases'] = phases
        report['runner'] = C.pin(runner / 'run_targeted.py')
        report['runner_common'] = C.pin(runner / 'controller_common.py')
        report['runner_runtime_bindings'] = C.pin(runner / 'runtime-bindings.json')
        report['formatted_bindings'] = C.pin(runner / 'source-bindings.json')
        report['formatted_patches'] = previous['formatted_patches']
        report['status'] = 'prepared_only_no_rust_execution'
        result = 0
    except BaseException as error:
        report['status'] = 'failed'
        report['failure_class'] = type(error).__name__
        report['failure_code'] = str(error) if isinstance(error, C.Blocked) else 'unexpected_controller_exception'
    finally:
        C.publish(ROOT / 'prepare.public.json', report)
        print(json.dumps({'status': report['status'], 'rust_tests_executed': False,
                          'prepare_receipt_sha256': C.sha(ROOT / 'prepare.public.json')}, sort_keys=True))
    return result


def aggregate_memory():
    wanted = {'MemTotal', 'MemAvailable'}
    rows = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        key, _, tail = line.partition(':')
        if key in wanted:
            value, unit = tail.split()
            if unit != 'kB' or not value.isdigit():
                raise RuntimeError('aggregate_memory_format_invalid')
            rows[key] = int(value) * 1024
    if set(rows) != wanted:
        raise RuntimeError('aggregate_memory_fields_missing')
    return {'observed_unix_ns': time.time_ns(), 'bytes': rows, 'process_details_read': False}


def prepare_private_cache(C, source, cargo_home, binding):
    """Copy only locked public archives/sparse records; no credentials/config."""
    # The operator must wait for the P0 producer to be terminal before invoking run.
    # This original immutable result is bound even if a later producer has its own result.
    result_path = P0 / 'result.public.json'
    C.pin(result_path, binding['p0_terminal_result'])
    previous = json.loads(result_path.read_bytes())
    C.require(previous.get('all_owned_children_reaped') is True
              and previous.get('controller_sha256') == binding['p0_producer_sha256'], 'P0_producer_terminal_receipt_invalid')
    C.require(previous['sources']['candidate']['commit'] == binding['source']['commit'], 'P0_cache_lock_source_mismatch')
    registry = P0 / 'cargo-home/registry'
    caches = [path for path in (registry / 'cache').iterdir()
              if re.fullmatch(r'index\.crates\.io-[0-9a-f]{16}', path.name) and path.is_dir() and not path.is_symlink()]
    C.require(len(caches) == 1, 'one_public_registry_required')
    key = caches[0].name
    index = registry / 'index' / key
    config = index / 'config.json'
    C.regular(config, maximum=65536)
    cfg = json.loads(config.read_bytes())
    C.require(cfg.get('dl') == 'https://static.crates.io/crates' and cfg.get('api') == 'https://crates.io'
              and cfg.get('auth-required', False) is False, 'public_registry_configuration_mismatch')
    cargo_home.mkdir(mode=0o700, exist_ok=False)
    target_index = cargo_home / 'registry/index' / key
    target_cache = cargo_home / 'registry/cache' / key
    target_index.mkdir(mode=0o700, parents=True)
    target_cache.mkdir(mode=0o700, parents=True)
    C.durable(target_index / 'config.json', config.read_bytes())
    lock = tomllib.loads((source / 'Cargo.lock').read_text())
    packages = {}
    for package in lock['package']:
        kind = package.get('source', '')
        C.require(not kind or kind == 'registry+https://github.com/rust-lang/crates.io-index', 'nonpublic_or_git_dependency_not_allowed')
        if not kind:
            continue
        name, version, checksum = package['name'], package['version'], package['checksum']
        C.require(re.fullmatch(r'[A-Za-z0-9_-]+', name) and re.fullmatch(r'[A-Za-z0-9_.+\-]+', version)
                  and re.fullmatch(r'[0-9a-f]{64}', checksum), 'invalid_locked_package')
        packages[(name, version)] = checksum
    copied, missing, index_pins = [], [], {}
    total = 0
    for (name, version), checksum in sorted(packages.items()):
        prefix = '1' if len(name) == 1 else '2' if len(name) == 2 else '3/' + name[0] if len(name) == 3 else name[:2] + '/' + name[2:4]
        relative = Path('.cache') / prefix / name
        entry = index / relative
        C.regular(entry, maximum=16 * 1024**2)
        raw = entry.read_bytes()
        matches = []
        parts = raw.split(b'\0')
        for i, value in enumerate(parts[:-1]):
            if value == version.encode():
                try:
                    record = json.loads(parts[i + 1])
                except (ValueError, UnicodeError):
                    continue
                if record.get('name') == name and record.get('vers') == version:
                    matches.append(record)
        C.require(len(matches) == 1 and matches[0].get('cksum') == checksum, 'locked_sparse_record_mismatch')
        if str(relative) not in index_pins:
            output = target_index / relative
            output.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
            C.durable(output, raw)
            index_pins[str(relative)] = C.pin(output)
        filename = name + '-' + version + '.crate'
        original = caches[0] / filename
        if not original.exists():
            missing.append(filename)
            continue
        C.regular(original, maximum=64 * 1024**2)
        data = original.read_bytes()
        C.require(hashlib.sha256(data).hexdigest() == checksum, 'public_crate_checksum_mismatch')
        total += len(data)
        C.require(total <= 2 * 1024**3, 'cache_copy_limit')
        C.durable(target_cache / filename, data)
        copied.append({'name': filename, 'bytes': len(data), 'sha256': checksum})
    C.pin(result_path, binding['p0_terminal_result'])
    result = {'scope': 'only_exact_3ada_lock_public_registry_archives_and_sparse_metadata',
              'network': False, 'global_Cargo_home_read': False, 'credentials_or_global_config_read': False,
              'P0_target_accessed': False, 'private_target_initially_empty': True,
              'missing_archives': missing, 'copied_archives': copied, 'sparse_index_pins': index_pins,
              'P0_result_status': previous['status'], 'P0_result_is_not_test_qualification': True}
    C.publish(ROOT / 'cache-preparation.public.json', result)
    return {'copied_archives_count': len(copied), 'missing_archives': missing,
            'receipt': C.pin(ROOT / 'cache-preparation.public.json')}


def execute(C, binding, binding_sha, prepared_sha, producer_terminal_confirmed):
    # An explicit separate invocation makes formatting review the last gate before build.
    C.require(producer_terminal_confirmed, 'P0_producer_terminal_confirmation_required')
    C.require(prepared_sha is not None and re.fullmatch(r'[0-9a-f]{64}', prepared_sha), 'prepare_receipt_sha_required')
    C.require(C.sha(ROOT / 'prepare.public.json') == prepared_sha, 'prepare_receipt_pin_mismatch')
    prepared = json.loads((ROOT / 'prepare.public.json').read_bytes())
    C.require(prepared['status'] == 'prepared_only_no_rust_execution'
              and prepared['bindings_sha256'] == binding_sha, 'prepare_stage_not_accepted')
    C.durable(ROOT / 'run.started', b'one explicit red-green attempt; never retry this workroot\n')
    logs = ROOT / 'run-private-logs'; logs.mkdir(mode=0o700)
    temporary = ROOT / 'private-tmp'
    env = environment(C, temporary)
    report = {'schema': 'heptabao.consistency-four-test-red-green.v1', 'status': 'running',
              'controller_sha256': C.sha(Path(__file__).resolve()), 'bindings_sha256': binding_sha,
              'prepared_receipt_sha256': prepared_sha, 'source_commit': binding['source']['commit'],
              'source_tree': binding['source']['tree'], 'full_ci_run': False, 'retries': 0,
              'CARGO_TARGET_DIR_is_new_private': True, 'CARGO_HOME_is_new_private': True,
              'P0_source_target_and_cache_modified': False, 'network_fetch': False,
              'api_client_proxy_live_profile_executed': False, 'original_CI_results_changed': False,
              'existing_original_503_body_repackaging_not_fixed': True,
              'resource_combination': {'memory_max_bytes': 17179869184, 'cpu_quota_percent': 400, 'cargo_build_jobs': 1},
              'prior_8GiB_attempt_preserved_as_failed': True,
              'prior_16GiB_single_CPU_attempt_preserved_as_failed': True, 'phases': []}
    result = 1
    started = time.monotonic()
    try:
        C.pin(SOURCE_INPUTS / '3ada.manifest.json', binding['source']['manifest'])
        manifest = json.loads((SOURCE_INPUTS / '3ada.manifest.json').read_bytes())
        source = ROOT / 'source'
        green = ROOT / 'formatted-green-source'
        runner = ROOT / 'runner'
        C.pin(runner / 'run_targeted.py', prepared['runner'])
        C.pin(runner / 'controller_common.py', prepared['runner_common'])
        C.pin(runner / 'runtime-bindings.json', prepared['runner_runtime_bindings'])
        C.pin(runner / 'source-bindings.json', prepared['formatted_bindings'])
        phases = json.loads((runner / 'source-bindings.json').read_bytes())
        for name, expected in prepared['toolchain'].items():
            C.pin(TOOL / name, expected)
        for phase, state, tree in (('red', 'tests-only', source), ('green', 'candidate', green)):
            check_phase_input(C, tree, phases['states'][state], manifest, env)
            C.require(C.rows_digest(C.inventory(tree)) == prepared['phases'][phase]['full_source_rows_sha256'], 'formatted_full_source_pin_mismatch')
        C.require(shutil.disk_usage(ROOT).free >= 20 * 1024**3, 'insufficient_private_build_space')
        report['aggregate_memory_before_build'] = aggregate_memory()
        C.require(report['aggregate_memory_before_build']['bytes']['MemAvailable'] >= 16 * 1024**3, 'available_memory_below_16GiB_attempt_cap')
        report['public_cache_copy'] = prepare_private_cache(C, source, ROOT / 'cargo-home', binding)
        target = ROOT / 'target'; target.mkdir(mode=0o700, exist_ok=False)
        C.require(not any(target.iterdir()), 'target_not_initially_empty')
        for phase, state in (('red', 'tests-only'), ('green', 'candidate')):
            if phase == 'green':
                check_phase_input(C, source, phases['states']['tests-only'], manifest, env)
                check_phase_input(C, green, phases['states']['candidate'], manifest, env)
                for path in FILES:
                    C.replace_owned(source / path, (green / path).read_bytes())
            identity = check_phase_input(C, source, phases['states'][state], manifest, env)
            C.require(C.rows_digest(C.inventory(source)) == prepared['phases'][phase]['full_source_rows_sha256'], 'phase_full_source_pin_mismatch')
            remaining = 2700 - (time.monotonic() - started)
            C.require(remaining > 0, 'controller_deadline')
            evidence = ROOT / (phase + '-private-evidence')
            command = C.run_owned(phase, ['/usr/bin/python3', '-I', '-B', str(runner / 'run_targeted.py'),
                '--phase', phase, '--repo', str(source), '--evidence', str(evidence), '--target-dir', str(target)],
                cwd=source, env=env, log_dir=logs, timeout=min(1200, remaining), allow_nonzero=True)
            C.regular(evidence / 'result.json', maximum=1024**2)
            actual = json.loads((evidence / 'result.json').read_bytes())
            after = check_phase_input(C, source, phases['states'][state], manifest, env)
            expected = set(binding['expected_rust_tests'])
            observed = actual.get('observed_outcomes', {})
            allowed = {name: value for name, value in observed.items() if name in expected and value in ('ok', 'FAILED')}
            accepted = (command['exit_code'] == 0 and actual.get('rust_tests_executed') is True
                        and actual.get('expected_regression_behavior_observed') is True
                        and set(actual.get('discovered_tests', [])) == expected and set(allowed) == expected
                        and identity == after)
            item = {'phase': phase, 'command': command, 'accepted': accepted,
                    'source_before': identity, 'source_after': after,
                    'tests_executed': actual.get('rust_tests_executed') is True,
                    'four_expected_tests_discovered': set(actual.get('discovered_tests', [])) == expected,
                    'observed_outcomes': allowed, 'private_runner_result': C.pin(evidence / 'result.json')}
            if phase == 'red':
                item['missing_hint_assertion_observed'] = actual.get('red_missing_hint_assertion_seen') is True
                accepted = accepted and item['missing_hint_assertion_observed']
                item['accepted'] = accepted
            report['phases'].append(item)
            C.require(accepted, 'real_targeted_regression_result_not_expected')
        report['status'] = 'observed_expected_red_and_all_four_green'
        result = 0
    except BaseException as error:
        report['status'] = 'failed'
        report['failure_class'] = type(error).__name__
        report['failure_code'] = str(error) if isinstance(error, C.Blocked) else 'unexpected_controller_exception'
    finally:
        report['duration_seconds'] = round(time.monotonic() - started, 3)
        report['finished_unix_ns'] = time.time_ns()
        C.publish(ROOT / 'run.public.json', report)
        print(json.dumps({'status': report['status'], 'completed_regression_phases': len(report['phases']),
                          'run_receipt_sha256': C.sha(ROOT / 'run.public.json')}, sort_keys=True))
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=('prepare', 'run'))
    parser.add_argument('--bindings-sha256', required=True)
    parser.add_argument('--prepared-sha256')
    parser.add_argument('--p0-producer-terminal-confirmed', action='store_true')
    args = parser.parse_args()
    path = HERE / 'bindings.public.json'
    if hashlib.sha256(path.read_bytes()).hexdigest() != args.bindings_sha256:
        raise RuntimeError('bindings_pin_mismatch')
    binding = json.loads(path.read_bytes())
    C = common(binding['controller_common']['sha256'])
    C.pin(Path(__file__).resolve(), binding['consistency_controller'])
    C.install_cancellation()
    os.umask(0o077)
    resource.setrlimit(resource.RLIMIT_FSIZE, (1024**3, 1024**3))
    resource.setrlimit(resource.RLIMIT_NOFILE, (4096, 4096))
    if args.stage == 'prepare':
        return prepare(C, binding, args.bindings_sha256)
    return execute(C, binding, args.bindings_sha256, args.prepared_sha256, args.p0_producer_terminal_confirmed)


if __name__ == '__main__':
    raise SystemExit(main())
