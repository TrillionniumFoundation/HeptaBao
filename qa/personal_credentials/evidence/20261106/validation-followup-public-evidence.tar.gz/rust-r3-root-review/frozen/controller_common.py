#!/usr/bin/env python3
"""Small explicit primitives shared by two isolated, reviewed controllers."""
from pathlib import Path, PurePosixPath
import ctypes
import hashlib
import json
import os
import signal
import stat
import subprocess
import tarfile
import time


class Blocked(RuntimeError):
    pass


class ControllerCancelled(BaseException):
    pass


def install_cancellation():
    def cancel(number, frame):
        # One cancellation enters bounded cleanup; repeated TERM/INT/HUP must
        # not interrupt the original-handle wait half way through cleanup.
        for item in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
            signal.signal(item, signal.SIG_IGN)
        raise ControllerCancelled('controller_cancelled')
    for item in (signal.SIGTERM, signal.SIGINT, signal.SIGHUP):
        signal.signal(item, cancel)


def require(value, code):
    if not value:
        raise Blocked(code)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def regular(path, *, maximum=None):
    path = Path(path)
    info = path.lstat()
    require(path.is_absolute() and path.resolve() == path and stat.S_ISREG(info.st_mode)
            and info.st_nlink == 1, 'input_not_unique_regular_file')
    if maximum is not None:
        require(info.st_size <= maximum, 'input_too_large')
    return info


def pin(path, expected=None):
    info = regular(path)
    result = {'bytes': info.st_size, 'sha256': sha(path)}
    if expected is not None:
        require(all(result[key] == expected[key] for key in ('bytes', 'sha256')), 'input_pin_mismatch')
    return result


def durable(path, data, mode=0o600):
    path = Path(path)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def publish(path, value):
    durable(path, (json.dumps(value, sort_keys=True, indent=2) + '\n').encode())


def snapshot(path, value):
    """Atomically replace only an owned progress receipt; retain partial streams."""
    path = Path(path)
    if path.exists():
        regular(path)
    temporary = path.with_name(path.name + '.next-' + str(os.getpid()) + '-' + str(time.monotonic_ns()))
    durable(temporary, (json.dumps(value, sort_keys=True, indent=2) + '\n').encode())
    os.replace(temporary, path)
    fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


RECORDED_ENV = ('PATH', 'LANG', 'LC_ALL', 'TZ', 'TMPDIR', 'CARGO_HOME',
                'CARGO_NET_OFFLINE', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL',
                'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG',
                'CARGO_TARGET_DIR', 'RUSTC', 'RUSTFLAGS', 'RUSTDOCFLAGS',
                'CARGO_ENCODED_RUSTFLAGS', 'CARGO_ENCODED_RUSTDOCFLAGS',
                'BINDGEN_EXTRA_CLANG_ARGS')


def original_child_identity(child, *, pgid, sid):
    """Inspect only this just-created Popen child, before any wait/reap."""
    def read_stat():
        raw = Path('/proc') / str(child.pid) / 'stat'
        fields = raw.read_text().rsplit(')', 1)[1].split()
        return {'pid': child.pid, 'ppid': int(fields[1]), 'pgid': int(fields[2]),
                'sid': int(fields[3]), 'start_ticks': int(fields[19])}
    first = read_stat()
    second = read_stat()
    require(first == second and first['ppid'] == os.getpid()
            and first['pgid'] == pgid and first['sid'] == sid, 'original_child_identity_mismatch')
    return dict(first, clock_ticks_per_second=os.sysconf('SC_CLK_TCK'),
                boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip())


def safe_relative(value):
    require(isinstance(value, str) and value and '\n' not in value and '\0' not in value, 'invalid_relative_path')
    path = PurePosixPath(value)
    require(not path.is_absolute() and str(path) == value and '..' not in path.parts
            and '.git' not in path.parts, 'invalid_relative_path')
    return path


def base_env(tmp):
    return {
        'PATH': '/usr/local/bin:/usr/bin:/bin',
        'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8', 'TZ': 'UTC',
        'TMPDIR': str(tmp), 'PYTHONDONTWRITEBYTECODE': '1',
        'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0',
        'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_CONFIG_SYSTEM': '/dev/null',
        'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_COUNT': '0',
        'GIT_ALLOW_PROTOCOL': '',
    }


def git(repo, env, *args, stdin=None):
    command = ['/usr/bin/git', '-c', 'core.hooksPath=/dev/null', '-c', 'protocol.allow=never',
               '-c', 'core.autocrlf=false', '-c', 'core.filemode=true', '-C', str(repo), *args]
    value = subprocess.run(command, input=stdin, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           env=env, timeout=60)
    require(value.returncode == 0, 'local_git_operation_failed')
    return value.stdout


def rows_digest(rows):
    return hashlib.sha256((json.dumps(rows, sort_keys=True, separators=(',', ':')) + '\n').encode()).hexdigest()


def inventory(source):
    source = Path(source)
    rows = []
    for root, dirs, files in os.walk(source, followlinks=False):
        root = Path(root)
        if root == source and '.git' in dirs:
            require(not (root / '.git').is_symlink(), 'source_git_symlink')
            dirs.remove('.git')
        for name in dirs:
            require(not (root / name).is_symlink(), 'source_directory_symlink')
        for name in files:
            path = root / name
            info = regular(path)
            relative = path.relative_to(source).as_posix()
            safe_relative(relative)
            require(stat.S_IMODE(info.st_mode) in (0o600, 0o700), 'source_file_mode_mismatch')
            rows.append({'path': relative, 'bytes': info.st_size, 'sha256': sha(path),
                         'git_mode': '100755' if info.st_mode & 0o111 else '100644'})
    return sorted(rows, key=lambda row: row['path'])


def expected_rows(manifest, overlays=()):
    rows = {row['path']: {key: row[key] for key in ('path', 'bytes', 'sha256', 'git_mode')}
            for row in manifest['files']}
    for overlay in overlays:
        rows[overlay['path']] = {key: overlay[key] for key in ('path', 'bytes', 'sha256', 'git_mode')}
    return [rows[path] for path in sorted(rows)]


def verify_source(source, manifest, rows, env, expected_dirty):
    require(inventory(source) == rows, 'full_source_inventory_mismatch')
    require(git(source, env, 'rev-parse', 'HEAD').decode().strip() == manifest['commit'], 'source_head_mismatch')
    require(git(source, env, 'rev-parse', 'HEAD^{tree}').decode().strip() == manifest['tree'], 'source_tree_mismatch')
    require(git(source, env, 'rev-parse', '--is-shallow-repository').strip() == b'true', 'source_shallow_boundary_missing')
    require((source / '.git/shallow').read_text() == manifest['commit'] + '\n', 'source_shallow_boundary_mismatch')
    changed = set(git(source, env, 'diff', '--name-only', 'HEAD', '--').decode().splitlines())
    untracked = set(git(source, env, 'ls-files', '--others', '--exclude-standard').decode().splitlines())
    require(changed | untracked == set(expected_dirty), 'source_change_set_mismatch')
    return {'commit': manifest['commit'], 'tree': manifest['tree'], 'shallow': True,
            'source_files': len(rows), 'source_content_sha256': rows_digest(rows),
            'changed_files': sorted(expected_dirty)}


def reconstruct(archive, raw_commit_path, manifest, destination, env):
    """Recreate a genuine original commit with a disclosed shallow boundary."""
    pin(archive, manifest['archive'])
    pin(raw_commit_path, manifest['raw_commit'])
    raw_commit = Path(raw_commit_path).read_bytes()
    require(raw_commit.startswith(('tree ' + manifest['tree'] + '\n').encode()), 'raw_commit_tree_mismatch')
    require(hashlib.sha1(b'commit ' + str(len(raw_commit)).encode() + b'\0' + raw_commit).hexdigest()
            == manifest['commit'], 'raw_commit_object_mismatch')
    destination.mkdir(mode=0o700, exist_ok=False)
    entries = {row['path']: row for row in manifest['files']}
    require(len(entries) == manifest['file_count'] and len(entries) <= 10000, 'source_entry_count_invalid')
    seen = set()
    total = 0
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar.getmembers():
            name = member.name.rstrip('/') if member.isdir() else member.name
            relative = safe_relative(name)
            target = destination.joinpath(*relative.parts)
            if member.isdir():
                target.mkdir(parents=True, exist_ok=True, mode=0o700)
                continue
            require(member.isfile() and name in entries and name not in seen, 'archive_member_not_expected_regular')
            row = entries[name]
            require(member.size == row['bytes'] and 0 <= member.size <= 64 * 1024**2, 'archive_member_size_mismatch')
            require(bool(member.mode & 0o111) == (row['git_mode'] == '100755'), 'archive_member_mode_mismatch')
            data = tar.extractfile(member).read(member.size + 1)
            require(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], 'archive_member_digest_mismatch')
            require(hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_blob'], 'archive_git_blob_mismatch')
            total += len(data)
            require(total <= 512 * 1024**2, 'source_expanded_limit')
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            durable(target, data, 0o700 if row['git_mode'] == '100755' else 0o600)
            seen.add(name)
    require(seen == set(entries) and total == manifest['expanded_bytes'], 'archive_source_set_mismatch')
    require(inventory(destination) == expected_rows(manifest), 'extracted_source_inventory_mismatch')
    git(destination, env, 'init', '--quiet', '--template=')
    git(destination, env, 'add', '--force', '--all', '--', '.')
    require(git(destination, env, 'write-tree').decode().strip() == manifest['tree'], 'reconstructed_git_tree_mismatch')
    require(git(destination, env, 'hash-object', '-t', 'commit', '-w', '--stdin', stdin=raw_commit).decode().strip()
            == manifest['commit'], 'reconstructed_git_commit_mismatch')
    durable(destination / '.git/shallow', (manifest['commit'] + '\n').encode())
    git(destination, env, 'update-ref', 'HEAD', manifest['commit'])
    git(destination, env, 'fsck', '--full', '--no-reflogs', '--no-dangling')
    return verify_source(destination, manifest, expected_rows(manifest), env, ())


def extract_selected(archive, expected_pin, files, destination):
    """Only named, digest-bound source artifacts are extracted, never fixtures."""
    pin(archive, expected_pin)
    destination.mkdir(mode=0o700, exist_ok=False)
    wanted = {row['member']: row for row in files}
    require(len(wanted) == len(files), 'duplicate_overlay_member')
    seen = set()
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar.getmembers():
            if member.name not in wanted:
                continue
            require(member.isfile() and member.name not in seen, 'overlay_member_invalid')
            row = wanted[member.name]
            relative = safe_relative(row['path'])
            require(member.size == row['bytes'] and member.size <= 4 * 1024**2, 'overlay_member_size_mismatch')
            data = tar.extractfile(member).read(member.size + 1)
            require(len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], 'overlay_member_digest_mismatch')
            path = destination.joinpath(*relative.parts)
            path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            durable(path, data, 0o700 if row.get('git_mode') == '100755' else 0o600)
            seen.add(member.name)
    require(seen == set(wanted), 'overlay_member_missing')


def replace_owned(path, data):
    """Replace one admitted file inside our new root; never follow a link."""
    path = Path(path)
    before = regular(path)
    fd = os.open(path, os.O_WRONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'wb') as stream:
        now = os.fstat(stream.fileno())
        require((now.st_dev, now.st_ino, now.st_nlink) == (before.st_dev, before.st_ino, 1), 'owned_file_changed_before_replace')
        stream.truncate(0)
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def enable_child_subreaper():
 # Linux prctl.h: process-local adoption, not a host/global service setting.
 libc=ctypes.CDLL(None,use_errno=True)
 value=ctypes.c_int()
 if libc.prctl(36,1,0,0,0)!=0 or libc.prctl(37,ctypes.byref(value),0,0,0)!=0 or value.value!=1:
  raise RuntimeError('child_subreaper_unavailable')
 return True


def observe_original_unreaped(child, identity):
    """WNOWAIT leaves the original PID/group anchor allocated until cleanup ends."""
    require(original_child_identity(child, pgid=child.pid, sid=child.pid) == identity,
            'original_group_anchor_identity_changed')
    try:
        return os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
    except ChildProcessError:
        raise Blocked('original_group_anchor_already_reaped') from None


def own_group_children(child, identity):
    """Only this controller's direct/adopted children; no host process scan."""
    observe_original_unreaped(child, identity)
    pids = (Path('/proc/self/task') / str(os.getpid()) / 'children').read_text().split()
    require(len(pids) <= 4096 and all(pid.isdigit() for pid in pids), 'owned_children_metadata_invalid')
    rows = []
    for value in pids:
        pid = int(value)
        if pid == child.pid:
            continue
        fields = (Path('/proc') / value / 'stat').read_text().rsplit(')', 1)[1].split()
        item = {'pid': pid, 'state': fields[0], 'ppid': int(fields[1]),
                'pgid': int(fields[2]), 'sid': int(fields[3]), 'start_ticks': int(fields[19])}
        require(item['ppid'] == os.getpid(), 'owned_child_reparented_during_observation')
        if item['pgid'] == child.pid:
            require(item['sid'] == child.pid, 'owned_group_session_mismatch')
            rows.append(item)
    return rows


def reap_owned_adopted_zombies(child, row, identity):
    # Exact admitted adopted PIDs only; never waitpid(-pgid), which could consume
    # the original leader before all group signals have finished.
    for item in own_group_children(child, identity):
        if item['state'] not in ('Z', 'X'):
            continue
        pid, status = os.waitpid(item['pid'], os.WNOHANG)
        if pid == 0:
            row['adopted_waitpid_not_ready_count'] = row.get('adopted_waitpid_not_ready_count', 0) + 1
            continue
        require(pid == item['pid'], 'owned_adopted_zombie_not_reaped')
        row.setdefault('adopted_descendants_reaped', []).append(dict(item, wait_status=status))


def close_owned_group(child, row):
    """Retain the leader until the final group signal and adopted-child reap."""
    identity = row.get('child_identity')
    require(identity is not None, 'original_group_anchor_identity_missing')
    leader = observe_original_unreaped(child, identity)
    descendants = own_group_children(child, identity)
    row.setdefault('cleanup_needed', False)
    if leader is None or descendants:
        row['cleanup_needed'] = True
        for sig in (signal.SIGTERM, signal.SIGKILL):
            reap_owned_adopted_zombies(child, row, identity)
            leader = observe_original_unreaped(child, identity)
            descendants = own_group_children(child, identity)
            if leader is not None and not descendants:
                break
            # A successful WNOWAIT observation plus matching original stat is a
            # prerequisite for every signal; no bare numeric PGID fallback.
            observe_original_unreaped(child, identity)
            os.killpg(child.pid, sig)
            row.setdefault('cleanup_signals', []).append(int(sig))
            until = time.monotonic() + 5
            while time.monotonic() < until:
                reap_owned_adopted_zombies(child, row, identity)
                leader = observe_original_unreaped(child, identity)
                if leader is not None and not own_group_children(child, identity):
                    break
                time.sleep(.02)
    reap_owned_adopted_zombies(child, row, identity)
    leader = observe_original_unreaped(child, identity)
    require(leader is not None and not own_group_children(child, identity), 'owned_process_group_cleanup_incomplete')
    row['original_leader_exit_observed_unreaped'] = True
    row['group_signals_only_before_original_leader_reap'] = True
    # The one original Popen wait happens last. No group signal or group probe
    # uses the now-reusable numeric PGID after this point.
    row['exit_code'] = child.wait(timeout=.1)
    row['reaped'] = child.returncode is not None
    row['descendant_group_absent'] = True
    row['group_absence_basis'] = 'held_original_exited_leader_and_no_matching_direct_or_adopted_owned_children_before_final_reap'


def run_owned(label, argv, *, cwd, env, log_dir, timeout, allow_nonzero=False):
    """Persist startup/streams and close only the original new-session group."""
    stdout = log_dir / (label + '.stdout.private')
    stderr = log_dir / (label + '.stderr.private')
    row = {'label': label, 'timeout_seconds': timeout, 'timed_out': False, 'started': False,
           'cleanup_needed': False, 'reaped': False, 'descendant_group_absent': False,
           'argv': list(map(str, argv)), 'environment': {key: env[key] for key in RECORDED_ENV if key in env},
           'child_subreaper_enabled': enable_child_subreaper()}
    child = None
    pending = None
    started = time.monotonic()
    try:
        with stdout.open('xb') as out, stderr.open('xb') as err:
            try:
                child = subprocess.Popen(list(map(str, argv)), cwd=cwd, env=env,
                                         stdin=subprocess.DEVNULL, stdout=out, stderr=err, start_new_session=True)
                row['started'] = True
                row['child_identity'] = original_child_identity(child, pgid=child.pid, sid=child.pid)
                publish(log_dir / (label + '.started.public.json'), row)
                deadline = time.monotonic() + timeout
                while observe_original_unreaped(child, row['child_identity']) is None:
                    if time.monotonic() >= deadline:
                        row['timed_out'] = True
                        break
                    time.sleep(.05)
            except BaseException as error:
                pending = error
                row['interrupted_by'] = type(error).__name__
            finally:
                if child is not None:
                    try:
                        close_owned_group(child, row)
                    except BaseException as error:
                        row['cleanup_failure_class'] = type(error).__name__
                        if pending is None:
                            pending = error
                out.flush()
                err.flush()
                os.fsync(out.fileno())
                os.fsync(err.fileno())
    finally:
        row['duration_seconds'] = round(time.monotonic() - started, 3)
        for key, path in (('stdout', stdout), ('stderr', stderr)):
            if path.exists():
                row[key] = pin(path)
        publish(log_dir / (label + '.command.public.json'), row)
    if pending is not None:
        raise pending
    require(not row['timed_out'] and not row['cleanup_needed'] and row['reaped']
            and row['descendant_group_absent'], 'command_deadline_or_cleanup_failed')
    if not allow_nonzero:
        require(row.get('exit_code') == 0, 'command_nonzero_exit')
    return row
