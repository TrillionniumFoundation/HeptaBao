import datetime, hashlib, json, subprocess
unit = "hepta-runtime-job-1a1b3290ce3-fc05-80db.service"
fields = ["LoadState", "ActiveState", "SubState", "CPUQuotaPerSecUSec", "CPUQuotaPeriodUSec", "CPUUsageNSec", "MemoryMax", "MemoryCurrent", "TasksCurrent"]
argv = ["/usr/bin/systemctl", "--user", "show", unit, "--property=" + ",".join(fields), "--no-pager"]
result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10, check=False)
assert len(result.stdout) <= 8192 and len(result.stderr) <= 8192
properties = {}
for line in result.stdout.decode("utf-8").splitlines():
    key, sep, value = line.partition("=")
    assert sep and key in fields and key not in properties
    properties[key] = value
report = {"schema": 1, "unit": unit, "sampled_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "command": argv, "command_exit_code": result.returncode, "properties": properties, "stderr_bytes": len(result.stderr), "stderr_sha256": hashlib.sha256(result.stderr).hexdigest(), "service_mutation": False, "process_signals": False, "global_process_inventory": False, "product_tests_executed": False}
print(json.dumps(report, sort_keys=True))
raise SystemExit(0 if result.returncode == 0 and set(properties) == set(fields) else 1)
