import hashlib, json, os, pathlib, signal, stat, subprocess, time

ROOT = pathlib.Path('/home/qq/heptabao-broker-poll-lint-20261106-r1')
BASE = pathlib.Path('/home/qq/heptabao-broker-poll-fix-20261106-r2')
SRC = BASE / 'source'
TOOLS = pathlib.Path('/home/qq/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin')
MANIFEST_SHA = 'eca73dbfc54eceef2b2b193053812dfaae695fda53c4d477a37e5047ba734423'
LOCK_SHA = 'ef3b19cf8b1b360f7888f11e3e5b1523e464762d6c24ce7e92b64d0d7d5c99a9'
BINARY_SHA = '6f9324480fb9e9f9ce08a182cd9822d5236cb866146578d5851845719319d9f5'
EXPECTED = {
    'crates/heptabao-credential-broker/Cargo.toml': '0f281abd2fb8ee3d37250a5d7d93bba92aa9089b0e49732a7bdbee8ba5b17ad6',
    'crates/heptabao-credential-broker/src/lib.rs': '3617799f6de0368fa3b4b4c1343510fe9d202ee3a31fc0e067eb312c40732001',
    'crates/heptabao-credential-broker/src/frame_read_tests.rs': '2a203ee7ca0e4c8f9b878abb0727374a57e3f977dc3a09e1d8cad5ed3a5b9fc7',
}

def require(ok, code):
    if not ok:
        raise RuntimeError(code)

def read(path, cap=256*1024*1024):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_size <= cap, 'nonregular_or_large_input')
        parts = []
        remaining = before.st_size
        while remaining:
            block = os.read(fd, min(1024*1024, remaining))
            require(bool(block), 'short_input')
            parts.append(block); remaining -= len(block)
        after = os.fstat(fd)
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_ctime_ns) ==
                (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_ctime_ns), 'input_changed')
        return b''.join(parts)
    finally:
        os.close(fd)

def meta(path):
    data = read(path)
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def create(name, data):
    fd = os.open(ROOT/name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        with os.fdopen(fd, 'wb', closefd=False) as stream:
            stream.write(data); stream.flush(); os.fsync(stream.fileno())
    finally:
        os.close(fd)

def snapshot():
    rows = []
    for path in sorted(SRC.rglob('*')):
        require(not path.is_symlink(), 'source_symlink')
        if path.is_file():
            require(len(rows) < 20000, 'source_count_limit')
            rows.append({'path': str(path.relative_to(SRC)), **meta(path)})
    return rows

os.umask(0o077)
ROOT.mkdir(mode=0o700)
create('controller.actual.py', SOURCE_BYTES)
report = {'schema': 1, 'scope': 'linux_broker_exact_existing_repaired_source_format_and_strict_clippy',
          'source_baseline_commit': 'c447536ae0343731d84c18291d2dcd712b3bea08',
          'source_overlay_sha256': EXPECTED, 'started_unix_ns': time.time_ns(), 'commands': [],
          'functional_tests_executed': 0, 'product_invocations': 0, 'phone_calls': 0,
          'prior_19_tests_inherited_as_new_execution': False, 'production_qualified': False,
          'external_security_review': False, 'source_manifest_sha256': MANIFEST_SHA,
          'controller': meta(ROOT/'controller.actual.py'), 'result': 'failed'}
environment = {
    'PATH': str(TOOLS)+':/usr/local/bin:/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LC_ALL': 'C.UTF-8',
    'CARGO_HOME': str(BASE/'cargo-home'), 'CARGO_TARGET_DIR': str(BASE/'target'),
    'CARGO_NET_OFFLINE': 'true', 'CARGO_BUILD_JOBS': '2', 'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0',
    'RUSTC': str(TOOLS/'rustc'), 'RUSTDOC': str(TOOLS/'rustdoc'), 'RUST_BACKTRACE': '0',
    'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null', 'GIT_OPTIONAL_LOCKS': '0',
    'GIT_TERMINAL_PROMPT': '0', 'TMPDIR': '/tmp',
}
def command(label, argv, timeout):
    item = {'label': label, 'argv': argv, 'cwd': str(SRC), 'environment': environment,
            'timeout_seconds': timeout, 'timed_out': False, 'started_unix_ns': time.time_ns()}
    started = time.monotonic_ns()
    out = ROOT/(label+'.stdout.original'); err = ROOT/(label+'.stderr.original')
    with out.open('xb') as stdout, err.open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=SRC, env=environment, stdin=subprocess.DEVNULL,
                                 stdout=stdout, stderr=stderr, start_new_session=True)
        item['owned_pid'] = child.pid
        try:
            item['exit_code'] = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            item['timed_out'] = True
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            item['exit_code'] = child.wait()
        item['owned_top_level_process_reaped'] = child.returncode is not None
        stdout.flush(); stderr.flush(); os.fsync(stdout.fileno()); os.fsync(stderr.fileno())
    item.update(elapsed_ns=time.monotonic_ns()-started,
                stdout={'file': out.name, **meta(out)}, stderr={'file': err.name, **meta(err)})
    report['commands'].append(item)
    require(out.stat().st_size <= 8*1024*1024 and err.stat().st_size <= 8*1024*1024, 'post_command_output_limit')
    require(item['exit_code'] == 0 and not item['timed_out'], 'command_failed_'+label)

try:
    manifest_raw = read(BASE/'candidate-source.manifest.public.json', 2*1024*1024)
    require(hashlib.sha256(manifest_raw).hexdigest() == MANIFEST_SHA, 'source_manifest_identity')
    expected_rows = json.loads(manifest_raw)['files']
    before = snapshot(); require(before == expected_rows, 'source_before_mismatch')
    report['source_file_count'] = len(before)
    require(meta(SRC/'Cargo.lock')['sha256'] == LOCK_SHA, 'lock_mismatch')
    for relative, digest in EXPECTED.items():
        require(meta(SRC/relative)['sha256'] == digest, 'overlay_mismatch')
    binary_before = meta(BASE/'bin-qualified/heptabao-credential-broker')
    require(binary_before['sha256'] == BINARY_SHA, 'qualified_binary_mismatch')
    report['qualified_binary_before'] = binary_before
    report['tools'] = {name: {'path': str(TOOLS/name), **meta(TOOLS/name)}
                       for name in ('cargo', 'rustc', 'cargo-clippy', 'clippy-driver', 'cargo-fmt', 'rustfmt')}
    require(report['tools']['cargo']['sha256'] == 'ff3022fcbd13b08434ea7afde9a0ef9d5b3f5c17b5fc7a40031be3ee000a6a24', 'cargo_identity')
    require(report['tools']['rustc']['sha256'] == '3690cc576ede140504698405d5d8fa3826aaadbe71699c6c4ed0a565d6f493e2', 'rustc_identity')
    command('format', [str(TOOLS/'cargo'), 'fmt', '-p', 'heptabao-credential-broker', '--', '--check'], 120)
    command('strict-clippy', [str(TOOLS/'cargo'), 'clippy', '--locked', '--offline', '-p',
                            'heptabao-credential-broker', '--all-targets', '--', '-D', 'warnings'], 600)
    require(snapshot() == before, 'source_after_mismatch')
    after = meta(BASE/'bin-qualified/heptabao-credential-broker')
    require(after == binary_before, 'qualified_binary_changed')
    report.update(result='passed', source_unchanged=True, qualified_binary_unchanged=True,
                  qualified_binary_after=after)
except Exception as error:
    report['error_type'] = type(error).__name__
    report['error_code'] = str(error) if isinstance(error, RuntimeError) else 'io_or_preparation_error'
finally:
    report['finished_unix_ns'] = time.time_ns()
    create('receipt.public.json', (json.dumps(report, sort_keys=True, indent=2)+'\n').encode())
    print(json.dumps({'result': report['result'], 'receipt': str(ROOT/'receipt.public.json'),
                      'receipt_sha256': meta(ROOT/'receipt.public.json')['sha256'],
                      'commands': len(report['commands']), 'functional_tests_executed': 0}), flush=True)
if report['result'] != 'passed':
    raise SystemExit(1)
