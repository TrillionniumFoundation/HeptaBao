# Validation follow-up aggregate 3

This aggregate preserves synthetic engineering evidence for explicitly bound source,
artifact, platform and resource combinations. It does not establish full OpenBao
compatibility, an independent security audit, production readiness, or a passing
full-CI result for a later commit. The top-level evidence index remains at 256
entries; this archive replaces the existing validation aggregate entry.

## Observed outcomes

| Execution | Actual outcome | Qualification boundary |
| --- | --- | --- |
| Historical OpenAPI follow-up | All 20 original checks passed | Historical `c27a0c22` server, exact five-file QA overlay on genuine shallow `3ada83a`, original 240-second budget. |
| Historical RADIUS renewal follow-up | Candidate and pinned OpenBao 2.6.2 each passed all 258 checks with matching results | Original 180-second budget and original cases; intentional-crash ownership and cleanup reporting were repaired. |
| Historical Kubernetes renewal follow-up | Candidate passed 16 observations and failed observation 17; the oracle passed all 101 | Candidate returned 403 with another provider request after assertion expiry; the oracle returned 200 without it. The 2.6.2 mismatch remains. Current source requires fresh TokenReview; this is not a new 2.7.1 qualification. |
| Exact base/candidate rolling | All 49 original scenarios passed | Independently bound `8f3dd835` base and freshly compiled `3ada83a` candidate, private loopback fixture, original 480-second budget. |
| Same-version membership | All 41 original scenarios passed | Exact newly built `3ada83a` candidate, five-process native pre-enrolled loopback fixture, original 360-second budget. |
| Rust attempt 1 | No completed discovery or test result | The exact unit journal records OOM; Runtime retained cancelled/exit one. The original owned-group cleanup was not established. |
| Rust attempt 2 | Cold compilation reached the 1,200-second phase limit; zero tests executed | The original outer cleanup failed at a non-waitable adopted-child boundary. The inner Cargo child being reaped did not establish outer-group cleanup. |
| Rust attempt 3 | Cold compilation again reached the 1,200-second phase limit; zero tests executed | Sixteen actual waitpid deferrals were followed by child and owned-group cleanup. Timeout cleanup is retained; the failed compilation is not an expected red regression. |
| Rust attempt 4 | Actual red: the normal-429 GET hint assertion failed and three controls passed; actual green: all four original tests passed | Exact three-file formatted overlay on `3ada83a`, separately successful compilations, unchanged 1,200-second test budget and unchanged source/test-artifact identities. Four library regressions only; no full CI or new server/API/client/proxy qualification. |

These denominators are separate profiles. Host controls, root repetitions, compile
commands, process-cleanup controls and read-only resource observations are not
added to product-test totals. The rolling and membership snapshot framing checks
do not qualify archive authenticity or backup restore. Membership's actual
prejoin-purge observation is distinct from the narrower download-helper receipt.

## Source and execution identity

The source manifests, exact patches, genuine original Git commit/tree records,
shallow boundaries, actual requests, original tool text, terminal records and full
profile output are retained in the indexed packets. Original tool text is saved
before JSON parsing, including integer identities that exceed JavaScript's exact
integer range. A recorded tool-result wrapper is not represented as a raw network
packet.

The r4 pipeline separates `cargo test --no-run` from the original discovery and
four-test runner. A successful compile alone is not a red or green test outcome.
Its new resource combination is CPU quota 400%, two Cargo build jobs and a 24 GiB
memory cap, with an observed available-memory precondition before each build.
That observation does not reserve memory or guarantee success. Each compile has
a separate 3,600-second budget; the original test budget remains 1,200 seconds.
Every stage requires the previous actual Runtime success, audit and complete
durable-output state, plus its exact accepted receipt SHA. Previous failed targets
are not reused. The original test assertions and formatted product source are
unchanged by the resource adjustment.

## Reading the aggregate

- `history/validation-followup-r2.original.tar.gz` preserves the exact previous
  2,331,946-byte archive, SHA-256
  `0b876832a3cc205c59256305e7cc04ae21829d2483e0723c7078067a6d9d1d73`.
- `followup-profiles/ci-live-and-consistency-r1-r3-history.public.tar.gz` preserves
  the fixed three-profile results and all three failed Rust attempts. Its own
  `qualified=false` outcome is not replaced by a later result.
- `followup-profiles/` also contains the complete rolling/membership follow-up,
  closed resource observations, backup receipts and bounded document reviews.
- `qa-repairs/` contains the separately counted host controls and repair sources.
- `rust-r2-root-review/`, `rust-r3-root-review/` and `rust-r4-root-review/` contain
  root-side frozen-source comparisons and independently read execution records.
- `followup-profiles/r4-separate-build-four-test-validation.public.tar.gz` contains the separately frozen r4 originals.

Earlier frozen plans and document snapshots retain their original pending states.
They are historical inputs, not current qualification statements. Final outcome
claims are tied to their corresponding actual terminal and full result records.

## Private data and remaining gates

Raw unit journals and complete tool wrappers containing those journals remain
private. Public records contain closed interpretations, numeric observations and
length/SHA references. No fixture directory, private key, Cargo cache or compiled
target is intentionally part of the admitted public packets. Internal peer review
covers the named source or exact archive admission set; it is not an external
security assessment.

The original `3ada83a` full head and prospective-merge jobs each had six failed
steps, and their final verdict failed. The original strict 2.7.0 policy-template
mismatch and head-only Transit connection closure remain recorded. A later commit
must receive its own CI observations; prior passes are not inherited.
