#!/usr/bin/env python3
"""One real exited leader with a live same-session descendant must fail/reap."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import time

p=argparse.ArgumentParser()
p.add_argument('--controller',required=True)
p.add_argument('--expected-controller-sha256',required=True)
p.add_argument('--output',required=True)
a=p.parse_args()
source=Path(a.controller).resolve(strict=True)
assert hashlib.sha256(source.read_bytes()).hexdigest()==a.expected_controller_sha256
spec=importlib.util.spec_from_file_location('actual_group_controller',source)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
root=Path(a.output).absolute();root.mkdir(mode=0o700,exist_ok=False)
m.ROOT=root;m.DEADLINE=time.monotonic()+30
assert m.enable_child_subreaper() is True
code="""import json,os,signal,sys
r,w=os.pipe()
pid=os.fork()
if pid==0:
 os.close(r)
 signal.signal(signal.SIGTERM,signal.SIG_IGN)
 os.write(w,b'R');os.close(w)
 while True:signal.pause()
os.close(w)
assert os.read(r,1)==b'R'
os.close(r)
print(json.dumps({'descendant_pid':pid}),flush=True)
raise SystemExit(7)
"""
started=time.monotonic()
error=None
try:
    m.command('exited-leader-live-descendant',[sys.executable,'-I','-B','-c',code],limit=3)
except RuntimeError as caught:
    error=str(caught)
finally:
    # Only the same actual Popen/created session is eligible for cleanup.
    for child in m.CHILDREN:
        m.close_owned_group(child,m.GROUP_ROWS[child.pid])
elapsed=time.monotonic()-started
assert error=='command_failed:exited-leader-live-descendant',error
assert len(m.COMMANDS)==1 and len(m.CHILDREN)==1
row=m.COMMANDS[0]
observed=json.loads((root/'exited-leader-live-descendant.stdout.original').read_bytes())
descendant=observed['descendant_pid']
assert row['exit_code']==7 and row['reaped'] is True and row['timed_out'] is False
assert row['cleanup_needed'] is True and row['descendant_group_absent'] is True
assert row['cleanup_signals']==[15,9]
assert any(x['pid']==descendant and os.waitstatus_to_exitcode(x['wait_status'])==-9 for x in row['adopted_descendants_reaped'])
assert not m.group_alive(row['owned_process_group'])
assert not Path('/proc',str(descendant)).exists()
assert elapsed<20
result={'schema':1,'scope':'actual_controller_command_one_real_owned_leader_and_descendant',
        'controller_sha256':a.expected_controller_sha256,'original_leader_exit':7,
        'command_failed_as_required':True,'TERM_then_KILL':[15,9],
        'direct_child_reaped':True,'adopted_descendant_reaped':True,'owned_group_absent':True,
        'elapsed_seconds':elapsed,'tests_run':1,'passed':True,'ADB_operations':0,
        'server_executions':0,'Cargo_executions':0,'network_operations':0}
m.publish('observation.public.json',result)
print(json.dumps(result,sort_keys=True))
