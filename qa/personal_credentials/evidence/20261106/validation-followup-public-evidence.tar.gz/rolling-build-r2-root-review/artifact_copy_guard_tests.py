#!/usr/bin/env python3
"""Exercise the real frozen controller copy function on private real files."""
import argparse
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import sys
import tempfile
import unittest
from unittest.mock import patch

parser=argparse.ArgumentParser()
parser.add_argument('--controller',required=True)
parser.add_argument('--expected-controller-sha256',required=True)
args=parser.parse_args()
controller=Path(args.controller).resolve(strict=True)
source_bytes=controller.read_bytes()
if hashlib.sha256(source_bytes).hexdigest()!=args.expected_controller_sha256:
    raise SystemExit('controller_sha256_mismatch')
spec=importlib.util.spec_from_file_location('actual_build_controller',controller)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

external_attempts=[]
def audit(event,values):
    if event.startswith('socket.') or event in ('subprocess.Popen','os.system','os.fork','os.exec','pty.spawn'):
        external_attempts.append(event)
        raise AssertionError('external_activity_forbidden')
sys.addaudithook(audit)

class ActualArtifactCopyControls(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='heptabao-owned-artifact-copy-')
        self.root=Path(self.tmp.name)
        self.root.chmod(0o700)
        self.target=self.root/'target'
        (self.target/'debug/deps').mkdir(mode=0o700,parents=True)
        self.source=self.target/'debug/heptabao-server'
        self.payload=(b'synthetic ELF stand-in, never executed\n'*32768)
        self.source.write_bytes(self.payload)
        self.source.chmod(0o700)
        self.alias=self.target/'debug/deps/heptabao-server-synthetic'
        os.link(self.source,self.alias)
        self.output_dir=self.root/'bin-qualified'
        self.output_dir.mkdir(mode=0o700)
        self.output=self.output_dir/'heptabao-server'
        self.sha=hashlib.sha256(self.payload).hexdigest()
        self.before_fds=len(list(Path('/proc/self/fd').iterdir()))

    def tearDown(self):
        self.assertEqual(len(list(Path('/proc/self/fd').iterdir())),self.before_fds)
        self.tmp.cleanup()

    def copy(self,**kwargs):
        options={'owned_target':self.target,'expected_sha256':self.sha,'expected_size':len(self.payload)}
        options.update(kwargs)
        return module.copy_cargo_artifact(self.source,self.output,**options)

    def test_01_original_regular_guard_still_rejects_real_two_link_file(self):
        self.assertEqual(self.source.stat().st_nlink,2)
        with self.assertRaises(AssertionError):
            module.regular(self.source,512*1024**2)
        self.assertFalse(self.output.exists())

    def test_02_real_two_link_input_copies_to_independent_synced_single_link(self):
        before=module.identity(self.source.stat())
        result=self.copy()
        self.assertEqual(result['sha256'],self.sha)
        self.assertEqual(result['source_link_count'],2)
        self.assertEqual(result['qualified_nlink'],1)
        self.assertTrue(result['qualified_file_and_directory_synced'])
        self.assertEqual(self.output.read_bytes(),self.payload)
        self.assertEqual(stat.S_IMODE(self.output.stat().st_mode),0o500)
        self.assertNotEqual(self.source.stat().st_ino,self.output.stat().st_ino)
        self.assertEqual(module.identity(self.source.stat()),before)
        module.regular(self.output,512*1024**2)

    def test_03_source_symlink_is_rejected_before_destination_creation(self):
        self.source.unlink()
        self.source.symlink_to(self.alias)
        with self.assertRaisesRegex(module.AdmissionError,'^cargo_output_symlink$'):
            self.copy()
        self.assertFalse(self.output.exists())

    def test_04_wrong_expected_content_hash_is_not_qualified(self):
        with self.assertRaisesRegex(module.AdmissionError,'^cargo_content_sha256$'):
            self.copy(expected_sha256='0'*64)
        self.assertEqual(stat.S_IMODE(self.output.stat().st_mode),0o600)
        self.assertEqual(self.source.read_bytes(),self.payload)

    def test_05_in_place_change_after_actual_read_is_rejected(self):
        real_read=os.read
        identity=(self.source.stat().st_dev,self.source.stat().st_ino)
        changed=[]
        def mutate(fd,count):
            block=real_read(fd,count)
            st=os.fstat(fd)
            if block and (st.st_dev,st.st_ino)==identity and not changed:
                # A real second descriptor changes a byte already read into the
                # first block. The copied digest alone would still match.
                with self.alias.open('r+b',buffering=0) as writer:
                    writer.seek(0);writer.write(b'X');os.fsync(writer.fileno())
                changed.append(True)
            return block
        with patch.object(module.os,'read',side_effect=mutate):
            with self.assertRaisesRegex(module.AdmissionError,'^cargo_input_changed$'):
                self.copy()
        self.assertEqual(changed,[True])
        self.assertEqual(stat.S_IMODE(self.output.stat().st_mode),0o600)

    def test_06_named_input_replacement_after_actual_read_is_rejected(self):
        replacement=self.target/'debug/replacement'
        replacement.write_bytes(self.payload);replacement.chmod(0o700)
        real_read=os.read
        original_inode=self.source.stat().st_ino
        changed=[]
        def replace(fd,count):
            block=real_read(fd,count)
            if block and os.fstat(fd).st_ino==original_inode and not changed:
                os.replace(replacement,self.source)
                changed.append(True)
            return block
        with patch.object(module.os,'read',side_effect=replace):
            with self.assertRaisesRegex(module.AdmissionError,'^cargo_input_changed$'):
                self.copy()
        self.assertEqual(changed,[True])
        self.assertEqual(stat.S_IMODE(self.output.stat().st_mode),0o600)

    def test_07_existing_destination_is_never_overwritten(self):
        self.output.write_bytes(b'preserve existing artifact')
        with self.assertRaises(FileExistsError):
            self.copy()
        self.assertEqual(self.output.read_bytes(),b'preserve existing artifact')

    def test_08_noncanonical_cargo_output_path_is_rejected(self):
        other=self.target/'debug/not-the-server'
        os.link(self.alias,other)
        with self.assertRaisesRegex(module.AdmissionError,'^cargo_output_path$'):
            module.copy_cargo_artifact(other,self.output,owned_target=self.target,
                expected_sha256=self.sha,expected_size=len(self.payload))
        self.assertFalse(self.output.exists())

suite=unittest.defaultTestLoader.loadTestsFromTestCase(ActualArtifactCopyControls)
details=io.StringIO()
result=unittest.TextTestRunner(stream=details,verbosity=2).run(suite)
sys.stderr.write(details.getvalue())
report={'schema':1,'scope':'actual_controller_functions_real_private_filesystem_controls_only',
        'controller_sha256':args.expected_controller_sha256,'tests_run':result.testsRun,
        'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
        'external_attempts':external_attempts,'ADB_operations':0,'network_operations':0,
        'server_executions':0,'Cargo_executions':0,'Android_or_remote_filesystem_qualification':False,
        'in_copy_mutation_hook':'os.read scheduling hook changes real backing file or directory entry; metadata and hashes are not mocked',
        'passed':result.wasSuccessful() and result.testsRun==8 and not external_attempts}
print(json.dumps(report,sort_keys=True))
raise SystemExit(0 if report['passed'] else 1)
