#!/usr/bin/env python3
"""One original rolling main(), fixed 480-second budget, exact owned children only."""
from pathlib import Path
import argparse,contextlib,hashlib,io,json,os,re,runpy,signal,stat,subprocess,sys,tarfile,time
os.umask(0o077)
BUILD=Path('/home/qian-qi/heptabao-rolling-exact-8f3-3ada-20261106-r2')
INPUT=Path('/home/qian-qi/heptabao-rolling-inputs-8f3-3ada-20261106-r1')
ROOT=Path('/home/qian-qi/heptabao-rolling-exact-8f3-3ada-live-20261106-r2')
PINS={'ha_rolling_upgrade.py':'318fc8b4e004ceb9ecda3e6bb194f081f5a250de7ec2c1ada34e12fb6ba16c43','ha_destructive.py':'403d10c594952c9b30094f42b08eb9a67cb732202d5af45c6d8adf0fe866d524','owned_process.py':'0ee96c9f43b50ebd57ee8f0ef95f2431c441ec02c1799992588dbf50768745d0','fixture_mounts.py':'55075ee436c22816a176dfb06cec387df37fdadd581c16acc07dabc837ba85b5'}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def file(p):
 s=p.lstat();assert p.resolve()==p and stat.S_ISREG(s.st_mode) and s.st_nlink==1;return s
def save(name,b):
 p=ROOT/name
 with p.open('xb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(fd);os.close(fd)
def emit(name,v):save(name,(json.dumps(v,sort_keys=True,indent=2)+'\n').encode())
ap=argparse.ArgumentParser();ap.add_argument('--expected-build-receipt-sha256',required=True);a=ap.parse_args()
assert re.fullmatch(r'[0-9a-f]{64}',a.expected_build_receipt_sha256)
rpath=BUILD/'result.public.json';file(rpath);assert sha(rpath)==a.expected_build_receipt_sha256
receipt=json.loads(rpath.read_bytes());assert receipt['status']=='builds_passed_distinct_pair_ready' and receipt['distinct_binaries'] is True and receipt['all_owned_children_reaped'] is True and receipt['profile_executions']==0
assert receipt['controller_sha256']=='5183845dd1ab4b1130aeb4229d7f86fe302f9b9028b5210ca0677d1cdc347788'
assert receipt['schema']==2 and receipt['base_recompiled'] is False
assert receipt['all_owned_groups_absent'] is True
assert receipt['completed_source_extractions']==['base','candidate']
assert set(receipt['new_source_rechecks_after'])=={'base','candidate'} and all(v['unchanged'] is True for v in receipt['new_source_rechecks_after'].values())
assert receipt['prior_failed_result_sha256']=='81bf1718a0e7b62d0318950fe5daaa6f6cbd13637aa383e3c84bc33c10aaaab6'
assert receipt['prior_metadata_and_sources_unchanged_after'] is True and receipt['qualified_binaries_unchanged_after'] is True
assert receipt['binaries']['base']['build_execution_origin']=='prior_r1_base_build_exit_0'
assert receipt['binaries']['base']['sha256']=='afbcaf45674b833fd3cd648563a089e25a08a844041edb9e19341c872f43220c'
assert receipt['binaries']['base']['build_command_sha256']=='96ca3baac20238647c5d325ab9eaa5e87de11d559a347bae0d8e490cd6c3ca7e'
assert receipt['binaries']['candidate']['build_execution_origin']=='new_r2_candidate_build_exit_0'
assert receipt['sources']['base']['commit']=='8f3dd8353aaf9642ad58f7716b0c14813d09983d' and receipt['sources']['candidate']['commit']=='3ada83a7b1008948a1b24a2e8cf585ee89357336'
paths={};hashes={}
for role in ('base','candidate'):
 p=BUILD/role/'bin-qualified/heptabao-server';row=receipt['binaries'][role];file(p);assert row['path']==str(p) and sha(p)==row['sha256'] and row['normal_default_features'] is True and row['source_content_unchanged'] is True
 paths[role]=p;hashes[role]=row['sha256']
assert hashes['base']!=hashes['candidate'],'same_binary_pair_not_admitted'
archive=INPUT/'rolling-qa.tar.gz';file(archive);assert archive.stat().st_size==21798 and sha(archive)=='22cabf53df430a8b8121a21cfaa070fc868d7e102a14280bbdfb96e4e637d4d0'
ROOT.mkdir(mode=0o700,exist_ok=False);qa=ROOT/'qa';qa.mkdir(mode=0o700)
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(PINS) and {m.name for m in members}==set(PINS)
 for m in members:
  assert m.isfile() and 0<m.size<65536;b=tf.extractfile(m).read();assert hashlib.sha256(b).hexdigest()==PINS[m.name];save('qa/'+m.name,b)
save('build.receipt.original.json',rpath.read_bytes())
main_argv=[str(qa/'ha_rolling_upgrade.py'),'--base-binary',str(paths['base']),'--base-sha256',hashes['base'],'--candidate-binary',str(paths['candidate']),'--candidate-sha256',hashes['candidate'],'--work-dir',str(ROOT/'cluster')]
report={'schema':1,'scope':'one_exact_pinned_base_candidate_original_rolling_main_private_loopback','controller_sha256':sha(Path(__file__).resolve()),'controller_argv':sys.argv,'actual_main_argv':main_argv,'profile_budget_seconds':480,'expected_build_receipt_sha256':a.expected_build_receipt_sha256,'base_sha256':hashes['base'],'candidate_sha256':hashes['candidate'],'QA_pins':PINS,'original_main_not_reimplemented':True,'status':'running','qualification':False,'external_review':False,'canonical_Owner_qualified':False,'ADB_operations':0,'children':[]}
children=[];original_popen=subprocess.Popen
# Return the exact original Popen object. Do not alter arguments or subprocess results.
def tracked_popen(*args,**kwargs):
 child=original_popen(*args,**kwargs);argv=args[0] if args else kwargs.get('args')
 children.append((child,{'argv':list(map(str,argv)) if isinstance(argv,(list,tuple)) else str(argv),'start_new_session':kwargs.get('start_new_session',False),'pid':child.pid}))
 return child
class ProfileDeadline(BaseException):pass
def timeout(signum,frame):raise ProfileDeadline('original_480_second_profile_budget')
original_handler=signal.signal(signal.SIGALRM,timeout)
outer_argv=sys.argv[:];out,err=io.StringIO(),io.StringIO();code=1;forced=False
start=time.monotonic();signal.setitimer(signal.ITIMER_REAL,480)
try:
 sys.path.insert(0,str(qa));namespace=runpy.run_path(str(qa/'ha_rolling_upgrade.py'),run_name='rolling_exact_pair_profile')
 assert namespace['owned_process']._CURRENT is None
 subprocess.Popen=tracked_popen;sys.argv=main_argv
 with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):code=namespace['main']()
except BaseException as error:
 report['exception_type']=type(error).__name__;report['timed_out']=isinstance(error,ProfileDeadline);code=1
finally:
 elapsed=time.monotonic()-start;signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,original_handler);sys.argv=outer_argv;subprocess.Popen=original_popen
 for child,row in children:
  rescue=False
  try:
   if child.poll() is None:
    forced=True;rescue=True
    if row['start_new_session']:
     try:os.killpg(child.pid,signal.SIGKILL)
     except ProcessLookupError:pass
    else:child.kill()
    child.wait(timeout=10)
   else:child.wait(timeout=0)
  except BaseException as error:
   forced=True;row['cleanup_error_type']=type(error).__name__
  row.update(exit_code=child.returncode,reaped=child.poll() is not None,rescue_cleanup=rescue);report['children'].append(row)
 stdout=out.getvalue().encode();stderr=err.getvalue().encode()
 save('profile.stdout.original',stdout);save('profile.stderr.original',stderr)
 report.update(main_exit_code=code,elapsed_seconds=elapsed,rescue_cleanup_required=forced,all_owned_children_reaped=all(p.poll() is not None for p,_ in children),stdout={'bytes':len(stdout),'sha256':hashlib.sha256(stdout).hexdigest()},stderr={'bytes':len(stderr),'sha256':hashlib.sha256(stderr).hexdigest()})
 try:
  actual=json.loads(stdout);report['original_report']=actual
  assert actual['status']=='pass_scoped_repository_fixture' and actual['qualification'] is False
  assert actual['base_binary_sha256']==hashes['base'] and actual['candidate_binary_sha256']==hashes['candidate']
  assert code==0 and elapsed<480 and not forced and report['all_owned_children_reaped']
  assert all(sha(paths[k])==hashes[k] for k in paths) and all(sha(qa/k)==v for k,v in PINS.items())
  assert sha(rpath)==a.expected_build_receipt_sha256
  report['source_and_binary_unchanged']=True;report['status']='passed_scoped_exact_pair_profile';code=0
 except BaseException as error:
  report['status']='failed';report['validation_failure_type']=type(error).__name__;code=1
 emit('result.public.json',report)
 print(json.dumps({'status':report['status'],'result_sha256':sha(ROOT/'result.public.json'),'scenario_count':report.get('original_report',{}).get('scenario_count'),'elapsed_seconds':elapsed,'all_owned_children_reaped':report['all_owned_children_reaped']},sort_keys=True),flush=True)
raise SystemExit(code)
