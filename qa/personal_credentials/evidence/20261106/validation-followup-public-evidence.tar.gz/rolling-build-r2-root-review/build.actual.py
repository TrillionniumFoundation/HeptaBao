#!/usr/bin/env python3
"""Resume only the admitted base artifact copy; independently build exact 3ada."""
from pathlib import Path, PurePosixPath
import ctypes,hashlib,json,os,re,resource,shutil,signal,stat,subprocess,sys,tarfile,time,tomllib

ROOT=Path('/home/qian-qi/heptabao-rolling-exact-8f3-3ada-20261106-r2')
INPUT=Path('/home/qian-qi/heptabao-rolling-inputs-8f3-3ada-20261106-r2')
PRIOR=Path('/home/qian-qi/heptabao-rolling-exact-8f3-3ada-20261106-r1')
PRIOR_INPUT=Path('/home/qian-qi/heptabao-rolling-inputs-8f3-3ada-20261106-r1')
OLD=Path('/home/qian-qi/heptabao-personal-credentials-20261106-r1')
OLD_BIN=Path('/home/qian-qi/heptabao-personal-build-evidence-20261106-a1b6ff-r1/server-build-r1/bin/heptabao-server')
OLD_SHA='c27a0c223d227d3b2b5292e1e3ab6cf0230562baee36b6465b22a7ddf17be172'
TOOL=Path('/home/qian-qi/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin')
PRIOR_RESULT_SHA='81bf1718a0e7b62d0318950fe5daaa6f6cbd13637aa383e3c84bc33c10aaaab6'
PRIOR_CONTROLLER_SHA='ed87f28e892676dc379f08346e8982b68c822db6b00a6c9dd647c5b770bc5f01'
PRIOR_CACHE_SHA='46d16a522fc60eff2cabdf8811a1a6f5e44072cbdf75cba3013546c9b0089253'
BASE_COMMAND_SHA='96ca3baac20238647c5d325ab9eaa5e87de11d559a347bae0d8e490cd6c3ca7e'
BASE_BINARY_SHA='afbcaf45674b833fd3cd648563a089e25a08a844041edb9e19341c872f43220c'
BASE_BINARY_BYTES=133627032
TOOL_PINS={'cargo':'ff3022fcbd13b08434ea7afde9a0ef9d5b3f5c17b5fc7a40031be3ee000a6a24','rustc':'3690cc576ede140504698405d5d8fa3826aaadbe71699c6c4ed0a565d6f493e2'}
SOURCES={
 'base':{'commit':'8f3dd8353aaf9642ad58f7716b0c14813d09983d','tree':'f5a9c5da159f41d9efeabd108aedebc92fda14bb','lock':'d2d07ea13e42a8d4ba65fafc642ca98ae1a7de68f6cd46a69043332267f378d5','manifest_sha256':'f73a89adb7ce88e2dff02ffe9b56ab605388b9cab188f3c04ac4c2be8471065d','source_content_sha256':'50ec8c88e8a3dc78b41b23fca62edf84991cf3611fb2a1a647ff0703d8e358d6','archive_sha256':'96af7db66ac253cc3ab698c7e2b10e6ab0221664fdb53763487c9f1aced8a2d5'},
 'candidate':{'commit':'3ada83a7b1008948a1b24a2e8cf585ee89357336','tree':'6196647cf9d8e3811347b95e5f984b5c1234ca70','lock':'ef3b19cf8b1b360f7888f11e3e5b1523e464762d6c24ce7e92b64d0d7d5c99a9','manifest_sha256':'edf8315dc14221e070fff45fff520dece91c71df14faf182bbe6a3e88d984212','source_content_sha256':'8a64245d290dbba334cc90cf85ca1f184ac7cdd59ec3be1b900126b342b9f306','archive_sha256':'34b058a2a3681c25d70b0a31539b34e638077e82a73705f515911f78cf3c1924'}}
DEADLINE=None
COMMANDS=[]
CHILDREN=[]
GROUP_ROWS={}
COMPLETED_EXTRACTIONS=[]
ENV={'PATH':str(TOOL)+':/usr/local/bin:/usr/bin:/bin','HOME':'/home/qian-qi','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','GIT_NO_LAZY_FETCH':'1','GIT_TERMINAL_PROMPT':'0','GIT_CONFIG_GLOBAL':'/dev/null','GIT_CONFIG_NOSYSTEM':'1','CARGO_NET_OFFLINE':'true','CARGO_BUILD_JOBS':'2','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','RUSTC':str(TOOL/'rustc'),'BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/15/include','PYTHONDONTWRITEBYTECODE':'1'}
# Keep the account HOME and original flags; copy no account Cargo config or credentials.

def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
 return h.hexdigest()
def regular(p,maximum=None):
 st=p.lstat();assert p.is_absolute() and p.resolve()==p and stat.S_ISREG(st.st_mode) and st.st_nlink==1
 if maximum is not None:assert st.st_size<=maximum
 return st
def durable(p,b,mode=0o600):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,mode)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 fd=os.open(p.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
def publish(name,value):durable(ROOT/name,(json.dumps(value,sort_keys=True,indent=2)+'\n').encode())
def remaining(limit):
 value=min(limit,DEADLINE-time.monotonic())
 if value<=0:raise TimeoutError('controller_deadline')
 return value
def enable_child_subreaper():
 # Linux prctl.h: process-local adoption, not a host/global service setting.
 libc=ctypes.CDLL(None,use_errno=True)
 value=ctypes.c_int()
 if libc.prctl(36,1,0,0,0)!=0 or libc.prctl(37,ctypes.byref(value),0,0,0)!=0 or value.value!=1:
  raise RuntimeError('child_subreaper_unavailable')
 return True

def group_alive(pgid):
 try:os.killpg(pgid,0);return True
 except ProcessLookupError:return False

def reap_adopted_group(pgid,row):
 # Called only after Popen has reaped its original direct child.
 while True:
  try:pid,status=os.waitpid(-pgid,os.WNOHANG)
  except ChildProcessError:return
  if pid==0:return
  row.setdefault('adopted_descendants_reaped',[]).append({'pid':pid,'wait_status':status})

def close_owned_group(child,row):
 row.setdefault('cleanup_needed',False)
 if child.poll() is not None:reap_adopted_group(child.pid,row)
 if child.poll() is None or group_alive(child.pid):
  row['cleanup_needed']=True
  for sig in (signal.SIGTERM,signal.SIGKILL):
   if child.poll() is not None and not group_alive(child.pid):break
   try:os.killpg(child.pid,sig);row.setdefault('cleanup_signals',[]).append(int(sig))
   except ProcessLookupError:pass
   until=time.monotonic()+5
   while time.monotonic()<until:
    if child.poll() is not None:reap_adopted_group(child.pid,row)
    if child.poll() is not None and not group_alive(child.pid):break
    time.sleep(.02)
  if child.poll() is None:child.wait(timeout=.1)
  reap_adopted_group(child.pid,row)
 row['exit_code']=child.returncode
 row['reaped']=child.poll() is not None
 row['descendant_group_absent']=not group_alive(child.pid)
 if not row['reaped'] or not row['descendant_group_absent']:
  raise RuntimeError('owned_process_group_cleanup_incomplete')

def command(label,argv,cwd=None,limit=30,extra=None):
 env=dict(ENV,**(extra or {}));stdout=ROOT/(label+'.stdout.original');stderr=ROOT/(label+'.stderr.original')
 before=time.time_ns();row={'label':label,'argv':list(map(str,argv)),'cwd':str(cwd) if cwd else None,'environment':env,'started_unix_ns':before,'timeout_seconds':remaining(limit),'timed_out':False,'cleanup_needed':False,'start_new_session':True}
 child=None
 try:
  with stdout.open('xb') as out,stderr.open('xb') as err:
   child=subprocess.Popen(row['argv'],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
   CHILDREN.append(child);GROUP_ROWS[child.pid]=row;row['pid']=child.pid;row['owned_process_group']=child.pid
   try:child.wait(timeout=row['timeout_seconds'])
   except subprocess.TimeoutExpired:row['timed_out']=True
   finally:close_owned_group(child,row)
   out.flush();err.flush();os.fsync(out.fileno());os.fsync(err.fileno())
 finally:
  if child is not None:
   try:close_owned_group(child,row)
   except BaseException as error:row['cleanup_error_type']=type(error).__name__
  row.update(finished_unix_ns=time.time_ns(),stdout={'bytes':stdout.stat().st_size,'sha256':sha(stdout)},stderr={'bytes':stderr.stat().st_size,'sha256':sha(stderr)})
  COMMANDS.append(row);publish(label+'.command.public.json',row)
 if row['timed_out'] or row.get('exit_code')!=0:raise RuntimeError('command_failed:'+label)
 if row['cleanup_needed'] or not row.get('reaped') or not row.get('descendant_group_absent'):raise RuntimeError('command_required_group_cleanup:'+label)
 if stdout.stat().st_size>64*1024**2 or stderr.stat().st_size>64*1024**2:raise RuntimeError('command_output_threshold:'+label)
 return stdout.read_bytes()
def git_snapshot(label):
 result={}
 for key,args in [('head',['rev-parse','HEAD']),('tree',['rev-parse','HEAD^{tree}']),('status',['status','--porcelain=v1','--untracked-files=all'])]:
  result[key]=command(label+'-'+key,['/usr/bin/git','-C',str(OLD),*args],limit=20).decode().strip()
 assert result=={'head':'a1b6ff4506f52082a0893b7167fafb4ff95610be','tree':'5f685c1aaf647f016afed0555a6710cd4a76c317','status':''}
 regular(OLD_BIN);assert sha(OLD_BIN)==OLD_SHA
 return {'git':result,'qualified_binary_sha256':OLD_SHA}
def extract(archive,dest):
 dest.mkdir(mode=0o700);names=set();total=0;regular_count=0
 with tarfile.open(archive,'r:gz') as tf:
  members=tf.getmembers();assert len(members)<=10000
  for m in members:
   q=PurePosixPath(m.name);assert not q.is_absolute() and all(x not in ('','..') for x in q.parts) and str(q) not in names and not m.name.startswith('.git/')
   names.add(str(q));p=dest.joinpath(*q.parts)
   assert m.isdir() or m.isfile()
   if m.isdir():p.mkdir(mode=0o700,parents=True,exist_ok=True);continue
   assert 0<=m.size<=64*1024**2;total+=m.size;assert total<=512*1024**2;regular_count+=1
   p.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
   src=tf.extractfile(m);b=src.read(m.size+1);assert len(b)==m.size
   durable(p,b,0o700 if m.mode&0o111 else 0o600)
 return {'regular_files':regular_count,'expanded_bytes':total,'archive_sha256':sha(archive)}
def source_inventory(root):
 rows=[]
 for p in sorted(root.rglob('*')):
  if p.is_dir():assert not p.is_symlink();continue
  regular(p);rows.append({'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p),'executable':bool(p.stat().st_mode&0o111)})
 b=(json.dumps(rows,sort_keys=True,separators=(',',':'))+'\n').encode();return rows,hashlib.sha256(b).hexdigest()

class AdmissionError(RuntimeError):
 pass

def require(condition,code):
 if not condition:raise AdmissionError(code)

def identity(st):
 return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_gid,st.st_nlink,
         st.st_size,st.st_mtime_ns,st.st_ctime_ns)

def owned_directory(p):
 require(p.is_absolute() and p.resolve()==p,'directory_path')
 st=p.lstat()
 require(stat.S_ISDIR(st.st_mode) and st.st_uid==os.geteuid()
         and st.st_mode&0o022==0,'directory_owner_or_mode')
 return st

def stable_read(p,maximum,expected_sha256=None):
 before=regular(p,maximum)
 fd=os.open(p,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
 try:
  require(identity(os.fstat(fd))==identity(before),'read_open_changed')
  parts=[];size=0
  while True:
   b=os.read(fd,min(1048576,maximum+1-size))
   if not b:break
   size+=len(b);require(size<=maximum,'read_size');parts.append(b)
  require(size==before.st_size and identity(os.fstat(fd))==identity(before)
          and identity(p.lstat())==identity(before),'read_changed')
  result=b''.join(parts)
  if expected_sha256 is not None:
   require(hashlib.sha256(result).hexdigest()==expected_sha256,'read_sha256')
  return result
 finally:os.close(fd)

def copy_cargo_artifact(source,destination,*,owned_target,expected_sha256=None,expected_size=None):
 """Only this exact owned Cargo output may have its normal two hard links.

 No source chmod, unlink or write occurs. The qualified copy is a different
 inode, single-link and non-executable until its complete bytes are checked.
 The caller must bind its completed Cargo command and frozen source first.
 """
 source=Path(source);destination=Path(destination);owned_target=Path(owned_target)
 require(source==owned_target/'debug/heptabao-server','cargo_output_path')
 owned_directory(owned_target);parent_before=owned_directory(source.parent)
 require(destination.name=='heptabao-server' and destination!=source,'qualified_path')
 destination_parent=owned_directory(destination.parent)
 require(stat.S_IMODE(destination_parent.st_mode)==0o700,'qualified_parent_mode')
 require(source.resolve()==source,'cargo_output_symlink')
 before=source.lstat()
 require(stat.S_ISREG(before.st_mode) and before.st_uid==os.geteuid()
         and stat.S_IMODE(before.st_mode)==0o700 and before.st_nlink in (1,2)
         and 0<before.st_size<=512*1024**2,'cargo_output_metadata')
 if expected_size is not None:require(before.st_size==expected_size,'cargo_output_size')
 if expected_sha256 is not None:require(re.fullmatch(r'[0-9a-f]{64}',expected_sha256) is not None,'cargo_expected_sha')
 source_fd=destination_fd=directory_fd=None
 try:
  source_fd=os.open(source,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK)
  require(identity(os.fstat(source_fd))==identity(before),'cargo_open_changed')
  directory_fd=os.open(destination.parent,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC|os.O_NOFOLLOW)
  opened_parent=os.fstat(directory_fd)
  require((opened_parent.st_dev,opened_parent.st_ino)==(destination_parent.st_dev,destination_parent.st_ino),'qualified_parent_changed')
  destination_fd=os.open(destination.name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=directory_fd)
  first_copy=os.fstat(destination_fd)
  require(stat.S_ISREG(first_copy.st_mode) and first_copy.st_nlink==1
          and first_copy.st_uid==os.geteuid() and (first_copy.st_dev,first_copy.st_ino)!=(before.st_dev,before.st_ino),'qualified_initial_metadata')
  count=0;h=hashlib.sha256()
  while True:
   block=os.read(source_fd,1048576)
   if not block:break
   count+=len(block);require(count<=before.st_size,'cargo_grew_during_copy');h.update(block)
   offset=0
   while offset<len(block):
    written=os.write(destination_fd,block[offset:]);require(written>0,'qualified_zero_write');offset+=written
  require(count==before.st_size,'cargo_short_read')
  digest=h.hexdigest()
  if expected_sha256 is not None:require(digest==expected_sha256,'cargo_content_sha256')
  require(identity(os.fstat(source_fd))==identity(before)
          and identity(source.lstat())==identity(before),'cargo_input_changed')
  parent_after=owned_directory(source.parent)
  require((parent_before.st_dev,parent_before.st_ino)==(parent_after.st_dev,parent_after.st_ino),'cargo_parent_changed')
  os.lseek(destination_fd,0,os.SEEK_SET);copied_hash=hashlib.sha256();copied_count=0
  while True:
   block=os.read(destination_fd,1048576)
   if not block:break
   copied_hash.update(block);copied_count+=len(block)
  require(copied_count==count and copied_hash.hexdigest()==digest,'qualified_readback')
  os.fchmod(destination_fd,0o500);os.fsync(destination_fd)
  copied=os.fstat(destination_fd)
  require(copied.st_size==count and copied.st_nlink==1 and stat.S_IMODE(copied.st_mode)==0o500
          and copied.st_uid==os.geteuid() and (copied.st_dev,copied.st_ino)==(first_copy.st_dev,first_copy.st_ino),'qualified_final_metadata')
  require(identity(os.stat(destination.name,dir_fd=directory_fd,follow_symlinks=False))==identity(copied),'qualified_name_changed')
  current_parent=owned_directory(destination.parent)
  require((current_parent.st_dev,current_parent.st_ino)==(opened_parent.st_dev,opened_parent.st_ino),'qualified_directory_changed')
  # Recheck the original descriptor and its name after the output readback too.
  require(identity(os.fstat(source_fd))==identity(before)
          and identity(source.lstat())==identity(before),'cargo_input_changed_after_readback')
  os.fsync(directory_fd)
  result={'path':str(destination),'bytes':count,'sha256':digest,'qualified_nlink':1,
          'qualified_mode':'0500','copied_from':str(source),'source_link_count':before.st_nlink,
          'source_descriptor_and_named_identity_stable':True,'source_bytes_unchanged':True,
          'qualified_same_sha256':True,'qualified_file_and_directory_synced':True}
 finally:
  # A close error propagates; no successful artifact receipt is returned.
  try:
   if destination_fd is not None:os.close(destination_fd)
  finally:
   try:
    if directory_fd is not None:os.close(directory_fd)
   finally:
    if source_fd is not None:os.close(source_fd)
 return result

def verify_prior():
 raw=stable_read(PRIOR/'result.public.json',1024**2,PRIOR_RESULT_SHA);r=json.loads(raw)
 require(r['status']=='failed' and r['failure_type']=='AssertionError' and r['failure_code']==''
         and r['binaries']=={} and r['profile_executions']==0 and r['all_owned_children_reaped'] is True
         and r['old_before']==r['old_after'] and r['controller_sha256']==PRIOR_CONTROLLER_SHA,'prior_terminal_contract')
 stable_read(PRIOR_INPUT/'build.actual.py',65536,PRIOR_CONTROLLER_SHA)
 rows=[x for x in r['commands'] if x['label']=='base-build']
 require(len(rows)==1,'prior_base_command_count');cmd=rows[0]
 require(cmd['exit_code']==0 and cmd['timed_out'] is False and cmd['reaped'] is True
         and cmd['argv']==[str(TOOL/'cargo'),'build','--offline','--locked','-p','heptabao-server','--bin','heptabao-server']
         and cmd['cwd']==str(PRIOR/'base/source'),'prior_successful_base_build')
 expected_env=dict(ENV,CARGO_HOME=str(PRIOR/'cargo-home'),CARGO_TARGET_DIR=str(PRIOR/'base/target'))
 require(cmd['environment']==expected_env,'prior_build_environment')
 command_raw=stable_read(PRIOR/'base-build.command.public.json',65536,BASE_COMMAND_SHA)
 require(json.loads(command_raw)==cmd,'prior_command_receipt')
 for stream in ('stdout','stderr'):
  b=stable_read(PRIOR/('base-build.'+stream+'.original'),64*1024**2,cmd[stream]['sha256'])
  require(len(b)==cmd[stream]['bytes'],'prior_build_log_length')
 cache_raw=stable_read(PRIOR/'cache-preparation.public.json',1024**2,PRIOR_CACHE_SHA)
 require(json.loads(cache_raw)==r['cache'],'prior_cache_receipt')
 manifests={}
 for role,pin in SOURCES.items():
  source=r['sources'][role]
  for key in ('commit','tree','lock','source_content_sha256'):require(source[key]==pin[key],'prior_source_binding')
  require(source['archive']['archive_sha256']==pin['archive_sha256'],'prior_archive_binding')
  raw_manifest=stable_read(PRIOR/(role+'.source-files.public.json'),2*1024**2,pin['manifest_sha256'])
  expected=json.loads(raw_manifest);actual,digest=source_inventory(PRIOR/role/'source')
  require(actual==expected and digest==pin['source_content_sha256']
          and sha(PRIOR/role/'source/Cargo.lock')==pin['lock'],'prior_source_changed')
  manifests[role]=expected
 return r,cmd,manifests

def prepare_cache(prior):
 cargo_home=ROOT/'cargo-home';cargo_home.mkdir(mode=0o700);ENV['CARGO_HOME']=str(cargo_home)
 seed=PRIOR/'cargo-home/registry';cache=seed/'cache';index=seed/'index'
 options=[p.name for p in cache.iterdir() if re.fullmatch(r'index\.crates\.io-[0-9a-f]{16}',p.name)
          and p.is_dir() and not p.is_symlink() and (index/p.name/'.cache').is_dir()]
 require(len(options)==1,'one_prior_sparse_registry_required');key=options[0]
 cfg=json.loads(stable_read(index/key/'config.json',65536))
 require(cfg.get('dl')=='https://static.crates.io/crates' and cfg.get('api')=='https://crates.io'
         and cfg.get('auth-required',False) is False,'official_public_registry')
 target_index=cargo_home/'registry/index'/key;target_cache=cargo_home/'registry/cache'/key
 target_index.mkdir(parents=True,mode=0o700);target_cache.mkdir(parents=True,mode=0o700)
 durable(target_index/'config.json',(json.dumps({'dl':'https://static.crates.io/crates','api':'https://crates.io'},sort_keys=True)+'\n').encode())
 packages={}
 for role in SOURCES:
  lock=tomllib.loads((ROOT/role/'source/Cargo.lock').read_text())
  for p in lock['package']:
   if p.get('source','').startswith('registry+'):
    require(p['source']=='registry+https://github.com/rust-lang/crates.io-index'
            and re.fullmatch(r'[0-9a-f]{64}',p['checksum']) is not None,'locked_registry')
    k=(p['name'],p['version']);require(k not in packages or packages[k]==p['checksum'],'conflicting_lock_checksum');packages[k]=p['checksum']
 old=prior['cache'];archived={x['name']:x for x in old['copied_archives']}
 require(len(archived)==len(old['copied_archives']) and len(packages)==old['locked_packages'],'prior_cache_inventory')
 require({n+'-'+v+'.crate' for n,v in packages}==set(archived)|set(old['missing_archives']),'exact_lock_archive_set')
 copied=[];missing=[];index_files={};total=0
 for (name,version),checksum in sorted(packages.items()):
  require(re.fullmatch(r'[A-Za-z0-9_-]+',name) is not None and re.fullmatch(r'[A-Za-z0-9_.+\-]+',version) is not None,'package_name')
  prefix='1' if len(name)==1 else '2' if len(name)==2 else '3/'+name[0] if len(name)==3 else name[:2]+'/'+name[2:4]
  rel=Path('.cache')/prefix/name;bound=old['sparse_index_files'][str(rel)]
  raw=stable_read(index/key/rel,16*1024**2,bound['sha256']);require(len(raw)==bound['bytes'],'sparse_index_length')
  parts=raw.split(b'\0');matches=[]
  for i,v in enumerate(parts[:-1]):
   if v==version.encode():
    try:x=json.loads(parts[i+1])
    except (ValueError,UnicodeError):continue
    if x.get('name')==name and x.get('vers')==version:matches.append(x)
  require(len(matches)==1 and matches[0].get('cksum')==checksum,'locked_sparse_index_mismatch')
  if str(rel) not in index_files:
   q=target_index/rel;q.parent.mkdir(parents=True,mode=0o700,exist_ok=True);durable(q,raw);index_files[str(rel)]={'bytes':len(raw),'sha256':sha(q)}
  filename=name+'-'+version+'.crate'
  if filename not in archived:missing.append(filename);continue
  bound=archived[filename];require(bound['sha256']==checksum,'locked_archive_binding')
  raw=stable_read(cache/key/filename,64*1024**2,checksum);require(len(raw)==bound['bytes'],'archive_length')
  total+=len(raw);require(total<=2*1024**3,'archive_total_size');durable(target_cache/filename,raw)
  copied.append({'name':filename,'bytes':len(raw),'sha256':checksum})
 require(index_files==old['sparse_index_files'] and copied==old['copied_archives'] and missing==old['missing_archives'],'cache_clone_matches_prior')
 receipt={'scope':'prior_public_cache_read_only_copy_exact_lock','seed_receipt_sha256':PRIOR_CACHE_SHA,
          'network':False,'seed_cache_modified':False,'credentials_or_global_config_copied':False,
          'locked_packages':len(packages),'copied_archives':copied,'missing_archives':missing,'sparse_index_files':index_files}
 publish('cache-preparation.public.json',receipt);return receipt

def main():
 global DEADLINE
 os.umask(0o077);require(os.environ.get('HOME')==ENV['HOME'],'original_account_home')
 resource.setrlimit(resource.RLIMIT_FSIZE,(1024**3,1024**3));resource.setrlimit(resource.RLIMIT_NOFILE,(4096,4096))
 DEADLINE=time.monotonic()+2700
 ROOT.mkdir(mode=0o700,exist_ok=False)
 parent_fd=os.open(ROOT.parent,os.O_RDONLY|os.O_DIRECTORY);os.fsync(parent_fd);os.close(parent_fd)
 report={'schema':2,'scope':'copy_verified_prior_base_and_new_exact_candidate_offline_normal_build_no_profile',
         'status':'running','source_representation':'exact git archives, not live worktrees','runtime_budget_seconds':2850,
         'controller_budget_seconds':2700,'per_build_budget_seconds':1200,'Cargo_build_jobs':2,'profile_executions':0,
         'sources':SOURCES,'commands':COMMANDS,'binaries':{},'new_http_fix_included':False,
         'prior_failed_result_sha256':PRIOR_RESULT_SHA,'prior_failure_preserved':True,'base_recompiled':False}
 code=1;prior=None;manifests=None
 try:
  report['process_local_child_subreaper']=enable_child_subreaper()
  require(shutil.disk_usage(ROOT).free>=20*1024**3,'free_space')
  report['old_before']=git_snapshot('old-before')
  prior,base_command,manifests=verify_prior()
  version=command('rustc-version',[str(TOOL/'rustc'),'-vV']).decode()
  require(version==prior['rustc_vV'] and version.startswith('rustc 1.98.0 '),'same_rustc_version')
  report['toolchain']={x:sha(TOOL/x) for x in ('cargo','rustc')}
  require(report['toolchain']==TOOL_PINS==prior['toolchain'],'same_toolchain_bytes');report['rustc_vV']=version
  save_inputs={'prior.result.original.json':PRIOR/'result.public.json','prior.base-command.original.json':PRIOR/'base-build.command.public.json',
               'prior.base-build.stdout.original':PRIOR/'base-build.stdout.original','prior.base-build.stderr.original':PRIOR/'base-build.stderr.original'}
  for name,p in save_inputs.items():durable(ROOT/name,stable_read(p,2*1024**2))
  for role,pin in SOURCES.items():
   d=ROOT/role;d.mkdir(mode=0o700)
   archive=PRIOR/'base/source.tar.gz' if role=='base' else PRIOR_INPUT/'candidate-source.tar.gz'
   regular(archive,32*1024**2);require(sha(archive)==pin['archive_sha256'],'source_archive_sha256')
   pin['archive']=extract(archive,d/'source')
   COMPLETED_EXTRACTIONS.append(role)
   rows,digest=source_inventory(d/'source')
   require(rows==manifests[role] and digest==pin['source_content_sha256']
           and sha(d/'source/Cargo.lock')==pin['lock'],'extracted_source_matches_prior')
   publish(role+'.source-files.public.json',rows)
  qualified=ROOT/'base/bin-qualified';qualified.mkdir(mode=0o700)
  base=copy_cargo_artifact(PRIOR/'base/target/debug/heptabao-server',qualified/'heptabao-server',
                           owned_target=PRIOR/'base/target',expected_sha256=BASE_BINARY_SHA,expected_size=BASE_BINARY_BYTES)
  base.update(normal_default_features=True,source_content_unchanged=True,argv=base_command['argv'],
              build_execution_origin='prior_r1_base_build_exit_0',build_command_sha256=BASE_COMMAND_SHA)
  report['binaries']['base']=base
  publish('base.build.public.json',{'schema':2,'source':SOURCES['base'],'binary':base,'original_build_command':base_command,
           'original_build_result_sha256':PRIOR_RESULT_SHA,'toolchain':report['toolchain'],'rustc_vV':version})
  report['cache']=prepare_cache(prior)
  target=ROOT/'candidate/target';require(not target.exists(),'candidate_target_must_be_new')
  argv=[str(TOOL/'cargo'),'build','--offline','--locked','-p','heptabao-server','--bin','heptabao-server']
  command('candidate-build',argv,cwd=ROOT/'candidate/source',limit=1200,extra={'CARGO_TARGET_DIR':str(target)})
  qualified=ROOT/'candidate/bin-qualified';qualified.mkdir(mode=0o700)
  candidate=copy_cargo_artifact(target/'debug/heptabao-server',qualified/'heptabao-server',owned_target=target)
  candidate.update(normal_default_features=True,source_content_unchanged=True,argv=argv,build_execution_origin='new_r2_candidate_build_exit_0')
  for role,pin in SOURCES.items():
   rows,digest=source_inventory(ROOT/role/'source')
   require(rows==manifests[role] and digest==pin['source_content_sha256'],'source_changed_during_build')
  report['binaries']['candidate']=candidate
  publish('candidate.build.public.json',{'schema':2,'source':SOURCES['candidate'],'binary':candidate,
           'command':COMMANDS[-1],'toolchain':report['toolchain'],'rustc_vV':version})
  report['distinct_binaries']=base['sha256']!=candidate['sha256']
  report['status']='builds_passed_distinct_pair_ready' if report['distinct_binaries'] else 'builds_passed_identical_pair_not_admitted'
  code=0 if report['distinct_binaries'] else 2
 except BaseException as error:
  report['status']='failed';report['failure_type']=type(error).__name__
  report['failure_code']=str(error)[:180] if isinstance(error,(RuntimeError,AssertionError,TimeoutError)) else None
 finally:
  for child in CHILDREN:
   row=GROUP_ROWS[child.pid]
   try:close_owned_group(child,row)
   except BaseException as error:
    report['status']='failed';report['group_cleanup_error_type']=type(error).__name__;code=1
   if row.get('cleanup_needed') or not row.get('descendant_group_absent'):
    report['status']='failed';report['cleanup_required']=True;code=1
  report['completed_source_extractions']=list(COMPLETED_EXTRACTIONS)
  report['new_source_rechecks_after']={}
  for role in COMPLETED_EXTRACTIONS:
   try:
    rows,digest=source_inventory(ROOT/role/'source')
    publish(role+'.source-files.after.public.json',rows)
    same=rows==manifests[role] and digest==SOURCES[role]['source_content_sha256'] and sha(ROOT/role/'source/Cargo.lock')==SOURCES[role]['lock']
    report['new_source_rechecks_after'][role]={'source_content_sha256':digest,'source_file_count':len(rows),'unchanged':same}
    if role in report['binaries']:report['binaries'][role]['source_content_unchanged']=same
    require(same,'new_source_changed_after_failure_or_success')
   except BaseException as error:
    report['status']='failed';report['new_source_after_check_error_type']=type(error).__name__;code=1
  try:
   report['old_after']=git_snapshot('old-after');require(report.get('old_before')==report['old_after'],'old_artifact_changed')
   stable_read(PRIOR/'result.public.json',1024**2,PRIOR_RESULT_SHA)
   stable_read(PRIOR/'base-build.command.public.json',65536,BASE_COMMAND_SHA)
   stable_read(PRIOR/'cache-preparation.public.json',1024**2,PRIOR_CACHE_SHA)
   if manifests is not None:
    for role,pin in SOURCES.items():
     rows,digest=source_inventory(PRIOR/role/'source')
     require(rows==manifests[role] and digest==pin['source_content_sha256'],'prior_source_changed_after')
   report['prior_metadata_and_sources_unchanged_after']=True
   for role,binary in report['binaries'].items():
    p=Path(binary['path']);regular(p,512*1024**2);require(sha(p)==binary['sha256'],'qualified_binary_changed_after')
   report['qualified_binaries_unchanged_after']=True
  except BaseException as error:
   report['status']='failed';report['after_check_error_type']=type(error).__name__;code=1
  report['all_owned_children_reaped']=all(p.poll() is not None for p in CHILDREN)
  report['all_owned_groups_absent']=all(GROUP_ROWS[p.pid].get('descendant_group_absent') is True for p in CHILDREN)
  report['controller_sha256']=sha(Path(__file__).resolve());report['actual_argv']=sys.argv;report['finished_unix_ns']=time.time_ns()
  publish('result.public.json',report)
  print(json.dumps({'status':report['status'],'profile_executions':0,'result_sha256':sha(ROOT/'result.public.json'),
                   'root':str(ROOT),'all_owned_children_reaped':report['all_owned_children_reaped']},sort_keys=True),flush=True)
 return code

if __name__=='__main__':raise SystemExit(main())
