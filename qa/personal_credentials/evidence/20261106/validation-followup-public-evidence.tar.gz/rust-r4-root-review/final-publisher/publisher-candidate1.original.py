#!/usr/bin/env python3
"""Seal a reviewed, exact r4 evidence snapshot; no remote execution or new tests."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import re
import stat
import tarfile

HERE = Path(__file__).resolve().parent
STAGES = ('build-red', 'test-red', 'build-green', 'test-green')
NORMAL = 'service::consistency::tests::consistency270_audited_wire_retains_retry_hint_and_no_application_effect'
EXPECTED = {
    NORMAL,
    'service::consistency::tests::consistency270_audited_wire_request_audit_failure_keeps_503_without_hint',
    'service::consistency::tests::consistency270_audited_wire_response_audit_failure_keeps_503_without_hint',
    'http::consistency_tests::consistency270_audited_wire_generic_429_does_not_acquire_a_retry_hint',
}
FIXED = {
    'freeze.public.json': '3a893600e495caee4af62f379e2c59549473634c353d6a0aee0a9176446e3185',
    'bindings.public.json': '524c8bb63fdcdce3aad3f1e0a07f41b7b914514ccb34fa6306f8341a372f6f05',
    'results/prepare/prepare.public.json': 'f865b1e9e9ff96f7d8267460d5b1b4f3757fba23ffcfeda09d49640fd41e2535',
    'build-red.actual.request.json': 'd2e0cb80a5c2c14fc60e7aed87bc037cf940d882ec818560b3bfa8cc7a5643f0',
}
REVIEW = 'public-stream-review.json'


def pin(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def collect_candidates():
    """Closed scopes plus an externally reviewed exact file manifest; never add other dirs."""
    selected = {}

    def add(path):
        name = path.relative_to(HERE).as_posix()
        assert name != REVIEW and name not in selected
        assert not any(parent.is_symlink() for parent in (path, *path.parents))
        info = path.lstat()
        assert stat.S_ISREG(info.st_mode) and info.st_nlink == 1 and info.st_size <= 32 * 1024**2
        selected[name] = path

    freeze = json.loads((HERE / 'freeze.public.json').read_bytes())
    assert pin((HERE / 'freeze.public.json').read_bytes())['sha256'] == FIXED['freeze.public.json']
    for name in sorted(set(freeze['files']) | {'freeze.public.json', 'peer-review.public.json', Path(__file__).name}):
        add(HERE / name)
    for stage in STAGES:
        request = HERE / (stage + '.actual.request.json')
        if request.is_file():
            add(request)
    for top in ('results', 'runtime-originals'):
        for stage in ('ingress', 'prepare', *STAGES):
            directory = HERE / top / stage
            if directory.exists():
                for path in sorted(directory.rglob('*')):
                    if path.is_file() and '__pycache__' not in path.parts:
                        add(path)
    return selected


def process_binding(admitted, name, request, expected_job):
    def load(relative):
        return json.loads(admitted[relative])

    base = 'runtime-originals/' + name + '/'
    launch = load(base + 'launch.content-0.original.txt')
    terminal_name = 'status.content-0.original.txt' if name in ('ingress', 'prepare') else 'terminal-status.content-0.original.txt'
    terminal = load(base + terminal_name)
    stream_name = 'streams.content-0.original.txt' if name in ('ingress', 'prepare') else 'terminal-streams.content-0.original.txt'
    output = load(base + stream_name)
    assert launch['job']['id'] == terminal['job_id'] == output['job_id'] == expected_job
    assert launch['reused'] is False and launch['audit_recorded'] is True and launch['launch']['ok'] is True
    for key in ('host', 'executable', 'cwd', 'args', 'idempotency_key'):
        assert launch['job'][key] == request[key]
    assert terminal['state'] in ('succeeded', 'failed', 'cancelled')
    assert terminal['audit_recorded'] is True and terminal['output_complete'] is True and terminal['output_durable'] is True
    for stream in ('stdout', 'stderr'):
        item = output[stream]
        data = bytes.fromhex(item['bytes_hex'])
        assert item['offset'] == 0 and item['eof'] is True and len(data) == item['size'] == item['next_offset']
        assert data.decode() == item['text']
        assert data == admitted['results/' + name + '/controller.' + stream + '.original']
    good = (terminal['state'] == 'succeeded' and terminal['exit_code'] == 0
            and terminal['cancelled'] is False and terminal['timed_out'] is False)
    return terminal, output, good


def verify_actual_evidence(admitted, review):
    def load(name):
        return json.loads(admitted[name])

    for name, digest in FIXED.items():
        assert pin(admitted[name])['sha256'] == digest
    freeze = load('freeze.public.json')
    for name, expected in freeze['files'].items():
        assert pin(admitted[name]) == expected
    binding = load('bindings.public.json')
    prepared = load('results/prepare/prepare.public.json')
    assert prepared['bindings_sha256'] == FIXED['bindings.public.json']
    assert prepared['status'] == 'prepared_only_no_rust_execution'
    assert prepared['runner'] == binding['targeted_runner'] and prepared['runner_common'] == binding['controller_common']
    assert prepared['controller_sha256'] == binding['consistency_controller']['sha256']
    assert set(binding['expected_rust_tests']) == EXPECTED and len(binding['expected_rust_tests']) == 4
    assert binding['source']['commit'] == '3ada83a7b1008948a1b24a2e8cf585ee89357336'
    assert binding['source']['tree'] == '6196647cf9d8e3811347b95e5f984b5c1234ca70'
    jobs = review['actual_job_ids']
    assert jobs['ingress'] == '1a1b3490f8c-fc05-81c3' and jobs['prepare'] == '1a1b34a5999-fc05-81ce'
    assert jobs['build-red'] == '1a1b34d4259-fc05-81dd'
    for name, request_name in (('ingress', 'ingress.request.json'), ('prepare', 'rust-prepare.request.json')):
        terminal, output, good = process_binding(admitted, name, load(request_name), jobs[name])
        assert good
        printed = json.loads(output['stdout']['text'])
        receipt = 'results/' + name + '/' + ('ingress.public.json' if name == 'ingress' else 'prepare.public.json')
        key = 'receipt_sha256' if name == 'ingress' else 'prepare_receipt_sha256'
        assert printed[key] == pin(admitted[receipt])['sha256']
    executed = [stage for stage in STAGES if 'runtime-originals/' + stage + '/launch.content-0.original.txt' in admitted]
    assert executed and executed == list(STAGES[:len(executed)])
    assert set(jobs) == {'ingress', 'prepare', *executed}
    observations = []
    previous = None
    all_good = True
    for stage in executed:
        phase = stage.split('-')[1]
        compile_only = stage.startswith('build-')
        assert previous is None or observations[-1]['accepted'] is True
        request_bytes = admitted[stage + '.actual.request.json']
        template = admitted[stage + '.request.template.json'].decode()
        wanted = template.replace('__PREPARED_RECEIPT_SHA256__', FIXED['results/prepare/prepare.public.json'])
        if previous:
            previous_digest = pin(admitted['results/' + previous + '/' + previous + '.public.json'])['sha256']
            wanted = wanted.replace('__PREVIOUS_STAGE_RECEIPT_SHA256__', previous_digest)
        assert request_bytes == wanted.encode()
        request = json.loads(request_bytes)
        assert request['cpu_quota_percent'] == 400 and request['memory_max_bytes'] == 25769803776
        assert request['timeout_seconds'] == (3750 if compile_only else 1350)
        terminal, output, good = process_binding(admitted, stage, request, jobs[stage])
        receipt_name = 'results/' + stage + '/' + stage + '.public.json'
        observation = {'stage': stage, 'job_id': jobs[stage], 'terminal': terminal,
                       'receipt_available': receipt_name in admitted, 'accepted': False}
        if receipt_name not in admitted:
            assert not good and stage == executed[-1]
            observation['limitation'] = 'stage receipt unavailable; no acceptance or cleanup inferred'
            observations.append(observation); all_good = False; previous = stage
            continue
        report = load(receipt_name)
        observation['receipt'] = pin(admitted[receipt_name])
        observation['status'] = report['status']
        printed = json.loads(output['stdout']['text'])
        assert printed['stage'] == report['stage'] == stage and printed['status'] == report['status']
        assert printed['accepted'] == report['accepted'] and printed['stage_receipt_sha256'] == pin(admitted[receipt_name])['sha256']
        assert report['bindings_sha256'] == FIXED['bindings.public.json']
        assert report['prepared_receipt_sha256'] == FIXED['results/prepare/prepare.public.json']
        assert report['controller_sha256'] == binding['consistency_controller']['sha256']
        assert report['source_commit'] == binding['source']['commit'] and report['source_tree'] == binding['source']['tree']
        assert report['phase'] == phase and report['compile_only'] is compile_only and report['retries'] == 0
        assert report['resource_combination'] == {'cpu_quota_percent': 400, 'memory_max_bytes': 25769803776, 'cargo_build_jobs': 2}
        assert report['prior_stage'] == previous
        assert report['prior_stage_receipt_sha256'] == (previous_digest if previous else None)
        if 'command' in report:
            command = report['command']
            label = stage if compile_only else phase
            command_prefix = 'results/' + stage + '/' + stage + '-private-logs/' + label
            command_name = command_prefix + '.command.public.json'
            assert load(command_name) == command and pin(admitted[command_name]) == report['command_receipt']
            for stream in ('stdout', 'stderr'):
                assert pin(admitted[command_prefix + '.' + stream + '.private']) == command[stream]
        if report['accepted'] is not True:
            assert not good and stage == executed[-1]
            observations.append(observation); all_good = False; previous = stage
            continue
        assert good and 'command' in report
        assert command['exit_code'] == 0 and command['reaped'] is True and command['descendant_group_absent'] is True
        assert command['timed_out'] is False and command['timeout_seconds'] == (3600 if compile_only else 1200)
        assert command['environment']['CARGO_BUILD_JOBS'] == '2' and command['environment']['CARGO_NET_OFFLINE'] == 'true'
        assert command['environment']['CARGO_PROFILE_DEV_DEBUG'] == command['environment']['CARGO_PROFILE_TEST_DEBUG'] == '0'
        identity = report['source_before']
        assert identity == report['source_after'] and identity['commit'] == binding['source']['commit']
        assert identity['tree'] == binding['source']['tree'] and identity['shallow'] is True
        assert identity['source_content_sha256'] == prepared['phases'][phase]['full_source_rows_sha256']
        assert identity['source_files'] == binding['source']['file_count']
        assert identity['changed_files'] == sorted(item['path'] for item in prepared['phases'][phase]['files'])
        if compile_only:
            assert report['status'] == 'built_only_no_rust_test_execution' and report['rust_tests_executed'] is False
            assert command['argv'] == ['/home/qian-qi/.rustup/toolchains/1.98.0-x86_64-unknown-linux-gnu/bin/cargo',
                'test', '--verbose', '--color', 'never', '--locked', '-p', 'heptabao-server', '--lib', '--no-run', 'consistency270_audited_wire']
            assert report['aggregate_memory_before_build']['bytes']['MemAvailable'] >= 25769803776
            artifact = report['test_artifact']
            assert re.fullmatch(r'target/debug/deps/heptabao_server-[0-9a-f]{16}', artifact['path'])
            assert 0 < artifact['bytes'] <= 1024**3 and re.fullmatch(r'[0-9a-f]{64}', artifact['sha256'])
            observation['test_artifact'] = artifact
        else:
            assert report['status'] == 'observed_expected_regression_result' and report['rust_tests_executed'] is True
            item = report['phase_result']
            assert item['phase'] == phase and item['accepted'] is True and item['command'] == command
            assert item['tests_executed'] is True and item['four_expected_tests_discovered'] is True
            assert item['source_before'] == identity == item['source_after']
            prior_report = load('results/' + previous + '/' + previous + '.public.json')
            for key in ('path', 'bytes', 'sha256'):
                assert prior_report['test_artifact'][key] == report['test_artifact_before'][key] == report['test_artifact_after'][key]
            prefix = 'results/' + stage + '/' + phase + '-private-evidence/'
            actual = load(prefix + 'result.json')
            assert pin(admitted[prefix + 'result.json']) == item['private_runner_result']
            assert actual['phase'] == phase and actual['source_base_commit'] == binding['source']['commit']
            assert actual['source_files'] == prepared['phases'][phase]['files']
            assert actual['rust_tests_executed'] is True and actual['source_binding_unchanged_after_tests'] is True
            assert actual['expected_regression_behavior_observed'] is True
            assert actual['status'] == 'observed_expected_regression_result'
            assert sorted(actual['expected_tests']) == sorted(actual['discovered_tests']) == sorted(EXPECTED)
            streams = {}
            for label in ('test-discovery', 'targeted-test'):
                row = actual['commands'][label]
                assert row['status'] == 'completed' and row['direct_child_reaped'] is True
                assert row['environment']['CARGO_BUILD_JOBS'] == '2'
                for stream in ('stdout', 'stderr'):
                    data = admitted[prefix + label + '.' + stream + '.txt']
                    assert pin(data) == row[stream]
                    streams[label + '.' + stream] = data.decode()
            discovered = re.findall(r'^([A-Za-z0-9_:]+): test$', streams['test-discovery.stdout'], re.MULTILINE)
            assert len(discovered) == 4 and set(discovered) == EXPECTED
            outcomes = re.findall(r'^test ([A-Za-z0-9_:]+) \.\.\. (ok|FAILED)$', streams['targeted-test.stdout'], re.MULTILINE)
            assert len(outcomes) == 4 and {name for name, _ in outcomes} == EXPECTED
            expected = {name: ('FAILED' if phase == 'red' and name == NORMAL else 'ok') for name in EXPECTED}
            assert dict(outcomes) == actual['observed_outcomes'] == item['observed_outcomes'] == expected
            assert actual['commands']['test-discovery']['exit_code'] == 0
            code = actual['commands']['targeted-test']['exit_code']
            if phase == 'red':
                assert code != 0 and isinstance(code, int)
                assert actual['red_missing_hint_assertion_seen'] is True and item['missing_hint_assertion_observed'] is True
                assert 'GET hint count' in streams['targeted-test.stdout'] + streams['targeted-test.stderr']
            else:
                assert code == 0
            observation['outcomes'] = expected
        observation['accepted'] = True
        observations.append(observation); previous = stage
    qualified = all_good and executed == list(STAGES) and all(item['accepted'] for item in observations)
    return {'schema': 'heptabao.r4-separate-build-four-test-validation.v1',
            'qualified_real_four_test_red_green': qualified, 'observations': observations,
            'resource_combination': binding['resource_combination'],
            'source_commit': binding['source']['commit'], 'source_tree': binding['source']['tree'],
            'prior_failed_attempts_retained_in_immutable_historical_package': binding['prior_r1_r2_r3_evidence_package'],
            'full_ci_reexecution': False, 'api_client_proxy_live_profile_executed': False,
            'independent_security_audit': False, 'new_server_binary_qualified': False,
            'existing_original_503_same_status_body_limitation_not_fixed': True,
            'raw_unit_journals_not_in_this_package': True,
            'four_stages_are_one_pipeline_without_stage_retries': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--review-sha256', required=True)
    args = parser.parse_args()
    assert re.fullmatch(r'[0-9a-f]{64}', args.review_sha256)
    review_data = (HERE / REVIEW).read_bytes()
    assert pin(review_data)['sha256'] == args.review_sha256
    review = json.loads(review_data)
    assert review['all_included_streams_reviewed'] is True
    selected = collect_candidates()
    assert sum(path.stat().st_size for path in selected.values()) <= 128 * 1024**2
    admitted = {name: path.read_bytes() for name, path in sorted(selected.items())}
    assert review['admitted_files'] == [{'path': name, **pin(data)} for name, data in sorted(admitted.items())]
    summary = verify_actual_evidence(admitted, review)
    admitted[REVIEW] = review_data
    verdict = '实际四测试 red/green 已取得资格' if summary['qualified_real_four_test_red_green'] else '实际四测试 red/green 尚未取得资格'
    readme = f'''# 独立编译与四测试验证：r4

当前结论：**{verdict}**。最终逐阶段状态、原始 Runtime 终态、源和产物绑定位于 `summary.public.json` 与对应 `results/`。这份包只记录 r4；此前 r1–r3 的失败与三个完整 profile 保留在 SHA 为 `1af5ac1cf89690034ba710c861f562766794fac1652cd4e4af40303d4366e31a` 的历史包，不能被本轮结果覆盖。

## 执行范围

同一真实 3ada shallow 源码与原实际格式化三文件，在全新私有工作目录内依次执行 build-red、test-red、build-green、test-green。每个 `--no-run` 纯编译独立上限 3,600 秒；每个原测试 runner 仍为 1,200 秒。每次编译前要求当时 MemAvailable 不低于 24 GiB。CPU400%、Cargo jobs2 和 24 GiB 是明确的新资源组合；可用内存快照不是资源预约，也不保证并行速度或通过。

每次推进都绑定上一实际回执 SHA，并在实际 Runtime success0/audited/output_complete/output_durable 后发起。编译成功不会被计为红色回归。红色仅接受正常429的 `GET hint count` 断言失败与另外三项通过；绿色要求准确四项全部通过。测试程序完整 SHA/字节数在每个测试阶段前后保持一致。服务器源码、四测试断言、opt-level1、debug/overflow检查与原其他编译设置保留。

## 证据与限制

`public-stream-review.json` 给出经内容审查的精确准入路径、字节数和 SHA；构建器只把核验后的同一字节快照入包。`manifest.public.json` 为除其自身外的全部成员提供校验值。所有原 stdout/stderr、实际 Tool 内容及失败均按已审范围保留；记录的 Tool 包装对象不冒称原网络封包。

本轮没有重跑完整 CI，没有执行新的 API/client/proxy live profile，也没有由这四项单元测试取得新 server binary 资格。原始503与审计503同码正文边界仍未修复。原始 unit journal、其完整 Tool wrapper、设备/服务器 fixture、密钥、Cargo cache实体与target实体不在此包。验证属于内部工程工作，不能替代独立安全审查或扩大真实凭据采用资格。
'''
    blobs = {'summary.public.json': json_bytes(summary), 'README.md': readme.encode()}
    manifest = [{'path': name, **pin(data)} for name, data in sorted({**admitted, **blobs}.items())]
    assert sum(row['bytes'] for row in manifest) <= 128 * 1024**2
    blobs['manifest.public.json'] = json_bytes({'schema': 1, 'manifest_self_excluded': True, 'files': manifest})
    out = HERE / 'validation-package'; out.mkdir(mode=0o700, exist_ok=False)
    for name, data in blobs.items():
        (out / name).write_bytes(data)
    archive = HERE / 'r4-separate-build-four-test-validation.public.tar.gz'
    with archive.open('xb') as stream:
        with gzip.GzipFile(fileobj=stream, mode='wb', filename='', mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w') as tar:
                for name, data in sorted({**admitted, **blobs}.items()):
                    member = tarfile.TarInfo(name); member.size = len(data); member.mode = 0o600; member.mtime = 0
                    member.uid = member.gid = 0; member.uname = member.gname = ''
                    tar.addfile(member, io.BytesIO(data))
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers(); by_name = {member.name: member for member in members}
        assert len(members) == len(by_name) == len(manifest) + 1 and all(member.isfile() for member in members)
        for item in manifest:
            assert pin(tar.extractfile(by_name[item['path']]).read()) == {key: item[key] for key in ('bytes', 'sha256')}
    receipt = {'schema': 1, 'archive': pin(archive.read_bytes()), 'regular_members': len(manifest) + 1,
               'indexed_members': len(manifest), 'admission': pin(review_data),
               'qualified_real_four_test_red_green': summary['qualified_real_four_test_red_green'],
               'existing_validation_aggregate_subpackage_only': True}
    (HERE / 'validation-package.public.json').write_bytes(json_bytes(receipt))
    print(json.dumps(receipt, sort_keys=True))


if __name__ == '__main__':
    main()
