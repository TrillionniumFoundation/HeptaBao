from pathlib import Path, PurePosixPath
import base64,hashlib,io,json,os,stat,tarfile
os.umask(0o077)
ROOT=Path('/home/qian-qi/heptabao-ci-diagnostics-inputs-20261106-r4')
def durable(path,data):
 fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb') as stream:
  stream.write(data);stream.flush();os.fsync(stream.fileno())
 fd=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
 try:os.fsync(fd)
 finally:os.close(fd)
blob=base64.b64decode(PAYLOAD,validate=True)
assert len(blob)==33005 and hashlib.sha256(blob).hexdigest()=='cdf1ea01b476c70bddca4abca217d586f059df448764f133766e1a75a3bbe071'
assert ROOT.parent.resolve()==ROOT.parent
ROOT.mkdir(mode=0o700,exist_ok=False)
durable(ROOT/'controllers-review.public.tar.gz',blob)
packet=ROOT/'packet';packet.mkdir(mode=0o700,exist_ok=False)
seen=set();total=0
with tarfile.open(fileobj=io.BytesIO(blob),mode='r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(EXPECTED)<=64
 for member in members:
  q=PurePosixPath(member.name)
  assert member.isfile() and str(q)==member.name and not q.is_absolute() and '..' not in q.parts and '.git' not in q.parts
  assert member.name in EXPECTED and member.name not in seen
  wanted=EXPECTED[member.name];assert member.size==wanted['bytes'] and 0<=member.size<=4*1024**2
  data=tar.extractfile(member).read(member.size+1)
  assert len(data)==member.size and hashlib.sha256(data).hexdigest()==wanted['sha256']
  total+=len(data);assert total<=16*1024**2
  path=packet.joinpath(*q.parts);path.parent.mkdir(mode=0o700,parents=True,exist_ok=True);durable(path,data)
  seen.add(member.name)
assert seen==set(EXPECTED)
receipt={'schema':1,'status':'exact_review_packet_staged','archive_bytes':len(blob),'archive_sha256':hashlib.sha256(blob).hexdigest(),'files':EXPECTED,'source_archive_reuploaded':False,'controllers_executed':False}
durable(ROOT/'ingress.public.json',(json.dumps(receipt,sort_keys=True,indent=2)+'\n').encode())
print(json.dumps({'status':receipt['status'],'files':len(EXPECTED),'controllers_executed':False,'receipt_sha256':hashlib.sha256((ROOT/'ingress.public.json').read_bytes()).hexdigest()},sort_keys=True))
