#!/usr/bin/env python3
from pathlib import Path
import hashlib, importlib.util, json, os, signal, subprocess, sys, threading, time
ROOT=Path(__file__).resolve().parent
OUT=Path('/home/qian-qi/heptabao-ci-r2-process-controls-20261106-r1'); OUT.mkdir(mode=0o700,exist_ok=False)
def load(name):
 spec=importlib.util.spec_from_file_location(name,ROOT/(name+'.py'))
 obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
C=load('controller_common')
for name in ('controller_common.py','consistency_controller.py','run_targeted.py'):
 assert not (ROOT/name).is_symlink()
def pin(path):return {'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
env=C.base_env(OUT)
driver=OUT/'stream-driver.py'
driver.write_text('''from pathlib import Path
import importlib.util,json,sys
root=Path(sys.argv[1]); evidence=Path(sys.argv[2]); evidence.mkdir(mode=0o700)
def load(name):
 spec=importlib.util.spec_from_file_location(name,root/(name+'.py'))
 obj=importlib.util.module_from_spec(spec);spec.loader.exec_module(obj);return obj
C=load('controller_common');R=load('run_targeted');C.install_cancellation()
report={}
def save():C.snapshot(evidence/'result.json',report)
try:
 value=R.run_streamed(C,'test-discovery',[sys.executable,'-I','-B','-c',sys.argv[3]],repo=root,env=C.base_env(evidence),evidence=evidence,report=report,save=save)
except BaseException as error:
 print(json.dumps({'failure_class':type(error).__name__}));raise SystemExit(1)
raise SystemExit(value.returncode)
''')
rows=[]
normal=OUT/'normal';normal.mkdir(mode=0o700)
command=C.run_owned('normal',[sys.executable,'-I','-B',str(driver),str(ROOT),str(normal/'evidence'),"import sys; print('normal-output',flush=True); print('compiler-note',file=sys.stderr,flush=True)"],cwd=ROOT,env=env,log_dir=normal,timeout=10)
inner=json.loads((normal/'evidence/result.json').read_text())['commands']['test-discovery']
assert command['exit_code']==0 and command['descendant_group_absent'] and not command['cleanup_needed']
assert inner['direct_child_reaped'] and inner['status']=='completed' and (normal/'evidence/test-discovery.stdout.txt').read_bytes()==b'normal-output\n'
assert inner['child_identity']['pgid']==command['child_identity']['pid']
rows.append({'case':'normal_direct_stream_and_child_identity','passed':True,'command':pin(normal/'normal.command.public.json')})
cancel=OUT/'cancel';cancel.mkdir(mode=0o700)
observation={'saw_partial_stream_before_child_completed':False,'saw_running_identity_before_cancel':False}
def observe():
 until=time.monotonic()+1.7
 while time.monotonic()<until:
  path=cancel/'evidence/test-discovery.stdout.txt'; result=cancel/'evidence/result.json'
  if path.exists() and path.read_bytes()==b'compile-start\n':
   observation['saw_partial_stream_before_child_completed']=True
  if result.exists():
   d=json.loads(result.read_text());r=d.get('commands',{}).get('test-discovery',{})
   if r.get('status')=='running' and r.get('child_identity',{}).get('start_ticks'):observation['saw_running_identity_before_cancel']=True
  if all(observation.values()):return
  time.sleep(.02)
watch=threading.Thread(target=observe);watch.start()
try:
 C.run_owned('cancel',[sys.executable,'-I','-B',str(driver),str(ROOT),str(cancel/'evidence'),"import sys,time; print('compile-start',flush=True); print('partial-compiler-stderr',file=sys.stderr,flush=True); time.sleep(30)"],cwd=ROOT,env=env,log_dir=cancel,timeout=2)
 raise AssertionError('timeout_was_accepted')
except C.Blocked as error:assert str(error)=='command_deadline_or_cleanup_failed'
watch.join(timeout=3);assert not watch.is_alive() and all(observation.values())
outer=json.loads((cancel/'cancel.command.public.json').read_text());inner=json.loads((cancel/'evidence/result.json').read_text())['commands']['test-discovery']
assert outer['timed_out'] and outer['reaped'] and outer['descendant_group_absent']
assert inner['status']=='interrupted' and inner['direct_child_reaped'] and inner['interrupted_by']=='ControllerCancelled'
assert (cancel/'evidence/test-discovery.stdout.txt').read_bytes()==b'compile-start\n'
assert (cancel/'evidence/test-discovery.stderr.txt').read_bytes()==b'partial-compiler-stderr\n'
C.publish(cancel/'observation.public.json',observation)
rows.append({'case':'partial_compile_output_and_identity_survive_exact_owned_group_timeout','passed':True,'command':pin(cancel/'cancel.command.public.json'),'observation':pin(cancel/'observation.public.json')})
dead=OUT/'exited-leader';dead.mkdir(mode=0o700)
marker=dead/'descendant-ready'
child_code="import signal,time;from pathlib import Path;signal.signal(signal.SIGTERM,signal.SIG_IGN);Path("+repr(str(marker))+").write_text('ready');time.sleep(30)"
leader="import subprocess,sys,time;from pathlib import Path;p=subprocess.Popen([sys.executable,'-I','-B','-c',"+repr(child_code)+"]);deadline=time.monotonic()+3\nwhile not Path("+repr(str(marker))+").exists():\n assert time.monotonic()<deadline\n time.sleep(.01)\nraise SystemExit(7)"
try:
 C.run_owned('exited-leader',[sys.executable,'-I','-B','-c',leader],cwd=ROOT,env=env,log_dir=dead,timeout=10,allow_nonzero=True)
 raise AssertionError('unexpected_descendant_cleanup_was_accepted')
except C.Blocked as error:assert str(error)=='command_deadline_or_cleanup_failed'
row=json.loads((dead/'exited-leader.command.public.json').read_text())
assert row['exit_code']==7 and row['reaped'] and row['descendant_group_absent'] and row['cleanup_needed']
assert signal.SIGKILL in row['cleanup_signals'] and row['adopted_descendants_reaped']
rows.append({'case':'exited_original_leader_same_group_term_ignoring_descendant_reaped','passed':True,'command':pin(dead/'exited-leader.command.public.json')})
# A real original child with deliberately wrong identity must produce no group signal.
identity_case=OUT/'identity-mismatch';identity_case.mkdir(mode=0o700)
child=subprocess.Popen([sys.executable,'-I','-B','-c','import time;time.sleep(30)'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
observed=C.original_child_identity(child,pgid=child.pid,sid=child.pid)
wrong=dict(observed,start_ticks=observed['start_ticks']+1)
signals=[];original_killpg=C.os.killpg
try:
 C.os.killpg=lambda pgid,sig: signals.append({'pgid':pgid,'signal':int(sig)})
 try:
  C.close_owned_group(child,{'child_identity':wrong})
  raise AssertionError('mismatched_identity_was_accepted')
 except C.Blocked as error:assert str(error)=='original_group_anchor_identity_changed'
finally:
 C.os.killpg=original_killpg
 child.kill();child.wait(timeout=5)
assert signals==[] and child.returncode==-signal.SIGKILL
C.publish(identity_case/'observation.public.json',{'passed':True,'real_original_child':observed,'mismatched_start_ticks_rejected':True,'group_signal_calls':signals,'original_direct_child_reaped_by_harness':True})
rows.append({'case':'mismatched_original_group_anchor_sends_no_group_signal','passed':True,'observation':pin(identity_case/'observation.public.json')})
result={'schema':'heptabao.ci-r2-host-seam-controls.v1','scope':'real local tiny children; no Cargo or product tests','passed':True,'controls':rows,'source_files':{n:pin(ROOT/n) for n in ('controller_common.py','run_targeted.py','consistency_controller.py')},'rust_tests_executed':False}
C.publish(OUT/'result.public.json',result)
print(json.dumps({'passed':True,'controls':len(rows),'rust_tests_executed':False,'receipt':pin(OUT/'result.public.json')},sort_keys=True))
