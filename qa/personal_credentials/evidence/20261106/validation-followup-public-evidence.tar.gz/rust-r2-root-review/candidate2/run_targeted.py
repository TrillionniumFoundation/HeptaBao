#!/usr/bin/env python3
"""Run one source-bound Rust regression phase in a separately prepared checkout.

This script never applies a patch, retries a test, runs full CI, publishes logs,
or accepts a compiler error as the expected red regression.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
NORMAL = "service::consistency::tests::consistency270_audited_wire_retains_retry_hint_and_no_application_effect"
EXPECTED = {
    NORMAL,
    "service::consistency::tests::consistency270_audited_wire_request_audit_failure_keeps_503_without_hint",
    "service::consistency::tests::consistency270_audited_wire_response_audit_failure_keeps_503_without_hint",
    "http::consistency_tests::consistency270_audited_wire_generic_429_does_not_acquire_a_retry_hint",
}


def runtime_common():
    binding = json.loads((HERE / 'runtime-bindings.json').read_bytes())
    path = HERE / 'controller_common.py'
    if path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != binding['controller_common']['sha256']:
        raise RuntimeError('runner_common_pin_mismatch')
    spec = importlib.util.spec_from_file_location('runner_common', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run_streamed(C, label, command, *, repo, env, evidence, report, save):
    """Cargo inherits the owned runner group; all output exists during compilation."""
    stdout = evidence / (label + '.stdout.txt')
    stderr = evidence / (label + '.stderr.txt')
    row = {'argv': command, 'environment': {key: env[key] for key in C.RECORDED_ENV if key in env},
           'started': False, 'status': 'starting', 'direct_child_reaped': False,
           'group_owned_by_outer_controller': True, 'periodic_fsync_seconds': 1}
    report.setdefault('commands', {})[label] = row
    report['active_command'] = label
    report[label + '_command'] = command
    child = None
    pending = None
    started = time.monotonic()
    try:
        with stdout.open('xb') as out, stderr.open('xb') as err:
            try:
                save()
                child = subprocess.Popen(command, cwd=repo, env=env, stdin=subprocess.DEVNULL,
                                         stdout=out, stderr=err, start_new_session=False)
                row['started'] = True
                row['child_identity'] = C.original_child_identity(child, pgid=os.getpgrp(), sid=os.getsid(0))
                row['status'] = 'running'
                save()
                while True:
                    try:
                        row['exit_code'] = child.wait(timeout=1)
                        break
                    except subprocess.TimeoutExpired:
                        out.flush(); err.flush()
                        os.fsync(out.fileno()); os.fsync(err.fileno())
                row['status'] = 'completed'
            except BaseException as error:
                pending = error
                row['status'] = 'interrupted'
                row['interrupted_by'] = type(error).__name__
                report['status'] = 'interrupted'
                # Save before bounded direct-child cleanup so an outer KILL does
                # not discard the already produced compiler output or identity.
                out.flush(); err.flush()
                os.fsync(out.fileno()); os.fsync(err.fileno())
                save()
            finally:
                if child is not None:
                    try:
                        if child.poll() is None:
                            child.terminate()
                            try:
                                child.wait(timeout=1)
                            except subprocess.TimeoutExpired:
                                child.kill()
                                child.wait(timeout=1)
                        row['exit_code'] = child.returncode
                        row['direct_child_reaped'] = child.poll() is not None
                    except BaseException as error:
                        row['direct_child_cleanup_failure_class'] = type(error).__name__
                        if pending is None:
                            pending = error
                out.flush(); err.flush()
                os.fsync(out.fileno()); os.fsync(err.fileno())
    finally:
        row['duration_seconds'] = round(time.monotonic() - started, 3)
        for key, path in (('stdout', stdout), ('stderr', stderr)):
            if path.exists():
                row[key] = C.pin(path)
        report[label + '_exit_code'] = row.get('exit_code')
        report['active_command'] = None
        save()
    if pending is not None:
        raise pending
    C.require(row['direct_child_reaped'], 'cargo_direct_child_not_reaped')
    return subprocess.CompletedProcess(command, child.returncode,
                                       stdout.read_text(), stderr.read_text())


def main() -> int:
    C = runtime_common()
    C.install_cancellation()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("red", "green"), required=True)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--target-dir", type=Path, required=True)
    args = parser.parse_args()
    repo = args.repo.resolve(strict=True)
    evidence = args.evidence.absolute()
    evidence.mkdir(mode=0o700, parents=False, exist_ok=False)
    binding = json.loads((HERE / "source-bindings.json").read_bytes())
    expected_files = binding["states"]["tests-only" if args.phase == "red" else "candidate"]
    report = {
        "schema": "heptabao.consistency-audit-regression.v1",
        "phase": args.phase,
        "status": "blocked",
        "rust_tests_executed": False,
        "expected_regression_behavior_observed": False,
        "expected_tests": sorted(EXPECTED),
        "source_base_commit": binding["base_commit"],
        "source_files": expected_files,
        "full_ci_run": False,
        "retries": 0,
    }

    def save() -> None:
        C.snapshot(evidence / "result.json", report)

    def stop(reason: str) -> int:
        report["blocked_reason"] = reason
        save()
        print(json.dumps({"status": report["status"], "phase": args.phase, "reason": reason}))
        return 1

    def source_matches() -> bool:
        observed = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo, capture_output=True, text=True)
        if observed.returncode or observed.stdout.strip() != binding["base_commit"]:
            return False
        changed = subprocess.run(["git", "diff", "--name-only", "HEAD"], cwd=repo, capture_output=True, text=True)
        if changed.returncode or set(changed.stdout.splitlines()) != {f["path"] for f in expected_files}:
            return False
        return all(
            (repo / item["path"]).is_file()
            and not (repo / item["path"]).is_symlink()
            and hashlib.sha256((repo / item["path"]).read_bytes()).hexdigest() == item["sha256"]
            for item in expected_files
        )

    save()
    if not source_matches():
        return stop("source_binding_mismatch")
    if shutil.which("cargo") is None or shutil.which("rustc") is None:
        return stop("cargo_or_rustc_unavailable")
    for name in ("rustc", "cargo"):
        version = subprocess.run([name, "--version"], cwd=repo, capture_output=True, text=True)
        if version.returncode:
            return stop("toolchain_version_unavailable")
        report[name + "_version"] = version.stdout.strip()
    env = os.environ.copy()
    env["CARGO_BUILD_JOBS"] = "1"
    env["CARGO_TARGET_DIR"] = str(args.target_dir.absolute())
    cargo = ["cargo", "test", "--verbose", "--color", "never", "--locked", "-p", "heptabao-server", "--lib", "consistency270_audited_wire"]

    def run(label: str, command: list[str]) -> subprocess.CompletedProcess:
        return run_streamed(C, label, command, repo=repo, env=env,
                            evidence=evidence, report=report, save=save)

    listing = run("test-discovery", cargo + ["--", "--list"])
    if listing.returncode:
        return stop("targeted_test_build_or_discovery_failed")
    names = set(re.findall(r"^([A-Za-z0-9_:]+): test$", listing.stdout, re.MULTILINE))
    report["discovered_tests"] = sorted(names)
    if names != EXPECTED:
        return stop("targeted_test_set_mismatch")
    result = run("targeted-test", cargo + ["--", "--nocapture", "--test-threads=1"])
    report["rust_tests_executed"] = True
    observed = dict(re.findall(r"^test ([A-Za-z0-9_:]+) \.\.\. (ok|FAILED)$", result.stdout, re.MULTILINE))
    report["observed_outcomes"] = observed
    unchanged = source_matches()
    report["source_binding_unchanged_after_tests"] = unchanged
    if not unchanged:
        return stop("source_binding_changed_during_tests")
    if set(observed) != EXPECTED:
        return stop("targeted_test_outcomes_incomplete")
    if args.phase == "red":
        report["red_missing_hint_assertion_seen"] = "GET hint count" in result.stdout + result.stderr
        accepted = (
            result.returncode != 0
            and observed[NORMAL] == "FAILED"
            and all(value == "ok" for name, value in observed.items() if name != NORMAL)
            and report["red_missing_hint_assertion_seen"]
        )
    else:
        accepted = result.returncode == 0 and set(observed.values()) == {"ok"}
    report["expected_regression_behavior_observed"] = accepted
    report["status"] = "observed_expected_regression_result" if accepted else "unexpected_regression_result"
    save()
    print(json.dumps({"phase": args.phase, "status": report["status"], "test_count": len(observed), "cargo_exit": result.returncode}, sort_keys=True))
    return 0 if accepted else 1


if __name__ == "__main__":
    try:
        code = main()
    except BaseException as error:
        print(json.dumps({'status': 'runner_interrupted_or_failed', 'failure_class': type(error).__name__}))
        code = 1
    sys.exit(code)
