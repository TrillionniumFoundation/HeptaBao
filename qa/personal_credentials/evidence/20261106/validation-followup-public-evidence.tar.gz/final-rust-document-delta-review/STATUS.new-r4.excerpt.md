The fourth attempt explicitly separated no-run compilation from the original
four-test discovery/execution phases. It used a new private source, Cargo home
and target with CPU quota 400%, two Cargo build jobs and a 24 GiB memory cap.
Each compile had its own 3,600-second budget; each test retained the original
1,200-second budget. The original combined 2,700-second controller budget is
not claimed for this new four-stage pipeline. The formatted product source,
four assertions, optimization level, debug assertions and overflow checks were
unchanged. An available-memory observation before each build is a precondition,
not a reservation. Every transition required an independently read successful,
audited Runtime terminal with complete durable output and the preceding actual
accepted receipt SHA. The earlier failed targets were not reused.

The actual red compile, Runtime job `1a1b34d4259-fc05-81dd`, completed in
715.070 seconds with no timeout or rescue cleanup. Its full source inventory
was unchanged. The 216,222,392-byte lib-test artifact has SHA-256
`c634f31a6ff2f6c403694471b457f3582bacad4aa7abbd429c0812cf1c92c258`.
The 5,434-byte compile-stage receipt is
`532ef3ef50432ded243207c23c3531126624d34c89f071b6e95f61b100c91742`.
This compile was not counted as a product-test result.

The subsequent actual red test, job `1a1b35a961d-fc05-825b`, discovered exactly
four unique tests and executed all four. The normal audited consistency-429
case failed at `GET hint count`, with zero headers observed and one expected;
the request-audit failure, response-audit failure and generic-429 controls all
passed. The targeted Cargo command exited 101, while the expectation-checking
runner correctly exited zero in 0.862 seconds. Full source and test-artifact
bindings were identical before and after the run; the owned group was closed
without rescue cleanup. The 9,483-byte test-stage receipt is
`1fdec05b0ab601249df80067ec3d5870bba25f1cdece22ab8eecc61334da6cb6`.
Root independently read the terminal, complete stage/inner/command records and
all four original stdout/stderr streams. The red normal case stopped at its
first GET assertion; it does not establish execution of its later HEAD or POST
subcases. This result reproduces the defect and precedes the separate green
compilation and actual four-test result below.

The fixed-source compilation then completed in 573.963 seconds, within its
separate 3,600-second budget. Runtime job `1a1b35eb63c-fc05-8276` succeeded,
with recorded audit, complete durable output and no timeout or rescue cleanup.
Its 4,920-byte stage receipt is
`820b7a2b17c5b78cda73a50ccefb055632cad08d88fc395d553e0bf18086e6fa`.
The resulting 216,222,888-byte unit-test executable is SHA-256
`14551e73d2dfa446a0cb1347f995a84ed837b80c121fcb90a4b5fdfbfd94b5cd`.
Compilation itself is not a test pass.

The final green job `1a1b3694d7d-fc05-82be` discovered the same four unique
tests and actually passed **4/4**, with targeted Cargo exit zero. Its runner
completed in 1.015 seconds within the original 1,200-second test budget.
The normal case reached GET, HEAD and POST: each kept exactly one original
`Retry-After: 1`, performed both audits and left application state and durable
generation unchanged. Request- and response-audit failures retained 503 with
no retry hint; a generic 429 acquired no hint. Source and unit-test executable
bindings were identical before and after. Runtime recorded success, audit and
complete durable output, with no timeout or rescue cleanup; the original
leader and owned group were closed. Root independently read the full terminal,
stage/inner/command records and all four original stdout/stderr streams.
The 9,454-byte test-stage receipt is
`f879b818704ca7e32fc27335f57c2ada8e359a350aabba2eb6e522422e9addc9`.
The 3,731 filtered tests were not executed and are not counted.

Only after those actual red and green observations, the exact formatted
three-file green delta was integrated. The final r4 public packet is 884,251
bytes, SHA-256
`f15392f24dbf4b860a2cb72df95dca11fe4ed183ecc9ddc1c488ce8dcd98f8b0`,
retained inside the existing validation aggregate. Its 207 regular members
include 206 indexed originals and derived records. The earlier three failed
attempts remain in their separate immutable history packet. This qualifies
these four server library regression tests on the bound source overlay and
resource combination; it is not a full CI rerun, a new API/client/proxy live
profile or a new server-executable qualification. The existing same-status
503 body-repackaging limitation remains unchanged.
