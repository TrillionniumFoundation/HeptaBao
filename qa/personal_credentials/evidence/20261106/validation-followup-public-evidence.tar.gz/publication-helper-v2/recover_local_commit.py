#!/usr/bin/env python3
"""Recover the exact API commit, then CAS the local ref and install its index.

No worktree rewrite and no network operation occur. An existing index.lock is
never removed. A failed index installation rolls back only this attempt's own
ref advance, with another expected-value CAS, while the index is still original.
If an interruption left the exact target ref with the original index, use the
explicit --resume-ref-advanced mode after resolving any still-owned stale lock.
This helper never guesses ownership of or removes a lock left by another run.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime
import argparse
import hashlib
import json
import os
import re
import stat
import subprocess
import tempfile

REPO = Path('/workspace/scratch/heptabao-recovery-20261106-r2')
OUT = Path('/workspace/scratch/heptabao-root-recovery-20261106-r2/checkpoint-20261106-p0-p5-final')
REPOSITORY = 'TrillionniumFoundation/HeptaBao'
BRANCH = 'checkpoint/personal-credentials-read-repair-20261106'
API = 'https://api.github.com/repos/' + REPOSITORY
GIT_ROUTING_VARIABLES = {
    'GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE',
    'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_NAMESPACE',
}
ENV = {k: v for k, v in os.environ.items() if k not in GIT_ROUTING_VARIABLES}
ENV.update(GIT_NO_LAZY_FETCH='1', GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0')


def require(value, code):
    if not value:
        raise RuntimeError(code)


def git(*args, data=None, env=None):
    return subprocess.run(['git', *args], cwd=REPO, env=env or ENV, input=data,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          check=True).stdout


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def read_regular(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
                and before.st_uid == os.geteuid(), 'unsafe_regular_file')
        data = stream.read()
        after = os.fstat(stream.fileno())
        fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        require(all(getattr(before, k) == getattr(after, k) for k in fields)
                and len(data) == before.st_size, 'file_changed_during_read')
    return data, before


def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_new(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    fsync_directory(path.parent)


def write_json_new(path, value):
    write_new(path, json.dumps(value, indent=2).encode() + b'\n')


def write_latest_receipt(value):
    fd, name = tempfile.mkstemp(prefix='.recovery-receipt-', dir=OUT)
    temporary = Path(name)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(json.dumps(value, indent=2).encode() + b'\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, OUT / 'local-commit-recovery.public.json')
        fsync_directory(OUT)
    finally:
        if temporary.exists():
            temporary.unlink()


def source_path(rel):
    pure = PurePosixPath(rel)
    require(not pure.is_absolute() and '..' not in pure.parts
            and str(pure) == rel and rel != '.', 'unsafe_relative_path')
    path = REPO / rel
    require(path.parent.resolve().is_relative_to(REPO.resolve()), 'source_parent_outside_repo')
    return path


def verify_sources(plan):
    entries = plan['files']
    require(entries and len({e['path'] for e in entries}) == len(entries), 'duplicate_or_empty_files')
    for entry in entries:
        actual, _ = read_regular(source_path(entry['path']))
        blob = hashlib.sha1(b'blob ' + str(len(actual)).encode() + b'\0' + actual).hexdigest()
        require(len(actual) == entry['bytes'] and sha256(actual) == entry['sha256']
                and blob == entry['git_blob_sha'], 'worktree_changed_since_freeze')


def stamp(person):
    parsed = datetime.fromisoformat(person['date'].replace('Z', '+00:00'))
    require(parsed.tzinfo is not None, 'api_date_has_no_timezone')
    return int(parsed.timestamp())


def reconstruct_commit(plan, commit):
    expected = commit['sha']
    offsets = ['-0500']
    for minute in range(-12 * 60, 14 * 60 + 1, 15):
        value = ('-' if minute < 0 else '+') + f'{abs(minute)//60:02d}{abs(minute)%60:02d}'
        if value not in offsets:
            offsets.append(value)
    candidates = []
    author, committer = commit['author'], commit['committer']
    for author_offset in offsets:
        for committer_offset in offsets:
            raw = (f"tree {plan['expected_tree']}\nparent {plan['base_commit']}\n"
                   f"author {author['name']} <{author['email']}> {stamp(author)} {author_offset}\n"
                   f"committer {committer['name']} <{committer['email']}> {stamp(committer)} {committer_offset}\n\n"
                   + commit['message']).encode()
            sha = hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            if sha == expected:
                candidates.append((raw, author_offset, committer_offset))
    require(len(candidates) == 1, 'exact_commit_reconstruction_failed_no_local_ref_update')
    return candidates[0]


def verify_api_identity(plan, commit, remote_ref):
    require(plan['schema'] == 2 and plan['repository'] == REPOSITORY
            and plan['branch'] == BRANCH, 'unexpected_frozen_plan_identity')
    expected = commit['sha']
    require(re.fullmatch(r'[0-9a-f]{40}', expected) is not None, 'invalid_commit_sha')
    require(remote_ref['ref'] == 'refs/heads/' + BRANCH
            and remote_ref['url'] == API + '/git/refs/heads/' + BRANCH
            and remote_ref['object']['type'] == 'commit'
            and remote_ref['object']['sha'] == expected
            and remote_ref['object']['url'] == API + '/git/commits/' + expected,
            'checkpoint_ref_identity_mismatch')
    require(commit['url'] == API + '/git/commits/' + expected
            and commit['tree']['sha'] == plan['expected_tree']
            and commit['tree']['url'] == API + '/git/trees/' + plan['expected_tree']
            and [x['sha'] for x in commit['parents']] == [plan['base_commit']]
            and commit['parents'][0]['url'] == API + '/git/commits/' + plan['base_commit'],
            'commit_repository_tree_or_parent_mismatch')
    return expected


def index_location(plan):
    require(Path(git('rev-parse', '--show-toplevel').decode().strip()).resolve() == REPO.resolve(),
            'unexpected_git_worktree')
    git_dir = Path(git('rev-parse', '--absolute-git-dir').decode().strip()).resolve()
    index = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    require(index == git_dir / 'index' and str(index) == plan['original_index']['path']
            and str(git_dir) == plan['original_index']['git_dir'], 'real_index_location_changed')
    return git_dir, index


def index_state(index, original, target, mode):
    try:
        data, st = read_regular(index)
    except (OSError, RuntimeError):
        return 'unknown'
    if stat.S_IMODE(st.st_mode) != mode:
        return 'unknown'
    if data == original and data == target:
        return 'original_and_target'
    if data == original:
        return 'original'
    if data == target:
        return 'target'
    return 'changed'


def own_lock_matches(lock, fd):
    try:
        actual = lock.lstat()
    except FileNotFoundError:
        return False
    opened = os.fstat(fd)
    return (stat.S_ISREG(actual.st_mode) and actual.st_nlink == 1
            and (actual.st_dev, actual.st_ino) == (opened.st_dev, opened.st_ino))


def main(resume_ref_advanced=False):
    plan_raw, _ = read_regular(OUT / 'plan.public.json')
    commit_raw_json, _ = read_regular(OUT / 'commit-readback.api-original.json')
    ref_raw_json, _ = read_regular(OUT / 'checkpoint-ref-after.api-original.json')
    plan, commit, remote_ref = map(json.loads, (plan_raw, commit_raw_json, ref_raw_json))
    expected = verify_api_identity(plan, commit, remote_ref)
    ref = 'refs/heads/' + BRANCH
    require(git('symbolic-ref', 'HEAD').decode().strip() == ref, 'unexpected_local_branch')
    git_dir, index = index_location(plan)
    old = plan['original_index']
    prepared = plan['prepared_index']
    require(old['snapshot_path'] == str(OUT / 'original.index')
            and prepared['path'] == str(OUT / 'temporary.index')
            and prepared['tree'] == plan['expected_tree'], 'unexpected_index_snapshot_path')
    original, _ = read_regular(Path(old['snapshot_path']))
    target, _ = read_regular(Path(prepared['path']))
    require(len(original) == old['bytes'] and sha256(original) == old['sha256']
            and len(target) == prepared['bytes'] and sha256(target) == prepared['sha256'],
            'index_snapshot_hash_mismatch')
    require(old['mode'] in (0o600, 0o644, 0o660, 0o664), 'unexpected_index_mode')
    verify_sources(plan)
    raw, author_offset, committer_offset = reconstruct_commit(plan, commit)
    raw_path = OUT / 'commit.raw'
    if os.path.lexists(raw_path):
        require(read_regular(raw_path)[0] == raw, 'existing_raw_commit_mismatch')
    else:
        write_new(raw_path, raw)
    require(git('hash-object', '-t', 'commit', '-w', '--stdin', data=raw).decode().strip() == expected,
            'written_commit_identity_mismatch')
    attempts = OUT / 'local-recovery-attempts'
    attempts.mkdir(mode=0o700, exist_ok=True)
    attempt = Path(tempfile.mkdtemp(prefix='attempt-', dir=attempts))
    fsync_directory(attempts)
    check_index = attempt / 'target.index'
    write_new(check_index, target)
    require(git('write-tree', env=dict(ENV, GIT_INDEX_FILE=str(check_index))).decode().strip()
            == plan['expected_tree'], 'prepared_index_tree_mismatch')
    require(read_regular(check_index)[0] == target, 'prepared_index_validation_changed_bytes')
    receipt = {
        'schema': 2, 'remote_commit': expected, 'tree': plan['expected_tree'],
        'parent': plan['base_commit'], 'branch': BRANCH, 'repository': REPOSITORY,
        'exact_raw_commit_sha256': sha256(raw), 'plan_sha256': sha256(plan_raw),
        'api_commit_readback_sha256': sha256(commit_raw_json),
        'api_checkpoint_ref_readback_sha256': sha256(ref_raw_json),
        'author_offset': author_offset, 'committer_offset': committer_offset,
        'message_trailing_newlines_added': 0,
        'original_index_sha256': sha256(original), 'target_index_sha256': sha256(target),
        'real_index_path': str(index), 'attempt_path': str(attempt),
        'resume_ref_advanced_requested': resume_ref_advanced,
        'remote_ref_mutation_performed': False, 'worktree_rewritten': False,
    }
    write_json_new(attempt / 'intent.public.json', receipt)
    lock = Path(str(index) + '.lock')
    lock_fd = None
    advanced_here = False
    installed = False
    already_complete = False
    target_index_observed_after_error = False
    error = None
    rollback = 'not_attempted'
    phase = 'before_index_lock'
    lock_cleanup = True
    try:
        lock_fd = os.open(lock, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, old['mode'])
        os.fchmod(lock_fd, old['mode'])
        lock_stat = os.fstat(lock_fd)
        write_json_new(attempt / 'owned-index-lock.public.json', {
            'path': str(lock), 'device': lock_stat.st_dev, 'inode': lock_stat.st_ino,
            'target_sha256': sha256(target), 'owner_pid': os.getpid(),
            'scope': 'This record does not authorize deleting a stale lock without process reconciliation.',
        })
        phase = 'index_locked'
        current = index_state(index, original, target, old['mode'])
        require(current in ('original', 'target', 'original_and_target'),
                'index_changed_since_freeze')
        observed_ref = git('rev-parse', ref).decode().strip()
        require(git('symbolic-ref', 'HEAD').decode().strip() == ref, 'local_branch_changed')
        if observed_ref == expected and current in ('target', 'original_and_target'):
            already_complete = True
            phase = 'already_complete'
        else:
            require(current in ('original', 'original_and_target'),
                    'index_target_without_expected_ref')
            if observed_ref == expected:
                require(resume_ref_advanced, 'ref_advanced_index_original_requires_explicit_resume')
            else:
                require(observed_ref == plan['base_commit'], 'local_ref_changed_since_freeze')
                require(not resume_ref_advanced, 'resume_requires_ref_already_advanced')
            verify_sources(plan)
            with os.fdopen(os.dup(lock_fd), 'wb') as stream:
                stream.write(target)
                stream.flush()
                os.fsync(stream.fileno())
            require(own_lock_matches(lock, lock_fd), 'owned_index_lock_replaced')
            require(index_state(index, original, target, old['mode'])
                    in ('original', 'original_and_target'),
                    'index_changed_while_locked')
            phase = 'target_index_ready'
            if observed_ref == plan['base_commit']:
                git('update-ref', ref, expected, plan['base_commit'])
                advanced_here = True
            else:
                git('update-ref', ref, expected, expected)
            phase = 'ref_at_target_index_original'
            require(git('symbolic-ref', 'HEAD').decode().strip() == ref
                    and git('rev-parse', ref).decode().strip() == expected,
                    'local_ref_or_branch_changed_after_cas')
            require(index_state(index, original, target, old['mode'])
                    in ('original', 'original_and_target')
                    and own_lock_matches(lock, lock_fd), 'index_or_lock_changed_before_install')
            os.replace(lock, index)
            installed = True
            phase = 'index_installed'
            fsync_directory(git_dir)
            phase = 'ref_and_index_installed'
    except BaseException as exc:
        error = exc
        current = index_state(index, original, target, old['mode'])
        target_index_observed_after_error = current in ('target', 'original_and_target')
        if advanced_here and not installed and current in ('original', 'original_and_target'):
            try:
                git('update-ref', ref, plan['base_commit'], expected)
                rollback = 'cas_restored_original_ref'
            except (OSError, subprocess.CalledProcessError):
                rollback = 'cas_failed_ref_preserved_for_reconciliation'
        elif advanced_here:
            rollback = 'not_attempted_index_not_original'
    finally:
        if lock_fd is not None:
            try:
                if os.path.lexists(lock):
                    if own_lock_matches(lock, lock_fd):
                        lock.unlink()
                        fsync_directory(git_dir)
                    else:
                        lock_cleanup = False
            except OSError as cleanup_error:
                lock_cleanup = False
                if error is None:
                    error = cleanup_error
            finally:
                os.close(lock_fd)
    receipt.update({
        'phase': phase, 'local_ref_advanced_this_attempt': advanced_here,
        'index_installed': installed, 'already_complete': already_complete,
        'target_index_observed_after_error': target_index_observed_after_error,
        'rollback': rollback, 'owned_index_lock_cleanup_complete': lock_cleanup,
    })
    if error is not None:
        state_after = index_state(index, original, target, old['mode'])
        try:
            ref_after = git('rev-parse', ref).decode().strip()
        except (OSError, subprocess.CalledProcessError):
            ref_after = None
        receipt.update({'status': 'failed', 'error_type': type(error).__name__,
                        'error_code': str(error) if isinstance(error, RuntimeError) else 'local_git_or_io_failure',
                        'index_state_after': state_after, 'ref_after': ref_after,
                        'index_lock_present_after': os.path.lexists(lock),
                        'recovery_required': not lock_cleanup or os.path.lexists(lock)
                                             or ref_after != plan['base_commit']
                                             or state_after not in ('original', 'original_and_target'),
                        'clean': False})
        write_json_new(attempt / 'result.public.json', receipt)
        write_latest_receipt(receipt)
        print(json.dumps(receipt))
        raise error
    try:
        require(lock_cleanup, 'owned_index_lock_cleanup_incomplete')
        require(git('symbolic-ref', 'HEAD').decode().strip() == ref
                and git('rev-parse', ref).decode().strip() == expected,
                'local_ref_changed_after_index_install')
        require(index_state(index, original, target, old['mode'])
                in ('target', 'original_and_target'),
                'index_changed_after_install')
        verify_sources(plan)
        clean = not git('status', '--porcelain')
        require(clean, 'worktree_not_clean_after_recovery')
    except BaseException as exc:
        receipt.update({'status': 'failed', 'error_type': type(exc).__name__,
                        'error_code': str(exc) if isinstance(exc, RuntimeError) else 'post_install_verification_failure',
                        'recovery_required': True, 'clean': False})
        write_json_new(attempt / 'result.public.json', receipt)
        write_latest_receipt(receipt)
        print(json.dumps(receipt))
        raise
    receipt.update({'status': 'completed', 'clean': True, 'recovery_required': False,
                    'unchanged_worktree_files_verified': len(plan['files']),
                    'index_and_ref_updated_without_worktree_rewrite': True})
    write_json_new(attempt / 'result.public.json', receipt)
    write_latest_receipt(receipt)
    print(json.dumps(receipt))
    return receipt


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--resume-ref-advanced', action='store_true')
    args = parser.parse_args()
    main(resume_ref_advanced=args.resume_ref_advanced)
