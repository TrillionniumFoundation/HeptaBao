#!/usr/bin/env python3
"""Targeted helper controls in fresh synthetic Git repositories only."""
from pathlib import Path
import ast
import contextlib
import datetime
import hashlib
import io
import json
import os
import stat
import subprocess
import types
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'helper-validation-v2' / 'run2'
OUT.mkdir(parents=True, mode=0o700)
ENV = {k: v for k, v in os.environ.items() if not k.startswith('GIT_')}
ENV.update(GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_CONFIG_SYSTEM='/dev/null',
           GIT_NO_LAZY_FETCH='1', GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0')
SOURCES = {n: (ROOT/n).read_bytes() for n in ('freeze_checkpoint.py','recover_local_commit.py')}
for raw in SOURCES.values(): ast.parse(raw)
SOURCE_PINS = {n: {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} for n,raw in SOURCES.items()}
PUBLIC_PATHS = [x['path'] for x in json.loads((ROOT.parent/'next-checkpoint-preuploaded/index.public.json').read_bytes())['entries']]
COMMANDS=[]
RESULTS=[]


def sha(raw): return hashlib.sha256(raw).hexdigest()
def blob(raw): return hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def dump(path,value): path.write_text(json.dumps(value,indent=2)+'\n')


def git(repo,*args,data=None):
    assert repo.resolve().is_relative_to(OUT.resolve())
    COMMANDS.append({'cwd':str(repo),'argv':['git',*args]})
    return subprocess.run(['git',*args],cwd=repo,env=ENV,input=data,stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE,check=True).stdout


def module(name,repo,frozen):
    m=types.ModuleType('synthetic_'+name)
    exec(compile(SOURCES[name],str(ROOT/name),'exec'),m.__dict__)
    m.REPO=repo;m.OUT=frozen;m.ENV=dict(ENV)
    original=m.git
    def guarded(*args,**kwargs):
        assert m.REPO.resolve().is_relative_to(OUT.resolve())
        COMMANDS.append({'cwd':str(m.REPO),'argv':['git',*args],
                         'isolated_index':kwargs.get('env',{}).get('GIT_INDEX_FILE')})
        return original(*args,**kwargs)
    m.git=guarded
    return m


def invoke(m,case,name,**kwargs):
    out=io.StringIO();err=io.StringIO();result=None;failure=None
    with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
        try: result=m.main(**kwargs)
        except BaseException as exc: failure=exc
    (case/(name+'.stdout.txt')).write_text(out.getvalue())
    (case/(name+'.stderr.txt')).write_text(err.getvalue())
    dump(case/(name+'.invocation.public.json'),{'result_returned':failure is None,
         'exception_type':None if failure is None else type(failure).__name__,
         'exception_code':str(failure) if isinstance(failure,RuntimeError) else None,
         'stdout_sha256':sha(out.getvalue().encode()),'stderr_sha256':sha(err.getvalue().encode())})
    return result,failure


def fixture(name,missing_rust=False):
    case=OUT/name;case.mkdir(mode=0o700)
    repo=case/'repo';repo.mkdir(mode=0o700)
    frozen=case/'frozen'
    f=module('freeze_checkpoint.py',repo,frozen)
    git(repo,'init','-q','-b',f.BRANCH)
    paths=PUBLIC_PATHS+sorted(f.RUST_PATHS)
    for rel in paths:
        p=repo/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('old synthetic '+rel+'\n')
    manifest=repo/'qa/personal_credentials/evidence/20261106/manifest.json'
    manifest.write_text(json.dumps({'entries':[{} for _ in range(256)]})+'\n')
    (repo/'unrelated.txt').write_text('unchanged synthetic baseline\n')
    git(repo,'add','--all')
    git(repo,'-c','user.name=Synthetic helper fixture','-c','user.email=fixture@example.invalid',
        'commit','-qm','synthetic baseline')
    parent=git(repo,'rev-parse','HEAD').decode().strip();f.PARENT=parent;f.PR_HEAD=parent
    pins={}
    for rel in paths:
        data=('new synthetic '+rel+'\n').encode()
        pins[rel]={'path':rel,'bytes':len(data),'sha256':sha(data),'git_blob_sha':blob(data)}
        if not (missing_rust and rel==sorted(f.RUST_PATHS)[0]): (repo/rel).write_bytes(data)
    for sub,selected,attr in [('next-checkpoint-preuploaded',PUBLIC_PATHS,'PREUPLOADED_INDEX_SHA256'),
                              ('rust-candidate-preuploaded',sorted(f.RUST_PATHS),'CANDIDATE_INDEX_SHA256')]:
        p=case/sub;p.mkdir();raw=(json.dumps({'schema':1,'entries':[pins[x] for x in selected]},indent=2)+'\n').encode()
        (p/'index.public.json').write_bytes(raw);setattr(f,attr,sha(raw))
    before_index=(repo/'.git/index').read_bytes()
    _,failure=invoke(f,case,'freeze')
    if missing_rust:
        assert isinstance(failure,RuntimeError) and str(failure)=='required_preuploaded_change_missing'
        assert not frozen.exists() and git(repo,'rev-parse','HEAD').decode().strip()==parent
        assert (repo/'.git/index').read_bytes()==before_index
        return case,repo,frozen,f,None,None
    assert failure is None, repr(failure)
    assert (repo/'.git/index').read_bytes()==before_index
    assert git(repo,'rev-parse','HEAD').decode().strip()==parent
    plan=json.loads((frozen/'plan.public.json').read_bytes())
    assert len(plan['files'])==55 and len(plan['required_preuploaded_paths'])==55
    r=module('recover_local_commit.py',repo,frozen)
    date='2026-11-07T00:00:00Z';epoch=int(datetime.datetime.fromisoformat(date.replace('Z','+00:00')).timestamp())
    person={'name':'Synthetic helper fixture','email':'fixture@example.invalid','date':date}
    message='synthetic API-created commit fixture\n'
    raw=(f"tree {plan['expected_tree']}\nparent {parent}\n"
         f"author {person['name']} <{person['email']}> {epoch} +0000\n"
         f"committer {person['name']} <{person['email']}> {epoch} +0000\n\n"+message).encode()
    expected=hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    commit={'sha':expected,'url':r.API+'/git/commits/'+expected,'tree':{'sha':plan['expected_tree'],'url':r.API+'/git/trees/'+plan['expected_tree']},
            'parents':[{'sha':parent,'url':r.API+'/git/commits/'+parent}],'author':person,'committer':person,'message':message,
            'synthetic_test_data_not_actual_api_readback':True}
    ref={'ref':'refs/heads/'+r.BRANCH,'url':r.API+'/git/refs/heads/'+r.BRANCH,
         'object':{'type':'commit','sha':expected,'url':r.API+'/git/commits/'+expected},
         'synthetic_test_data_not_actual_api_readback':True}
    dump(frozen/'commit-readback.api-original.json',commit);dump(frozen/'checkpoint-ref-after.api-original.json',ref)
    return case,repo,frozen,r,plan,(expected,raw)


def record(name,fn):
    try:
        detail=fn();RESULTS.append({'name':name,'passed':True,'detail':detail})
        print('PASS '+name,flush=True)
    except BaseException as exc:
        RESULTS.append({'name':name,'passed':False,'exception_type':type(exc).__name__,'exception':str(exc)})
        print('FAIL '+name+' '+type(exc).__name__+' '+str(exc),flush=True)
        raise


def success():
    case,repo,out,r,plan,(expected,raw)=fixture('01-success')
    work={e['path']:(repo/e['path']).read_bytes() for e in plan['files']}
    receipt,error=invoke(r,case,'recover')
    assert error is None,repr(error)
    assert receipt['status']=='completed' and receipt['clean']
    assert git(repo,'rev-parse','HEAD').decode().strip()==expected
    assert all((repo/p).read_bytes()==b for p,b in work.items())
    assert not (repo/'.git/index.lock').exists()
    receipt2,error=invoke(r,case,'recover-again')
    assert error is None and receipt2['already_complete']
    return {'mandatory_preuploaded_blobs':55,'worktree_unchanged':True,'idempotent_completed_state':True}


def missing():
    fixture('02-missing-rust',missing_rust=True)
    return {'missing_required_rust_rejected_before_freeze':True}


def identities():
    case,repo,out,r,plan,(expected,raw)=fixture('03-api-identities')
    cp=out/'commit-readback.api-original.json';rp=out/'checkpoint-ref-after.api-original.json'
    original_c=cp.read_bytes();original_r=rp.read_bytes();ix=(repo/'.git/index').read_bytes()
    variants=[('ref',lambda c,j:j.update(ref='refs/heads/wrong')),
              ('repository',lambda c,j:j.update(url=j['url'].replace('/HeptaBao/','/Unrelated/'))),
              ('object-type',lambda c,j:j['object'].update(type='blob')),
              ('commit-url',lambda c,j:c.update(url=c['url'].replace('/HeptaBao/','/Unrelated/')))]
    for label,mutate in variants:
        c=json.loads(original_c);j=json.loads(original_r);mutate(c,j);dump(cp,c);dump(rp,j)
        _,error=invoke(r,case,'reject-'+label)
        assert isinstance(error,RuntimeError)
        assert git(repo,'rev-parse','HEAD').decode().strip()==plan['base_commit']
        assert (repo/'.git/index').read_bytes()==ix
    return {'invalid_api_identity_variants_rejected':4}


def staged_drift():
    case,repo,out,r,plan,(expected,raw)=fixture('04-staged-drift')
    p=repo/'unrelated.txt';old=p.read_bytes();p.write_text('new staged synthetic content\n');git(repo,'add','unrelated.txt');p.write_bytes(old)
    staged=(repo/'.git/index').read_bytes();_,error=invoke(r,case,'recover')
    assert isinstance(error,RuntimeError) and str(error)=='index_changed_since_freeze'
    assert (repo/'.git/index').read_bytes()==staged and p.read_bytes()==old
    assert git(repo,'rev-parse','HEAD').decode().strip()==plan['base_commit']
    assert not (repo/'.git/index.lock').exists()
    return {'new_staged_content_preserved':True,'ref_unchanged':True}


def install_failure():
    case,repo,out,r,plan,(expected,raw)=fixture('05-install-failure')
    ix=(repo/'.git/index').read_bytes();real_replace=os.replace
    def injected(src,dst):
        if Path(src)==repo/'.git/index.lock' and Path(dst)==repo/'.git/index':raise OSError('synthetic install failure')
        return real_replace(src,dst)
    with patch.object(r.os,'replace',injected): _,error=invoke(r,case,'recover')
    assert isinstance(error,OSError)
    receipt=json.loads((out/'local-commit-recovery.public.json').read_bytes())
    assert receipt['rollback']=='cas_restored_original_ref' and not receipt['recovery_required']
    assert git(repo,'rev-parse','HEAD').decode().strip()==plan['base_commit']
    assert (repo/'.git/index').read_bytes()==ix and not (repo/'.git/index.lock').exists()
    return {'forward_cas_then_rollback_cas_observed':True,'index_original':True}


def rollback_conflict():
    case,repo,out,r,plan,(expected,raw)=fixture('06-rollback-conflict')
    ix=(repo/'.git/index').read_bytes();git(repo,'hash-object','-t','commit','-w','--stdin',data=raw)
    competitor_raw=raw.replace(b'parent '+plan['base_commit'].encode(),b'parent '+expected.encode()).replace(b'synthetic API-created commit fixture',b'competing synthetic local ref fixture')
    competitor=git(repo,'hash-object','-t','commit','-w','--stdin',data=competitor_raw).decode().strip()
    real_replace=os.replace
    def injected(src,dst):
        if Path(src)==repo/'.git/index.lock' and Path(dst)==repo/'.git/index':
            git(repo,'update-ref','refs/heads/'+r.BRANCH,competitor,expected)
            raise OSError('synthetic install failure after competing CAS')
        return real_replace(src,dst)
    with patch.object(r.os,'replace',injected): _,error=invoke(r,case,'recover')
    assert isinstance(error,OSError)
    receipt=json.loads((out/'local-commit-recovery.public.json').read_bytes())
    assert receipt['rollback']=='cas_failed_ref_preserved_for_reconciliation' and receipt['recovery_required']
    assert git(repo,'rev-parse','HEAD').decode().strip()==competitor
    assert (repo/'.git/index').read_bytes()==ix and not (repo/'.git/index.lock').exists()
    return {'competing_ref_not_overwritten':True,'explicit_reconciliation_required':True}


def resume():
    case,repo,out,r,plan,(expected,raw)=fixture('07-resume')
    ix=(repo/'.git/index').read_bytes();git(repo,'hash-object','-t','commit','-w','--stdin',data=raw)
    git(repo,'update-ref','refs/heads/'+r.BRANCH,expected,plan['base_commit'])
    _,error=invoke(r,case,'without-resume')
    assert isinstance(error,RuntimeError) and str(error)=='ref_advanced_index_original_requires_explicit_resume'
    assert (repo/'.git/index').read_bytes()==ix
    failure=json.loads((out/'local-commit-recovery.public.json').read_bytes());assert failure['recovery_required']
    receipt,error=invoke(r,case,'with-explicit-resume',resume_ref_advanced=True)
    assert error is None and receipt['status']=='completed' and not receipt['local_ref_advanced_this_attempt']
    assert git(repo,'rev-parse','HEAD').decode().strip()==expected
    return {'implicit_resume_refused':True,'explicit_exact_state_resume_completed':True}


def post_install_failure():
    case,repo,out,r,plan,(expected,raw)=fixture('08-post-install-failure')
    actual=r.fsync_directory;injected_count=[0]
    def injected(path):
        if Path(path)==repo/'.git' and injected_count[0]==0:
            injected_count[0]+=1;raise OSError('synthetic directory fsync failure')
        return actual(path)
    with patch.object(r,'fsync_directory',injected): _,error=invoke(r,case,'recover')
    assert isinstance(error,OSError) and injected_count[0]==1
    receipt=json.loads((out/'local-commit-recovery.public.json').read_bytes())
    assert receipt['index_installed'] and receipt['recovery_required'] and receipt['rollback']=='not_attempted_index_not_original'
    assert git(repo,'rev-parse','HEAD').decode().strip()==expected
    assert (repo/'.git/index').read_bytes()==(out/'temporary.index').read_bytes()
    second,error=invoke(r,case,'reconcile-installed')
    assert error is None and second['already_complete'] and second['clean']
    return {'no_ref_rollback_after_index_installed':True,'installed_state_reconciled':True}


def foreign_lock():
    case,repo,out,r,plan,(expected,raw)=fixture('09-foreign-lock')
    lock=repo/'.git/index.lock';lock.write_bytes(b'foreign synthetic lock\n');ix=(repo/'.git/index').read_bytes()
    _,error=invoke(r,case,'recover')
    assert isinstance(error,FileExistsError) and lock.read_bytes()==b'foreign synthetic lock\n'
    assert (repo/'.git/index').read_bytes()==ix
    assert git(repo,'rev-parse','HEAD').decode().strip()==plan['base_commit']
    return {'existing_lock_untouched':True,'ref_and_index_unchanged':True}


def already_staged():
    case,repo,out,r,plan,(expected,raw)=fixture('10-original-index-already-target')
    target=(out/'temporary.index').read_bytes()
    (repo/'.git/index').write_bytes(target);(out/'original.index').write_bytes(target)
    plan['original_index']['bytes']=len(target);plan['original_index']['sha256']=sha(target);dump(out/'plan.public.json',plan)
    receipt,error=invoke(r,case,'recover')
    assert error is None and receipt['status']=='completed'
    assert git(repo,'rev-parse','HEAD').decode().strip()==expected
    assert (repo/'.git/index').read_bytes()==target
    return {'already_staged_exact_target_supported':True}


try:
    for name,fn in [('freeze_55_and_success',success),('missing_candidate_rust_rejected',missing),
                    ('exact_remote_identity_rejected',identities),('post_freeze_staging_preserved',staged_drift),
                    ('installation_failure_rolls_back_owned_ref',install_failure),('competing_ref_preserved',rollback_conflict),
                    ('explicit_partial_state_resume',resume),('post_install_failure_not_rolled_back',post_install_failure),
                    ('existing_index_lock_preserved',foreign_lock),('already_staged_target_supported',already_staged)]: record(name,fn)
finally:
    after={n:{'bytes':len((ROOT/n).read_bytes()),'sha256':sha((ROOT/n).read_bytes())} for n in SOURCES}
    receipt={'schema':1,'scope':'Synthetic Git helper controls only; no product or remote execution',
             'source_before':SOURCE_PINS,'source_after':after,'source_unchanged':after==SOURCE_PINS,
             'controlled_constant_overrides':['REPO','OUT','PARENT','PR_HEAD','fixture inventory SHA256','ENV'],
             'expected_controls':10,'passed':sum(x['passed'] for x in RESULTS),'results':RESULTS,
             'git_command_count':len(COMMANDS),'all_git_cwds_within_new_throwaway_root':all(Path(x['cwd']).resolve().is_relative_to(OUT.resolve()) for x in COMMANDS),
             'network_calls':0,'runtime_calls':0,'actual_project_helper_executions':0,'actual_project_refs_or_index_modified':False}
    dump(OUT/'commands.public.json',COMMANDS);dump(OUT/'receipt.public.json',receipt)
    print(json.dumps({'passed':receipt['passed'],'expected':10,'receipt':str(OUT/'receipt.public.json')}))
