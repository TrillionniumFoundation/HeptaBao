#!/usr/bin/env python3
"""Freeze reviewed bytes using a separate index; no ref or worktree update.

The two preupload inventories are independent and mandatory. This helper creates
local immutable Git objects and a frozen plan only. Remote checkpoint and PR CAS
operations belong to the separately reviewed caller.
"""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import stat
import subprocess

REPO = Path('/workspace/scratch/heptabao-recovery-20261106-r2')
OUT = Path('/workspace/scratch/heptabao-root-recovery-20261106-r2/checkpoint-20261106-p0-p5-final')
PARENT = '2fadf19f67e91e7941aa5a311a4672dad4611515'
PR_HEAD = '3ada83a7b1008948a1b24a2e8cf585ee89357336'
BRANCH = 'checkpoint/personal-credentials-read-repair-20261106'
REPOSITORY = 'TrillionniumFoundation/HeptaBao'
PREUPLOADED_INDEX_SHA256 = '1d469605655c88c2ec9e05d0f4845d830f9a5181302d224b33c188cb1678fdde'
CANDIDATE_INDEX_SHA256 = '10b374387334155a09e9191b5980291132d3fb32b96340fa5a062f9c9d347aed'
RUST_PATHS = {
    'crates/heptabao-server/src/http.rs',
    'crates/heptabao-server/src/http_consistency_tests.rs',
    'crates/heptabao-server/src/service_consistency.rs',
}
ALLOWED = {
    '.github/workflows/personal-credentials-synthetic.yml',
    'clients/android/README.md',
    'docs/personal-credentials/STATUS.md',
    'docs/personal-credentials/SUPPORTED_COMBINATIONS.md',
    'qa/openbao-acceptance/core_isolation.py',
    'qa/openbao-acceptance/ha_rolling_upgrade.py',
    'qa/openbao-acceptance/kubernetes_renewal_live.py',
    'qa/openbao-acceptance/official_openbao_launcher.py',
    'qa/openbao-acceptance/openapi_live.py',
    'qa/openbao-acceptance/radius_renewal_live.py',
    'qa/openbao-acceptance/raft_membership_live.py',
    'qa/openbao-acceptance/tests/test_core_isolation.py',
    'qa/openbao-acceptance/tests/test_ha_rolling_upgrade.py',
    'qa/openbao-acceptance/tests/test_ha_rolling_admission.py',
    'qa/openbao-acceptance/tests/test_official_oracle_crash.py',
    'qa/openbao-acceptance/tests/test_raft_membership_snapshot.py',
    'qa/personal_credentials/android_cancel_observation_guard_tests.py',
    'qa/personal_credentials/android_lifecycle_diagnostic_guard_tests.py',
    'qa/personal_credentials/android_prebinding_popup_guard_tests.py',
    'qa/personal_credentials/android_live.py',
    'qa/personal_credentials/evidence/20261106/android-autofill-followup-public-evidence.tar.gz',
    'qa/personal_credentials/evidence/20261106/manifest.json',
    'qa/personal_credentials/evidence/20261106/validation-followup-public-evidence.tar.gz',
    'qa/personal_credentials/evidence/20261106/passkey-r9-final-evidence.public.tar.gz',
} | RUST_PATHS
GIT_ROUTING_VARIABLES = {
    'GIT_DIR', 'GIT_WORK_TREE', 'GIT_COMMON_DIR', 'GIT_INDEX_FILE',
    'GIT_OBJECT_DIRECTORY', 'GIT_ALTERNATE_OBJECT_DIRECTORIES', 'GIT_NAMESPACE',
}
ENV = {k: v for k, v in os.environ.items() if k not in GIT_ROUTING_VARIABLES}
ENV.update(GIT_NO_LAZY_FETCH='1', GIT_NO_REPLACE_OBJECTS='1', GIT_OPTIONAL_LOCKS='0')


def require(value, code):
    if not value:
        raise RuntimeError(code)


def git(*args, env=None, data=None):
    return subprocess.run(['git', *args], cwd=REPO, env=env or ENV,
                          input=data, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=True).stdout


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def read_regular(path):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, 'rb') as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
                and before.st_uid == os.geteuid(), 'unsafe_regular_file')
        data = stream.read()
        after = os.fstat(stream.fileno())
        fields = ('st_dev', 'st_ino', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        require(all(getattr(before, k) == getattr(after, k) for k in fields)
                and len(data) == before.st_size, 'file_changed_during_read')
    return data, before


def source_path(rel):
    pure = PurePosixPath(rel)
    require(not pure.is_absolute() and '..' not in pure.parts
            and str(pure) == rel and rel != '.', 'unsafe_relative_path')
    path = REPO / rel
    require(path.parent.resolve().is_relative_to(REPO.resolve()), 'source_parent_outside_repo')
    return path


def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_new(path, data):
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    fsync_directory(path.parent)


def index_location():
    top = Path(git('rev-parse', '--show-toplevel').decode().strip()).resolve()
    require(top == REPO.resolve(), 'unexpected_git_worktree')
    git_dir = Path(git('rev-parse', '--absolute-git-dir').decode().strip()).resolve()
    index = Path(git('rev-parse', '--path-format=absolute', '--git-path', 'index').decode().strip())
    require(index.is_absolute() and index == git_dir / 'index', 'unexpected_real_index_path')
    return git_dir, index


def inventory(relative, expected_sha, count):
    path = OUT.parent / relative
    raw, _ = read_regular(path)
    require(sha256(raw) == expected_sha, 'preupload_inventory_hash_mismatch')
    entries = json.loads(raw)['entries']
    require(len(entries) == count and len({e['path'] for e in entries}) == count,
            'preupload_inventory_count_or_duplicates')
    return entries, {'path': str(path), 'bytes': len(raw), 'sha256': expected_sha,
                     'entries': count}


def main():
    require(git('symbolic-ref', 'HEAD').decode().strip() == 'refs/heads/' + BRANCH,
            'unexpected_checkpoint_branch')
    require(git('rev-parse', 'HEAD').decode().strip() == PARENT, 'unexpected_parent')
    git_dir, real_index = index_location()
    require(not os.path.lexists(str(real_index) + '.lock'), 'existing_index_lock')
    original_index, index_stat = read_regular(real_index)
    git('diff', '--no-ext-diff', '--no-textconv', '--check', 'HEAD')
    status_paths = git('diff', '--no-ext-diff', '--no-textconv', '--name-only', '-z', 'HEAD').split(b'\0')
    status_paths += git('ls-files', '--others', '--exclude-standard', '-z').split(b'\0')
    paths = sorted({x.decode() for x in status_paths if x})
    require(all(p in ALLOWED or p.startswith('qa/personal_credentials/passkey_r9/')
                for p in paths), 'unexpected_changed_path')
    require(len([p for p in paths if p.startswith('qa/personal_credentials/passkey_r9/')]) == 33,
            'unexpected_passkey_path_count')
    manifest_bytes, _ = read_regular(REPO / 'qa/personal_credentials/evidence/20261106/manifest.json')
    require(len(json.loads(manifest_bytes)['entries']) == 256, 'unexpected_evidence_count')
    old, old_binding = inventory('next-checkpoint-preuploaded/index.public.json',
                                 PREUPLOADED_INDEX_SHA256, 52)
    rust, rust_binding = inventory('rust-candidate-preuploaded/index.public.json',
                                   CANDIDATE_INDEX_SHA256, 3)
    require({e['path'] for e in rust} == RUST_PATHS, 'unexpected_candidate_rust_paths')
    require(not ({e['path'] for e in old} & RUST_PATHS), 'overlapping_preupload_inventories')
    pins = {e['path']: e for e in old + rust}
    require(set(pins).issubset(paths), 'required_preuploaded_change_missing')
    for rel, entry in pins.items():
        data, _ = read_regular(source_path(rel))
        require(len(data) == entry['bytes'] and sha256(data) == entry['sha256']
                and blob_sha(data) == entry['git_blob_sha'], 'preuploaded_source_mismatch')
    require(not os.path.lexists(OUT), 'frozen_destination_already_exists')
    OUT.mkdir(mode=0o700)
    fsync_directory(OUT.parent)
    snapshot = OUT / 'original.index'
    write_new(snapshot, original_index)
    index = OUT / 'temporary.index'
    index_env = dict(ENV, GIT_INDEX_FILE=str(index))
    git('read-tree', PARENT, env=index_env)
    tracked = {}
    snapshot_env = dict(ENV, GIT_INDEX_FILE=str(snapshot))
    for raw in git('ls-files', '--stage', '-z', env=snapshot_env).split(b'\0'):
        if raw:
            meta, path = raw.split(b'\t', 1)
            mode, _, stage = meta.decode().split()
            require(stage == '0', 'unmerged_original_index')
            tracked[path.decode()] = mode
    entries = []
    for rel in paths:
        data, _ = read_regular(source_path(rel))
        mode = tracked.get(rel, '100644')
        require(mode in ('100644', '100755'), 'unsupported_git_mode')
        expected = blob_sha(data)
        if rel in pins:
            pin = pins[rel]
            require(len(data) == pin['bytes'] and sha256(data) == pin['sha256']
                    and expected == pin['git_blob_sha'], 'preuploaded_source_changed')
        require(git('hash-object', '-w', '--stdin', data=data).decode().strip() == expected,
                'git_blob_identity_mismatch')
        target = OUT / 'files' / rel
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        write_new(target, data)
        require(read_regular(source_path(rel))[0] == data, 'source_changed_while_freezing')
        git('update-index', '--add', '--cacheinfo', mode, expected, rel, env=index_env)
        entries.append({'path': rel, 'mode': mode, 'bytes': len(data),
                        'sha256': sha256(data), 'git_blob_sha': expected})
    tree = git('write-tree', env=index_env).decode().strip()
    base_tree = git('rev-parse', PARENT + '^{tree}').decode().strip()
    changed = {x.decode() for x in git('diff', '--no-ext-diff', '--no-textconv',
                                       '--name-only', '-z', PARENT, tree).split(b'\0') if x}
    require(changed == set(paths), 'frozen_tree_change_set_mismatch')
    for entry in entries:
        data, _ = read_regular(source_path(entry['path']))
        require(len(data) == entry['bytes'] and sha256(data) == entry['sha256'],
                'source_changed_after_freezing')
    current_index, current_stat = read_regular(real_index)
    require(current_index == original_index
            and stat.S_IMODE(current_stat.st_mode) == stat.S_IMODE(index_stat.st_mode)
            and not os.path.lexists(str(real_index) + '.lock'), 'real_index_changed_during_freeze')
    require(git('rev-parse', 'HEAD').decode().strip() == PARENT
            and git('symbolic-ref', 'HEAD').decode().strip() == 'refs/heads/' + BRANCH,
            'checkpoint_changed_during_freeze')
    prepared_index, _ = read_regular(index)
    plan = {
        'schema': 2, 'repository': REPOSITORY, 'branch': BRANCH,
        'pr_branch': 'feat/personal-agent-credentials-20261106',
        'base_commit': PARENT, 'base_tree': base_tree, 'expected_tree': tree,
        'expected_pr_head': PR_HEAD, 'evidence_entries': 256, 'files': entries,
        'preuploaded_inventories': [old_binding, rust_binding],
        'required_preuploaded_paths': sorted(pins),
        'original_index': {'path': str(real_index), 'git_dir': str(git_dir),
                           'bytes': len(original_index), 'sha256': sha256(original_index),
                           'mode': stat.S_IMODE(index_stat.st_mode), 'snapshot_path': str(snapshot)},
        'prepared_index': {'path': str(index), 'bytes': len(prepared_index),
                           'sha256': sha256(prepared_index), 'tree': tree},
        'worktree_or_branch_rewritten': False, 'real_index_rewritten': False,
        'remote_ref_mutation_performed': False,
    }
    write_new(OUT / 'plan.public.json', json.dumps(plan, indent=2).encode() + b'\n')
    print(json.dumps({'files': len(entries), 'bytes': sum(e['bytes'] for e in entries),
                      'expected_tree': tree, 'required_preuploaded_blobs': len(pins),
                      'plan': str(OUT / 'plan.public.json')}))


if __name__ == '__main__':
    main()
