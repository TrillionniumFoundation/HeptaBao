#!/usr/bin/env python3
"""One unchanged membership main, exact new binary, genuine shallow QA source."""
from pathlib import Path
import argparse,contextlib,ctypes,hashlib,importlib.util,io,json,os,re,runpy,signal,subprocess,sys,time

ROOT=Path('/home/qian-qi/heptabao-membership-exact-3ada-live-20261106-r1')
INPUT=Path('/home/qian-qi/heptabao-membership-inputs-3ada-20261106-r1')
PACKET=Path('/home/qian-qi/heptabao-ci-diagnostics-inputs-20261106-r1/packet')
BUILD=Path('/home/qian-qi/heptabao-rolling-exact-8f3-3ada-20261106-r2')
ARCHIVE=Path('/home/qian-qi/heptabao-rolling-inputs-8f3-3ada-20261106-r1/candidate-source.tar.gz')
COMMIT='3ada83a7b1008948a1b24a2e8cf585ee89357336'
TREE='6196647cf9d8e3811347b95e5f984b5c1234ca70'
COMMON_SHA='d229be0b114276122895049bf30a304085b2ea008993e09e6ff43c306a5a4fa1'
MANIFEST_SHA='5c8ee8545946a80ba07576f3f2ed00abfe5278934a280f021ab2b008e24a06ae'
RAW_COMMIT_SHA='1e9d9bac5706447d29265f23735944cac27d0fa9fd47793efbc6d46bda2d7bb7'
BUILD_CONTROLLER_SHA='5183845dd1ab4b1130aeb4229d7f86fe302f9b9028b5210ca0677d1cdc347788'
OVERLAYS=(
 {'path':'qa/openbao-acceptance/raft_membership_live.py','bytes':13952,'sha256':'584eb55c6512779c9b43fca05d673927b5e1ecb14e6362bc33ce8967a757866b','git_mode':'100644'},
 {'path':'qa/openbao-acceptance/tests/test_raft_membership_snapshot.py','bytes':2800,'sha256':'d8cd2eec25c669f0d51f4514f4bbdb8976d02da2f3efe02c7917ad9f62bec48f','git_mode':'100644'},
)
# These four cleanup functions are byte-for-byte copies from the reviewed r2
# build controller. They apply only to actual child objects and groups we own.
def enable_child_subreaper():
 # Linux prctl.h: process-local adoption, not a host/global service setting.
 libc=ctypes.CDLL(None,use_errno=True)
 value=ctypes.c_int()
 if libc.prctl(36,1,0,0,0)!=0 or libc.prctl(37,ctypes.byref(value),0,0,0)!=0 or value.value!=1:
  raise RuntimeError('child_subreaper_unavailable')
 return True

def group_alive(pgid):
 try:os.killpg(pgid,0);return True
 except ProcessLookupError:return False

def reap_adopted_group(pgid,row):
 # Called only after Popen has reaped its original direct child.
 while True:
  try:pid,status=os.waitpid(-pgid,os.WNOHANG)
  except ChildProcessError:return
  if pid==0:return
  row.setdefault('adopted_descendants_reaped',[]).append({'pid':pid,'wait_status':status})

def close_owned_group(child,row):
 row.setdefault('cleanup_needed',False)
 if child.poll() is not None:reap_adopted_group(child.pid,row)
 if child.poll() is None or group_alive(child.pid):
  row['cleanup_needed']=True
  for sig in (signal.SIGTERM,signal.SIGKILL):
   if child.poll() is not None and not group_alive(child.pid):break
   try:os.killpg(child.pid,sig);row.setdefault('cleanup_signals',[]).append(int(sig))
   except ProcessLookupError:pass
   until=time.monotonic()+5
   while time.monotonic()<until:
    if child.poll() is not None:reap_adopted_group(child.pid,row)
    if child.poll() is not None and not group_alive(child.pid):break
    time.sleep(.02)
  if child.poll() is None:child.wait(timeout=.1)
  reap_adopted_group(child.pid,row)
 row['exit_code']=child.returncode
 row['reaped']=child.poll() is not None
 row['descendant_group_absent']=not group_alive(child.pid)
 if not row['reaped'] or not row['descendant_group_absent']:
  raise RuntimeError('owned_process_group_cleanup_incomplete')

class ProfileDeadline(BaseException):pass

def deadline(signum,frame):raise ProfileDeadline('original_360_second_profile_budget')

def load_common():
 p=PACKET/'controller_common.py'
 assert p.resolve()==p and not p.is_symlink() and hashlib.sha256(p.read_bytes()).hexdigest()==COMMON_SHA
 spec=importlib.util.spec_from_file_location('membership_frozen_common',p)
 module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 return module

def admit_build(C,expected_sha):
 p=BUILD/'result.public.json';C.pin(p,{'bytes':C.regular(p,maximum=1024**2).st_size,'sha256':expected_sha})
 b=p.read_bytes();r=json.loads(b)
 C.require(r['schema']==2 and r['controller_sha256']==BUILD_CONTROLLER_SHA
           and r['status']=='builds_passed_distinct_pair_ready'
           and r['distinct_binaries'] is True and r['profile_executions']==0
           and r['base_recompiled'] is False and r['all_owned_children_reaped'] is True
           and r['all_owned_groups_absent'] is True,'build_receipt_not_ready')
 C.require(r['completed_source_extractions']==['base','candidate']
           and set(r['new_source_rechecks_after'])=={'base','candidate'}
           and all(v['unchanged'] is True for v in r['new_source_rechecks_after'].values())
           and r['prior_metadata_and_sources_unchanged_after'] is True
           and r['qualified_binaries_unchanged_after'] is True,'build_final_checks_missing')
 C.require(r['prior_failed_result_sha256']=='81bf1718a0e7b62d0318950fe5daaa6f6cbd13637aa383e3c84bc33c10aaaab6'
           and r['sources']['base']['commit']=='8f3dd8353aaf9642ad58f7716b0c14813d09983d'
           and r['sources']['candidate']['commit']==COMMIT
           and r['sources']['candidate']['tree']==TREE
           and r['sources']['candidate']['lock']=='ef3b19cf8b1b360f7888f11e3e5b1523e464762d6c24ce7e92b64d0d7d5c99a9','build_source_pin_mismatch')
 C.require(r['binaries']['base']['build_execution_origin']=='prior_r1_base_build_exit_0'
           and r['binaries']['base']['sha256']=='afbcaf45674b833fd3cd648563a089e25a08a844041edb9e19341c872f43220c'
           and r['binaries']['candidate']['build_execution_origin']=='new_r2_candidate_build_exit_0','build_execution_origin_mismatch')
 pins={}
 for role in ('base','candidate'):
  binary=BUILD/role/'bin-qualified/heptabao-server';row=r['binaries'][role]
  C.require(row['path']==str(binary) and row['qualified_nlink']==1 and row['qualified_mode']=='0500'
            and row['normal_default_features'] is True and row['source_content_unchanged'] is True,'binary_qualification_binding')
  C.require(oct(C.regular(binary).st_mode&0o777)=='0o500','qualified_binary_mode')
  pins[role]=C.pin(binary,row)
 C.require(pins['base']['sha256']!=pins['candidate']['sha256'],'distinct_binary_guard')
 return b,r,pins

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--expected-build-receipt-sha256',required=True);a=ap.parse_args()
 assert re.fullmatch('[0-9a-f]{64}',a.expected_build_receipt_sha256)
 C=load_common();C.install_cancellation();os.umask(0o077);sys.dont_write_bytecode=True
 build_bytes,build,pins=admit_build(C,a.expected_build_receipt_sha256)
 C.pin(PACKET/'3ada.manifest.json',{'bytes':1231967,'sha256':MANIFEST_SHA})
 C.pin(PACKET/'3ada.commit.raw',{'bytes':1046,'sha256':RAW_COMMIT_SHA})
 manifest=json.loads((PACKET/'3ada.manifest.json').read_bytes())
 C.require(manifest['commit']==COMMIT and manifest['tree']==TREE,'qa_source_identity_mismatch')
 for row in OVERLAYS:C.pin(INPUT/Path(row['path']).name,row)
 ROOT.mkdir(mode=0o700,exist_ok=False)
 private_tmp=ROOT/'private-tmp';private_tmp.mkdir(mode=0o700)
 source=ROOT/'source';environment=C.base_env(private_tmp)
 os.environ.clear();os.environ.update(environment)
 import tempfile
 tempfile.tempdir=str(private_tmp)
 C.durable(ROOT/'build.receipt.original.json',build_bytes)
 C.durable(ROOT/'source.manifest.original.json',(PACKET/'3ada.manifest.json').read_bytes())
 C.durable(ROOT/'source.commit.original.raw',(PACKET/'3ada.commit.raw').read_bytes())
 report={'schema':'heptabao.membership-fixed-qa-live.v1','status':'preparing',
  'scope':'one_complete_original_same_version_loopback_membership_profile',
  'controller_sha256':C.sha(Path(__file__).resolve()),'controller_argv':sys.argv[:],
  'expected_build_receipt_sha256':a.expected_build_receipt_sha256,'build_source_commit':COMMIT,
  'candidate_binary':pins['candidate'],'base_binary_only_used_for_distinct_admission':pins['base'],
  'source_representation':'genuine original commit with one disclosed shallow boundary and two explicit QA overlays',
  'source_manifest_sha256':MANIFEST_SHA,'source_commit_object_sha256':RAW_COMMIT_SHA,'common_sha256':COMMON_SHA,
  'QA_overlays':list(OVERLAYS),'original_main_not_reimplemented':True,'profile_budget_seconds':360,
  'original_snapshot_budget_seconds':12,'original_purge_poll_seconds':5,'dead_cleanup':True,
  'profile_executions':0,'profile_retries':0,'api_effect_retries_added':0,'qualification':False,
  'external_review':False,'canonical_Owner_qualified':False,'ADB_operations':0,'children':[]}
 source_ready=False;before=None;expected_rows=C.expected_rows(manifest,OVERLAYS)
 dirty=[r['path'] for r in OVERLAYS];children=[];code=1;profile_error=False;profile_started=None
 out,err=io.StringIO(),io.StringIO();original_popen=subprocess.Popen;original_argv=sys.argv[:]
 def tracked_popen(*args,**kwargs):
  child=original_popen(*args,**kwargs);argv=args[0] if args else kwargs.get('args')
  children.append((child,{'argv':list(map(str,argv)) if isinstance(argv,(list,tuple)) else str(argv),
     'start_new_session':kwargs.get('start_new_session',False),'pid':child.pid,'cleanup_needed':False}))
  return child
 try:
  C.reconstruct(ARCHIVE,PACKET/'3ada.commit.raw',manifest,source,environment)
  for row in OVERLAYS:
   target=source/row['path'];data=(INPUT/Path(row['path']).name).read_bytes()
   if target.exists():C.replace_owned(target,data)
   else:
    target.parent.mkdir(parents=True,exist_ok=True,mode=0o700);C.durable(target,data)
  before=C.verify_source(source,manifest,expected_rows,environment,dirty);source_ready=True
  C.publish(ROOT/'qa-source.before.public.json',before)
  report['actual_main_argv']=[str(source/'qa/openbao-acceptance/raft_membership_live.py'),
     '--binary',str(BUILD/'candidate/bin-qualified/heptabao-server'),'--dead-cleanup',
     '--output',str(ROOT/'original-report.public.json')]
  C.publish(ROOT/'profile-intent.public.json',report)
  enable_child_subreaper();original_alarm=signal.signal(signal.SIGALRM,deadline)
  profile_started=time.monotonic();signal.setitimer(signal.ITIMER_REAL,360)
  try:
   qa=source/'qa/openbao-acceptance';sys.path.insert(0,str(qa))
   # Import the real owned_process class before replacing only the Popen factory.
   import owned_process
   C.require(owned_process._CURRENT is None,'standalone_owner_required')
   subprocess.Popen=tracked_popen
   with contextlib.redirect_stdout(out),contextlib.redirect_stderr(err):
    namespace=runpy.run_path(str(qa/'raft_membership_live.py'),run_name='membership_exact_candidate_profile')
    sys.argv=report['actual_main_argv'];report['profile_executions']=1;code=namespace['main']()
  except BaseException as error:
   profile_error=True;code=1;report['exception_type']=type(error).__name__
   report['timed_out']=isinstance(error,ProfileDeadline)
  finally:
   report['profile_elapsed_seconds']=time.monotonic()-profile_started
   signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,original_alarm)
   subprocess.Popen=original_popen;sys.argv=original_argv
 except BaseException as error:
  code=1;report['preparation_or_control_error_type']=type(error).__name__
 finally:
  subprocess.Popen=original_popen;sys.argv=original_argv
  forced=False
  for child,row in children:
   try:
    if row['start_new_session']:
     close_owned_group(child,row)
    else:
     if child.poll() is None:
      row['cleanup_needed']=True;child.kill();child.wait(timeout=10)
     else:child.wait(timeout=0)
     row['reaped']=child.poll() is not None;row['exit_code']=child.returncode
     row['descendant_group_absent']=None
   except BaseException as error:
    row['cleanup_error_type']=type(error).__name__;forced=True
   forced=forced or row.get('cleanup_needed',False)
   report['children'].append(row)
  stdout=out.getvalue().encode();stderr=err.getvalue().encode()
  C.durable(ROOT/'profile.stdout.original',stdout);C.durable(ROOT/'profile.stderr.original',stderr)
  report.update(main_exit_code=code,rescue_cleanup_required=forced,
     all_original_children_reaped=all(p.poll() is not None for p,_ in children),
     all_owned_session_groups_absent=all(row.get('descendant_group_absent') is True for _,row in children if row['start_new_session']),
     non_session_children_scope='original child only; no foreign process-group scan',
     stdout={'bytes':len(stdout),'sha256':hashlib.sha256(stdout).hexdigest()},
     stderr={'bytes':len(stderr),'sha256':hashlib.sha256(stderr).hexdigest()})
  checks_ok=True
  if source_ready:
   try:
    after=C.verify_source(source,manifest,expected_rows,environment,dirty)
    C.publish(ROOT/'qa-source.after.public.json',after)
    report['qa_source_unchanged_after']=after==before
    C.require(after==before,'qa_source_changed_after_execution')
   except BaseException as error:
    checks_ok=False;report['source_after_error_type']=type(error).__name__
  else:checks_ok=False
  try:
   C.pin(BUILD/'result.public.json',{'bytes':len(build_bytes),'sha256':a.expected_build_receipt_sha256})
   for role in ('base','candidate'):C.pin(BUILD/role/'bin-qualified/heptabao-server',pins[role])
   C.pin(PACKET/'controller_common.py',{'bytes':14109,'sha256':COMMON_SHA})
   C.pin(PACKET/'3ada.manifest.json',{'bytes':1231967,'sha256':MANIFEST_SHA})
   C.pin(PACKET/'3ada.commit.raw',{'bytes':1046,'sha256':RAW_COMMIT_SHA})
   for row in OVERLAYS:C.pin(INPUT/Path(row['path']).name,row)
   report['admitted_input_bytes_unchanged_after']=True
  except BaseException as error:
   checks_ok=False;report['admitted_input_after_error_type']=type(error).__name__
  try:
   original_path=ROOT/'original-report.public.json';original_pin=C.pin(original_path)
   C.require(original_pin['bytes']<=1024**2,'original_report_size_limit')
   actual=json.loads(original_path.read_bytes());report['original_report_pin']=original_pin
   report['original_report']=actual
   C.require(actual['schema']=='heptabao.raft-administration-live.v1'
    and actual['status']=='passed' and actual['independent_qualification'] is False
    and actual['same_version_loopback_only'] is True and actual['native_membership'] is True
    and actual['dead_cleanup'] is True and actual['require_compact_snapshots'] is False
    and actual['source_and_binary_unchanged'] is True and actual['binary_sha256']==pins['candidate']['sha256'],
    'original_membership_report_failed')
   identity=actual['source_identity']
   C.require(identity['source_commit']==COMMIT and identity['source_tree']==TREE
     and identity['source_dirty'] is True and identity['binary_sha256']==pins['candidate']['sha256'],
     'original_source_identity_mismatch')
   C.require(code==0 and not profile_error and checks_ok and not forced
     and report['profile_executions']==1 and report['profile_elapsed_seconds']<360
     and report['all_original_children_reaped'] and report['all_owned_session_groups_absent'],
     'profile_deadline_cleanup_or_postcheck_failed')
   report['status']='passed_scoped_membership_profile';code=0
  except BaseException as error:
   report['status']='failed';report['validation_error_type']=type(error).__name__;code=1
  C.publish(ROOT/'result.public.json',report)
  print(json.dumps({'status':report['status'],'scenario_count':report.get('original_report',{}).get('scenario_count'),
   'profile_executions':report['profile_executions'],'result_sha256':C.sha(ROOT/'result.public.json'),
   'all_original_children_reaped':report['all_original_children_reaped'],
   'all_owned_session_groups_absent':report['all_owned_session_groups_absent']},sort_keys=True),flush=True)
 return code

if __name__=='__main__':raise SystemExit(main())
