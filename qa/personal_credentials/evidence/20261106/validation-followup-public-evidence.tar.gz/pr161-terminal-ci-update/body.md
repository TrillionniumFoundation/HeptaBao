## Purpose

Implement the P0–P5 credential path with executable clients and real synthetic-service, browser and device observations. Every result remains bound to its source, artifact and platform.

**Draft; unmerged.** The PR head remains `3ada83a7b1008948a1b24a2e8cf585ee89357336`, tree `6196647cf9d8e3811347b95e5f984b5c1234ca70`, on PR #160 (`8f3dd8353aaf9642ad58f7716b0c14813d09983d`).

## Published follow-up checkpoint

[Checkpoint `2fadf19`](https://github.com/TrillionniumFoundation/HeptaBao/commit/2fadf19f67e91e7941aa5a311a4672dad4611515), tree `6528e4d9611e04dcbb3c0aad41bbbdf4eaf4a214`, follows `02555ce`, `0e61726` and `87d1301` on `checkpoint/personal-credentials-read-repair-20261106`. These follow-ups descend from the current PR head and are published separately while follow-up validation is completed. They are not yet the PR head and do not inherit its CI.

The broker repair addresses a real macOS failure when changing a receive timeout after closure. Per-call nonblocking receives and monotonic polling preserve the original shared frame deadline and separate HTTP deadline. The original thirteen functional tests plus six real Unix-socket regressions passed independently on Linux and Mac. Formatting and strict Clippy passed on Mac, and a separate later Linux execution also passed both checks on the same repaired source without re-running the nineteen tests.

The Android follow-ups fix service-request ownership, retain closed unlock diagnostics and observe late menus within the original QA waits. Authorization, cancellation, expiry, target and final-handoff guards remain enforced. Actual c9/QA17 r15 passed seven original cases, including system login, the cached-dataset attempt, explicit lock and actual expiry refusal, then failed at its cancellation-cause observation. The global diagnostic had been overwritten by later memory cleanup; this does not establish a passing cancellation case. Earlier r13 4/12 and r14 1/12 remain separate failures.

The new c10/QA18 candidate adds a separate non-authorizing request observation and an explicit Cancel-action marker. Matched cancellation captures immutable before/after state; later trim does not overwrite it. The original `finish`/`onPause`, authorization, expiry and fresh rejected-fill/empty-field checks remain. c10 completed its own SDK build, twelve interoperability checks and twelve APK checks. Its device profile has not run at this checkpoint; r15 remains failed 7/12.

The new Firefox native entry accepts the real manifest-path/add-on-ID tuple with exact private manifest binding and a create-only staging installer. It passed thirteen real CLI/pipe cases, separately eight original Chrome pipe cases, and a new actual headed Chrome 26/26 regression against native binary `f1913261`. This is not Firefox browser execution; no Firefox profile, registry or portal permission was changed. The Chrome fixture retains its TLS exception and `--no-sandbox` launch. New original packets are being consolidated with the device follow-ups; the previous evidence index is retained unchanged in this source checkpoint.

The checkpoint retains the original thirty-minute broker continuity trial, platform histories, r8 Passkey observations and explicit support/Runtime limits. All 15 changed source/document blobs relative to `02555ce` and the resulting tree match the frozen local bytes. The unchanged evidence index retains **255 files / 14,010,729 bytes** from `02555ce`; its integrity check does not interpret outcomes or grant qualification.

## Changes already in the PR head

- Correct bootstrap-negative child cleanup; validate bounded native gzip snapshots; request Raft compaction and require purge coverage of the captured applied index.
- Add the CredentialManager fixture's required normal allowed-provider permission while preserving the provider APK and earlier observations.
- Bind Autofill returns to the original WMS window, ActivityRecord, task and owner. Reject unknown/plaintext popup presentations and late observations; use at most one ordinary display-0 Back.
- Retain original HA, upgrade/rollback, phone, host and CI evidence. Recover only hash-matching bytes after executor replacement and identify unavailable local-only originals.

## Evidence and limits

| Phase | Completed observation | Open boundary |
| --- | --- | --- |
| P0 | Fixed Linux TLS/auth/KV/audit/recovery scope: 57/57. Frozen r3 QA completed destructive, partition and replay profiles against the original server; replay frontier 61/61/61 followed by actual rejoin, leadership and read-back. | Fixed synthetic combinations; not full OpenBao replacement. Original r1/r2 failures remain. |
| P1 | CLI/SDK/local broker, exact owner grants, numeric-loopback API use, SSHSIG and actual Git signing. The separate repaired-source checkpoint passed **19/19 on Linux and 19/19 on Mac**. | Trusted OS owner; task/run labels are not attested Runtime principals. External HTTPS APIs and SSH login unsupported. |
| P2 | Encrypted login/note/API entries, generation, RFC-vector TOTP, offline CLI, health, backup/recovery, JSON import/export and password change. Independent-process/SIGKILL recovery; the frozen Mac vault separately passed 14/14. | No hostile-owner isolation, hardware anti-rollback, arbitrary import formats or external audit. |
| P3 | Headed Chrome/native host 26/26; native backpressure 8/8; physical two-device synchronization 14 stages/18 authenticated transfers retained conflicts and both histories. Android c9/QA17 r15 passed seven original cases, including actual login, the cache attempt, explicit lock and expiry refusal. | r15 failed **7/12** at cancellation-cause observation. r13 **4/12**, r14 **1/12** and earlier failures remain separate; no complete Android profile passes. Sync remains an explicit CLI workflow. |
| P4 | Actual native CredentialManager create/get, encrypted SAF backup, same-device app-data reset/new-process restore, and RP rejection after restoring an old counter. Original r8 ledger **16 passed / 2 failed**; independent supplements **3/3**. | Original failures, G08 causal limit and M05 launch-audit gap remain. No physical second-device Passkey migration. Exchange, sharing, revocation and broad platforms unsupported. **P4 remains unqualified.** |
| P5 | Fixed old→new→old→new broker sequence: 27/27, including SIGKILL/unknown fencing. Separate thirty-minute trial: 60 cycles, 491 protocol requests, 60 distinct effects each exactly once, seven sequential broker processes and complete final result recovery. All 621 child processes were reaped. | Fixed artifacts and synthetic scope. Sampled resource maxima are not absolute peaks or continuous enforcement. No arbitrary migration, signed release, long-term stability, operational-support or external-security-review qualification. |

### Validation boundaries

- HA inventories contain 22, 66 and 53 overlapping scenarios; they are not a summed independent denominator.
- Both repaired broker platforms completed locked offline builds and all nineteen tests. Mac formatting and strict Clippy passed. A separate later Linux job passed both lint commands on the unchanged 4,076-file candidate, with the qualified binary unchanged; it executed zero functional tests and does not recount the nineteen.
- Original Mac broker 4/13 and intermediate IPC-only repair 16/19 remain preserved. Later successes do not rewrite those failures.
- Android r11's filtered provider log was available but empty. Missing byte/line/process-relationship metadata prevents a causal interpretation. The later MainActivity `request_expired` observation is not proof of original timer expiry. Both r10/r11 releases restored settings and verified absence of the three owned installed/retained packages.
- c8/r12 remained failed at 2/12; its new diagnostic exposed missing authorization after an unrelated service rejection, without proving timer expiry. The paired actual-class host regression produced c8 4/8 and c9 8/8. Those host controls do not replace phone cases. r13, r14 and r15 releases independently restored settings and removed the owned packages. r15's closed cancellation/trim logs are not strict request identity and do not repair its failed cancellation check.
- Host-only diagnostic and Passkey evidence-consistency checks are separate from actual device cases. Original denominators are preserved.
- Runtime shadow admission explicitly leaves final use `not_granted`; caller labels and fixed privileged-action names are not task attestation. The source-described isolated Runtime route has not been qualified as deployed.
- The earlier clean `c447536` Python preflight passed 1,988 tests with five platform skips. It does not qualify the complete newer tree.

### CI

Current PR head `3ada83a` passed [synthetic core 42233353626](https://github.com/TrillionniumFoundation/HeptaBao/actions/runs/42233353626) and both combinations of [workflow trust 42233353627](https://github.com/TrillionniumFoundation/HeptaBao/actions/runs/42233353627).

The [full replacement run 42233353960](https://github.com/TrillionniumFoundation/HeptaBao/actions/runs/42233353960) is terminal **failure**. Head completed at 20:21:19 UTC, prospective merge at 20:23:50 UTC, and the final verdict at 20:24:06 UTC. Each combination failed six steps: exact-base rolling upgrade, strict OpenBao 2.7.0 runtime/ACL comparison, RADIUS renewal, the online-authentication group at Kubernetes renewal, OpenAPI, and membership snapshot catch-up. The API's seventy-two successful steps include setup and cleanup; they are not a functional-test denominator.

The terminal logs retain the actual failure boundaries: rolling startup rejection after eight scenarios; a missing consistency `Retry-After` header and an ACL-template assertion; renewal cleanup exceptions before final business reports; OpenAPI's non-root visibility assertion; and membership's binary-response decoding error. Head also has a Transit POST with unknown transport outcome, while merge's separate full Transit profile passed. These logs do not establish the unprinted renewal business verdicts or the cause of the Transit disconnect. Repairs and fresh bounded executions are in progress on isolated follow-up sources. **No failed result is reclassified, no strict version contract is relaxed, and the checkpoint has no inherited passing full CI.**

Earlier `7e77aa3` full CI was cancelled. Older `2280c36` [full qualification 42186444220](https://github.com/TrillionniumFoundation/HeptaBao/actions/runs/42186444220) retained three HA failures before cancellation. Passing earlier steps does not make either full run successful.

## Review material and merge gates

- [Follow-up status, artifacts and support boundaries](https://github.com/TrillionniumFoundation/HeptaBao/blob/2fadf19f67e91e7941aa5a311a4672dad4611515/docs/personal-credentials/STATUS.md)
- [Observed combinations and unsupported operations](https://github.com/TrillionniumFoundation/HeptaBao/blob/2fadf19f67e91e7941aa5a311a4672dad4611515/docs/personal-credentials/SUPPORTED_COMBINATIONS.md)
- [Follow-up exact evidence index](https://github.com/TrillionniumFoundation/HeptaBao/blob/2fadf19f67e91e7941aa5a311a4672dad4611515/qa/personal_credentials/evidence/20261106/manifest.json)
- [Runtime identity limits](https://github.com/TrillionniumFoundation/HeptaBao/blob/2fadf19f67e91e7941aa5a311a4672dad4611515/docs/personal-credentials/RUNTIME_IDENTITY.md)
- [Current PR-head status](https://github.com/TrillionniumFoundation/HeptaBao/blob/3ada83a7b1008948a1b24a2e8cf585ee89357336/docs/personal-credentials/STATUS.md)
- [Internal dependency review](https://github.com/TrillionniumFoundation/HeptaBao/blob/2fadf19f67e91e7941aa5a311a4672dad4611515/docs/personal-credentials/DEPENDENCY_REVIEW.md)

Keep this draft unmerged while required checks or accepted-scope gates remain open. The final integrated source needs its own head and prospective-merge checks. Android Autofill still needs the complete real twelve-case run; broader P4/P5 and external review require their own evidence.

All credentials and targets are synthetic. Device password entry temporarily places a synthetic value in the innermost ADB argv; this is not an argv-free production transport.
